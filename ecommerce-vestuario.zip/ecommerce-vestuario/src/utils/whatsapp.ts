import type { CartItem } from '../types';

// Altere este número para o WhatsApp da loja (formato internacional sem +)
export const WHATSAPP_NUMBER = '5511999999999';

export function formatCurrency(value: number): string {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function buildOrderMessage(
  items: CartItem[],
  customer: { name: string; phone: string; address?: string; notes?: string },
  orderId: string
): string {
  const lines: string[] = [
    `*NOVO PEDIDO #${orderId}*`,
    ``,
    `*Cliente:* ${customer.name}`,
    `*Telefone:* ${customer.phone}`,
  ];

  if (customer.address) {
    lines.push(`*Endereço:* ${customer.address}`);
  }
  if (customer.notes) {
    lines.push(`*Observações:* ${customer.notes}`);
  }

  lines.push(``, `*Itens:*`);

  items.forEach((item, idx) => {
    lines.push(
      `${idx + 1}. ${item.product.name}`,
      `   Tamanho: ${item.size} | Cor: ${item.color}`,
      `   Qtd: ${item.quantity} × ${formatCurrency(item.product.price)} = ${formatCurrency(item.product.price * item.quantity)}`
    );
  });

  const total = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  lines.push(``, `*Total: ${formatCurrency(total)}*`, ``, `_Pedido enviado pelo site_`);

  return lines.join('\n');
}

export function openWhatsApp(message: string): void {
  const encoded = encodeURIComponent(message);
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}

export function generateOrderId(): string {
  const now = new Date();
  const date = now.toISOString().slice(2, 10).replace(/-/g, '');
  const rand = Math.floor(Math.random() * 9000) + 1000;
  return `${date}${rand}`;
}

export function buildStatusMessage(orderId: string): string {
  return `Olá! Gostaria de acompanhar o status do pedido *#${orderId}*. Poderiam me informar, por favor?`;
}
