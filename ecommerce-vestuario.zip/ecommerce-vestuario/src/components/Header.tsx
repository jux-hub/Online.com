import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, Sun, Moon, Package } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useTheme } from '../context/ThemeContext';

export function Header() {
  const [open, setOpen] = useState(false);
  const { totalItems } = useCart();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  const nav = [
    { to: '/', label: 'Início' },
    { to: '/loja', label: 'Loja' },
    { to: '/pedidos', label: 'Meus Pedidos' },
    { to: '/contato', label: 'Contato' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-brand-50/90 dark:bg-brand-950/90 backdrop-blur-md border-b border-brand-200/50 dark:border-brand-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link to="/" className="font-display text-2xl md:text-3xl font-semibold tracking-tight">
            ATELIER<span className="text-brand-500">.</span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={`text-sm font-medium transition-colors ${
                  isActive(item.to)
                    ? 'text-brand-950 dark:text-brand-50'
                    : 'text-brand-600 dark:text-brand-400 hover:text-brand-950 dark:hover:text-brand-50'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-brand-100 dark:hover:bg-brand-900 transition"
              aria-label="Alternar tema"
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>

            <Link
              to="/carrinho"
              className="relative p-2 rounded-full hover:bg-brand-100 dark:hover:bg-brand-900 transition"
            >
              <ShoppingBag size={20} />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-accent text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {totalItems > 9 ? '9+' : totalItems}
                </span>
              )}
            </Link>

            <button
              className="md:hidden p-2 rounded-full hover:bg-brand-100 dark:hover:bg-brand-900"
              onClick={() => setOpen(!open)}
              aria-label="Menu"
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {open && (
          <div className="md:hidden pb-4 border-t border-brand-200 dark:border-brand-800 pt-3">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={`block py-2.5 px-2 text-sm font-medium rounded-lg ${
                  isActive(item.to)
                    ? 'bg-brand-100 dark:bg-brand-900 text-brand-950 dark:text-brand-50'
                    : 'text-brand-600 dark:text-brand-400'
                }`}
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/pedidos"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2 py-2.5 px-2 text-sm font-medium text-brand-600 dark:text-brand-400"
            >
              <Package size={16} /> Meus Pedidos
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}
