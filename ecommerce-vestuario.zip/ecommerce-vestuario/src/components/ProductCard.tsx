import { Link } from 'react-router-dom';
import type { Product } from '../types';
import { formatCurrency } from '../utils/whatsapp';

interface Props {
  product: Product;
}

export function ProductCard({ product }: Props) {
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <Link to={`/produto/${product.id}`} className="group card">
      <div className="relative aspect-[3/4] overflow-hidden bg-brand-100 dark:bg-brand-800">
        <img
          src={product.images[0]}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {hasDiscount && (
          <span className="absolute top-3 left-3 bg-accent text-white text-xs font-semibold px-2.5 py-1 rounded-full">
            -{Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)}%
          </span>
        )}
        {product.featured && (
          <span className="absolute top-3 right-3 bg-brand-50/90 dark:bg-brand-950/90 text-xs font-medium px-2.5 py-1 rounded-full backdrop-blur">
            Destaque
          </span>
        )}
      </div>
      <div className="p-4">
        <p className="text-xs uppercase tracking-wider text-brand-500 mb-1">{product.category}</p>
        <h3 className="font-medium text-brand-950 dark:text-brand-50 line-clamp-1 group-hover:underline underline-offset-2">
          {product.name}
        </h3>
        <div className="mt-2 flex items-center gap-2">
          <span className="font-semibold">{formatCurrency(product.price)}</span>
          {hasDiscount && (
            <span className="text-sm text-brand-400 line-through">
              {formatCurrency(product.originalPrice!)}
            </span>
          )}
        </div>
        <div className="mt-3 flex gap-1.5">
          {product.colors.slice(0, 4).map((c) => (
            <span
              key={c.name}
              className="w-4 h-4 rounded-full border border-brand-200 dark:border-brand-700"
              style={{ backgroundColor: c.hex }}
              title={c.name}
            />
          ))}
        </div>
      </div>
    </Link>
  );
}
