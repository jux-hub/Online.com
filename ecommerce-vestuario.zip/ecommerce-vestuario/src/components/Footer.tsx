import { Link } from 'react-router-dom';
import { MessageCircle } from 'lucide-react';
import { WHATSAPP_NUMBER } from '../utils/whatsapp';

export function Footer() {
  return (
    <footer className="bg-brand-100 dark:bg-brand-900 border-t border-brand-200 dark:border-brand-800 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <Link to="/" className="font-display text-2xl font-semibold">
              ATELIER<span className="text-brand-500">.</span>
            </Link>
            <p className="mt-3 text-brand-600 dark:text-brand-400 text-sm max-w-sm leading-relaxed">
              Vestuário contemporâneo com foco em qualidade, caimento e atemporalidade. 
              Compre com facilidade e finalize seu pedido direto no WhatsApp.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider">Navegação</h4>
            <ul className="space-y-2 text-sm text-brand-600 dark:text-brand-400">
              <li><Link to="/loja" className="hover:text-brand-950 dark:hover:text-brand-50 transition">Loja</Link></li>
              <li><Link to="/pedidos" className="hover:text-brand-950 dark:hover:text-brand-50 transition">Meus Pedidos</Link></li>
              <li><Link to="/contato" className="hover:text-brand-950 dark:hover:text-brand-50 transition">Contato</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider">Atendimento</h4>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm text-brand-600 dark:text-brand-400 hover:text-brand-950 dark:hover:text-brand-50 transition"
            >
              <MessageCircle size={16} />
              WhatsApp
            </a>
            <p className="mt-3 text-xs text-brand-500">
              Seg–Sex 9h–18h<br />
              Sáb 9h–13h
            </p>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-brand-200 dark:border-brand-800 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-brand-500">
          <p>© {new Date().getFullYear()} Atelier. Todos os direitos reservados.</p>
          <p>Otimizado para Cloudflare Pages · Performance 2026</p>
        </div>
      </div>
    </footer>
  );
}
