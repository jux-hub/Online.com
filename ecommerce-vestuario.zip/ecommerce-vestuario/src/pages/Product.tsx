import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import { products } from '../data/products';
import { useCart } from '../context/CartContext';
import { formatCurrency } from '../utils/whatsapp';
import { ArrowLeft, Check, Minus, Plus } from 'lucide-react';

export function Product() {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const { addItem } = useCart();

  const [size, setSize] = useState(product?.sizes[0] || '');
  const [color, setColor] = useState(product?.colors[0]?.name || '');
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const [imgIdx, setImgIdx] = useState(0);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-brand-500">Produto não encontrado.</p>
        <Link to="/loja" className="btn-primary mt-6 inline-flex">
          Voltar à loja
        </Link>
      </div>
    );
  }

  const handleAdd = () => {
    addItem(product, size, color, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link
        to="/loja"
        className="inline-flex items-center gap-2 text-sm text-brand-500 hover:text-brand-950 dark:hover:text-brand-50 mb-8 transition"
      >
        <ArrowLeft size={16} /> Voltar à loja
      </Link>

      <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
        {/* Images */}
        <div>
          <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-brand-100 dark:bg-brand-800 mb-4">
            <img
              src={product.images[imgIdx]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-3">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setImgIdx(i)}
                  className={`w-20 h-24 rounded-xl overflow-hidden border-2 transition ${
                    imgIdx === i ? 'border-accent' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          <p className="text-xs uppercase tracking-wider text-brand-500 mb-2">{product.category}</p>
          <h1 className="font-display text-3xl md:text-4xl font-medium">{product.name}</h1>

          <div className="mt-4 flex items-center gap-3">
            <span className="text-2xl font-semibold">{formatCurrency(product.price)}</span>
            {hasDiscount && (
              <>
                <span className="text-lg text-brand-400 line-through">
                  {formatCurrency(product.originalPrice!)}
                </span>
                <span className="text-sm bg-accent text-white px-2 py-0.5 rounded-full">
                  -{Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)}%
                </span>
              </>
            )}
          </div>

          <p className="mt-6 text-brand-600 dark:text-brand-400 leading-relaxed">
            {product.description}
          </p>

          {/* Colors */}
          <div className="mt-8">
            <p className="text-sm font-medium mb-3">
              Cor: <span className="font-normal text-brand-500">{color}</span>
            </p>
            <div className="flex gap-2">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  onClick={() => setColor(c.name)}
                  className={`w-9 h-9 rounded-full border-2 transition ${
                    color === c.name ? 'border-accent scale-110' : 'border-brand-200 dark:border-brand-700'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
            </div>
          </div>

          {/* Sizes */}
          <div className="mt-6">
            <p className="text-sm font-medium mb-3">Tamanho</p>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`min-w-[3rem] px-3 py-2 rounded-lg border text-sm font-medium transition ${
                    size === s
                      ? 'border-accent bg-accent text-white'
                      : 'border-brand-200 dark:border-brand-700 hover:border-brand-400'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Qty + Add */}
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <div className="flex items-center border border-brand-200 dark:border-brand-700 rounded-full">
              <button
                onClick={() => setQty(Math.max(1, qty - 1))}
                className="p-3 hover:bg-brand-100 dark:hover:bg-brand-800 rounded-l-full transition"
              >
                <Minus size={16} />
              </button>
              <span className="w-10 text-center font-medium">{qty}</span>
              <button
                onClick={() => setQty(qty + 1)}
                className="p-3 hover:bg-brand-100 dark:hover:bg-brand-800 rounded-r-full transition"
              >
                <Plus size={16} />
              </button>
            </div>

            <button onClick={handleAdd} className="btn-primary flex-1 sm:flex-none min-w-[200px]">
              {added ? (
                <>
                  <Check size={18} /> Adicionado
                </>
              ) : (
                'Adicionar ao carrinho'
              )}
            </button>
          </div>

          <p className="mt-4 text-xs text-brand-500">
            {product.stock > 10 ? 'Em estoque' : `Apenas ${product.stock} unidades restantes`}
          </p>
        </div>
      </div>
    </div>
  );
}
