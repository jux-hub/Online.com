import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { products, categories } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { Search, SlidersHorizontal } from 'lucide-react';

export function Shop() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const activeCategory = searchParams.get('categoria') || 'todos';
  const activeGender = searchParams.get('genero') || 'todos';

  const filtered = useMemo(() => {
    return products.filter((p) => {
      if (activeCategory !== 'todos' && p.category !== activeCategory) return false;
      if (activeGender !== 'todos' && p.gender !== activeGender && p.gender !== 'unissex') return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tags.some((t) => t.includes(q))
        );
      }
      return true;
    });
  }, [activeCategory, activeGender, search]);

  const setCategory = (id: string) => {
    const next = new URLSearchParams(searchParams);
    if (id === 'todos') next.delete('categoria');
    else next.set('categoria', id);
    setSearchParams(next);
  };

  const setGender = (g: string) => {
    const next = new URLSearchParams(searchParams);
    if (g === 'todos') next.delete('genero');
    else next.set('genero', g);
    setSearchParams(next);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="font-display text-3xl md:text-4xl font-medium">Loja</h1>
        <p className="mt-2 text-brand-600 dark:text-brand-400">
          {filtered.length} {filtered.length === 1 ? 'produto' : 'produtos'}
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters sidebar */}
        <aside className={`lg:w-56 shrink-0 ${showFilters ? 'block' : 'hidden lg:block'}`}>
          <div className="space-y-8 sticky top-28">
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider mb-3">Categoria</h3>
              <ul className="space-y-1.5">
                {categories.map((c) => (
                  <li key={c.id}>
                    <button
                      onClick={() => setCategory(c.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition ${
                        activeCategory === c.id
                          ? 'bg-brand-200 dark:bg-brand-800 font-medium'
                          : 'hover:bg-brand-100 dark:hover:bg-brand-900 text-brand-600 dark:text-brand-400'
                      }`}
                    >
                      {c.name} <span className="text-xs opacity-60">({c.count})</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider mb-3">Gênero</h3>
              <ul className="space-y-1.5">
                {[
                  { id: 'todos', label: 'Todos' },
                  { id: 'feminino', label: 'Feminino' },
                  { id: 'masculino', label: 'Masculino' },
                  { id: 'unissex', label: 'Unissex' },
                ].map((g) => (
                  <li key={g.id}>
                    <button
                      onClick={() => setGender(g.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition ${
                        activeGender === g.id
                          ? 'bg-brand-200 dark:bg-brand-800 font-medium'
                          : 'hover:bg-brand-100 dark:hover:bg-brand-900 text-brand-600 dark:text-brand-400'
                      }`}
                    >
                      {g.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </aside>

        {/* Products */}
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row gap-3 mb-6">
            <div className="relative flex-1">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-400" />
              <input
                type="search"
                placeholder="Buscar produtos..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input pl-10"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="lg:hidden btn-secondary"
            >
              <SlidersHorizontal size={18} />
              Filtros
            </button>
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-20 text-brand-500">
              Nenhum produto encontrado com esses filtros.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
