import { useSearchParams, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { formatCurrency, openWhatsApp, buildStatusMessage } from '../utils/whatsapp';
import { MessageCircle, Package, Clock, CheckCircle2 } from 'lucide-react';

const statusLabels: Record<string, { label: string; color: string }> = {
  enviado: { label: 'Enviado para WhatsApp', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300' },
  confirmado: { label: 'Confirmado', color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300' },
  em_preparo: { label: 'Em preparo', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-300' },
  enviado_entrega: { label: 'Enviado', color: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300' },
  entregue: { label: 'Entregue', color: 'bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300' },
};

export function Orders() {
  const { orders } = useCart();
  const [searchParams] = useSearchParams();
  const novo = searchParams.get('novo');

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex items-center gap-3 mb-2">
        <Package size={28} />
        <h1 className="font-display text-3xl font-medium">Meus Pedidos</h1>
      </div>
      <p className="text-brand-500 mb-8">
        Acompanhe seus pedidos e fale conosco pelo WhatsApp a qualquer momento.
      </p>

      {novo && (
        <div className="mb-8 p-4 rounded-2xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 flex items-start gap-3">
          <CheckCircle2 className="text-green-600 shrink-0 mt-0.5" size={20} />
          <div>
            <p className="font-medium text-green-800 dark:text-green-300">
              Pedido #{novo} enviado com sucesso!
            </p>
            <p className="text-sm text-green-700 dark:text-green-400 mt-1">
              O WhatsApp foi aberto com a mensagem do seu pedido. Confirme o envio e aguarde nosso retorno.
            </p>
          </div>
        </div>
      )}

      {orders.length === 0 ? (
        <div className="text-center py-16 card">
          <Clock size={40} className="mx-auto text-brand-300 mb-4" />
          <p className="text-brand-500 mb-6">Você ainda não possui pedidos registrados neste dispositivo.</p>
          <Link to="/loja" className="btn-primary">
            Fazer minha primeira compra
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => {
            const st = statusLabels[order.status] || statusLabels.enviado;
            return (
              <div key={order.id} className="card p-5">
                <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
                  <div>
                    <p className="font-semibold">Pedido #{order.id}</p>
                    <p className="text-xs text-brand-500 mt-0.5">
                      {new Date(order.createdAt).toLocaleString('pt-BR')}
                    </p>
                  </div>
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${st.color}`}>
                    {st.label}
                  </span>
                </div>

                <ul className="text-sm space-y-1.5 mb-4">
                  {order.items.map((item, i) => (
                    <li key={i} className="flex justify-between text-brand-600 dark:text-brand-400">
                      <span>
                        {item.quantity}x {item.product.name} ({item.size}/{item.color})
                      </span>
                      <span>{formatCurrency(item.product.price * item.quantity)}</span>
                    </li>
                  ))}
                </ul>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-brand-100 dark:border-brand-800">
                  <span className="font-semibold">{formatCurrency(order.total)}</span>
                  <button
                    onClick={() => openWhatsApp(buildStatusMessage(order.id))}
                    className="btn-secondary text-sm py-2 px-4"
                  >
                    <MessageCircle size={16} />
                    Consultar status
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-12 p-6 rounded-2xl bg-brand-100 dark:bg-brand-900 border border-brand-200 dark:border-brand-800">
        <h3 className="font-semibold mb-2">Como funciona o acompanhamento?</h3>
        <ol className="text-sm text-brand-600 dark:text-brand-400 space-y-2 list-decimal list-inside">
          <li>Você envia o pedido pelo site → WhatsApp abre com a mensagem pronta.</li>
          <li>Nossa equipe confirma disponibilidade, frete e pagamento.</li>
          <li>Use o botão “Consultar status” acima a qualquer momento para falar conosco.</li>
          <li>Os pedidos ficam salvos apenas neste dispositivo (localStorage).</li>
        </ol>
      </div>
    </div>
  );
}
