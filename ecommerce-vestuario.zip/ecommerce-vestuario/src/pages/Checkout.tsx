import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import {
  formatCurrency,
  buildOrderMessage,
  openWhatsApp,
  generateOrderId,
} from '../utils/whatsapp';
import type { Order } from '../types';
import { MessageCircle, ArrowLeft } from 'lucide-react';

export function Checkout() {
  const { items, totalPrice, clearCart, addOrder } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    phone: '',
    address: '',
    notes: '',
  });
  const [sending, setSending] = useState(false);

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-brand-500 mb-6">Nenhum item no carrinho.</p>
        <Link to="/loja" className="btn-primary">
          Ir para a loja
        </Link>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) return;

    setSending(true);
    const orderId = generateOrderId();
    const message = buildOrderMessage(items, form, orderId);

    const order: Order = {
      id: orderId,
      items: [...items],
      customer: { ...form },
      total: totalPrice,
      status: 'enviado',
      createdAt: new Date().toISOString(),
      whatsappMessage: message,
    };

    addOrder(order);
    openWhatsApp(message);
    clearCart();
    setSending(false);
    navigate(`/pedidos?novo=${orderId}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link
        to="/carrinho"
        className="inline-flex items-center gap-2 text-sm text-brand-500 hover:text-brand-950 dark:hover:text-brand-50 mb-8 transition"
      >
        <ArrowLeft size={16} /> Voltar ao carrinho
      </Link>

      <h1 className="font-display text-3xl font-medium mb-2">Finalizar pedido</h1>
      <p className="text-brand-500 mb-10">
        Preencha seus dados. O pedido será enviado automaticamente para nosso WhatsApp.
      </p>

      <div className="grid lg:grid-cols-5 gap-10">
        <form onSubmit={handleSubmit} className="lg:col-span-3 space-y-5">
          <div>
            <label className="block text-sm font-medium mb-1.5">Nome completo *</label>
            <input
              required
              className="input"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Seu nome"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">WhatsApp / Telefone *</label>
            <input
              required
              type="tel"
              className="input"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="(11) 99999-9999"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Endereço de entrega</label>
            <textarea
              className="input min-h-[80px] resize-y"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              placeholder="Rua, número, bairro, cidade - UF, CEP"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Observações</label>
            <textarea
              className="input min-h-[80px] resize-y"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Preferências de entrega, observações sobre tamanhos, etc."
            />
          </div>

          <button type="submit" disabled={sending} className="btn-primary w-full sm:w-auto">
            <MessageCircle size={18} />
            {sending ? 'Abrindo WhatsApp...' : 'Enviar pedido via WhatsApp'}
          </button>
        </form>

        <div className="lg:col-span-2">
          <div className="card p-6 sticky top-28">
            <h2 className="font-semibold mb-4">Seu pedido</h2>
            <ul className="space-y-3 max-h-64 overflow-y-auto">
              {items.map((item) => (
                <li
                  key={`${item.product.id}-${item.size}-${item.color}`}
                  className="flex gap-3 text-sm"
                >
                  <img
                    src={item.product.images[0]}
                    alt=""
                    className="w-14 h-18 rounded-lg object-cover bg-brand-100"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium line-clamp-1">{item.product.name}</p>
                    <p className="text-brand-500 text-xs">
                      {item.size} · {item.color} · x{item.quantity}
                    </p>
                    <p className="font-medium mt-0.5">
                      {formatCurrency(item.product.price * item.quantity)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
            <div className="mt-4 pt-4 border-t border-brand-200 dark:border-brand-700 flex justify-between font-semibold">
              <span>Total</span>
              <span>{formatCurrency(totalPrice)}</span>
            </div>
            <p className="mt-3 text-xs text-brand-500">
              Frete e formas de pagamento serão combinados no WhatsApp.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
