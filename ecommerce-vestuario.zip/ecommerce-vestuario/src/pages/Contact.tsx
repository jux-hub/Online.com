import { MessageCircle, Mail, MapPin, Clock } from 'lucide-react';
import { WHATSAPP_NUMBER, openWhatsApp } from '../utils/whatsapp';

export function Contact() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="font-display text-3xl md:text-4xl font-medium mb-2">Contato</h1>
      <p className="text-brand-500 mb-12 max-w-xl">
        Estamos prontos para atender você. Prefira o WhatsApp para respostas mais rápidas sobre pedidos e produtos.
      </p>

      <div className="grid md:grid-cols-2 gap-10">
        <div className="space-y-6">
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="card p-6 flex items-start gap-4 hover:shadow-md transition group"
          >
            <div className="p-3 rounded-xl bg-green-100 dark:bg-green-900/30 text-green-600">
              <MessageCircle size={24} />
            </div>
            <div>
              <h3 className="font-semibold group-hover:underline">WhatsApp</h3>
              <p className="text-sm text-brand-500 mt-1">Resposta em até 1 hora no horário comercial</p>
              <p className="text-sm font-medium mt-2">+55 11 99999-9999</p>
            </div>
          </a>

          <div className="card p-6 flex items-start gap-4">
            <div className="p-3 rounded-xl bg-brand-100 dark:bg-brand-800 text-brand-600 dark:text-brand-300">
              <Mail size={24} />
            </div>
            <div>
              <h3 className="font-semibold">E-mail</h3>
              <p className="text-sm text-brand-500 mt-1">Para assuntos gerais</p>
              <p className="text-sm font-medium mt-2">contato@atelier.com.br</p>
            </div>
          </div>

          <div className="card p-6 flex items-start gap-4">
            <div className="p-3 rounded-xl bg-brand-100 dark:bg-brand-800 text-brand-600 dark:text-brand-300">
              <MapPin size={24} />
            </div>
            <div>
              <h3 className="font-semibold">Showroom</h3>
              <p className="text-sm text-brand-500 mt-1">Visitas com agendamento</p>
              <p className="text-sm font-medium mt-2">São Paulo · SP</p>
            </div>
          </div>

          <div className="card p-6 flex items-start gap-4">
            <div className="p-3 rounded-xl bg-brand-100 dark:bg-brand-800 text-brand-600 dark:text-brand-300">
              <Clock size={24} />
            </div>
            <div>
              <h3 className="font-semibold">Horário</h3>
              <p className="text-sm text-brand-500 mt-1">
                Segunda a Sexta: 9h – 18h<br />
                Sábado: 9h – 13h
              </p>
            </div>
          </div>
        </div>

        <div className="card p-8">
          <h2 className="font-display text-xl font-medium mb-4">Mensagem rápida</h2>
          <p className="text-sm text-brand-500 mb-6">
            Clique no botão abaixo para abrir uma conversa no WhatsApp com uma mensagem pronta.
          </p>
          <button
            onClick={() =>
              openWhatsApp(
                'Olá! Vim pelo site da Atelier e gostaria de mais informações sobre os produtos.'
              )
            }
            className="btn-primary w-full"
          >
            <MessageCircle size={18} />
            Conversar no WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
}
