import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { products } from '../data/products';
import { ProductCard } from '../components/ProductCard';

export function Home() {
  const featured = products.filter((p) => p.featured).slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-[85vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1600&q=80"
            alt="Fashion"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-950/80 via-brand-950/50 to-transparent" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-xl text-white">
            <p className="text-sm uppercase tracking-[0.2em] text-brand-200 mb-4">Nova Coleção 2026</p>
            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-medium leading-[1.1]">
              Essência em cada peça
            </h1>
            <p className="mt-6 text-lg text-brand-100 leading-relaxed">
              Peças atemporais com design contemporâneo. Qualidade premium e caimento impecável para o seu dia a dia.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link to="/loja" className="btn-primary bg-white text-brand-950 hover:bg-brand-100">
                Explorar Coleção
                <ArrowRight size={18} />
              </Link>
              <Link to="/loja?categoria=vestidos" className="btn-secondary border-white/40 text-white hover:bg-white/10">
                Vestidos
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-sm uppercase tracking-wider text-brand-500 mb-2">Seleção especial</p>
            <h2 className="font-display text-3xl md:text-4xl font-medium">Destaques</h2>
          </div>
          <Link to="/loja" className="hidden sm:inline-flex items-center gap-2 text-sm font-medium hover:underline underline-offset-4">
            Ver tudo <ArrowRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
        <div className="mt-8 text-center sm:hidden">
          <Link to="/loja" className="btn-secondary">
            Ver toda a loja
          </Link>
        </div>
      </section>

      {/* Banner */}
      <section className="bg-brand-100 dark:bg-brand-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="font-display text-3xl md:text-4xl font-medium leading-tight">
              Compre com facilidade.<br />Finalize no WhatsApp.
            </h2>
            <p className="mt-4 text-brand-600 dark:text-brand-400 leading-relaxed">
              Monte seu carrinho no site e envie o pedido completo direto para nosso atendimento. 
              Rápido, seguro e sem complicação de cadastro.
            </p>
            <Link to="/loja" className="btn-primary mt-8">
              Começar a comprar
            </Link>
          </div>
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1441984900000-8e4eecf4b0d1?w=1000&q=80"
              alt="Atendimento"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
