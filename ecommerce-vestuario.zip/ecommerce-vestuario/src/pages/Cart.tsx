import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { formatCurrency } from '../utils/whatsapp';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';

export function Cart() {
  const { items, updateQuantity, removeItem, totalPrice, totalItems } = useCart();

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <ShoppingBag size={48} className="mx-auto text-brand-300 mb-4" />
        <h1 className="font-display text-2xl font-medium mb-2">Seu carrinho está vazio</h1>
        <p className="text-brand-500 mb-8">Adicione peças incríveis à sua seleção.</p>
        <Link to="/loja" className="btn-primary">
          Ir para a loja
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="font-display text-3xl font-medium mb-8">
        Carrinho <span className="text-brand-400 text-xl">({totalItems})</span>
      </h1>

      <div className="grid lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <div
              key={`${item.product.id}-${item.size}-${item.color}`}
              className="card flex gap-4 p-4"
            >
              <Link to={`/produto/${item.product.id}`} className="w-24 h-32 shrink-0 rounded-xl overflow-hidden bg-brand-100">
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  className="w-full h-full object-cover"
                />
              </Link>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between gap-2">
                  <div>
                    <Link
                      to={`/produto/${item.product.id}`}
                      className="font-medium hover:underline line-clamp-1"
                    >
                      {item.product.name}
                    </Link>
                    <p className="text-sm text-brand-500 mt-0.5">
                      {item.size} · {item.color}
                    </p>
                  </div>
                  <button
                    onClick={() => removeItem(item.product.id, item.size, item.color)}
                    className="p-1.5 text-brand-400 hover:text-red-500 transition shrink-0"
                    aria-label="Remover"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center border border-brand-200 dark:border-brand-700 rounded-full">
                    <button
                      onClick={() =>
                        updateQuantity(item.product.id, item.size, item.color, item.quantity - 1)
                      }
                      className="p-2 hover:bg-brand-100 dark:hover:bg-brand-800 rounded-l-full"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                    <button
                      onClick={() =>
                        updateQuantity(item.product.id, item.size, item.color, item.quantity + 1)
                      }
                      className="p-2 hover:bg-brand-100 dark:hover:bg-brand-800 rounded-r-full"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <span className="font-semibold">
                    {formatCurrency(item.product.price * item.quantity)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="card p-6 h-fit sticky top-28">
          <h2 className="font-semibold text-lg mb-4">Resumo</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-brand-500">Subtotal</span>
              <span>{formatCurrency(totalPrice)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-brand-500">Frete</span>
              <span className="text-brand-500">Calculado no WhatsApp</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-brand-200 dark:border-brand-700 flex justify-between font-semibold text-lg">
            <span>Total</span>
            <span>{formatCurrency(totalPrice)}</span>
          </div>
          <Link to="/checkout" className="btn-primary w-full mt-6">
            Finalizar pedido
          </Link>
          <Link
            to="/loja"
            className="block text-center text-sm text-brand-500 mt-4 hover:underline"
          >
            Continuar comprando
          </Link>
        </div>
      </div>
    </div>
  );
}
