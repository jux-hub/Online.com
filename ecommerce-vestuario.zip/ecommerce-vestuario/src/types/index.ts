export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: 'camisetas' | 'calcas' | 'vestidos' | 'jaquetas' | 'acessorios' | 'calcados';
  gender: 'masculino' | 'feminino' | 'unissex';
  sizes: string[];
  colors: { name: string; hex: string }[];
  images: string[];
  tags: string[];
  featured?: boolean;
  stock: number;
}

export interface CartItem {
  product: Product;
  size: string;
  color: string;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  customer: {
    name: string;
    phone: string;
    address?: string;
    notes?: string;
  };
  total: number;
  status: 'enviado' | 'confirmado' | 'em_preparo' | 'enviado_entrega' | 'entregue';
  createdAt: string;
  whatsappMessage: string;
}
