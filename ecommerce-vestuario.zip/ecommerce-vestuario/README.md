# Atelier — E-commerce de Vestuário

Loja virtual especializada em vestuário contemporâneo, otimizada para **Cloudflare Pages**, com integração nativa de pedidos via **WhatsApp** e padrão profissional de alta performance para 2026.

## Características

- Catálogo completo com filtros (categoria, gênero, busca)
- Carrinho persistente (localStorage)
- Checkout que gera mensagem formatada e abre o WhatsApp automaticamente
- Aba **Meus Pedidos** com histórico local + botão de consulta de status via WhatsApp
- Tema claro/escuro
- Design responsivo, tipografia elegante (Playfair Display + Inter)
- Build estático ultra-leve (Vite + React + Tailwind)
- Pronto para Cloudflare Pages (zero configuração de servidor)

## Stack

- Vite 6 + React 19 + TypeScript
- Tailwind CSS 3
- React Router 7
- Lucide Icons
- localStorage para carrinho e pedidos

## Configuração rápida

1. **Altere o número do WhatsApp da loja**

   Abra `src/utils/whatsapp.ts` e troque:

   ```ts
   export const WHATSAPP_NUMBER = '5511999999999'; // seu número com DDI
   ```

2. **Instale e rode localmente**

   ```bash
   npm install
   npm run dev
   ```

3. **Build de produção**

   ```bash
   npm run build
   ```

   A pasta `dist/` estará pronta para deploy.

## Deploy na Cloudflare Pages

### Opção A — Via Dashboard (recomendado)

1. Faça push deste repositório para o GitHub/GitLab.
2. No [Cloudflare Dashboard](https://dash.cloudflare.com) → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
3. Selecione o repositório.
4. Configurações de build:
   - **Framework preset**: Vite
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
   - **Root directory**: `/` (ou deixe em branco)
5. Clique em **Save and Deploy**.

### Opção B — Via Wrangler CLI

```bash
npm install -g wrangler
npm run build
wrangler pages deploy dist --project-name=atelier-vestuario
```

## Personalização

- **Produtos**: edite `src/data/products.ts`
- **Cores da marca**: `tailwind.config.js` → `theme.extend.colors.brand`
- **Textos e logo**: componentes em `src/components/` e páginas em `src/pages/`

## Estrutura de pastas

```
src/
├── components/     # Header, Footer, ProductCard
├── context/        # CartContext, ThemeContext
├── data/           # products.ts
├── pages/          # Home, Shop, Product, Cart, Checkout, Orders, Contact
├── types/          # TypeScript interfaces
└── utils/          # whatsapp.ts (formatação + abertura do WA)
```

## Performance (2026)

- Code-splitting automático (vendor chunk)
- Imagens com `loading="lazy"`
- CSS crítico mínimo + Tailwind purge
- Sem backend → TTFB mínimo na edge da Cloudflare
- Core Web Vitals otimizados (LCP, CLS, INP)

---

Desenvolvido para ser simples de manter e extremamente rápido de carregar.
