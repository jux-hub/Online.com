/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#faf9f7',
          100: '#f5f3ef',
          200: '#e8e4db',
          300: '#d4cdc0',
          400: '#b8ad9a',
          500: '#9c8f78',
          600: '#7a6f5c',
          700: '#635a4b',
          800: '#524a3f',
          900: '#453f36',
          950: '#24211c',
        },
        accent: {
          DEFAULT: '#1a1a1a',
          light: '#333333',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Playfair Display', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
}
