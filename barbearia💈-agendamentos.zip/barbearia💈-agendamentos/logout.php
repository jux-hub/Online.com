<?php
session_start();
session_destroy();

// Limpa o cookie de sessão
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

require_once __DIR__ . '/config.php';
header('Location: ' . BASE_URL . '/login.php');
exit;