<?php
define('DB_PATH', __DIR__ . '/barbearia.db');

function getDB() {
    static $db = null;
    if ($db === null) {
        try {
            $db = new PDO('sqlite:' . DB_PATH);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $db->exec('PRAGMA journal_mode=WAL');
            $db->exec('PRAGMA foreign_keys=ON');
            initDB($db);
        } catch (Exception $e) {
            die('Erro ao conectar ao banco: ' . $e->getMessage());
        }
    }
    return $db;
}

function initDB($db) {

    // ── Usuários ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS usuarios (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            nome             TEXT    NOT NULL,
            email            TEXT    UNIQUE NOT NULL,
            senha            TEXT    NOT NULL,
            tipo             TEXT    NOT NULL DEFAULT 'barbeiro',
            telefone         TEXT,
            comissao_percent REAL    DEFAULT 50,
            foto             TEXT,
            ativo            INTEGER DEFAULT 1,
            criado_em        DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // ── Corrigir CHECK constraint antigo automaticamente ──
    try {
        $tblInfo = $db->query("SELECT sql FROM sqlite_master WHERE type='table' AND name='usuarios'")->fetch();
        if ($tblInfo && strpos($tblInfo['sql'], "tipo IN ('admin','barbeiro')") !== false) {
            $db->exec("PRAGMA foreign_keys=OFF");
            $db->exec("
                CREATE TABLE usuarios_new (
                    id               INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome             TEXT    NOT NULL,
                    email            TEXT    UNIQUE NOT NULL,
                    senha            TEXT    NOT NULL,
                    tipo             TEXT    NOT NULL DEFAULT 'barbeiro',
                    telefone         TEXT,
                    comissao_percent REAL    DEFAULT 50,
                    foto             TEXT,
                    ativo            INTEGER DEFAULT 1,
                    criado_em        DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ");
            $db->exec("INSERT INTO usuarios_new SELECT * FROM usuarios");
            $db->exec("DROP TABLE usuarios");
            $db->exec("ALTER TABLE usuarios_new RENAME TO usuarios");
            $db->exec("PRAGMA foreign_keys=ON");
        }
    } catch (Exception $e) {}

    // ── Serviços ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS servicos (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            nome            TEXT    NOT NULL,
            preco           REAL    NOT NULL DEFAULT 0,
            duracao_minutos INTEGER NOT NULL DEFAULT 30,
            tempo_minutos   INTEGER NOT NULL DEFAULT 30,
            ativo           INTEGER DEFAULT 1,
            criado_em       DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // ── Clientes ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS clientes (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            nome      TEXT    NOT NULL,
            telefone  TEXT    NOT NULL,
            email     TEXT,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // ── Fila ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS fila (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            nome            TEXT,
            telefone        TEXT,
            cliente_id      INTEGER,
            barbeiro_id     INTEGER NOT NULL,
            servico_id      INTEGER,
            status          TEXT    NOT NULL DEFAULT 'aguardando'
                                CHECK(status IN ('aguardando','atendendo','concluido','cancelado')),
            posicao         INTEGER,
            valor           REAL,
            forma_pagamento TEXT    CHECK(forma_pagamento IN ('pix','dinheiro','debito','credito')),
            observacoes     TEXT,
            notificado      INTEGER DEFAULT 0,
            avaliacao_nota  INTEGER DEFAULT NULL,
            avaliacao_obs   TEXT    DEFAULT NULL,
            token           TEXT,
            criado_em       DATETIME DEFAULT CURRENT_TIMESTAMP,
            iniciado_em     DATETIME,
            finalizado_em   DATETIME,
            FOREIGN KEY(cliente_id)  REFERENCES clientes(id),
            FOREIGN KEY(barbeiro_id) REFERENCES usuarios(id),
            FOREIGN KEY(servico_id)  REFERENCES servicos(id)
        )
    ");

    // ── Configurações ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS configuracoes (
            chave TEXT PRIMARY KEY,
            valor TEXT NOT NULL
        )
    ");

    // ── Promoções ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS promocoes (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo           TEXT    NOT NULL,
            mensagem         TEXT    NOT NULL,
            icone            TEXT    DEFAULT 'bi-tag-fill',
            cor              TEXT    DEFAULT '#e94560',
            whatsapp_numero  TEXT    DEFAULT '',
            whatsapp_texto   TEXT    DEFAULT '',
            whatsapp_ativo   INTEGER DEFAULT 1,
            ativo            INTEGER DEFAULT 1,
            criado_em        DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // ── Pacotes ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS pacotes (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            nome          TEXT    NOT NULL,
            descricao     TEXT,
            tipo          TEXT    NOT NULL DEFAULT 'servico'
                              CHECK(tipo IN ('servico','misto')),
            creditos      INTEGER NOT NULL DEFAULT 1,
            preco         REAL    NOT NULL DEFAULT 0,
            servico_id    INTEGER,
            validade_dias INTEGER DEFAULT 0,
            ativo         INTEGER DEFAULT 1,
            criado_em     DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(servico_id) REFERENCES servicos(id)
        )
    ");

    // ── Produtos ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS produtos (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            nome         TEXT    NOT NULL,
            descricao    TEXT,
            preco        REAL    NOT NULL DEFAULT 0,
            estoque      INTEGER DEFAULT 0,
            estoque_min  INTEGER DEFAULT 0,
            categoria    TEXT    DEFAULT 'outros',
            ativo        INTEGER DEFAULT 1,
            criado_em    DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // ── Vendas ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS vendas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id      INTEGER NOT NULL,
            tipo            TEXT    NOT NULL
                                CHECK(tipo IN ('pacote','produto')),
            pacote_id       INTEGER,
            produto_id      INTEGER,
            quantidade      INTEGER NOT NULL DEFAULT 1,
            valor_unitario  REAL    NOT NULL DEFAULT 0,
            valor_total     REAL    NOT NULL DEFAULT 0,
            forma_pagamento TEXT    NOT NULL DEFAULT 'dinheiro'
                                CHECK(forma_pagamento IN ('pix','dinheiro','debito','credito')),
            observacoes     TEXT,
            vendedor_id     INTEGER,
            criado_em       DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_id)  REFERENCES clientes(id),
            FOREIGN KEY(pacote_id)   REFERENCES pacotes(id),
            FOREIGN KEY(produto_id)  REFERENCES produtos(id),
            FOREIGN KEY(vendedor_id) REFERENCES usuarios(id)
        )
    ");

    // ── Saldo de pacotes por cliente ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS clientes_pacotes (
            id                 INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id         INTEGER NOT NULL,
            pacote_id          INTEGER NOT NULL,
            venda_id           INTEGER NOT NULL,
            creditos_total     INTEGER NOT NULL DEFAULT 0,
            creditos_usados    INTEGER NOT NULL DEFAULT 0,
            creditos_restantes INTEGER NOT NULL DEFAULT 0,
            validade_em        DATETIME,
            ativo              INTEGER DEFAULT 1,
            criado_em          DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_id) REFERENCES clientes(id),
            FOREIGN KEY(pacote_id)  REFERENCES pacotes(id),
            FOREIGN KEY(venda_id)   REFERENCES vendas(id)
        )
    ");

    // ── Uso de créditos ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS creditos_uso (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_pacote_id INTEGER NOT NULL,
            fila_id           INTEGER,
            usado_em          DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_pacote_id) REFERENCES clientes_pacotes(id),
            FOREIGN KEY(fila_id)           REFERENCES fila(id)
        )
    ");

    // ── Pedidos (loja online) ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS pedidos (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_nome   TEXT    NOT NULL,
            cliente_tel    TEXT    NOT NULL,
            cliente_end    TEXT,
            cliente_bairro TEXT,
            cliente_ref    TEXT,
            tipo_entrega   TEXT    NOT NULL DEFAULT 'retirada'
                               CHECK(tipo_entrega IN ('retirada','entrega')),
            taxa_entrega   REAL    NOT NULL DEFAULT 0,
            subtotal       REAL    NOT NULL DEFAULT 0,
            total          REAL    NOT NULL DEFAULT 0,
            status         TEXT    NOT NULL DEFAULT 'pendente'
                               CHECK(status IN ('pendente','confirmado','pronto','entregue','cancelado')),
            observacoes    TEXT,
            notificado     INTEGER DEFAULT 0,
            criado_em      DATETIME DEFAULT CURRENT_TIMESTAMP,
            atualizado_em  DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // ── Itens do pedido ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS pedidos_itens (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            pedido_id   INTEGER NOT NULL,
            tipo        TEXT    NOT NULL CHECK(tipo IN ('produto','pacote')),
            produto_id  INTEGER,
            pacote_id   INTEGER,
            nome        TEXT    NOT NULL,
            quantidade  INTEGER NOT NULL DEFAULT 1,
            valor_unit  REAL    NOT NULL DEFAULT 0,
            valor_total REAL    NOT NULL DEFAULT 0,
            FOREIGN KEY(pedido_id)  REFERENCES pedidos(id),
            FOREIGN KEY(produto_id) REFERENCES produtos(id),
            FOREIGN KEY(pacote_id)  REFERENCES pacotes(id)
        )
    ");

    // ── Códigos de acesso (minha conta) ──
    $db->exec("
        CREATE TABLE IF NOT EXISTS codigos_acesso (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id  INTEGER NOT NULL,
            codigo      TEXT    NOT NULL,
            usado       INTEGER DEFAULT 0,
            expira_em   DATETIME NOT NULL,
            criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_id) REFERENCES clientes(id)
        )
    ");

    // ── Configurações padrão ──
    $db->exec("
        INSERT OR IGNORE INTO configuracoes (chave, valor) VALUES
            ('nome_barbearia',           'Barbearia Premium'),
            ('tempo_medio_corte',        '30'),
            ('limite_fila',              '20'),
            ('notificacao_posicoes',     '2'),
            ('horario_abertura',         '08:00'),
            ('horario_fechamento',       '20:00'),
            ('dias_funcionamento',       'Segunda a Sábado'),
            ('mensagem_boas_vindas',     ''),
            ('logo_path',                ''),
            ('capa_bg_path',             ''),
            ('wa_provider',              'callmebot'),
            ('wa_callmebot_apikey',      ''),
            ('wa_zapi_instance',         ''),
            ('wa_zapi_token',            ''),
            ('wa_zapi_client_token',     ''),
            ('wa_uazapi_url',            ''),
            ('wa_uazapi_token',          ''),
            ('wa_uazapi_instance',       ''),
            ('wa_evolution_url',         ''),
            ('wa_evolution_key',         ''),
            ('wa_evolution_instance',    ''),
            ('fila_ativa',               '1'),
            ('dias_semana',              '1,2,3,4,5,6'),
            ('loja_ativa',               '1'),
            ('loja_taxa_entrega',        '5.00'),
            ('loja_entrega_ativa',       '1'),
            ('loja_retirada_ativa',      '1'),
            ('loja_min_entrega',         '0'),
            ('loja_botao_index',         '1'),
            ('minha_conta_botao_index',  '1'),
            ('site_url',                 '')
    ");

    // ── Migrations seguras ──
    $migrations = [
        // Usuários
        "ALTER TABLE usuarios ADD COLUMN foto             TEXT",
        "ALTER TABLE usuarios ADD COLUMN ativo            INTEGER DEFAULT 1",
        "ALTER TABLE usuarios ADD COLUMN comissao_percent REAL    DEFAULT 50",
        // Fila
        "ALTER TABLE fila     ADD COLUMN notificado       INTEGER DEFAULT 0",
        "ALTER TABLE fila     ADD COLUMN observacoes      TEXT",
        "ALTER TABLE fila     ADD COLUMN nome             TEXT",
        "ALTER TABLE fila     ADD COLUMN telefone         TEXT",
        "ALTER TABLE fila     ADD COLUMN cliente_id       INTEGER",
        "ALTER TABLE fila     ADD COLUMN avaliacao_nota   INTEGER DEFAULT NULL",
        "ALTER TABLE fila     ADD COLUMN avaliacao_obs    TEXT    DEFAULT NULL",
        "ALTER TABLE fila     ADD COLUMN motivo_remocao   TEXT",
        "ALTER TABLE fila     ADD COLUMN token            TEXT",
        // Serviços
        "ALTER TABLE servicos ADD COLUMN duracao_minutos  INTEGER DEFAULT 30",
        "ALTER TABLE servicos ADD COLUMN preco            REAL    DEFAULT 0",
        // Promoções
        "ALTER TABLE promocoes ADD COLUMN whatsapp_numero TEXT    DEFAULT ''",
        "ALTER TABLE promocoes ADD COLUMN whatsapp_texto  TEXT    DEFAULT ''",
        "ALTER TABLE promocoes ADD COLUMN whatsapp_ativo  INTEGER DEFAULT 1",
        "ALTER TABLE promocoes ADD COLUMN icone           TEXT    DEFAULT 'bi-tag-fill'",
        "ALTER TABLE promocoes ADD COLUMN cor             TEXT    DEFAULT '#e94560'",
        // Produtos
        "ALTER TABLE produtos ADD COLUMN estoque_min      INTEGER DEFAULT 0",
        "ALTER TABLE produtos ADD COLUMN categoria        TEXT    DEFAULT 'outros'",
        "ALTER TABLE produtos ADD COLUMN tipo             TEXT    NOT NULL DEFAULT 'produto'",
        // Pedidos
        "ALTER TABLE pedidos  ADD COLUMN cliente_bairro   TEXT",
        "ALTER TABLE pedidos  ADD COLUMN cliente_ref      TEXT",
        "ALTER TABLE pedidos  ADD COLUMN taxa_entrega     REAL    DEFAULT 0",
        "ALTER TABLE pedidos  ADD COLUMN atualizado_em    DATETIME",
        // Clientes
        "ALTER TABLE clientes ADD COLUMN email            TEXT",
    ];
    foreach ($migrations as $sql) {
        try { $db->exec($sql); } catch (Exception $e) {}
    }

    // ── Índices ──
    $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_barbeiro_status ON fila(barbeiro_id, status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_status          ON fila(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_telefone        ON fila(telefone)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_cliente         ON fila(cliente_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_criado          ON fila(criado_em)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_token           ON fila(token)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_usuarios_tipo        ON usuarios(tipo)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_usuarios_email       ON usuarios(email)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_clientes_telefone    ON clientes(telefone)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_clientes_email       ON clientes(email)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_promocoes_ativo      ON promocoes(ativo)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_vendas_cliente       ON vendas(cliente_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_vendas_criado        ON vendas(criado_em)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_vendas_tipo          ON vendas(tipo)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_cli_pac_cliente      ON clientes_pacotes(cliente_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_cli_pac_ativo        ON clientes_pacotes(ativo)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_produtos_ativo       ON produtos(ativo)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_pacotes_ativo        ON pacotes(ativo)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_pedidos_status       ON pedidos(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_pedidos_criado       ON pedidos(criado_em)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_pedidos_tel          ON pedidos(cliente_tel)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_pedidos_itens        ON pedidos_itens(pedido_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_codigos_cliente      ON codigos_acesso(cliente_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_codigos_expira       ON codigos_acesso(expira_em)");

    // ── Admin padrão ──
    $stmt = $db->prepare('SELECT id FROM usuarios WHERE tipo=? LIMIT 1');
    $stmt->execute(['admin']);
    if (!$stmt->fetch()) {
        $db->prepare("
            INSERT INTO usuarios (nome, email, senha, tipo, ativo)
            VALUES (?, ?, ?, 'admin', 1)
        ")->execute([
            'Administrador',
            'admin@barbearia.com',
            password_hash('admin123', PASSWORD_DEFAULT),
        ]);
    }

    // ── Serviços padrão ──
    $stmt = $db->prepare('SELECT id FROM servicos LIMIT 1');
    $stmt->execute();
    if (!$stmt->fetch()) {
        $db->exec("
            INSERT INTO servicos (nome, preco, duracao_minutos, tempo_minutos) VALUES
                ('Corte Simples',  25.00, 20, 20),
                ('Corte + Barba',  45.00, 40, 40),
                ('Barba',          25.00, 20, 20),
                ('Degradê',        35.00, 30, 30),
                ('Corte Infantil', 20.00, 20, 20)
        ");
    }

    // ── Pacotes padrão ──
    $stmt = $db->prepare('SELECT id FROM pacotes LIMIT 1');
    $stmt->execute();
    if (!$stmt->fetch()) {
        $db->exec("
            INSERT INTO pacotes (nome, descricao, creditos, preco, validade_dias) VALUES
                ('Pacote 4 Cortes',    '4 cortes pelo preço de 3',   4,  75.00, 90),
                ('Pacote 8 Cortes',    '8 cortes com 25% desconto',  8, 140.00, 180),
                ('Pacote 4 Barbearia', '4 cortes + barba inclusa',   4, 130.00, 90)
        ");
    }
}