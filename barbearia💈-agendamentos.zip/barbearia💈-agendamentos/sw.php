<?php
// sw.php — Service Worker gerado dinamicamente com BASE_URL correto
header('Content-Type: application/javascript');
header('Service-Worker-Allowed: /');

// Detectar BASE_URL igual ao config.php mas sem depender dele
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$base = rtrim($scriptDir, '/');
?>
const CACHE_NAME = 'barbearia-v2';
const BASE = '<?= $base ?>';
const STATIC_ASSETS = [
  BASE + '/',
  BASE + '/index.php',
  BASE + '/login.php',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS).catch(() => {});
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const options = {
    body: data.body || 'Sua vez está chegando!',
    icon: BASE + '/icons/icon-192.png',
    badge: BASE + '/icons/icon-72.png',
    vibrate: [200, 100, 200],
    data: { url: data.url || BASE + '/' },
    actions: [
      { action: 'ver', title: '👀 Ver fila' },
      { action: 'fechar', title: '✕ Fechar' }
    ]
  };
  event.waitUntil(
    self.registration.showNotification(data.title || '✂️ Barbearia', options)
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action !== 'fechar') {
    event.waitUntil(clients.openWindow(event.notification.data.url));
  }
});
