<?php
require_once '../config.php';
requireLogin();
if (!isAssistente() && !isAdmin()) { header('Location: ' . BASE_URL . '/login.php'); exit; }
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');

// ── Criar tabelas de estoque ──
$db->exec("
    CREATE TABLE IF NOT EXISTS estoque_produtos (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        nome          TEXT NOT NULL,
        categoria     TEXT DEFAULT 'Geral',
        unidade       TEXT DEFAULT 'un',
        estoque_atual REAL DEFAULT 0,
        estoque_min   REAL DEFAULT 5,
        preco_custo   REAL DEFAULT 0,
        ativo         INTEGER DEFAULT 1,
        criado_em     DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
$db->exec("
    CREATE TABLE IF NOT EXISTS estoque_movimentos (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        produto_id  INTEGER NOT NULL,
        tipo        TEXT NOT NULL CHECK(tipo IN ('entrada','saida','ajuste')),
        quantidade  REAL NOT NULL,
        obs         TEXT,
        usuario     TEXT,
        criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'add_produto') {
        $nome  = trim($_POST['nome'] ?? '');
        $cat   = trim($_POST['categoria'] ?? 'Geral');
        $und   = trim($_POST['unidade'] ?? 'un');
        $atual = (float)($_POST['estoque_atual'] ?? 0);
        $min   = (float)($_POST['estoque_min']   ?? 5);
        $custo = (float)($_POST['preco_custo']   ?? 0);
        if ($nome) {
            $db->prepare("INSERT INTO estoque_produtos (nome,categoria,unidade,estoque_atual,estoque_min,preco_custo) VALUES (?,?,?,?,?,?)")
               ->execute([$nome,$cat,$und,$atual,$min,$custo]);
            if ($atual > 0) {
                $id = $db->lastInsertId();
                $db->prepare("INSERT INTO estoque_movimentos (produto_id,tipo,quantidade,obs,usuario) VALUES (?,'entrada',?,?,?)")
                   ->execute([$id,$atual,'Estoque inicial',$_SESSION['usuario_nome']??'Admin']);
            }
            flash('success','Produto adicionado!');
        }
        header('Location: estoque.php'); exit;

    } elseif ($acao === 'movimento') {
        $pid  = (int)($_POST['produto_id'] ?? 0);
        $tipo = $_POST['tipo'] ?? '';
        $qtd  = (float)($_POST['quantidade'] ?? 0);
        $obs  = trim($_POST['obs'] ?? '');
        if ($pid && in_array($tipo,['entrada','saida','ajuste']) && $qtd > 0) {
            $db->prepare("INSERT INTO estoque_movimentos (produto_id,tipo,quantidade,obs,usuario) VALUES (?,?,?,?,?)")
               ->execute([$pid,$tipo,$qtd,$obs,$_SESSION['usuario_nome']??'Admin']);
            // Atualizar estoque
            if ($tipo === 'entrada') {
                $db->prepare("UPDATE estoque_produtos SET estoque_atual=estoque_atual+? WHERE id=?")->execute([$qtd,$pid]);
            } elseif ($tipo === 'saida') {
                $db->prepare("UPDATE estoque_produtos SET estoque_atual=MAX(0,estoque_atual-?) WHERE id=?")->execute([$qtd,$pid]);
            } else {
                $db->prepare("UPDATE estoque_produtos SET estoque_atual=? WHERE id=?")->execute([$qtd,$pid]);
            }
            flash('success','Movimento registrado!');
        }
        header('Location: estoque.php'); exit;

    } elseif ($acao === 'del_produto') {
        $db->prepare("UPDATE estoque_produtos SET ativo=0 WHERE id=?")->execute([(int)($_POST['id']??0)]);
        flash('warning','Produto removido.');
        header('Location: estoque.php'); exit;
    }
}

// ── Dados ──
$produtos  = $db->query("SELECT * FROM estoque_produtos WHERE ativo=1 ORDER BY categoria, nome")->fetchAll();
$alertas   = array_filter($produtos, fn($p) => $p['estoque_atual'] <= $p['estoque_min']);
$ultMovs   = $db->query("
    SELECT m.*, p.nome AS produto_nome
    FROM estoque_movimentos m JOIN estoque_produtos p ON p.id=m.produto_id
    ORDER BY m.criado_em DESC LIMIT 20
")->fetchAll();

$categorias = array_unique(array_column($produtos, 'categoria'));

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Estoque – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
    .fila-header-card{flex-wrap:wrap}
    .btn-adicionar-grande{width:100%;justify-content:center}
  }

  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.1rem}
  .card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
  .prod-row{display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
  .prod-row:last-child{border-bottom:none}
  .stock-bar{height:6px;background:rgba(255,255,255,.08);border-radius:10px;overflow:hidden;margin-top:.2rem;min-width:60px}
  .stock-fill{height:100%;border-radius:10px;transition:width .4s}
  .form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:10px;padding:.55rem .85rem;width:100%;font-size:.88rem}
  .form-control-dark:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
  .form-control-dark::placeholder{color:rgba(255,255,255,.3)}
  select.form-control-dark option{background:#1a1a2e}
  .btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;border-radius:10px;padding:.6rem 1.2rem;font-weight:700;cursor:pointer;transition:all .3s;font-size:.88rem}
  .btn-primary-custom:hover{transform:translateY(-1px);box-shadow:0 5px 18px rgba(233,69,96,.4)}
  .alerta-card{background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.25);border-radius:12px;padding:.75rem 1rem;margin-bottom:.5rem;display:flex;align-items:center;gap:.65rem}
  h4,h5,h6{color:#fff;margin:0}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Recepção</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(59,130,246,.2);color:#60a5fa">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Assistente') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Assistente</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Recepção</div>
    <a href="dashboard.php"     class="<?= navActive('dashboard.php',     $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="agendamentos.php"  class="<?= navActive('agendamentos.php',  $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <a href="relatorio_dia.php" class="<?= navActive('relatorio_dia.php', $paginaAtual) ?>"><i class="bi bi-bar-chart"></i>Relatório do Dia</a>
    <a href="estoque.php"       class="<?= navActive('estoque.php',       $paginaAtual) ?>"><i class="bi bi-boxes"></i>Estoque</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Estoque</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($nomeUsuario??$_SESSION['usuario_nome']??'Assistente') ?></span>
  </div>
</div>
<div class="page-body">

    <?= renderFlash() ?>

    <!-- Alertas de estoque baixo -->
    <?php if (!empty($alertas)): ?>
    <div class="card-sec" style="border-color:rgba(245,158,11,.3)">
      <div class="card-title"><i class="bi bi-exclamation-triangle-fill" style="color:#f59e0b"></i>
        Estoque Baixo <span style="background:rgba(245,158,11,.15);color:#fbbf24;border-radius:20px;padding:.1rem .5rem;font-size:.72rem;margin-left:auto"><?= count($alertas) ?></span>
      </div>
      <?php foreach ($alertas as $a): ?>
      <div class="alerta-card">
        <i class="bi bi-exclamation-circle-fill" style="color:#fbbf24;flex-shrink:0"></i>
        <div style="flex:1">
          <strong style="color:#fff"><?= htmlspecialchars($a['nome']) ?></strong>
          <span style="color:rgba(255,255,255,.4);font-size:.8rem"> — <?= $a['categoria'] ?></span>
        </div>
        <div style="text-align:right">
          <div style="font-weight:800;color:#fbbf24"><?= $a['estoque_atual'] ?> <?= $a['unidade'] ?></div>
          <div style="font-size:.72rem;color:rgba(255,255,255,.35)">mín: <?= $a['estoque_min'] ?></div>
        </div>
        <button onclick="abrirMovimento(<?= $a['id'] ?>, '<?= htmlspecialchars(addslashes($a['nome'])) ?>')"
          style="background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);color:#4ade80;
                 border-radius:8px;padding:.3rem .65rem;cursor:pointer;font-size:.78rem;font-weight:700;flex-shrink:0">
          <i class="bi bi-plus-lg me-1"></i>Repor
        </button>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="row g-3">
      <!-- Lista de produtos -->
      <div class="col-12 col-lg-8">
        <div class="card-sec">
          <div class="card-title"><i class="bi bi-box-seam" style="color:#60a5fa"></i>Produtos em Estoque</div>
          <?php
          $catAtual = null;
          foreach ($produtos as $p):
            if ($p['categoria'] !== $catAtual) {
                $catAtual = $p['categoria'];
                echo "<div style='font-size:.72rem;font-weight:700;color:rgba(255,255,255,.3);text-transform:uppercase;letter-spacing:.5px;padding:.5rem 0 .25rem'>{$catAtual}</div>";
            }
            $pct = $p['estoque_min'] > 0 ? min(100, round($p['estoque_atual']/$p['estoque_min']*50)) : 100;
            $cor = $p['estoque_atual'] <= 0 ? '#f87171' : ($p['estoque_atual'] <= $p['estoque_min'] ? '#fbbf24' : '#4ade80');
          ?>
          <div class="prod-row">
            <div style="flex:1;min-width:0">
              <div style="font-size:.88rem;font-weight:600;color:#fff"><?= htmlspecialchars($p['nome']) ?></div>
              <div class="stock-bar">
                <div class="stock-fill" style="width:<?= $pct ?>%;background:<?= $cor ?>"></div>
              </div>
            </div>
            <div style="text-align:center;flex-shrink:0;min-width:70px">
              <div style="font-weight:800;color:<?= $cor ?>;font-size:.95rem"><?= $p['estoque_atual'] ?></div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.3)"><?= $p['unidade'] ?> / mín:<?= $p['estoque_min'] ?></div>
            </div>
            <?php if ($p['preco_custo'] > 0): ?>
            <div style="text-align:right;font-size:.8rem;color:rgba(255,255,255,.4);flex-shrink:0;min-width:65px">
              R$ <?= number_format($p['preco_custo'],2,',','.') ?>
            </div>
            <?php endif; ?>
            <div style="display:flex;gap:.3rem;flex-shrink:0">
              <button onclick="abrirMovimento(<?= $p['id'] ?>, '<?= htmlspecialchars(addslashes($p['nome'])) ?>')"
                style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);
                       border-radius:8px;padding:.28rem .55rem;cursor:pointer;font-size:.75rem">
                <i class="bi bi-arrow-left-right"></i>
              </button>
              <form method="POST" style="display:inline;margin:0" onsubmit="return confirm('Remover produto?')">
                <input type="hidden" name="acao" value="del_produto">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);
                  color:#f87171;border-radius:8px;padding:.28rem .5rem;cursor:pointer;font-size:.75rem">
                  <i class="bi bi-trash"></i>
                </button>
              </form>
            </div>
          </div>
          <?php endforeach; ?>
          <?php if (empty($produtos)): ?>
          <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25);font-size:.85rem">
            <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
            Nenhum produto cadastrado
          </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Últimos movimentos -->
      <div class="col-12 col-lg-4">
        <div class="card-sec">
          <div class="card-title"><i class="bi bi-clock-history" style="color:#8b5cf6"></i>Últimos Movimentos</div>
          <?php foreach ($ultMovs as $m):
            $isEnt = in_array($m['tipo'],['entrada','ajuste']);
            $cor   = $isEnt ? '#4ade80' : '#f87171';
            $ic    = $isEnt ? 'bi-plus-circle-fill' : 'bi-dash-circle-fill';
          ?>
          <div style="display:flex;gap:.6rem;padding:.45rem 0;border-bottom:1px solid rgba(255,255,255,.04)">
            <i class="bi <?= $ic ?>" style="color:<?= $cor ?>;flex-shrink:0;margin-top:.15rem"></i>
            <div style="flex:1;min-width:0">
              <div style="font-size:.82rem;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($m['produto_nome']) ?></div>
              <div style="font-size:.7rem;color:rgba(255,255,255,.3)"><?= date('d/m H:i',strtotime($m['criado_em'])) ?> · <?= htmlspecialchars($m['usuario']) ?></div>
              <?php if ($m['obs']): ?><div style="font-size:.7rem;color:rgba(255,255,255,.25);font-style:italic"><?= htmlspecialchars($m['obs']) ?></div><?php endif; ?>
            </div>
            <div style="font-weight:700;color:<?= $cor ?>;flex-shrink:0"><?= ($isEnt?'+':'-') . $m['quantidade'] ?></div>
          </div>
          <?php endforeach; ?>
          <?php if (empty($ultMovs)): ?>
          <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.82rem">Sem movimentos</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Add Produto -->
<div id="modalAddProd" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9000;align-items:center;justify-content:center">
  <div style="background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:1.75rem;width:100%;max-width:460px;margin:1rem;max-height:90vh;overflow-y:auto">
    <h5 style="margin-bottom:1.25rem"><i class="bi bi-plus-circle me-2" style="color:var(--primary)"></i>Novo Produto</h5>
    <form method="POST">
      <input type="hidden" name="acao" value="add_produto">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.65rem;margin-bottom:.65rem">
        <div style="grid-column:1/-1">
          <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Nome *</label>
          <input type="text" name="nome" class="form-control-dark" placeholder="Ex: Pomada Modeladora" required>
        </div>
        <div>
          <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Categoria</label>
          <input type="text" name="categoria" class="form-control-dark" placeholder="Pomadas, Shampoos…" list="cats">
          <datalist id="cats">
            <?php foreach ($categorias as $cat): ?><option value="<?= htmlspecialchars($cat) ?>"><?php endforeach; ?>
            <option value="Pomadas"><option value="Shampoos"><option value="Condicionadores">
            <option value="Lâminas"><option value="Toalhas"><option value="Descartáveis">
          </datalist>
        </div>
        <div>
          <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Unidade</label>
          <select name="unidade" class="form-control-dark">
            <option value="un">un (unidade)</option><option value="cx">cx (caixa)</option>
            <option value="ml">ml</option><option value="g">g</option><option value="kg">kg</option>
          </select>
        </div>
        <div>
          <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Qtd atual</label>
          <input type="number" step="0.01" min="0" name="estoque_atual" class="form-control-dark" value="0">
        </div>
        <div>
          <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Qtd mínima</label>
          <input type="number" step="0.01" min="0" name="estoque_min" class="form-control-dark" value="5">
        </div>
        <div style="grid-column:1/-1">
          <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Preço de custo R$</label>
          <input type="number" step="0.01" min="0" name="preco_custo" class="form-control-dark" value="0">
        </div>
      </div>
      <div style="display:flex;gap:.5rem">
        <button type="button" onclick="document.getElementById('modalAddProd').style.display='none'"
          style="flex:1;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.6);border-radius:10px;padding:.65rem;cursor:pointer;font-weight:600">Cancelar</button>
        <button type="submit" class="btn-primary-custom" style="flex:1">Salvar</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Movimento -->
<div id="modalMov" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9000;align-items:center;justify-content:center">
  <div style="background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:1.75rem;width:100%;max-width:380px;margin:1rem">
    <h5 style="margin-bottom:1.25rem" id="movTitulo"><i class="bi bi-arrow-left-right me-2" style="color:#f59e0b"></i>Registrar Movimento</h5>
    <form method="POST">
      <input type="hidden" name="acao" value="movimento">
      <input type="hidden" name="produto_id" id="movProdId">
      <div style="margin-bottom:.7rem">
        <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Tipo</label>
        <select name="tipo" class="form-control-dark">
          <option value="entrada">⬆️ Entrada (compra/reposição)</option>
          <option value="saida">⬇️ Saída (uso/venda)</option>
          <option value="ajuste">🔄 Ajuste (inventário)</option>
        </select>
      </div>
      <div style="margin-bottom:.7rem">
        <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Quantidade</label>
        <input type="number" step="0.01" min="0.01" name="quantidade" class="form-control-dark" required>
      </div>
      <div style="margin-bottom:1rem">
        <label style="font-size:.8rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">Observação</label>
        <input type="text" name="obs" class="form-control-dark" placeholder="Opcional…">
      </div>
      <div style="display:flex;gap:.5rem">
        <button type="button" onclick="document.getElementById('modalMov').style.display='none'"
          style="flex:1;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.6);border-radius:10px;padding:.65rem;cursor:pointer;font-weight:600">Cancelar</button>
        <button type="submit" class="btn-primary-custom" style="flex:1">Registrar</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));

function abrirMovimento(id, nome) {
  document.getElementById('movProdId').value = id;
  document.getElementById('movTitulo').innerHTML = `<i class="bi bi-arrow-left-right me-2" style="color:#f59e0b"></i>${nome}`;
  document.getElementById('modalMov').style.display = 'flex';
}
['modalAddProd','modalMov'].forEach(id => {
  document.getElementById(id)?.addEventListener('click', e => { if(e.target.id===id) e.target.style.display='none'; });
});

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body></html>
