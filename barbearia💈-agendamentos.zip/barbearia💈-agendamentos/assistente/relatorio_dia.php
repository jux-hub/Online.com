<?php
require_once '../config.php';
requireLogin();
if (!isAssistente() && !isAdmin()) { header('Location: ' . BASE_URL . '/login.php'); exit; }
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');
$dataFiltro    = $_GET['data'] ?? date('Y-m-d');

// ── Totais gerais ──
$totais = $db->prepare("
    SELECT
        COUNT(CASE WHEN f.status='concluido' THEN 1 END) AS total_atend,
        COALESCE(SUM(CASE WHEN f.status='concluido' THEN f.valor END),0) AS receita_servicos,
        COALESCE(SUM(CASE WHEN f.status='concluido' THEN 0 END),0) AS receita_produtos,
        COUNT(CASE WHEN f.status='cancelado' THEN 1 END) AS faltas,
        COUNT(CASE WHEN f.status='aguardando' THEN 1 END) AS em_fila
    FROM fila f
    WHERE DATE(COALESCE(f.finalizado_em, f.criado_em)) = ?
");
$totais->execute([$dataFiltro]);
$totais = $totais->fetch();
$receitaTotal = $totais['receita_servicos'] + $totais['receita_produtos'];

// ── Por barbeiro ──
$porBarbeiro = $db->prepare("
    SELECT b.nome, NULL,
           COUNT(f.id) AS atend,
           COALESCE(SUM(f.valor),0) AS receita,
           COALESCE(SUM(0),0) AS prod
    FROM usuarios b
    LEFT JOIN fila f ON f.barbeiro_id=b.id AND f.status='concluido' AND DATE(f.finalizado_em)=?
    WHERE b.ativo=1 AND b.tipo='barbeiro'
    GROUP BY b.id
    ORDER BY receita DESC
");
$porBarbeiro->execute([$dataFiltro]);
$porBarbeiro = $porBarbeiro->fetchAll();

// ── Por serviço ──
$porServico = $db->prepare("
    SELECT s.nome,
           COUNT(f.id) AS qtd,
           COALESCE(SUM(f.valor),0) AS receita
    FROM fila f
    JOIN servicos s ON s.id=f.servico_id
    WHERE f.status='concluido' AND DATE(f.finalizado_em)=?
    GROUP BY s.id
    ORDER BY qtd DESC
    LIMIT 10
");
$porServico->execute([$dataFiltro]);
$porServico = $porServico->fetchAll();

// ── Agendamentos do dia ──
$agStats = ['total'=>0,'confirmados'=>0,'concluidos'=>0,'cancelados'=>0];
try {
    $stmt = $db->prepare("SELECT status, COUNT(*) AS qtd FROM agendamentos WHERE DATE(data_hora)=? GROUP BY status");
    $stmt->execute([$dataFiltro]);
    foreach ($stmt->fetchAll() as $r) {
        $agStats['total'] += $r['qtd'];
        if ($r['status']==='confirmado') $agStats['confirmados'] = $r['qtd'];
        if ($r['status']==='concluido')  $agStats['concluidos']  = $r['qtd'];
        if ($r['status']==='cancelado')  $agStats['cancelados']  = $r['qtd'];
    }
} catch (Exception $e) {}

// ── Evolução por hora (atendimentos) ──
$porHora = $db->prepare("
    SELECT strftime('%H',finalizado_em) AS hora, COUNT(*) AS qtd
    FROM fila WHERE status='concluido' AND DATE(finalizado_em)=?
    GROUP BY hora ORDER BY hora
");
$porHora->execute([$dataFiltro]);
$porHora = $porHora->fetchAll();
$horasLabels = array_column($porHora, 'hora');
$horasQtd    = array_column($porHora, 'qtd');

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Relatório do Dia – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
    .fila-header-card{flex-wrap:wrap}
    .btn-adicionar-grande{width:100%;justify-content:center}
  }

  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.1rem}
  .card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.2rem;text-align:center}
  .stat-value{font-size:1.6rem;font-weight:800;color:#fff;line-height:1}
  .stat-label{color:rgba(255,255,255,.4);font-size:.75rem;margin-top:.3rem}
  .form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:10px;padding:.5rem .85rem;font-size:.88rem}
  h4,h5,h6{color:#fff;margin:0}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Recepção</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(59,130,246,.2);color:#60a5fa">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Assistente') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Assistente</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Recepção</div>
    <a href="dashboard.php"     class="<?= navActive('dashboard.php',     $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="agendamentos.php"  class="<?= navActive('agendamentos.php',  $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <a href="relatorio_dia.php" class="<?= navActive('relatorio_dia.php', $paginaAtual) ?>"><i class="bi bi-bar-chart"></i>Relatório do Dia</a>
    <a href="estoque.php"       class="<?= navActive('estoque.php',       $paginaAtual) ?>"><i class="bi bi-boxes"></i>Estoque</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Relatório do Dia</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($nomeUsuario??$_SESSION['usuario_nome']??'Assistente') ?></span>
  </div>
</div>
<div class="page-body">

    <!-- Stats principais -->
    <div class="row g-3 mb-3">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#4ade80">R$ <?= number_format($receitaTotal,2,',','.') ?></div>
          <div class="stat-label"><i class="bi bi-currency-dollar me-1"></i>Receita Total</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#60a5fa"><?= $totais['total_atend'] ?></div>
          <div class="stat-label"><i class="bi bi-scissors me-1"></i>Atendimentos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#f59e0b">R$ <?= number_format($totais['receita_produtos'],2,',','.') ?></div>
          <div class="stat-label"><i class="bi bi-bag me-1"></i>Produtos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#f87171"><?= $totais['faltas'] ?></div>
          <div class="stat-label"><i class="bi bi-person-x me-1"></i>Faltas/Desistências</div>
        </div>
      </div>
    </div>

    <div class="row g-3">
      <!-- Por barbeiro -->
      <div class="col-12 col-lg-6">
        <div class="card-sec">
          <div class="card-title"><i class="bi bi-people-fill" style="color:#8b5cf6"></i>Por Barbeiro</div>
          <?php foreach ($porBarbeiro as $b):
            $cor = htmlspecialchars($b['cor'] ?? '#e94560');
            $pct = $receitaTotal > 0 ? round(($b['receita']+$b['prod'])/$receitaTotal*100) : 0;
          ?>
          <div style="display:flex;align-items:center;gap:.75rem;padding:.55rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <div style="width:34px;height:34px;border-radius:50%;background:<?= $cor ?>22;color:<?= $cor ?>;
                        display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.82rem;flex-shrink:0">
              <?= mb_strtoupper(mb_substr($b['nome'],0,1)) ?>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:.88rem;font-weight:600;color:#fff"><?= htmlspecialchars($b['nome']) ?></div>
              <div style="height:5px;background:rgba(255,255,255,.08);border-radius:10px;margin-top:.25rem;overflow:hidden">
                <div style="height:100%;width:<?= $pct ?>%;background:<?= $cor ?>;border-radius:10px"></div>
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-weight:700;color:#4ade80;font-size:.88rem">R$ <?= number_format($b['receita']+$b['prod'],2,',','.') ?></div>
              <div style="font-size:.7rem;color:rgba(255,255,255,.3)"><?= $b['atend'] ?> atend.</div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Agendamentos do dia -->
        <?php if ($agStats['total'] > 0): ?>
        <div class="card-sec">
          <div class="card-title"><i class="bi bi-calendar3" style="color:#3b82f6"></i>Agendamentos</div>
          <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:.5rem;text-align:center">
            <div><div style="font-size:1.3rem;font-weight:800;color:#fff"><?= $agStats['total'] ?></div><div style="font-size:.72rem;color:rgba(255,255,255,.35)">Total</div></div>
            <div><div style="font-size:1.3rem;font-weight:800;color:#60a5fa"><?= $agStats['confirmados'] ?></div><div style="font-size:.72rem;color:rgba(255,255,255,.35)">Confirm.</div></div>
            <div><div style="font-size:1.3rem;font-weight:800;color:#4ade80"><?= $agStats['concluidos'] ?></div><div style="font-size:.72rem;color:rgba(255,255,255,.35)">Concluídos</div></div>
            <div><div style="font-size:1.3rem;font-weight:800;color:#f87171"><?= $agStats['cancelados'] ?></div><div style="font-size:.72rem;color:rgba(255,255,255,.35)">Cancelados</div></div>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <!-- Por serviço + gráfico por hora -->
      <div class="col-12 col-lg-6">
        <div class="card-sec">
          <div class="card-title"><i class="bi bi-scissors" style="color:#f59e0b"></i>Serviços mais realizados</div>
          <?php if (empty($porServico)): ?>
          <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.85rem">Nenhum atendimento</div>
          <?php else: ?>
          <?php $maxQtd = $porServico[0]['qtd'] ?: 1; ?>
          <?php foreach ($porServico as $s): $pct = round($s['qtd']/$maxQtd*100); ?>
          <div style="display:flex;align-items:center;gap:.65rem;padding:.45rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <div style="flex:1;min-width:0">
              <div style="font-size:.85rem;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($s['nome']) ?></div>
              <div style="height:4px;background:rgba(255,255,255,.08);border-radius:10px;margin-top:.3rem;overflow:hidden">
                <div style="height:100%;width:<?= $pct ?>%;background:linear-gradient(90deg,var(--primary),#c41230);border-radius:10px"></div>
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-weight:700;color:#fff"><?= $s['qtd'] ?>x</div>
              <div style="font-size:.7rem;color:rgba(255,255,255,.3)">R$ <?= number_format($s['receita'],2,',','.') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <!-- Gráfico por hora -->
        <?php if (!empty($porHora)): ?>
        <div class="card-sec">
          <div class="card-title"><i class="bi bi-clock" style="color:#60a5fa"></i>Atendimentos por hora</div>
          <canvas id="chartHora" height="140"></canvas>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));

<?php if (!empty($porHora)): ?>
new Chart(document.getElementById('chartHora'), {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_map(fn($h)=>$h.'h', $horasLabels)) ?>,
    datasets: [{
      data: <?= json_encode($horasQtd) ?>,
      backgroundColor: 'rgba(233,69,96,.6)',
      borderColor: '#e94560',
      borderWidth: 1,
      borderRadius: 6,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { color: 'rgba(255,255,255,.06)' }, ticks: { color: 'rgba(255,255,255,.4)', font: { size: 11 } } },
      y: { grid: { color: 'rgba(255,255,255,.06)' }, ticks: { color: 'rgba(255,255,255,.4)', stepSize: 1 }, beginAtZero: true }
    }
  }
});
<?php endif; ?>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body></html>
