<?php
require_once '../config.php';
requireLogin();
if (!isAssistente() && !isAdmin()) { header('Location: ' . BASE_URL . '/login.php'); exit; }
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    $id   = (int)($_POST['id'] ?? 0);
    if ($id && in_array($acao, ['confirmar','cancelar','faltou','concluir'])) {
        $novoStatus = match($acao) {
            'confirmar' => 'confirmado',
            'cancelar'  => 'cancelado',
            'faltou'    => 'faltou',
            'concluir'  => 'concluido',
        };
        $db->prepare("UPDATE agendamentos SET status=? WHERE id=?")->execute([$novoStatus, $id]);
        flash('success', 'Agendamento atualizado!');
    }
    header('Location: agendamentos.php?' . http_build_query($_GET)); exit;
}

$dataFiltro   = $_GET['data']   ?? date('Y-m-d');
$barFiltro    = (int)($_GET['barbeiro_id'] ?? 0);
$statusFiltro = $_GET['status'] ?? '';

$where  = ["DATE(ag.data_hora)=?"];
$params = [$dataFiltro];
if ($barFiltro)    { $where[] = "ag.barbeiro_id=?";  $params[] = $barFiltro; }
if ($statusFiltro) { $where[] = "ag.status=?";       $params[] = $statusFiltro; }

$agendamentos = [];
try {
    $stmt = $db->prepare("
        SELECT ag.*, s.nome AS servico_nome, s.preco AS servico_preco,
               b.nome AS barbeiro_nome, b.cor AS barbeiro_cor
        FROM agendamentos ag
        LEFT JOIN servicos s ON s.id=ag.servico_id
        LEFT JOIN usuarios b ON b.id=ag.barbeiro_id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY ag.data_hora ASC
    ");
    $stmt->execute($params);
    $agendamentos = $stmt->fetchAll();
} catch (Exception $e) {}

$barbeiros = $db->query("SELECT id,nome FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();

$statusCfg = [
    'pendente'  => ['Pendente',   '#fbbf24','rgba(245,158,11,.15)'],
    'confirmado'=> ['Confirmado', '#60a5fa','rgba(59,130,246,.15)'],
    'concluido' => ['Concluído',  '#4ade80','rgba(34,197,94,.15)'],
    'cancelado' => ['Cancelado',  '#f87171','rgba(239,68,68,.15)'],
    'faltou'    => ['Faltou',     '#9ca3af','rgba(107,114,128,.15)'],
];

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agendamentos – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
    .fila-header-card{flex-wrap:wrap}
    .btn-adicionar-grande{width:100%;justify-content:center}
  }

  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.1rem}
  .ag-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:1rem;margin-bottom:.6rem}
  .form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:10px;padding:.5rem .85rem;font-size:.88rem}
  .form-control-dark:focus{outline:none;border-color:var(--primary)}
  select.form-control-dark option{background:#1a1a2e}
  .btn-xs{border:none;border-radius:8px;padding:.28rem .6rem;cursor:pointer;font-size:.75rem;font-weight:700}
  h4,h5,h6{color:#fff;margin:0}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Recepção</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(59,130,246,.2);color:#60a5fa">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Assistente') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Assistente</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Recepção</div>
    <a href="dashboard.php"     class="<?= navActive('dashboard.php',     $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="agendamentos.php"  class="<?= navActive('agendamentos.php',  $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <a href="relatorio_dia.php" class="<?= navActive('relatorio_dia.php', $paginaAtual) ?>"><i class="bi bi-bar-chart"></i>Relatório do Dia</a>
    <a href="estoque.php"       class="<?= navActive('estoque.php',       $paginaAtual) ?>"><i class="bi bi-boxes"></i>Estoque</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Agendamentos</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($nomeUsuario??$_SESSION['usuario_nome']??'Assistente') ?></span>
  </div>
</div>
<div class="page-body">

    <?= renderFlash() ?>

    <!-- Filtros -->
    <form method="GET" style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;align-items:center">
      <input type="date" name="data" value="<?= htmlspecialchars($dataFiltro) ?>" class="form-control-dark" style="width:auto">
      <select name="barbeiro_id" class="form-control-dark" style="width:auto">
        <option value="">Todos barbeiros</option>
        <?php foreach ($barbeiros as $b): ?>
        <option value="<?= $b['id'] ?>" <?= $barFiltro==$b['id'] ? 'selected':'' ?>><?= htmlspecialchars($b['nome']) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="status" class="form-control-dark" style="width:auto">
        <option value="">Todos status</option>
        <?php foreach ($statusCfg as $sk=>$sv): ?>
        <option value="<?= $sk ?>" <?= $statusFiltro===$sk ? 'selected':'' ?>><?= $sv[0] ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" style="background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;border-radius:10px;padding:.5rem 1rem;font-weight:700;cursor:pointer">Filtrar</button>
    </form>

    <?php if (empty($agendamentos)): ?>
    <div style="text-align:center;padding:3rem;color:rgba(255,255,255,.25)">
      <i class="bi bi-calendar-x" style="font-size:2.5rem;display:block;margin-bottom:.75rem"></i>
      Nenhum agendamento nesta data
    </div>
    <?php else: ?>
    <?php foreach ($agendamentos as $ag):
      [$slabel,$scolor,$sbg] = $statusCfg[$ag['status']] ?? ['?','#fff','rgba(255,255,255,.1)'];
      $cor = htmlspecialchars($ag['barbeiro_cor'] ?? '#e94560');
      $telLimpo = preg_replace('/\D/','',$ag['cliente_tel']);
      $numBr = str_starts_with($telLimpo,'55') ? $telLimpo : '55'.$telLimpo;
    ?>
    <div class="ag-card">
      <div style="display:flex;align-items:flex-start;gap:.85rem;flex-wrap:wrap">
        <div style="background:rgba(255,255,255,.07);border-radius:10px;padding:.5rem .75rem;text-align:center;flex-shrink:0;min-width:55px">
          <div style="font-size:1.05rem;font-weight:800;color:#fff"><?= date('H:i',strtotime($ag['data_hora'])) ?></div>
          <div style="font-size:.62rem;color:rgba(255,255,255,.35)"><?= date('d/m',strtotime($ag['data_hora'])) ?></div>
        </div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;gap:.45rem;align-items:center;flex-wrap:wrap;margin-bottom:.3rem">
            <span style="font-weight:700;color:#fff"><?= htmlspecialchars($ag['cliente_nome']) ?></span>
            <span style="background:<?= $sbg ?>;color:<?= $scolor ?>;border-radius:20px;padding:.1rem .5rem;font-size:.68rem;font-weight:700"><?= $slabel ?></span>
          </div>
          <div style="font-size:.78rem;color:rgba(255,255,255,.4);display:flex;gap:.65rem;flex-wrap:wrap">
            <span><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($ag['cliente_tel']) ?></span>
            <?php if ($ag['servico_nome']): ?><span><i class="bi bi-scissors me-1"></i><?= htmlspecialchars($ag['servico_nome']) ?></span><?php endif; ?>
            <?php if ($ag['barbeiro_nome']): ?><span style="color:<?= $cor ?>"><i class="bi bi-person me-1"></i><?= htmlspecialchars($ag['barbeiro_nome']) ?></span><?php endif; ?>
          </div>
          <?php if ($ag['observacao']): ?>
          <div style="font-size:.73rem;color:rgba(255,255,255,.3);margin-top:.2rem;font-style:italic">"<?= htmlspecialchars($ag['observacao']) ?>"</div>
          <?php endif; ?>
        </div>
        <div style="display:flex;gap:.3rem;flex-wrap:wrap;flex-shrink:0">
          <?php if ($ag['status']==='pendente'): ?>
          <form method="POST" style="display:inline"><input type="hidden" name="acao" value="confirmar"><input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <button type="submit" class="btn-xs" style="background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.3);color:#60a5fa"><i class="bi bi-check2 me-1"></i>Confirmar</button></form>
          <?php endif; ?>
          <?php if (in_array($ag['status'],['pendente','confirmado'])): ?>
          <form method="POST" style="display:inline"><input type="hidden" name="acao" value="concluir"><input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <button type="submit" class="btn-xs" style="background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);color:#4ade80"><i class="bi bi-check2-all me-1"></i>Concluir</button></form>
          <form method="POST" style="display:inline"><input type="hidden" name="acao" value="faltou"><input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <button type="submit" class="btn-xs" style="background:rgba(107,114,128,.12);border:1px solid rgba(107,114,128,.25);color:#9ca3af"><i class="bi bi-person-x me-1"></i>Faltou</button></form>
          <form method="POST" style="display:inline"><input type="hidden" name="acao" value="cancelar"><input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <button type="submit" class="btn-xs" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#f87171"><i class="bi bi-x me-1"></i>Cancelar</button></form>
          <?php endif; ?>
          <a href="https://wa.me/<?= $numBr ?>" target="_blank"
             class="btn-xs" style="background:rgba(37,211,102,.1);border:1px solid rgba(37,211,102,.25);color:#4ade80;text-decoration:none">
            <i class="bi bi-whatsapp"></i>
          </a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body></html>
