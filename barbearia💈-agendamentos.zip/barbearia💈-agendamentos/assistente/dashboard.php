<?php
require_once '../config.php';
function navActive(string $a, string $b): string { return basename($b)===$a?'nav-link-side active':'nav-link-side'; }
$paginaAtual = __FILE__;

if (!isLoggedIn() || (!isAssistente() && !isAdmin())) {
    header('Location: ' . BASE_URL . '/login.php'); exit;
}

$db            = getDB();
$nomeBarbearia = getConfig('nome_barbearia');
$tempoMedio    = (int)getConfig('tempo_medio_corte');
$nomeUsuario   = $_SESSION['nome'] ?? $_SESSION['usuario_nome'] ?? 'Recepção';

// ── Migração: tabela fila_itens ──
try {
    $db->exec("CREATE TABLE IF NOT EXISTS fila_itens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fila_id INTEGER NOT NULL,
        produto_id INTEGER,
        nome TEXT NOT NULL,
        preco REAL DEFAULT 0,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch(Exception $e) {}

// ── API autocomplete de clientes ──
if (isset($_GET['buscar_cliente'])) {
    header('Content-Type: application/json');
    $q = '%' . trim($_GET['buscar_cliente']) . '%';
    $stmt = $db->prepare("
        SELECT c.id, c.nome, c.telefone,
               COUNT(f.id) as total_visitas,
               MAX(f.finalizado_em) as ultima_visita
        FROM clientes c
        LEFT JOIN fila f ON f.cliente_id = c.id AND f.status = 'concluido'
        WHERE c.nome LIKE ? OR c.telefone LIKE ?
        GROUP BY c.id ORDER BY total_visitas DESC, c.nome ASC LIMIT 8
    ");
    $stmt->execute([$q, $q]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// ── Ações POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    $id   = (int)($_POST['id'] ?? 0);

    switch ($acao) {

        case 'adicionar_cliente':
            $barb_id  = (int)($_POST['barbeiro_id'] ?? 0);
            $nome     = trim($_POST['cliente_nome'] ?? '');
            $telefone = trim($_POST['cliente_fone'] ?? '');
            if (!$barb_id || !$nome) { flash('danger','Barbeiro e nome são obrigatórios.'); break; }

            $stmtC = $db->prepare("SELECT id FROM clientes WHERE telefone=? AND telefone!='' LIMIT 1");
            $stmtC->execute([$telefone]);
            $cli = $stmtC->fetch();
            if ($cli) {
                $cli_id = $cli['id'];
                $db->prepare("UPDATE clientes SET nome=? WHERE id=?")->execute([$nome, $cli_id]);
            } else {
                $db->prepare("INSERT INTO clientes (nome,telefone) VALUES (?,?)")->execute([$nome, $telefone]);
                $cli_id = $db->lastInsertId();
            }
            $stmtP = $db->prepare("SELECT COALESCE(MAX(posicao),0)+1 as prox FROM fila WHERE barbeiro_id=? AND status='aguardando'");
            $stmtP->execute([$barb_id]);
            $pos = (int)$stmtP->fetch()['prox'];
            $db->prepare("INSERT INTO fila (cliente_id,barbeiro_id,posicao,status,criado_em) VALUES (?,?,?,'aguardando',CURRENT_TIMESTAMP)")
               ->execute([$cli_id, $barb_id, $pos]);
            flash('success', "Cliente <strong>{$nome}</strong> adicionado à fila!");
            break;

        case 'iniciar':
            $db->prepare("UPDATE fila SET status='atendendo', iniciado_em=CURRENT_TIMESTAMP WHERE id=? AND status='aguardando'")
               ->execute([$id]);
            flash('success', 'Atendimento iniciado!');
            break;

        case 'finalizar':
            $valor  = (float)str_replace(',', '.', $_POST['valor'] ?? 0);
            $pgto   = $_POST['forma_pagamento'] ?? null;
            $extras = $_POST['extras'] ?? '[]';
            if (!in_array($pgto, ['pix','dinheiro','debito','credito'])) $pgto = null;

            $db->prepare("UPDATE fila SET status='concluido', valor=?, forma_pagamento=?,
                          finalizado_em=CURRENT_TIMESTAMP WHERE id=?")
               ->execute([$valor, $pgto, $id]);

            if ($extras && $extras !== '[]') {
                try {
                    $itens = json_decode($extras, true);
                    foreach ($itens as $item) {
                        $qty = (int)($item['qty'] ?? 1);
$db->prepare("INSERT INTO fila_itens (fila_id, produto_id, pacote_id, nome, preco, quantidade, subtotal) VALUES (?,?,?,?,?,?,?)")
   ->execute([
       $id,
       $item['tipo'] === 'produto' ? ($item['id'] ?? null) : null,
       $item['tipo'] === 'pacote'  ? ($item['id'] ?? null) : null,
       $item['nome'],
       $item['preco'],
       $qty,
       $item['preco'] * $qty,
   ]);
                    }
                } catch(Exception $e) {}
            }

            require_once '../whatsapp/config.php';
            $stmtCli = $db->prepare("SELECT c.nome, c.telefone FROM fila f JOIN clientes c ON c.id=f.cliente_id WHERE f.id=?");
            $stmtCli->execute([$id]);
            $cli = $stmtCli->fetch();
            $nomeBarbeariaWa = getConfig('nome_barbearia');
            if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbeariaWa);
            if ($cli && $valor > 0) {
                $keyComp = substr(md5($id . 'barbearia_renato'), 0, 8);
                $urlComp = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'
                         . $_SERVER['HTTP_HOST'] . BASE_URL . "/comprovante.php?id={$id}&key={$keyComp}";
                $msg = montarMensagemConclusao($cli['nome'], $valor, $pgto ?? 'dinheiro');
                $msg .= "\n\n📄 Comprovante: {$urlComp}";
                @enviarWhatsApp($cli['telefone'], $msg);
            }
            $keyLink = substr(md5($id . 'barbearia_renato'), 0, 8);
            flash('success',"Finalizado! <a href='" . BASE_URL . "/comprovante.php?id={$id}&key={$keyLink}' target='_blank' class='alert-link'><i class='bi bi-receipt me-1'></i>Ver comprovante</a>");
            break;

        case 'cancelar':
            $db->prepare("UPDATE fila SET status='cancelado' WHERE id=? AND status IN ('aguardando','atendendo')")
               ->execute([$id]);
            flash('success', 'Cliente removido da fila.');
            break;

        case 'mover':
            $novo_barbeiro = (int)($_POST['novo_barbeiro_id'] ?? 0);
            if ($novo_barbeiro) {
                $stmtPos = $db->prepare("SELECT COALESCE(MAX(posicao),0)+1 as prox FROM fila WHERE barbeiro_id=? AND status='aguardando'");
                $stmtPos->execute([$novo_barbeiro]);
                $novaPosicao = (int)$stmtPos->fetch()['prox'];
                $db->prepare("UPDATE fila SET barbeiro_id=?, posicao=?, status='aguardando' WHERE id=? AND status IN ('aguardando','atendendo')")
                   ->execute([$novo_barbeiro, $novaPosicao, $id]);
                flash('success', 'Cliente movido!');
            }
            break;
    }

    header('Location: dashboard.php'); exit;
}

// ── Dados ──
$todosBarbeiros = $db->query("SELECT id, nome FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();

// ── Produtos e Pacotes separados ──
$produtos = [];
$pacotes  = [];
try {
    $produtos = $db->query("SELECT id, nome, descricao, preco, 'produto' as tipo FROM produtos WHERE ativo=1 ORDER BY nome")->fetchAll();
} catch(Exception $e) {}
try {
    $pacotes = $db->query("SELECT id, nome, descricao, preco, 'pacote' as tipo FROM pacotes WHERE ativo=1 ORDER BY nome")->fetchAll();
} catch(Exception $e) {}

$barbeiros = $db->query("
    SELECT u.id, u.nome, u.foto,
        COUNT(CASE WHEN f.status='aguardando' THEN 1 END) as aguardando,
        COUNT(CASE WHEN f.status='atendendo'  THEN 1 END) as atendendo
    FROM usuarios u
    LEFT JOIN fila f ON f.barbeiro_id = u.id
    WHERE u.tipo='barbeiro' AND u.ativo=1
    GROUP BY u.id ORDER BY u.nome
")->fetchAll();

$filaCompleta = [];
foreach ($barbeiros as $b) {
    $stmt = $db->prepare("
        SELECT f.*, c.nome AS cliente_nome, c.telefone AS cliente_tel, c.id AS cliente_id,
               s.nome AS servico_nome, s.preco,
               (SELECT MAX(f2.finalizado_em) FROM fila f2
                WHERE f2.cliente_id = c.id AND f2.status='concluido'
                  AND f2.id != f.id) AS ultima_visita
        FROM fila f
        JOIN clientes c ON c.id = f.cliente_id
        LEFT JOIN servicos s ON s.id = f.servico_id
        WHERE f.barbeiro_id = ? AND f.status IN ('aguardando','atendendo')
        ORDER BY f.status DESC, f.posicao ASC
    ");
    $stmt->execute([$b['id']]);
    $filaCompleta[$b['id']] = $stmt->fetchAll();
}

$totalFila  = (int)$db->query("SELECT COUNT(*) FROM fila WHERE status='aguardando'")->fetchColumn();
$totalAtend = (int)$db->query("SELECT COUNT(*) FROM fila WHERE status='atendendo'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Recepção – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
    .fila-header-card{flex-wrap:wrap}
    .btn-adicionar-grande{width:100%;justify-content:center}
  }

  .fila-header-card{background:linear-gradient(135deg,rgba(255,255,255,.06),rgba(255,255,255,.03));border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.1rem 1.25rem;display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem;gap:1rem}
  .fila-header-left{display:flex;align-items:center;gap:.85rem}
  .fila-num{font-size:2.2rem;font-weight:900;color:#fff;line-height:1}
  .fila-label{font-size:.95rem;font-weight:700;color:#fff;line-height:1.2}
  .fila-sub{font-size:.75rem;color:rgba(255,255,255,.4);margin-top:.15rem}
  .btn-adicionar-grande{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:14px;padding:.75rem 1.5rem;font-weight:800;font-size:1rem;cursor:pointer;transition:.2s;display:flex;align-items:center;gap:.5rem;white-space:nowrap;flex-shrink:0;box-shadow:0 4px 20px rgba(233,69,96,.35)}
  .btn-adicionar-grande:hover{opacity:.88;transform:translateY(-1px)}

  .add-card{background:rgba(233,69,96,.05);border:1px solid rgba(233,69,96,.2);border-radius:16px;padding:1.25rem;margin-bottom:1.5rem;display:none}
  .add-card.visivel{display:block}
  .add-card-title{font-size:.95rem;font-weight:700;color:#fff;display:flex;align-items:center;gap:.5rem;margin-bottom:1rem}
  .fc{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px;padding:.5rem .85rem;font-size:.875rem;width:100%}
  .fc:focus{outline:none;border-color:var(--primary);background:rgba(255,255,255,.12);box-shadow:0 0 0 .2rem rgba(233,69,96,.2)}
  .fc::placeholder{color:rgba(255,255,255,.35)}
  .fc option{background:#1a1a2e}
  .form-lbl{color:rgba(255,255,255,.6);font-size:.78rem;display:block;margin-bottom:.3rem}
  .btn-add{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;padding:.55rem 1.2rem;font-weight:700;font-size:.875rem;cursor:pointer;transition:.2s;width:100%}

  .autocomplete-wrap{position:relative}
  .autocomplete-lista{position:absolute;top:calc(100% + 4px);left:0;right:0;background:#1a1a2e;border:1px solid rgba(233,69,96,.35);border-radius:10px;z-index:999;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.5);display:none}
  .autocomplete-lista.aberta{display:block}
  .autocomplete-item{padding:.6rem 1rem;cursor:pointer;transition:.15s;display:flex;align-items:center;gap:.75rem;border-bottom:1px solid rgba(255,255,255,.05)}
  .autocomplete-item:last-child{border-bottom:none}
  .autocomplete-item:hover{background:rgba(233,69,96,.15)}
  .autocomplete-avatar{width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.78rem;font-weight:700;color:#fff}
  .autocomplete-nome{font-weight:600;color:#fff;font-size:.85rem}
  .autocomplete-tel{font-size:.73rem;color:rgba(255,255,255,.45)}
  .autocomplete-visitas{margin-left:auto;background:rgba(255,255,255,.08);border-radius:20px;padding:.12rem .5rem;font-size:.68rem;color:rgba(255,255,255,.4);white-space:nowrap;flex-shrink:0}
  .autocomplete-novo{padding:.6rem 1rem;cursor:pointer;color:rgba(255,255,255,.5);font-size:.82rem;display:flex;align-items:center;gap:.5rem;transition:.15s}
  .autocomplete-novo:hover{background:rgba(255,255,255,.05);color:#fff}
  .badge-novo{background:rgba(34,197,94,.2);color:#4ade80;border-radius:20px;padding:.12rem .5rem;font-size:.68rem;font-weight:700;flex-shrink:0}
  .autocomplete-loading{padding:.6rem 1rem;color:rgba(255,255,255,.4);font-size:.82rem;display:flex;align-items:center;gap:.5rem}

  .barb-section{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;overflow:hidden;margin-bottom:1.25rem}
  .barb-header{padding:1rem 1.25rem;display:flex;align-items:center;gap:.85rem;border-bottom:1px solid rgba(255,255,255,.06);cursor:pointer;transition:.2s}
  .barb-header:hover{background:rgba(255,255,255,.03)}
  .barb-avatar{width:50px;height:50px;border-radius:50%;object-fit:cover;border:2px solid rgba(233,69,96,.4);flex-shrink:0}
  .barb-avatar-ph{width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:flex;align-items:center;justify-content:center;flex-shrink:0;border:2px solid rgba(233,69,96,.4)}
  .barb-nome{font-weight:700;color:#fff;font-size:.95rem}
  .barb-stats{display:flex;gap:.6rem;flex-wrap:wrap;margin-top:.25rem}
  .mini-badge{padding:.2rem .6rem;border-radius:6px;font-size:.72rem;font-weight:600}
  .mb-aguard{background:rgba(251,191,36,.15);color:#fbbf24}
  .mb-atend{background:rgba(34,197,94,.15);color:#4ade80}
  .barb-chevron{margin-left:auto;color:rgba(255,255,255,.3);transition:transform .3s}
  .barb-section.open .barb-chevron{transform:rotate(180deg)}

  .fila-body{padding:.75rem}
  .fila-vazia{text-align:center;padding:1.5rem;color:rgba(255,255,255,.25)}
  .fila-vazia i{font-size:1.8rem;display:block;margin-bottom:.5rem}

  .fila-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:.85rem 1rem;margin-bottom:.5rem;transition:.2s}
  .fila-item:hover{background:rgba(255,255,255,.06)}
  .fila-item.atendendo-now{background:rgba(34,197,94,.07);border-color:rgba(34,197,94,.25)}
  .pos-num{width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.88rem;color:#fff;flex-shrink:0}
  .pos-num.pos-1{background:linear-gradient(135deg,#fbbf24,#d97706);color:#000}
  .pos-num.atend-icon{background:linear-gradient(135deg,#4ade80,#16a34a);color:#000}
  .cli-nome{font-weight:700;color:#fff;font-size:.9rem}
  .cli-tel{color:rgba(255,255,255,.45);font-size:.78rem}

  .ultima-visita{display:inline-flex;align-items:center;gap:.3rem;font-size:.72rem;color:rgba(255,255,255,.4);background:rgba(255,255,255,.05);border-radius:5px;padding:.15rem .45rem;margin-top:.2rem}
  .ultima-visita.hoje{color:#4ade80;background:rgba(34,197,94,.1)}
  .ultima-visita.recente{color:#60a5fa;background:rgba(59,130,246,.1)}
  .ultima-visita.nunca{color:rgba(255,255,255,.25);background:rgba(255,255,255,.03)}

  .status-pill{padding:.2rem .65rem;border-radius:99px;font-size:.7rem;font-weight:700}
  .sp-aguard{background:rgba(251,191,36,.15);color:#fbbf24}
  .sp-atend{background:rgba(34,197,94,.15);color:#4ade80}

  .btn-ac{border:none;border-radius:7px;padding:.3rem .65rem;font-size:.76rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.25rem}
  .btn-iniciar{background:rgba(34,197,94,.2);color:#4ade80}
  .btn-iniciar:hover{background:rgba(34,197,94,.35)}
  .btn-finalizar-rec{background:rgba(233,69,96,.2);color:#e94560}
  .btn-finalizar-rec:hover{background:rgba(233,69,96,.35)}
  .btn-mover{background:rgba(59,130,246,.2);color:#60a5fa}
  .btn-mover:hover{background:rgba(59,130,246,.35)}
  .btn-cancelar{background:rgba(239,68,68,.15);color:#f87171}
  .btn-cancelar:hover{background:rgba(239,68,68,.3)}

  .painel-finalizar{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:1rem;margin-top:.75rem;display:none}
  .painel-finalizar.aberto{display:block}
  .pgto-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);color:rgba(255,255,255,.7);border-radius:8px;padding:.35rem .7rem;font-size:.82rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.3rem}
  .pgto-btn:hover,.pgto-btn.sel{background:rgba(233,69,96,.2);border-color:var(--primary);color:#fff}
  .pgto-btn input{display:none}
  .btn-confirmar-fin{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;padding:.6rem 1.1rem;font-weight:700;font-size:.88rem;cursor:pointer;transition:.2s;width:100%}
  .btn-confirmar-fin:hover{opacity:.88}
  .btn-cancelar-fin{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.5);border-radius:10px;padding:.5rem .9rem;font-size:.85rem;cursor:pointer}

  .btn-produtos{background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.35);color:#60a5fa;border-radius:10px;padding:.6rem 1rem;font-weight:600;font-size:.88rem;cursor:pointer;transition:.2s;width:100%;display:flex;align-items:center;justify-content:center;gap:.45rem;margin-bottom:.6rem}
  .btn-produtos:hover{background:rgba(59,130,246,.28);border-color:rgba(59,130,246,.6);color:#93c5fd}

  .extras-badge{background:rgba(59,130,246,.15);border:1px dashed rgba(59,130,246,.4);border-radius:8px;padding:.5rem .75rem;margin-bottom:.6rem;font-size:.83rem;color:#93c5fd;display:none}
  .extras-badge .extra-item{display:flex;justify-content:space-between;align-items:center;padding:.2rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
  .extras-badge .extra-item:last-child{border-bottom:none}

  .modal-dark .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.1);color:#e0e0e0;border-radius:18px}
  .modal-dark .modal-header{border-bottom:1px solid rgba(255,255,255,.08);padding:1.1rem 1.4rem .9rem}
  .modal-dark .modal-footer{border-top:1px solid rgba(255,255,255,.08);padding:.9rem 1.4rem}
  .modal-dark .modal-title{color:#fff;font-weight:700}
  .modal-dark .btn-close{filter:invert(1) opacity(.5)}
  .modal-dark .btn-close:hover{filter:invert(1) opacity(.9)}
  .produto-tipo-titulo{font-size:.72rem;font-weight:700;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.08em;margin:1rem 0 .4rem}
  .produto-item{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:.65rem .9rem;margin-bottom:.35rem;cursor:pointer;transition:.2s;gap:.75rem}
  .produto-item:hover{background:rgba(59,130,246,.12);border-color:rgba(59,130,246,.3)}
  .produto-item.selecionado{background:rgba(59,130,246,.18);border-color:rgba(59,130,246,.5)}
  .produto-item-nome{font-weight:600;color:#fff;font-size:.9rem}
  .produto-item-preco{color:#60a5fa;font-weight:700;font-size:.9rem;white-space:nowrap}
  .produto-item-qty{display:flex;align-items:center;gap:.4rem;background:rgba(255,255,255,.07);border-radius:8px;padding:.2rem .4rem}
  .qty-btn{background:none;border:none;color:#fff;cursor:pointer;font-size:1.1rem;line-height:1;padding:0 .2rem;transition:.15s}
  .qty-btn:hover{color:#e94560}
  .qty-num{min-width:18px;text-align:center;font-weight:700;color:#fff;font-size:.9rem}

  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.1)}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08)}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08)}
  .modal-title{color:#fff}
  .form-select-dark{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px;padding:.5rem .85rem;width:100%}
  .form-select-dark option{background:#1a1a2e}
  .form-select-dark:focus{border-color:var(--primary);box-shadow:0 0 0 .25rem rgba(233,69,96,.2);outline:none}to{width:0%}}

  .section-label{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);text-transform:uppercase;letter-spacing:1px;margin-bottom:.75rem;display:flex;align-items:center;gap:.4rem}

  @media(max-width:576px){
    .topbar{padding:.75rem 1rem}
    .live-badge{display:none}
    .btn-adicionar-grande{padding:.65rem 1.1rem;font-size:.9rem}
    .fila-num{font-size:1.8rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Recepção</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(59,130,246,.2);color:#60a5fa">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Assistente') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Assistente</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Recepção</div>
    <a href="dashboard.php"     class="<?= navActive('dashboard.php',     $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="agendamentos.php"  class="<?= navActive('agendamentos.php',  $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <a href="relatorio_dia.php" class="<?= navActive('relatorio_dia.php', $paginaAtual) ?>"><i class="bi bi-bar-chart"></i>Relatório do Dia</a>
    <a href="estoque.php"       class="<?= navActive('estoque.php',       $paginaAtual) ?>"><i class="bi bi-boxes"></i>Estoque</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Recepção</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($nomeUsuario??$_SESSION['usuario_nome']??'Assistente') ?></span>
  </div>
</div>
<div class="page-body">

  <?= renderFlash() ?>

  <div class="fila-header-card">
    <div class="fila-header-left">
      <div><div class="fila-num"><?= $totalFila ?></div></div>
      <div>
        <div class="fila-label">Na fila agora</div>
        <div class="fila-sub"><?= $totalAtend ?> em atendimento</div>
      </div>
    </div>
    <button class="btn-adicionar-grande" onclick="toggleAddCard()">
      <i class="bi bi-person-plus-fill"></i>Adicionar
    </button>
  </div>

  <!-- ── Form Adicionar ── -->
  <div class="add-card" id="addCard">
    <div class="add-card-title">
      <i class="bi bi-person-plus-fill" style="color:#e94560"></i>
      Adicionar Cliente à Fila
      <button type="button" onclick="toggleAddCard()"
        style="margin-left:auto;background:none;border:none;color:rgba(255,255,255,.4);font-size:1.1rem;cursor:pointer;padding:0">
        <i class="bi bi-x-lg"></i>
      </button>
    </div>
    <form method="POST" id="formAdd">
      <input type="hidden" name="acao" value="adicionar_cliente">
      <div class="row g-2 align-items-end">
        <div class="col-12 col-sm-5">
          <label class="form-lbl">Nome do cliente *</label>
          <div class="autocomplete-wrap">
            <input type="text" name="cliente_nome" id="inputNome" class="fc"
              placeholder="Digite o nome..." required autocomplete="off">
            <div class="autocomplete-lista" id="listaAuto"></div>
          </div>
        </div>
        <div class="col-12 col-sm-4">
          <label class="form-lbl">
            WhatsApp
            <span id="telAutoTag" style="display:none;background:rgba(34,197,94,.2);color:#4ade80;
              border-radius:20px;padding:.1rem .5rem;font-size:.68rem;margin-left:.3rem;font-weight:700">
              <i class="bi bi-check2"></i> preenchido
            </span>
          </label>
          <input type="tel" name="cliente_fone" id="inputTel" class="fc" placeholder="(00) 00000-0000">
        </div>
        <div class="col-12 col-sm-3">
          <label class="form-lbl">Barbeiro *</label>
          <select name="barbeiro_id" id="selectBarbeiro" class="fc" required>
            <option value="">– Selecione –</option>
            <?php foreach($barbeiros as $b): ?>
            <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['nome']) ?> (<?= $b['aguardando'] ?> na fila)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12">
          <button type="submit" class="btn-add">
            <i class="bi bi-plus-lg me-1"></i>Adicionar à Fila
          </button>
        </div>
      </div>
    </form>
  </div>

  <div class="section-label">
    <i class="bi bi-people-fill"></i>Fila por Barbeiro
    <span style="margin-left:auto;font-weight:400;color:rgba(255,255,255,.2)"><?= date('d/m/Y H:i') ?></span>
  </div>

  <?php if (empty($barbeiros)): ?>
    <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:3rem;text-align:center;color:rgba(255,255,255,.25)">
      <i class="bi bi-people fs-1 d-block mb-2"></i>Nenhum barbeiro ativo
    </div>
  <?php endif; ?>

  <?php foreach ($barbeiros as $b):
    $fila    = $filaCompleta[$b['id']] ?? [];
    $temFoto = !empty($b['foto']) && file_exists(__DIR__.'/../uploads/barbeiros/'.$b['foto']);
    $fotoUrl = $temFoto ? BASE_URL.'/uploads/barbeiros/'.htmlspecialchars($b['foto']) : null;
    $aberto  = count($fila) > 0 ? 'open' : '';
  ?>
  <div class="barb-section <?= $aberto ?>" id="sec_<?= $b['id'] ?>">
    <div class="barb-header" onclick="toggleSection(<?= $b['id'] ?>)">
      <?php if ($fotoUrl): ?>
        <img src="<?= $fotoUrl ?>" class="barb-avatar" alt="">
      <?php else: ?>
        <div class="barb-avatar-ph"><i class="bi bi-person-fill text-white"></i></div>
      <?php endif; ?>
      <div class="flex-grow-1">
        <div class="barb-nome"><?= htmlspecialchars($b['nome']) ?></div>
        <div class="barb-stats">
          <span class="mini-badge mb-aguard"><i class="bi bi-hourglass-split me-1"></i><?= $b['aguardando'] ?> na fila</span>
          <?php if ($b['atendendo']): ?>
          <span class="mini-badge mb-atend"><i class="bi bi-scissors me-1"></i>Atendendo</span>
          <?php endif; ?>
          <?php if ($b['aguardando'] > 0): ?>
          <span class="mini-badge" style="background:rgba(251,191,36,.1);color:rgba(251,191,36,.8)">
            <i class="bi bi-clock me-1"></i>~<?= $b['aguardando'] * $tempoMedio ?>min
          </span>
          <?php endif; ?>
        </div>
      </div>
      <i class="bi bi-chevron-down barb-chevron"></i>
    </div>

    <div class="fila-body" id="fila_<?= $b['id'] ?>" style="<?= $aberto ? '' : 'display:none' ?>">
      <?php if (empty($fila)): ?>
        <div class="fila-vazia"><i class="bi bi-check-circle"></i>Fila vazia</div>
      <?php else: ?>
        <?php foreach ($fila as $i => $item):
          $atendNow  = $item['status'] === 'atendendo';
          $pos       = $atendNow ? 0 : (int)$item['posicao'];
          $ultVisita = $item['ultima_visita'] ?? null;
          if ($ultVisita) {
              $diffDias = (int)floor((time() - strtotime($ultVisita)) / 86400);
              if ($diffDias === 0)     { $visitaLabel = 'Última visita: hoje';               $visitaClass = 'hoje'; }
              elseif ($diffDias <= 7)  { $visitaLabel = "Última visita: {$diffDias}d atrás";  $visitaClass = 'recente'; }
              elseif ($diffDias <= 30) { $visitaLabel = "Última visita: {$diffDias}d atrás";  $visitaClass = ''; }
              else                     { $visitaLabel = date('d/m/Y', strtotime($ultVisita)); $visitaClass = ''; }
          } else {
              $visitaLabel = 'Primeira visita'; $visitaClass = 'nunca';
          }
        ?>
        <div class="fila-item <?= $atendNow ? 'atendendo-now' : '' ?>" id="item_<?= $item['id'] ?>">
          <div class="d-flex align-items-start gap-2">
            <?php if ($atendNow): ?>
              <div class="pos-num atend-icon"><i class="bi bi-scissors" style="font-size:.75rem"></i></div>
            <?php elseif ($pos === 1): ?>
              <div class="pos-num pos-1">1</div>
            <?php else: ?>
              <div class="pos-num"><?= $pos ?></div>
            <?php endif; ?>

            <div class="flex-grow-1" style="min-width:0">
              <div class="d-flex align-items-center gap-2 flex-wrap">
                <span class="cli-nome"><?= htmlspecialchars($item['cliente_nome']) ?></span>
                <?php if ($atendNow): ?>
                  <span class="status-pill sp-atend"><i class="bi bi-scissors me-1"></i>Atendendo</span>
                <?php else: ?>
                  <span class="status-pill sp-aguard"><i class="bi bi-hourglass-split me-1"></i>Aguardando</span>
                <?php endif; ?>
              </div>

              <?php if (!empty($item['cliente_tel'])): ?>
              <div class="cli-tel mt-1">
                <i class="bi bi-whatsapp me-1" style="color:#25d366"></i><?= htmlspecialchars($item['cliente_tel']) ?>
              </div>
              <?php endif; ?>

              <div>
                <span class="ultima-visita <?= $visitaClass ?>">
                  <i class="bi bi-clock-history"></i><?= $visitaLabel ?>
                </span>
              </div>

              <div class="d-flex gap-1 mt-2 flex-wrap">
                <?php if (!$atendNow): ?>
                <form method="POST" class="d-inline">
                  <input type="hidden" name="acao" value="iniciar">
                  <input type="hidden" name="id" value="<?= $item['id'] ?>">
                  <button type="submit" class="btn-ac btn-iniciar"><i class="bi bi-play-fill"></i>Iniciar</button>
                </form>
                <?php endif; ?>

                <button type="button" class="btn-ac btn-finalizar-rec"
                  onclick="togglePainel('fin_<?= $item['id'] ?>')">
                  <i class="bi bi-check-lg"></i>Finalizar
                </button>

                <button type="button" class="btn-ac btn-mover"
                  onclick="abrirModalMover(<?= $item['id'] ?>, '<?= htmlspecialchars($item['cliente_nome'], ENT_QUOTES) ?>', <?= $b['id'] ?>, <?= $atendNow ? 'true' : 'false' ?>)">
                  <i class="bi bi-arrow-left-right"></i>Mover
                </button>

                <form method="POST" class="d-inline">
                  <input type="hidden" name="acao" value="cancelar">
                  <input type="hidden" name="id" value="<?= $item['id'] ?>">
                  <button type="submit" class="btn-ac btn-cancelar"
                    onclick="return confirm('Remover <?= htmlspecialchars($item['cliente_nome'], ENT_QUOTES) ?> da fila?')">
                    <i class="bi bi-x-lg"></i>Remover
                  </button>
                </form>
              </div>

              <!-- ── Painel Finalizar ── -->
              <div class="painel-finalizar" id="fin_<?= $item['id'] ?>">
                <form method="POST" id="formFin_<?= $item['id'] ?>">
                  <input type="hidden" name="acao" value="finalizar">
                  <input type="hidden" name="id" value="<?= $item['id'] ?>">
                  <input type="hidden" name="extras" id="extrasInput_<?= $item['id'] ?>" value="[]">

                  <div class="row g-2 align-items-end">
                    <div class="col-12 col-sm-4">
                      <label class="form-lbl">Valor cobrado (R$)</label>
                      <input type="text" name="valor" class="fc mascara-valor" placeholder="0,00"
                        id="valor_<?= $item['id'] ?>"
                        value="<?= $item['preco'] ? number_format($item['preco'],2,',','.') : '' ?>">
                    </div>
                    <div class="col-12 col-sm-8">
                      <label class="form-lbl">Pagamento</label>
                      <div class="d-flex gap-1 flex-wrap">
                        <?php foreach(['pix'=>'PIX','dinheiro'=>'Dinheiro','debito'=>'Débito','credito'=>'Crédito'] as $v=>$l): ?>
                        <label class="pgto-btn">
                          <input type="radio" name="forma_pagamento" value="<?= $v ?>"> <?= $l ?>
                        </label>
                        <?php endforeach; ?>
                      </div>
                    </div>

                    <div class="col-12">
                      <button type="button" class="btn-produtos"
                        onclick="abrirModalProdutos(<?= $item['id'] ?>, '<?= addslashes(htmlspecialchars($item['cliente_nome'])) ?>')">
                        <i class="bi bi-bag-plus-fill"></i>Adicionar Produtos / Pacotes
                      </button>
                      <div class="extras-badge" id="extrasBadge_<?= $item['id'] ?>">
                        <div style="font-size:.75rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;font-weight:700">
                          <i class="bi bi-bag-check-fill me-1"></i>ITENS ADICIONADOS
                        </div>
                        <div id="extrasLista_<?= $item['id'] ?>"></div>
                        <div style="border-top:1px solid rgba(255,255,255,.08);margin-top:.4rem;padding-top:.4rem;display:flex;justify-content:space-between">
                          <span style="color:rgba(255,255,255,.5);font-size:.8rem">Total extras</span>
                          <span style="color:#60a5fa;font-weight:700" id="extrasTotal_<?= $item['id'] ?>">R$ 0,00</span>
                        </div>
                      </div>
                    </div>

                    <div class="col-12">
                      <button type="submit" class="btn-confirmar-fin">
                        <i class="bi bi-check-lg me-1"></i>Finalizar Atendimento
                      </button>
                    </div>
                    <div class="col-12">
                      <button type="button" class="btn-cancelar-fin w-100"
                        onclick="togglePainel('fin_<?= $item['id'] ?>')">Cancelar</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>

  <div style="text-align:center;margin-top:1.5rem;font-size:.72rem;color:rgba(255,255,255,.2)">
    Atualiza automaticamente a cada 2 minutos · <?= htmlspecialchars($nomeBarbearia) ?>
  </div>
</div>

<!-- MODAL: Produtos / Pacotes -->
<div class="modal fade modal-dark" id="modalProdutos" tabindex="-1">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-bag-plus-fill me-2" style="color:#60a5fa"></i>Produtos & Pacotes</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="padding:1rem 1.25rem">
        <div style="font-size:.85rem;color:rgba(255,255,255,.45);margin-bottom:1rem" id="modalProdutosCliente"></div>
        <?php $temProdutos = !empty($produtos); $temPacotes = !empty($pacotes); ?>
        <?php if (!$temProdutos && !$temPacotes): ?>
          <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.3)">
            <i class="bi bi-bag-x" style="font-size:2.5rem;display:block;margin-bottom:.75rem"></i>
            Nenhum produto ou pacote cadastrado.<br>
            <a href="../admin/produtos.php" style="color:#60a5fa;font-size:.85rem">Cadastrar agora →</a>
          </div>
        <?php else: ?>
          <?php if ($temProdutos): ?>
            <div class="produto-tipo-titulo">🧴 PRODUTOS</div>
            <?php foreach($produtos as $p): ?>
            <div class="produto-item" id="prodItem_<?= $p['id'] ?>_produto"
                 onclick="toggleItem('produto', <?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['nome'])) ?>', <?= $p['preco'] ?>)">
              <div>
                <div class="produto-item-nome"><?= htmlspecialchars($p['nome']) ?></div>
                <?php if(!empty($p['descricao'])): ?>
                <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-top:.15rem"><?= htmlspecialchars($p['descricao']) ?></div>
                <?php endif; ?>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span class="produto-item-preco"><?= formatMoney($p['preco']) ?></span>
                <div class="produto-item-qty" id="qtyBox_produto_<?= $p['id'] ?>" style="display:none!important">
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('produto',<?= $p['id'] ?>,-1)">−</button>
                  <span class="qty-num" id="qty_produto_<?= $p['id'] ?>">1</span>
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('produto',<?= $p['id'] ?>,+1)">+</button>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>
          <?php if ($temPacotes): ?>
            <div class="produto-tipo-titulo" style="margin-top:<?= $temProdutos ? '1.25rem' : '0' ?>">📦 PACOTES</div>
            <?php foreach($pacotes as $p): ?>
            <div class="produto-item" id="prodItem_<?= $p['id'] ?>_pacote"
                 onclick="toggleItem('pacote', <?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['nome'])) ?>', <?= $p['preco'] ?>)">
              <div>
                <div class="produto-item-nome"><?= htmlspecialchars($p['nome']) ?></div>
                <?php if(!empty($p['descricao'])): ?>
                <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-top:.15rem"><?= htmlspecialchars($p['descricao']) ?></div>
                <?php endif; ?>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span class="produto-item-preco"><?= formatMoney($p['preco']) ?></span>
                <div class="produto-item-qty" id="qtyBox_pacote_<?= $p['id'] ?>" style="display:none!important">
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('pacote',<?= $p['id'] ?>,-1)">−</button>
                  <span class="qty-num" id="qty_pacote_<?= $p['id'] ?>">1</span>
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('pacote',<?= $p['id'] ?>,+1)">+</button>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
      <div class="modal-footer justify-content-between align-items-center">
        <div>
          <span style="font-size:.8rem;color:rgba(255,255,255,.45)">Total selecionado</span><br>
          <span style="font-weight:800;color:#60a5fa;font-size:1.1rem" id="modalTotalProdutos">R$ 0,00</span>
        </div>
        <div class="d-flex gap-2">
          <button type="button" class="btn btn-sm"
            style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.6);border:none;border-radius:8px"
            data-bs-dismiss="modal">Cancelar</button>
          <button type="button" class="btn btn-sm"
            style="background:linear-gradient(135deg,#3b82f6,#1d4ed8);color:#fff;border:none;border-radius:8px;font-weight:700;padding:.5rem 1.1rem"
            onclick="confirmarProdutos()">
            <i class="bi bi-check-lg me-1"></i>Confirmar
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL: Mover -->
<div class="modal fade" id="modalMover" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-arrow-left-right me-2" style="color:#60a5fa"></i>Mover Cliente</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="acao" value="mover">
        <input type="hidden" name="id" id="moverFilaId">
        <div class="modal-body">
          <p style="color:rgba(255,255,255,.7);font-size:.9rem;margin-bottom:.35rem">
            Mover <strong id="moverClienteNome" style="color:#fff"></strong> para:
          </p>
          <div id="moverStatusInfo" style="font-size:.75rem;color:rgba(251,191,36,.7);background:rgba(251,191,36,.08);border-radius:8px;padding:.4rem .7rem;margin-bottom:.85rem;display:none">
            <i class="bi bi-info-circle me-1"></i>Cliente em atendimento — será movido como aguardando no novo barbeiro.
          </div>
          <label style="color:rgba(255,255,255,.6);font-size:.82rem;display:block;margin-bottom:.35rem">Novo barbeiro</label>
          <select name="novo_barbeiro_id" class="form-select-dark" id="selectNovoBarbeiro">
            <?php foreach($todosBarbeiros as $tb): ?>
            <option value="<?= $tb['id'] ?>"><?= htmlspecialchars($tb['nome']) ?></option>
            <?php endforeach; ?>
          </select>
          <small style="color:rgba(255,255,255,.3);font-size:.73rem;margin-top:.4rem;display:block">Será adicionado ao final da fila.</small>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-sm"
            style="background:linear-gradient(135deg,#3b82f6,#1d4ed8);color:#fff;border:none;border-radius:8px;padding:.4rem 1.2rem;font-weight:600">
            <i class="bi bi-arrow-left-right me-1"></i>Mover
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
</script>
<script>
function toggleAddCard() {
  const card = document.getElementById('addCard');
  card.classList.toggle('visivel');
  if (card.classList.contains('visivel')) {
    card.scrollIntoView({behavior:'smooth', block:'nearest'});
    document.getElementById('inputNome').focus();
  }
}

function togglePainel(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const jaAberto = el.classList.contains('aberto');
  document.querySelectorAll('.painel-finalizar').forEach(p => p.classList.remove('aberto'));
  if (!jaAberto) el.classList.add('aberto');
}

function toggleSection(id) {
  const sec  = document.getElementById('sec_'  + id);
  const body = document.getElementById('fila_' + id);
  if (!sec || !body) return;
  const open = sec.classList.toggle('open');
  body.style.display = open ? 'block' : 'none';
}

function abrirModalMover(filaId, clienteNome, barbAtualId, estaAtendendo) {
  document.getElementById('moverFilaId').value = filaId;
  document.getElementById('moverClienteNome').textContent = clienteNome;
  document.getElementById('moverStatusInfo').style.display = estaAtendendo ? 'block' : 'none';
  const sel = document.getElementById('selectNovoBarbeiro');
  Array.from(sel.options).forEach(opt => { opt.disabled = parseInt(opt.value) === barbAtualId; });
  for (let opt of sel.options) { if (!opt.disabled) { opt.selected = true; break; } }
  new bootstrap.Modal(document.getElementById('modalMover')).show();
}

document.querySelectorAll('.mascara-valor').forEach(i => {
  i.addEventListener('input', function() {
    let v = this.value.replace(/\D/g,'');
    v = (parseInt(v||0)/100).toFixed(2).replace('.',',');
    this.value = v;
  });
});

document.querySelectorAll('.pgto-btn input').forEach(r => {
  r.addEventListener('change', function() {
    const grp = this.closest('.d-flex');
    grp.querySelectorAll('.pgto-btn').forEach(b => b.classList.remove('sel'));
    this.closest('.pgto-btn').classList.add('sel');
  });
});

// ── Produtos / Pacotes ──
let modalFilaId = null;
let itensSel    = {};

function abrirModalProdutos(filaId, nomeCliente) {
  modalFilaId = filaId;
  document.getElementById('modalProdutosCliente').textContent = 'Adicionando para: ' + nomeCliente;
  const extrasRaw = document.getElementById('extrasInput_' + filaId).value;
  const extras    = JSON.parse(extrasRaw || '[]');
  document.querySelectorAll('.produto-item').forEach(el => el.classList.remove('selecionado'));
  document.querySelectorAll('[id^="qtyBox_"]').forEach(el => el.style.setProperty('display','none','important'));
  itensSel = {};
  extras.forEach(item => {
    const key = item.tipo + '_' + item.id;
    itensSel[key] = { id: item.id, tipo: item.tipo, nome: item.nome, preco: item.preco, qty: item.qty || 1 };
    const el = document.getElementById('prodItem_' + item.id + '_' + item.tipo);
    if (el) {
      el.classList.add('selecionado');
      const qtyBox = document.getElementById('qtyBox_' + item.tipo + '_' + item.id);
      if (qtyBox) qtyBox.style.removeProperty('display');
      const qtyNum = document.getElementById('qty_' + item.tipo + '_' + item.id);
      if (qtyNum) qtyNum.textContent = item.qty || 1;
    }
  });
  atualizarTotalModal();
  new bootstrap.Modal(document.getElementById('modalProdutos')).show();
}

function toggleItem(tipo, id, nome, preco) {
  const key = tipo + '_' + id;
  if (itensSel[key]) {
    delete itensSel[key];
    document.getElementById('prodItem_' + id + '_' + tipo).classList.remove('selecionado');
    document.getElementById('qtyBox_' + tipo + '_' + id).style.setProperty('display','none','important');
  } else {
    itensSel[key] = { id, tipo, nome, preco, qty: 1 };
    document.getElementById('prodItem_' + id + '_' + tipo).classList.add('selecionado');
    document.getElementById('qtyBox_' + tipo + '_' + id).style.removeProperty('display');
    document.getElementById('qty_' + tipo + '_' + id).textContent = 1;
  }
  atualizarTotalModal();
}

function alterarQtyItem(tipo, id, delta) {
  const key = tipo + '_' + id;
  if (!itensSel[key]) return;
  let q = itensSel[key].qty + delta;
  if (q < 1) { toggleItem(tipo, id, itensSel[key].nome, itensSel[key].preco); return; }
  itensSel[key].qty = q;
  document.getElementById('qty_' + tipo + '_' + id).textContent = q;
  atualizarTotalModal();
}

function atualizarTotalModal() {
  let total = 0;
  Object.values(itensSel).forEach(p => total += p.preco * p.qty);
  document.getElementById('modalTotalProdutos').textContent = 'R$ ' + total.toFixed(2).replace('.',',');
}

function confirmarProdutos() {
  if (!modalFilaId) return;
  const itens = Object.values(itensSel);
  document.getElementById('extrasInput_' + modalFilaId).value = JSON.stringify(itens);
  const badge = document.getElementById('extrasBadge_' + modalFilaId);
  const lista = document.getElementById('extrasLista_'  + modalFilaId);
  const tot   = document.getElementById('extrasTotal_'  + modalFilaId);
  if (itens.length === 0) {
    badge.style.display = 'none';
  } else {
    badge.style.display = 'block';
    lista.innerHTML = '';
    let totalExtras = 0;
    itens.forEach(item => {
      totalExtras += item.preco * item.qty;
      const div = document.createElement('div');
      div.className = 'extra-item';
      const tipoIcon = item.tipo === 'pacote' ? '📦 ' : '🧴 ';
      div.innerHTML = `<span>${tipoIcon}${item.qty > 1 ? item.qty + 'x ' : ''}${item.nome}</span>
        <span style="color:#60a5fa;font-weight:700">R$ ${(item.preco * item.qty).toFixed(2).replace('.',',')}</span>`;
      lista.appendChild(div);
    });
    tot.textContent = 'R$ ' + totalExtras.toFixed(2).replace('.',',');
    const inputValor = document.getElementById('valor_' + modalFilaId);
    if (!inputValor.dataset.base) inputValor.dataset.base = parseFloat(inputValor.value.replace(',','.')) || 0;
    const novoTotal = parseFloat(inputValor.dataset.base) + totalExtras;
    inputValor.value = novoTotal.toFixed(2).replace('.',',');
  }
  bootstrap.Modal.getInstance(document.getElementById('modalProdutos')).hide();
}

// ── Autocomplete ──
const inputNome  = document.getElementById('inputNome');
const inputTel   = document.getElementById('inputTel');
const lista      = document.getElementById('listaAuto');
const telAutoTag = document.getElementById('telAutoTag');
let debounceTimer;

function inicialLetra(nome) { return nome ? nome.trim().charAt(0).toUpperCase() : '?'; }

function renderLista(itens, query) {
  lista.innerHTML = '';
  const novo = document.createElement('div');
  novo.className = 'autocomplete-novo';
  novo.innerHTML = `<i class="bi bi-person-plus" style="color:#e94560"></i>
    Adicionar "<strong>${query}</strong>" como novo <span class="badge-novo ms-auto">Novo</span>`;
  novo.addEventListener('mousedown', () => {
    inputNome.value = query; inputTel.value = '';
    telAutoTag.style.display = 'none'; lista.classList.remove('aberta');
  });
  lista.appendChild(novo);
  itens.forEach(item => {
    const div = document.createElement('div');
    div.className = 'autocomplete-item';
    const visitas = parseInt(item.total_visitas) || 0;
    const ultV    = item.ultima_visita ? new Date(item.ultima_visita).toLocaleDateString('pt-BR') : null;
    div.innerHTML = `
      <div class="autocomplete-avatar">${inicialLetra(item.nome)}</div>
      <div style="min-width:0;flex:1">
        <div class="autocomplete-nome">${item.nome}</div>
        <div class="autocomplete-tel">${item.telefone || 'Sem telefone'}${ultV ? ' · última: '+ultV : ''}</div>
      </div>
      ${visitas > 0 ? `<div class="autocomplete-visitas"><i class="bi bi-scissors me-1"></i>${visitas}x</div>` : ''}
    `;
    div.addEventListener('mousedown', () => {
      inputNome.value = item.nome;
      inputTel.value  = item.telefone || '';
      telAutoTag.style.display = item.telefone ? 'inline' : 'none';
      lista.classList.remove('aberta');
    });
    lista.appendChild(div);
  });
  lista.classList.add('aberta');
}

inputNome.addEventListener('input', function() {
  const q = this.value.trim();
  telAutoTag.style.display = 'none';
  clearTimeout(debounceTimer);
  if (q.length < 1) { lista.classList.remove('aberta'); return; }
  lista.innerHTML = `<div class="autocomplete-loading"><div class="spinner-border spinner-border-sm text-danger me-2"></div>Buscando...</div>`;
  lista.classList.add('aberta');
  debounceTimer = setTimeout(async () => {
    try {
      const res = await fetch(`dashboard.php?buscar_cliente=${encodeURIComponent(q)}`);
      renderLista(await res.json(), q);
    } catch(e) { lista.classList.remove('aberta'); }
  }, 280);
});
inputNome.addEventListener('blur', () => setTimeout(() => lista.classList.remove('aberta'), 150));

setTimeout(() => location.reload(), 120000);
</script>
<?php if (file_exists(__DIR__ . '/../sw.js')): ?>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope)).catch(e => console.log('SW erro:', e));
  });
}


</script>
<?php endif; ?>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body>
</html>