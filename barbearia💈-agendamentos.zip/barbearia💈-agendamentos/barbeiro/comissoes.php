<?php
require_once '../config.php';
requireLogin();
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');
$userId        = $_SESSION['usuario_id'] ?? 0;
$isAdmin       = isAdmin();

// Barbeiro logado ou selecionado pelo admin
$barId = $isAdmin ? (int)($_GET['barbeiro_id'] ?? 0) : null;
if (!$isAdmin) {
    $stmt = $db->prepare("SELECT id FROM usuarios WHERE id=? AND tipo='barbeiro'");
    $stmt->execute([$userId]);
    $barRow = $stmt->fetch();
    $barId  = $barRow['id'] ?? 0;
}

$mesFiltro = $_GET['mes'] ?? date('Y-m');

// ── Criar tabelas ──
$db->exec("
    CREATE TABLE IF NOT EXISTS comissao_regras (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        barbeiro_id INTEGER,
        servico_id  INTEGER,
        percentual  REAL DEFAULT 50,
        UNIQUE(barbeiro_id, servico_id)
    )
");

// ── POST (admin salva regras) ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isAdmin) {
    $acao = $_POST['acao'] ?? '';
    if ($acao === 'salvar_regras') {
        $bId = (int)($_POST['barbeiro_id'] ?? 0);
        foreach (($_POST['percentual'] ?? []) as $sId => $pct) {
            $sId = (int)$sId;
            $pct = max(0, min(100, (float)$pct));
            $db->prepare("
                INSERT INTO comissao_regras (barbeiro_id, servico_id, percentual)
                VALUES (?,?,?)
                ON CONFLICT(barbeiro_id, servico_id) DO UPDATE SET percentual=excluded.percentual
            ")->execute([$bId, $sId, $pct]);
        }
        flash('success', 'Comissões salvas!');
        header('Location: comissoes.php?barbeiro_id=' . $bId . '&mes=' . $mesFiltro); exit;
    }
}

// ── Barbeiros (para admin) ──
$todosBarbeiros = $isAdmin ? $db->query("SELECT id, nome, NULL as cor FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll() : [];

// ── Serviços com regras do barbeiro ──
$servicos = [];
if ($barId) {
    $stmt = $db->prepare("
        SELECT s.id, s.nome, s.preco,
               COALESCE(r.percentual, 50) AS percentual
        FROM servicos s
        LEFT JOIN comissao_regras r ON r.servico_id = s.id AND r.barbeiro_id = ?
        WHERE s.ativo = 1
        ORDER BY s.nome
    ");
    $stmt->execute([$barId]);
    $servicos = $stmt->fetchAll();
}

// ── Atendimentos do período com comissão calculada ──
$atendimentos = [];
$totalComissao = 0;
$totalFaturado = 0;
if ($barId) {
    $stmt = $db->prepare("
        SELECT f.id, f.finalizado_em, f.valor, 0,
               c.nome AS cliente_nome, s.nome AS servico_nome,
               COALESCE(r.percentual, 50) AS percentual
        FROM fila f
        LEFT JOIN clientes c ON c.id = f.cliente_id
        LEFT JOIN servicos s ON s.id = f.servico_id
        LEFT JOIN comissao_regras r ON r.servico_id = f.servico_id AND r.barbeiro_id = f.barbeiro_id
        WHERE f.barbeiro_id = ?
          AND f.status = 'concluido'
          AND strftime('%Y-%m', f.finalizado_em) = ?
        ORDER BY f.finalizado_em DESC
    ");
    $stmt->execute([$barId, $mesFiltro]);
    $atendimentos = $stmt->fetchAll();

    foreach ($atendimentos as &$a) {
        $base = $a['valor'] ?? 0;
        $a['comissao'] = round($base * $a['percentual'] / 100, 2);
        $totalComissao += $a['comissao'];
        $totalFaturado += $base + ($a['0'] ?? 0);
    }
    unset($a);
}

// Barbeiro info
$barInfo = null;
if ($barId) {
    $stmt = $db->prepare("SELECT nome FROM usuarios WHERE tipo='barbeiro' AND id=?");
    $stmt->execute([$barId]);
    $barInfo = $stmt->fetch();
    if ($barInfo) $barInfo['cor'] = '#e94560';
}

// Resumo por serviço
$resumoServico = [];
foreach ($atendimentos as $a) {
    $k = $a['servico_nome'] ?? 'Sem serviço';
    if (!isset($resumoServico[$k])) $resumoServico[$k] = ['qtd'=>0,'base'=>0,'comissao'=>0,'pct'=>$a['percentual']];
    $resumoServico[$k]['qtd']++;
    $resumoServico[$k]['base'] += $a['valor'] ?? 0;
    $resumoServico[$k]['comissao'] += $a['comissao'];
}

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Comissões – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
  }
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
  border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.2rem;text-align:center}
.stat-value{font-size:1.6rem;font-weight:800;color:#fff;line-height:1}
.stat-label{color:rgba(255,255,255,.45);font-size:.78rem;margin-top:.3rem}
.form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
  color:#fff;border-radius:10px;padding:.55rem .85rem;width:100%;font-size:.88rem}
.form-control-dark:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
select.form-control-dark option{background:#1a1a2e}
.btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;
  border-radius:10px;padding:.7rem 1.4rem;font-weight:700;cursor:pointer;transition:all .3s;font-size:.9rem}
.btn-primary-custom:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(233,69,96,.4)}
.trow{display:flex;align-items:center;gap:.65rem;padding:.55rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
.trow:last-child{border-bottom:none}
h4,h5,h6{color:#fff;margin:0}
@media(max-width:768px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.page-body{padding:1rem}}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel do Barbeiro</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(233,69,96,.2);color:#e94560">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Barbeiro') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Barbeiro</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Meu Painel</div>
    <a href="dashboard.php"         class="<?= navActive('dashboard.php',         $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="minha-agenda.php"      class="<?= navActive('minha-agenda.php',      $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Minha Agenda</a>
    <a href="comissoes.php"         class="<?= navActive('comissoes.php',         $paginaAtual) ?>"><i class="bi bi-percent"></i>Comissões</a>
    <a href="historico.php"         class="<?= navActive('historico.php',         $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="adicionar_cliente.php" class="<?= navActive('adicionar_cliente.php', $paginaAtual) ?>"><i class="bi bi-person-plus-fill"></i>Adicionar Cliente</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Comissões</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($_SESSION['usuario_nome']??'') ?></span>
  </div>
</div>
<div class="page-body">

    <?= renderFlash() ?>

    <?php if (!$barId): ?>
    <div style="text-align:center;padding:4rem;color:rgba(255,255,255,.3)">
      <i class="bi bi-person-circle" style="font-size:3rem;display:block;margin-bottom:1rem"></i>
      Selecione um barbeiro para ver as comissões
    </div>
    <?php else: ?>

    <!-- Stats -->
    <div class="row g-3 mb-3">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#4ade80">R$ <?= number_format($totalComissao,2,',','.') ?></div>
          <div class="stat-label"><i class="bi bi-percent me-1"></i>Total Comissão</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#60a5fa">R$ <?= number_format($totalFaturado,2,',','.') ?></div>
          <div class="stat-label"><i class="bi bi-currency-dollar me-1"></i>Total Faturado</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#f59e0b"><?= count($atendimentos) ?></div>
          <div class="stat-label"><i class="bi bi-scissors me-1"></i>Atendimentos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#a78bfa">
            <?= $totalFaturado > 0 ? number_format($totalComissao / $totalFaturado * 100, 1) : 0 ?>%
          </div>
          <div class="stat-label"><i class="bi bi-graph-up me-1"></i>% Médio</div>
        </div>
      </div>
    </div>

    <div class="row g-3">

      <!-- Resumo por serviço -->
      <div class="col-12 col-lg-5">
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-pie-chart-fill" style="color:#f59e0b"></i>
            Resumo por Serviço — <?= date('m/Y', strtotime($mesFiltro.'-01')) ?>
          </div>
          <?php if (empty($resumoServico)): ?>
          <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25);font-size:.88rem">
            <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
            Nenhum atendimento neste período
          </div>
          <?php else: ?>
          <?php foreach ($resumoServico as $nome => $r): ?>
          <div class="trow">
            <div style="flex:1;min-width:0">
              <div style="font-size:.88rem;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($nome) ?></div>
              <div style="font-size:.73rem;color:rgba(255,255,255,.35)"><?= $r['qtd'] ?> atend. · <?= $r['pct'] ?>% comissão</div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-weight:800;color:#4ade80">R$ <?= number_format($r['comissao'],2,',','.') ?></div>
              <div style="font-size:.72rem;color:rgba(255,255,255,.35)">de R$ <?= number_format($r['base'],2,',','.') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <!-- Configurar % por serviço (só admin) -->
        <?php if ($isAdmin): ?>
        <div class="card-sec" style="border-color:rgba(233,69,96,.2)">
          <div class="card-title">
            <i class="bi bi-sliders" style="color:var(--primary)"></i>
            Configurar % por Serviço
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_regras">
            <input type="hidden" name="barbeiro_id" value="<?= $barId ?>">
            <?php foreach ($servicos as $s): ?>
            <div style="display:flex;align-items:center;gap:.75rem;padding:.45rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
              <div style="flex:1;font-size:.85rem;color:#fff"><?= htmlspecialchars($s['nome']) ?>
                <span style="color:rgba(255,255,255,.35);font-size:.75rem"> — R$ <?= number_format($s['preco'],2,',','.') ?></span>
              </div>
              <div style="display:flex;align-items:center;gap:.3rem;flex-shrink:0">
                <input type="number" step="0.5" min="0" max="100"
                       name="percentual[<?= $s['id'] ?>]"
                       value="<?= $s['percentual'] ?>"
                       style="width:65px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
                              color:#fff;border-radius:8px;padding:.3rem .5rem;text-align:center;font-size:.88rem">
                <span style="color:rgba(255,255,255,.4);font-size:.82rem">%</span>
              </div>
            </div>
            <?php endforeach; ?>
            <div style="margin-top:.85rem">
              <button type="submit" class="btn-primary-custom" style="font-size:.85rem;padding:.55rem 1.1rem">
                <i class="bi bi-check2 me-1"></i>Salvar Percentuais
              </button>
            </div>
          </form>
        </div>
        <?php endif; ?>
      </div>

      <!-- Extrato detalhado -->
      <div class="col-12 col-lg-7">
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-receipt" style="color:#8b5cf6"></i>
            Extrato Detalhado
            <span style="background:rgba(139,92,246,.12);color:#a78bfa;border-radius:20px;
              padding:.1rem .5rem;font-size:.72rem;margin-left:auto"><?= count($atendimentos) ?></span>
          </div>
          <div style="max-height:520px;overflow-y:auto">
          <?php if (empty($atendimentos)): ?>
          <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25);font-size:.88rem">
            <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
            Nenhum atendimento concluído neste período
          </div>
          <?php else: ?>
          <?php foreach ($atendimentos as $a): ?>
          <div class="trow">
            <div style="width:36px;height:36px;border-radius:10px;background:rgba(139,92,246,.15);
                        color:#a78bfa;display:flex;align-items:center;justify-content:center;
                        font-size:.78rem;font-weight:800;flex-shrink:0">
              <?= mb_strtoupper(mb_substr($a['cliente_nome'] ?? '?', 0, 1)) ?>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:.85rem;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                <?= htmlspecialchars($a['cliente_nome'] ?? '—') ?>
              </div>
              <div style="font-size:.73rem;color:rgba(255,255,255,.35)">
                <?= htmlspecialchars($a['servico_nome'] ?? '—') ?> ·
                <?= date('d/m H:i', strtotime($a['finalizado_em'])) ?> ·
                <?= $a['percentual'] ?>%
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-weight:800;color:#4ade80;font-size:.9rem">R$ <?= number_format($a['comissao'],2,',','.') ?></div>
              <div style="font-size:.72rem;color:rgba(255,255,255,.3)">de R$ <?= number_format($a['valor'],2,',','.') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
          </div>

          <!-- Total -->
          <?php if (!empty($atendimentos)): ?>
          <div style="border-top:2px solid rgba(255,255,255,.1);padding-top:.85rem;margin-top:.5rem;
                      display:flex;justify-content:space-between;align-items:center">
            <div style="font-weight:700;color:#fff">Total do período</div>
            <div style="font-size:1.3rem;font-weight:800;color:#4ade80">R$ <?= number_format($totalComissao,2,',','.') ?></div>
          </div>
          <?php endif; ?>
        </div>
      </div>

    </div>
    <?php endif; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
<script>
document.getElementById('btnMenu')?.addEventListener('click', () =>
  document.getElementById('sidebar').classList.toggle('open'));
</script>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body>
</html>
