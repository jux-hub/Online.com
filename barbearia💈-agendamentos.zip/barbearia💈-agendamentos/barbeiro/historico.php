<?php
require_once '../config.php';
function navActive(string $a, string $b): string { return basename($b)===$a?'nav-link-side active':'nav-link-side'; }
$paginaAtual = __FILE__;
requireLogin();
$db      = getDB();
$barb_id = $_SESSION['usuario_id'];

$periodo = $_GET['periodo'] ?? 'mes';
$hoje    = date('Y-m-d');
switch($periodo) {
    case 'hoje':   $dataInicio = $hoje; break;
    case 'semana': $dataInicio = date('Y-m-d', strtotime('-7 days')); break;
    default:       $dataInicio = date('Y-m-01');
}

$stmt = $db->prepare("
    SELECT f.*, c.nome as cliente_nome, s.nome as servico_nome
    FROM fila f JOIN clientes c ON c.id=f.cliente_id LEFT JOIN servicos s ON s.id=f.servico_id
    WHERE f.barbeiro_id=? AND f.status='concluido' AND DATE(f.finalizado_em)>=?
    ORDER BY f.finalizado_em DESC
");
$stmt->execute([$barb_id, $dataInicio]);
$hist = $stmt->fetchAll();

$barbInfo      = $db->prepare('SELECT * FROM usuarios WHERE id=?'); $barbInfo->execute([$barb_id]); $barbInfo = $barbInfo->fetch();
$totalFat      = array_sum(array_column($hist,'valor'));
$totalCom      = $totalFat * ($barbInfo['comissao_percent']/100);
$nomeBarbearia = getConfig('nome_barbearia');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Meu Histórico – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
  }
  
  }
  .stat-mini{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:1rem;text-align:center}
  .stat-val{font-size:1.5rem;font-weight:800;color:#fff}
  .section-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:1.25rem;overflow:hidden}
  .btn-periodo{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.7);border-radius:8px;padding:.4rem .9rem;font-size:.875rem;transition:.2s;text-decoration:none}
  .btn-periodo.active,.btn-periodo:hover{background:var(--primary);border-color:var(--primary);color:#fff}
  h5{color:#fff}
  .tabela-hist{width:100%;border-collapse:collapse}
  .tabela-hist thead tr{background:rgba(255,255,255,.06)}
  .tabela-hist th{color:rgba(255,255,255,.55);font-weight:600;font-size:.78rem;text-transform:uppercase;letter-spacing:.5px;padding:.75rem 1rem;border-bottom:1px solid rgba(255,255,255,.08);white-space:nowrap}
  .tabela-hist td{padding:.75rem 1rem;border-bottom:1px solid rgba(255,255,255,.05);color:#e0e0e0;font-size:.88rem;vertical-align:middle;background:#0f0f23}
  .tabela-hist tbody tr:last-child td{border-bottom:none}
  .tabela-hist tbody tr:hover td{background:rgba(255,255,255,.04)}
  .td-data{color:rgba(255,255,255,.5);font-size:.8rem;white-space:nowrap}
  .td-comissao{color:#fbbf24;font-weight:700;font-size:1rem}
  .td-dash{color:rgba(255,255,255,.25)}
  .pgto-tag{display:inline-flex;align-items:center;gap:.3rem;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:6px;padding:.2rem .55rem;font-size:.78rem;color:rgba(255,255,255,.7);white-space:nowrap}
  .servico-tag{display:inline-flex;align-items:center;gap:.3rem;background:rgba(59,130,246,.15);border-radius:6px;padding:.2rem .55rem;font-size:.78rem;color:#60a5fa}
  .btn-comprovante{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.55);border-radius:8px;padding:.3rem .65rem;font-size:.82rem;text-decoration:none;transition:.2s;display:inline-flex;align-items:center;gap:.3rem}
  .btn-comprovante:hover{background:rgba(233,69,96,.2);border-color:var(--primary);color:#fff}
  @media(max-width:600px){
    .tabela-hist th:nth-child(3),.tabela-hist td:nth-child(3){display:none}
    .tabela-hist th,.tabela-hist td{padding:.65rem .65rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel do Barbeiro</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(233,69,96,.2);color:#e94560">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Barbeiro') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Barbeiro</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Meu Painel</div>
    <a href="dashboard.php"         class="<?= navActive('dashboard.php',         $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="minha-agenda.php"      class="<?= navActive('minha-agenda.php',      $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Minha Agenda</a>
    <a href="comissoes.php"         class="<?= navActive('comissoes.php',         $paginaAtual) ?>"><i class="bi bi-percent"></i>Comissões</a>
    <a href="historico.php"         class="<?= navActive('historico.php',         $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="adicionar_cliente.php" class="<?= navActive('adicionar_cliente.php', $paginaAtual) ?>"><i class="bi bi-person-plus-fill"></i>Adicionar Cliente</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Histórico</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($_SESSION['usuario_nome']??'') ?></span>
  </div>
</div>
<div class="page-body">

  <div class="d-flex gap-2 mb-4 flex-wrap">
    <?php foreach(['hoje'=>'Hoje','semana'=>'7 dias','mes'=>'Este Mês'] as $v=>$l): ?>
    <a href="?periodo=<?= $v ?>" class="btn-periodo <?= $periodo===$v?'active':'' ?>"><?= $l ?></a>
    <?php endforeach; ?>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-6">
      <div class="stat-mini">
        <div class="stat-val"><?= count($hist) ?></div>
        <div style="color:rgba(255,255,255,.45);font-size:.8rem">Cortes</div>
      </div>
    </div>
    <div class="col-6">
      <div class="stat-mini">
        <div class="stat-val" style="color:#fbbf24;font-size:1.15rem"><?= formatMoney($totalCom) ?></div>
        <div style="color:rgba(255,255,255,.45);font-size:.8rem">Minha Comissão</div>
      </div>
    </div>
  </div>

  <div class="section-card">
    <?php if(empty($hist)): ?>
      <div class="text-center py-4" style="color:rgba(255,255,255,.3)">
        <i class="bi bi-inbox fs-1 d-block mb-2"></i>Nenhum atendimento no período
      </div>
    <?php else: ?>
    <div class="table-responsive">
      <table class="tabela-hist">
        <thead>
          <tr>
            <th>Data/Hora</th>
            <th>Cliente</th>
            <th>Serviço</th>
            <th>Pagamento</th>
            <th>Comissão</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($hist as $h):
            $com = ($h['valor']??0) * ($barbInfo['comissao_percent']/100);
            $pgIcons = ['pix'=>'bi-qr-code','dinheiro'=>'bi-cash','debito'=>'bi-credit-card','credito'=>'bi-credit-card-2-front'];
            $icon    = $pgIcons[$h['forma_pagamento']??''] ?? 'bi-dash';
            // ── CORRIGIDO: mesmo salt do comprovante.php ──
            $keyComp = substr(md5($h['id'] . 'barbearia_renato'), 0, 8);
          ?>
          <tr>
            <td class="td-data">
              <?= $h['finalizado_em'] ? date('d/m', strtotime($h['finalizado_em'])) : '–' ?><br>
              <span style="color:rgba(255,255,255,.35)"><?= $h['finalizado_em'] ? date('H:i', strtotime($h['finalizado_em'])) : '' ?></span>
            </td>
            <td style="font-weight:600;color:#fff"><?= htmlspecialchars($h['cliente_nome']) ?></td>
            <td>
              <?php if($h['servico_nome']): ?>
                <span class="servico-tag"><i class="bi bi-scissors"></i><?= htmlspecialchars($h['servico_nome']) ?></span>
              <?php else: ?>
                <span class="td-dash">–</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if($h['forma_pagamento']): ?>
                <span class="pgto-tag"><i class="bi <?= $icon ?>"></i><?= ucfirst($h['forma_pagamento']) ?></span>
              <?php else: ?>
                <span class="td-dash">–</span>
              <?php endif; ?>
            </td>
            <td class="td-comissao"><?= $h['valor'] ? formatMoney($com) : '<span class="td-dash">–</span>' ?></td>
            <td>
              <?php if($h['valor']): ?>
              <a href="../comprovante.php?id=<?= $h['id'] ?>&key=<?= $keyComp ?>" target="_blank" class="btn-comprovante">
                <i class="bi bi-receipt"></i>
              </a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body>
</html>