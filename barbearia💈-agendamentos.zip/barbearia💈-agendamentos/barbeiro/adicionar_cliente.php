<?php
require_once '../config.php';
function navActive(string $a, string $b): string { return basename($b)===$a?'nav-link-side active':'nav-link-side'; }
$paginaAtual = __FILE__;
requireLogin();
if (!isBarbeiro() && !isAdmin()) { header('Location: ../login.php'); exit; }

$db      = getDB();
$barb_id = $_SESSION['usuario_id'];

// ── API autocomplete ──
if (isset($_GET['buscar_cliente'])) {
    header('Content-Type: application/json');
    $q = '%' . trim($_GET['buscar_cliente']) . '%';
    $stmt = $db->prepare("
        SELECT c.nome, c.telefone, COUNT(f.id) as total_visitas
        FROM clientes c
        LEFT JOIN fila f ON f.cliente_id = c.id AND f.status = 'concluido'
        WHERE c.nome LIKE ? OR c.telefone LIKE ?
        GROUP BY c.id ORDER BY total_visitas DESC, c.nome ASC LIMIT 8
    ");
    $stmt->execute([$q, $q]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome       = trim($_POST['cliente_nome'] ?? '');
    $telefone   = trim($_POST['cliente_fone'] ?? '');
    $servico_id = (int)($_POST['servico_id']  ?? 0) ?: null;

    if (!$nome) { flash('danger', 'Informe o nome do cliente.'); }
    else {
        // Busca ou cria cliente
        if ($telefone) {
            $stmtC = $db->prepare("SELECT id FROM clientes WHERE telefone=? LIMIT 1");
            $stmtC->execute([$telefone]);
            $cli = $stmtC->fetch();
        } else {
            $cli = null;
        }

        if ($cli) {
            $cli_id = $cli['id'];
            $db->prepare("UPDATE clientes SET nome=? WHERE id=?")->execute([$nome, $cli_id]);
        } else {
            $db->prepare("INSERT INTO clientes (nome, telefone) VALUES (?, ?)")->execute([$nome, $telefone]);
            $cli_id = $db->lastInsertId();
        }

        // Posição na fila
        $stmtP = $db->prepare("SELECT COALESCE(MAX(posicao),0)+1 as prox FROM fila WHERE barbeiro_id=? AND status='aguardando'");
        $stmtP->execute([$barb_id]);
        $pos = (int)$stmtP->fetch()['prox'];

        $db->prepare("INSERT INTO fila (cliente_id, barbeiro_id, servico_id, posicao, status, criado_em)
                      VALUES (?, ?, ?, ?, 'aguardando', CURRENT_TIMESTAMP)")
           ->execute([$cli_id, $barb_id, $servico_id, $pos]);

        flash('success', "Cliente <strong>{$nome}</strong> adicionado à fila!");
        header('Location: dashboard.php'); exit;
    }
}

$servicos      = $db->query("SELECT * FROM servicos WHERE ativo=1 ORDER BY nome")->fetchAll();
$nomeBarbearia = getConfig('nome_barbearia');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Adicionar Cliente – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
  }
  .btn-voltar{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:8px;padding:.4rem .85rem;text-decoration:none;font-size:.9rem;
    display:flex;align-items:center;gap:.4rem;transition:.2s}
  .btn-voltar:hover{background:rgba(255,255,255,.15);color:#fff}

  .form-card{background:rgba(255,255,255,.04);border:1px solid rgba(233,69,96,.2);
    border-radius:18px;padding:1.5rem;margin-bottom:1rem}
  .form-card-title{font-size:1rem;font-weight:700;color:#fff;
    display:flex;align-items:center;gap:.5rem;margin-bottom:1.25rem}

  .form-lbl{color:rgba(255,255,255,.65);font-size:.82rem;display:block;margin-bottom:.35rem;font-weight:600}
  .fc{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;
    border-radius:12px;padding:.65rem 1rem;font-size:.95rem;width:100%;transition:.2s}
  .fc:focus{outline:none;border-color:var(--primary);background:rgba(255,255,255,.12);
    box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .fc::placeholder{color:rgba(255,255,255,.3)}
  .fc option{background:#1a1a2e}

  /* Autocomplete */
  .autocomplete-wrap{position:relative}
  .autocomplete-lista{position:absolute;top:calc(100% + 4px);left:0;right:0;
    background:#1a1a2e;border:1px solid rgba(233,69,96,.35);border-radius:12px;
    z-index:999;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.5);display:none}
  .autocomplete-lista.aberta{display:block}
  .autocomplete-item{padding:.65rem 1rem;cursor:pointer;transition:.15s;
    display:flex;align-items:center;gap:.75rem;border-bottom:1px solid rgba(255,255,255,.05)}
  .autocomplete-item:last-child{border-bottom:none}
  .autocomplete-item:hover{background:rgba(233,69,96,.15)}
  .auto-avatar{width:34px;height:34px;border-radius:50%;
    background:linear-gradient(135deg,#e94560,#c41230);
    display:flex;align-items:center;justify-content:center;
    flex-shrink:0;font-size:.85rem;font-weight:700;color:#fff}
  .auto-nome{font-weight:600;color:#fff;font-size:.88rem}
  .auto-tel{font-size:.75rem;color:rgba(255,255,255,.45)}
  .auto-visitas{margin-left:auto;background:rgba(255,255,255,.08);border-radius:20px;
    padding:.12rem .5rem;font-size:.7rem;color:rgba(255,255,255,.4);white-space:nowrap;flex-shrink:0}
  .autocomplete-novo{padding:.65rem 1rem;cursor:pointer;color:rgba(255,255,255,.5);
    font-size:.85rem;display:flex;align-items:center;gap:.5rem;transition:.15s}
  .autocomplete-novo:hover{background:rgba(255,255,255,.05);color:#fff}
  .badge-novo{background:rgba(34,197,94,.2);color:#4ade80;border-radius:20px;
    padding:.1rem .5rem;font-size:.7rem;font-weight:700;flex-shrink:0;margin-left:auto}
  .autocomplete-loading{padding:.65rem 1rem;color:rgba(255,255,255,.4);
    font-size:.85rem;display:flex;align-items:center;gap:.5rem}

  /* Tag telefone preenchido */
  .tag-tel{background:rgba(34,197,94,.2);color:#4ade80;border-radius:20px;
    padding:.1rem .5rem;font-size:.7rem;font-weight:700;margin-left:.4rem}

  /* Serviços como cards clicáveis */
  .servico-grid{display:grid;grid-template-columns:1fr 1fr;gap:.6rem;margin-top:.25rem}
  .servico-opt{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);
    border-radius:12px;padding:.75rem;cursor:pointer;transition:.2s;position:relative}
  .servico-opt:hover{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.25)}
  .servico-opt.sel{background:rgba(233,69,96,.15);border-color:rgba(233,69,96,.5)}
  .servico-opt input{position:absolute;opacity:0;width:0;height:0}
  .servico-nome{font-size:.88rem;font-weight:700;color:#fff}
  .servico-preco{font-size:.78rem;color:rgba(255,255,255,.45);margin-top:.15rem}
  .servico-opt.sel .servico-preco{color:#e94560}
  .servico-sem{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
    border-radius:12px;padding:.65rem;cursor:pointer;transition:.2s;margin-bottom:.6rem}
  .servico-sem:hover{background:rgba(255,255,255,.08)}
  .servico-sem.sel{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.25)}
  .servico-sem input{position:absolute;opacity:0;width:0;height:0}

  /* Botão submit */
  .btn-submit{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;
    border-radius:14px;padding:.85rem;font-weight:800;font-size:1rem;width:100%;
    cursor:pointer;transition:.2s;display:flex;align-items:center;justify-content:center;gap:.5rem;
    margin-top:.5rem}
  .btn-submit:hover{opacity:.9;transform:translateY(-1px)}
  .btn-submit:active{transform:translateY(0)}

  /* Cliente selecionado badge */
  .cli-selecionado{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);
    border-radius:10px;padding:.6rem .85rem;display:flex;align-items:center;gap:.6rem;margin-bottom:.5rem}
  .cli-sel-avatar{width:32px;height:32px;border-radius:50%;
    background:linear-gradient(135deg,#22c55e,#16a34a);
    display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:#fff;flex-shrink:0}
  .cli-sel-nome{font-weight:700;color:#fff;font-size:.9rem}
  .cli-sel-sub{font-size:.75rem;color:rgba(255,255,255,.45)}

  .alert-danger-dark{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.3);
    color:#f87171;border-radius:12px;padding:.85rem 1rem;margin-bottom:1rem;font-size:.9rem}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel do Barbeiro</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(233,69,96,.2);color:#e94560">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Barbeiro') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Barbeiro</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Meu Painel</div>
    <a href="dashboard.php"         class="<?= navActive('dashboard.php',         $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="minha-agenda.php"      class="<?= navActive('minha-agenda.php',      $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Minha Agenda</a>
    <a href="comissoes.php"         class="<?= navActive('comissoes.php',         $paginaAtual) ?>"><i class="bi bi-percent"></i>Comissões</a>
    <a href="historico.php"         class="<?= navActive('historico.php',         $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="adicionar_cliente.php" class="<?= navActive('adicionar_cliente.php', $paginaAtual) ?>"><i class="bi bi-person-plus-fill"></i>Adicionar Cliente</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Adicionar Cliente</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($_SESSION['usuario_nome']??'') ?></span>
  </div>
</div>
<div class="page-body">

  <?= renderFlash() ?>

  <form method="POST" id="formAdd">

    <!-- ── Card: Cliente ── -->
    <div class="form-card">
      <div class="form-card-title">
        <i class="bi bi-person-fill" style="color:#e94560"></i>
        Dados do Cliente
      </div>

      <!-- Cliente selecionado (aparece após autocomplete) -->
      <div id="cliSelecionado" style="display:none" class="cli-selecionado">
        <div class="cli-sel-avatar" id="cliAvatar">?</div>
        <div>
          <div class="cli-sel-nome" id="cliSelNome">—</div>
          <div class="cli-sel-sub" id="cliSelSub">Cliente cadastrado</div>
        </div>
        <button type="button" onclick="limparCliente()"
          style="margin-left:auto;background:none;border:none;color:rgba(255,255,255,.4);
                 font-size:1.1rem;cursor:pointer;padding:0;line-height:1">
          <i class="bi bi-x-circle"></i>
        </button>
      </div>

      <div class="mb-3">
        <label class="form-lbl">
          Nome do cliente *
        </label>
        <div class="autocomplete-wrap">
          <input type="text" name="cliente_nome" id="inputNome" class="fc"
            placeholder="Digite para buscar ou adicionar…"
            required autocomplete="off">
          <div class="autocomplete-lista" id="listaAuto"></div>
        </div>
      </div>

      <div>
        <label class="form-lbl">
          WhatsApp
          <span id="telTag" class="tag-tel" style="display:none">
            <i class="bi bi-check2"></i> preenchido
          </span>
        </label>
        <input type="tel" name="cliente_fone" id="inputTel" class="fc"
          placeholder="(00) 00000-0000">
      </div>
    </div>

    <!-- ── Card: Serviço ── -->
    <div class="form-card">
      <div class="form-card-title">
        <i class="bi bi-scissors" style="color:#e94560"></i>
        Serviço
        <span style="font-size:.72rem;color:rgba(255,255,255,.35);font-weight:400">(opcional)</span>
      </div>

      <!-- Sem serviço -->
      <label class="servico-sem sel" id="optSemServico">
        <input type="radio" name="servico_id" value="" checked>
        <div style="display:flex;align-items:center;gap:.5rem">
          <i class="bi bi-dash-circle" style="color:rgba(255,255,255,.4)"></i>
          <span style="font-size:.88rem;color:rgba(255,255,255,.6);font-weight:600">Sem serviço</span>
        </div>
      </label>

      <!-- Grid de serviços -->
      <?php if (!empty($servicos)): ?>
      <div class="servico-grid">
        <?php foreach ($servicos as $sv): ?>
        <label class="servico-opt" id="opt_<?= $sv['id'] ?>">
          <input type="radio" name="servico_id" value="<?= $sv['id'] ?>">
          <div class="servico-nome"><?= htmlspecialchars($sv['nome']) ?></div>
          <div class="servico-preco">R$ <?= number_format($sv['preco'], 2, ',', '.') ?></div>
        </label>
        <?php endforeach; ?>
      </div>
      <?php else: ?>
        <div style="color:rgba(255,255,255,.3);font-size:.85rem;text-align:center;padding:.5rem 0">
          Nenhum serviço cadastrado
        </div>
      <?php endif; ?>
    </div>

    <!-- ── Botão ── -->
    <button type="submit" class="btn-submit" id="btnSubmit">
      <i class="bi bi-person-plus-fill"></i>
      Adicionar à Fila
    </button>

  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
<script>
const inputNome = document.getElementById('inputNome');
const inputTel  = document.getElementById('inputTel');
const lista     = document.getElementById('listaAuto');
const telTag    = document.getElementById('telTag');
let debounceTimer;

// ── Autocomplete ──
function inicialLetra(nome) { return nome ? nome.trim().charAt(0).toUpperCase() : '?'; }

function renderLista(itens, query) {
  lista.innerHTML = ''; 

  // Opção "adicionar novo"
  const novo = document.createElement('div');
  novo.className = 'autocomplete-novo';
  novo.innerHTML = `<i class="bi bi-person-plus" style="color:#e94560"></i>
    Adicionar "<strong>${query}</strong>" como novo
    <span class="badge-novo">Novo</span>`;
  novo.addEventListener('mousedown', () => {
    inputNome.value = query;
    inputTel.value  = '';
    telTag.style.display = 'none';
    lista.classList.remove('aberta');
    esconderCliSelecionado();
  });
  lista.appendChild(novo);

  itens.forEach(item => {
    const div = document.createElement('div');
    div.className = 'autocomplete-item';
    const visitas = parseInt(item.total_visitas) || 0;
    div.innerHTML = `
      <div class="auto-avatar">${inicialLetra(item.nome)}</div>
      <div style="min-width:0">
        <div class="auto-nome">${item.nome}</div>
        <div class="auto-tel">${item.telefone || 'Sem telefone'}</div>
      </div>
      ${visitas > 0 ? `<div class="auto-visitas"><i class="bi bi-scissors me-1"></i>${visitas}x</div>` : ''}
    `;
    div.addEventListener('mousedown', () => {
      inputNome.value = item.nome;
      inputTel.value  = item.telefone || '';
      telTag.style.display = item.telefone ? 'inline' : 'none';
      lista.classList.remove('aberta');
      mostrarCliSelecionado(item.nome, item.telefone, visitas);
    });
    lista.appendChild(div);
  });

  lista.classList.add('aberta');
}

inputNome.addEventListener('input', function() {
  const q = this.value.trim();
  telTag.style.display = 'none';
  esconderCliSelecionado();
  clearTimeout(debounceTimer);
  if (q.length < 1) { lista.classList.remove('aberta'); return; }
  lista.innerHTML = `<div class="autocomplete-loading">
    <div class="spinner-border spinner-border-sm text-danger me-2"></div>Buscando...</div>`;
  lista.classList.add('aberta');
  debounceTimer = setTimeout(async () => {
    try {
      const res  = await fetch(`adicionar_cliente.php?buscar_cliente=${encodeURIComponent(q)}`);
      const data = await res.json();
      renderLista(data, q);
    } catch(e) { lista.classList.remove('aberta'); }
  }, 280);
});

inputNome.addEventListener('blur', () => setTimeout(() => lista.classList.remove('aberta'), 150));
inputTel.addEventListener('input', () => { telTag.style.display = 'none'; });

// ── Badge cliente selecionado ──
function mostrarCliSelecionado(nome, tel, visitas) {
  document.getElementById('cliSelecionado').style.display = 'flex';
  document.getElementById('cliAvatar').textContent = inicialLetra(nome);
  document.getElementById('cliSelNome').textContent = nome;
  document.getElementById('cliSelSub').textContent  = visitas > 0
    ? `Cliente cadastrado · ${visitas} visita${visitas !== 1 ? 's' : ''}`
    : 'Cliente cadastrado';
  inputNome.style.display = 'none';
  inputTel.style.display  = 'none';
  document.querySelector('label[for="inputTel"]')?.classList?.add('d-none');
}
function esconderCliSelecionado() {
  document.getElementById('cliSelecionado').style.display = 'none';
  inputNome.style.display = '';
  inputTel.style.display  = '';
}
function limparCliente() {
  esconderCliSelecionado();
  inputNome.value = '';
  inputTel.value  = '';
  telTag.style.display = 'none';
  inputNome.focus();
}

// ── Serviços ──
const todasOpts = document.querySelectorAll('.servico-opt, .servico-sem');
todasOpts.forEach(label => {
  label.addEventListener('click', () => {
    todasOpts.forEach(l => l.classList.remove('sel'));
    label.classList.add('sel');
  });
});

// ── Submit feedback ──
document.getElementById('formAdd').addEventListener('submit', function() {
  const btn = document.getElementById('btnSubmit');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Adicionando...';
});
</script>
<?php if (file_exists(__DIR__ . '/../sw.js')): ?>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope)).catch(e => console.log('SW erro:', e));
  });
}
</script>
<?php endif; ?>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body>
</html>