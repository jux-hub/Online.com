<?php
require_once '../config.php';
requireLogin();
if (!isBarbeiro() && !isAdmin()) { header('Location: ../login.php'); exit; }
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');
$userId        = $_SESSION['usuario_id'] ?? 0;

// Barbeiro logado (usuarios onde id = usuario_id da sessão)
$stmt = $db->prepare("SELECT * FROM usuarios WHERE id=? AND tipo='barbeiro'");
$stmt->execute([$userId]);
$barbeiro = $stmt->fetch();
if (!$barbeiro && !isAdmin()) { header('Location: dashboard.php'); exit; }
$barId  = $barbeiro['id'] ?? 0;
$corBar = '#e94560';

// ── POST: pausas ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    $db->exec("CREATE TABLE IF NOT EXISTS barbeiro_pausas (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        barbeiro_id INTEGER NOT NULL,
        inicio      DATETIME NOT NULL,
        fim         DATETIME,
        motivo      TEXT DEFAULT 'Pausa',
        ativo       INTEGER DEFAULT 1
    )");

    if ($acao === 'iniciar_pausa') {
        // Fechar pausa ativa se existir
        $db->prepare("UPDATE barbeiro_pausas SET fim=CURRENT_TIMESTAMP, ativo=0
                      WHERE barbeiro_id=? AND ativo=1")->execute([$barId]);
        $motivo = trim($_POST['motivo'] ?? 'Pausa');
        $db->prepare("INSERT INTO barbeiro_pausas (barbeiro_id, inicio, motivo) VALUES (?,CURRENT_TIMESTAMP,?)")
           ->execute([$barId, $motivo]);
        flash('success', 'Pausa iniciada!');

    } elseif ($acao === 'encerrar_pausa') {
        $db->prepare("UPDATE barbeiro_pausas SET fim=CURRENT_TIMESTAMP, ativo=0
                      WHERE barbeiro_id=? AND ativo=1")->execute([$barId]);
        flash('success', 'Pausa encerrada!');
    }
    header('Location: minha-agenda.php'); exit;
}

// ── Criar tabela de pausas se não existir ──
$db->exec("CREATE TABLE IF NOT EXISTS barbeiro_pausas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barbeiro_id INTEGER NOT NULL,
    inicio DATETIME NOT NULL,
    fim DATETIME,
    motivo TEXT DEFAULT 'Pausa',
    ativo INTEGER DEFAULT 1
)");

// ── Pausa ativa ──
$pausaAtiva = $db->prepare("SELECT * FROM barbeiro_pausas WHERE barbeiro_id=? AND ativo=1 LIMIT 1");
$pausaAtiva->execute([$barId]);
$pausaAtiva = $pausaAtiva->fetch();

// ── Filtro de período ──
$periodo = $_GET['periodo'] ?? 'hoje';
switch ($periodo) {
    case 'semana': $dataInicio = date('Y-m-d', strtotime('monday this week')); $dataFim = date('Y-m-d', strtotime('sunday this week')); break;
    case 'mes':    $dataInicio = date('Y-m-01'); $dataFim = date('Y-m-t'); break;
    default:       $dataInicio = $dataFim = date('Y-m-d'); $periodo = 'hoje';
}

// ── Atendimentos do período ──
$stmt = $db->prepare("
    SELECT f.*, s.nome AS servico_nome, c.nome AS cliente_nome,
           COALESCE(cr.percentual, 50) AS pct_comissao
    FROM fila f
    LEFT JOIN servicos s ON s.id = f.servico_id
    LEFT JOIN clientes c ON c.id = f.cliente_id
    LEFT JOIN comissao_regras cr ON cr.servico_id = f.servico_id AND cr.barbeiro_id = f.barbeiro_id
    WHERE f.barbeiro_id=? AND f.status='concluido'
      AND DATE(f.finalizado_em) BETWEEN ? AND ?
    ORDER BY f.finalizado_em DESC
");
$stmt->execute([$barId, $dataInicio, $dataFim]);
$atendimentos = $stmt->fetchAll();

$totalFaturado  = array_sum(array_column($atendimentos, 'valor'));
$totalComissao  = array_sum(array_map(fn($a) => $a['valor'] * $a['pct_comissao'] / 100, $atendimentos));
$totalAtend     = count($atendimentos);

// ── Agendamentos do dia ──
$agendamentos = [];
try {
    $stmt = $db->prepare("
        SELECT ag.*, s.nome AS servico_nome
        FROM agendamentos ag
        LEFT JOIN servicos s ON s.id = ag.servico_id
        WHERE ag.barbeiro_id=? AND DATE(ag.data_hora)=DATE('now')
          AND ag.status NOT IN ('cancelado','faltou')
        ORDER BY ag.data_hora ASC
    ");
    $stmt->execute([$barId]);
    $agendamentos = $stmt->fetchAll();
} catch (Exception $e) {}

// ── Ranking do mês ──
$ranking = $db->query("
    SELECT b.id, b.nome, NULL,
           COUNT(f.id) AS atend,
           COALESCE(SUM(f.valor),0) AS faturado
    FROM usuarios b
    LEFT JOIN fila f ON f.barbeiro_id=b.id AND f.status='concluido'
        AND strftime('%Y-%m',f.finalizado_em)=strftime('%Y-%m','now')
    WHERE b.ativo=1 AND b.tipo='barbeiro'
    GROUP BY b.id
    ORDER BY faturado DESC
")->fetchAll();

// Posição do barbeiro no ranking
$posRank = 0;
foreach ($ranking as $i => $r) {
    if ($r['id'] == $barId) { $posRank = $i + 1; break; }
}

// ── Pausas do dia ──
$pausas = $db->prepare("
    SELECT *, ROUND((julianday(COALESCE(fim,CURRENT_TIMESTAMP))-julianday(inicio))*1440) AS minutos
    FROM barbeiro_pausas
    WHERE barbeiro_id=? AND DATE(inicio)=DATE('now')
    ORDER BY inicio DESC
");
$pausas->execute([$barId]);
$pausas = $pausas->fetchAll();
$totalPausaMin = array_sum(array_column($pausas, 'minutos'));

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Minha Agenda – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
  }
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
  border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.2rem;text-align:center}
.stat-value{font-size:1.6rem;font-weight:800;color:#fff;line-height:1}
.stat-label{color:rgba(255,255,255,.4);font-size:.75rem;margin-top:.3rem}
.periodo-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  color:rgba(255,255,255,.55);border-radius:20px;padding:.3rem .85rem;
  font-size:.8rem;font-weight:600;cursor:pointer;transition:.2s;text-decoration:none}
.periodo-btn:hover,.periodo-btn.active{background:rgba(233,69,96,.15);border-color:rgba(233,69,96,.3);color:#fff}
.rank-item{display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
.rank-item:last-child{border-bottom:none}
.ag-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
  border-radius:12px;padding:.85rem;margin-bottom:.5rem;display:flex;align-items:center;gap:.85rem}
.pausa-ativa{background:rgba(245,158,11,.08);border:2px solid rgba(245,158,11,.3);border-radius:14px;padding:1rem}
.btn-pausa{border:none;border-radius:10px;padding:.65rem 1.25rem;font-weight:700;cursor:pointer;transition:all .3s;font-size:.88rem}
h4,h5,h6{color:#fff;margin:0}
@media(max-width:768px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.page-body{padding:1rem}}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel do Barbeiro</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(233,69,96,.2);color:#e94560">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Barbeiro') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Barbeiro</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Meu Painel</div>
    <a href="dashboard.php"         class="<?= navActive('dashboard.php',         $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="minha-agenda.php"      class="<?= navActive('minha-agenda.php',      $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Minha Agenda</a>
    <a href="comissoes.php"         class="<?= navActive('comissoes.php',         $paginaAtual) ?>"><i class="bi bi-percent"></i>Comissões</a>
    <a href="historico.php"         class="<?= navActive('historico.php',         $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="adicionar_cliente.php" class="<?= navActive('adicionar_cliente.php', $paginaAtual) ?>"><i class="bi bi-person-plus-fill"></i>Adicionar Cliente</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Minha Agenda</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($_SESSION['usuario_nome']??'') ?></span>
  </div>
</div>
<div class="page-body">

    <?= renderFlash() ?>

    <!-- Stats do período -->
    <div class="row g-3 mb-3">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#4ade80">R$ <?= number_format($totalFaturado,2,',','.') ?></div>
          <div class="stat-label"><i class="bi bi-currency-dollar me-1"></i>Faturado</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#fbbf24">R$ <?= number_format($totalComissao,2,',','.') ?></div>
          <div class="stat-label"><i class="bi bi-percent me-1"></i>Minha Comissão</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#60a5fa"><?= $totalAtend ?></div>
          <div class="stat-label"><i class="bi bi-scissors me-1"></i>Atendimentos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:<?= $posRank === 1 ? '#fbbf24' : '#fff' ?>">
            <?= $posRank ? "#{$posRank}" : '—' ?>
            <?= $posRank === 1 ? ' 🏆' : '' ?>
          </div>
          <div class="stat-label"><i class="bi bi-trophy me-1"></i>Ranking do mês</div>
        </div>
      </div>
    </div>

    <div class="row g-3">

      <!-- Coluna esquerda -->
      <div class="col-12 col-lg-8">

        <!-- Agendamentos do dia -->
        <div class="card-sec" style="border-color:rgba(233,69,96,.15)">
          <div class="card-title">
            <i class="bi bi-calendar-check" style="color:var(--primary)"></i>
            Agendamentos de Hoje
            <span style="background:rgba(233,69,96,.12);color:var(--primary);border-radius:20px;
              padding:.1rem .5rem;font-size:.72rem;margin-left:auto"><?= count($agendamentos) ?></span>
          </div>
          <?php if (empty($agendamentos)): ?>
          <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.85rem">
            <i class="bi bi-calendar-x" style="font-size:1.8rem;display:block;margin-bottom:.4rem"></i>
            Nenhum agendamento hoje
          </div>
          <?php else: ?>
          <?php
          $statusColors = [
            'pendente'  => ['#fbbf24','rgba(245,158,11,.15)'],
            'confirmado'=> ['#60a5fa','rgba(59,130,246,.15)'],
            'concluido' => ['#4ade80','rgba(34,197,94,.15)'],
          ];
          foreach ($agendamentos as $ag):
            [$sc,$sb] = $statusColors[$ag['status']] ?? ['#9ca3af','rgba(107,114,128,.15)'];
          ?>
          <div class="ag-item">
            <div style="background:rgba(255,255,255,.07);border-radius:10px;padding:.5rem .7rem;
                        text-align:center;flex-shrink:0;min-width:52px">
              <div style="font-size:1rem;font-weight:800;color:#fff"><?= date('H:i',strtotime($ag['data_hora'])) ?></div>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-weight:700;color:#fff;font-size:.9rem"><?= htmlspecialchars($ag['cliente_nome']) ?></div>
              <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
                <?= htmlspecialchars($ag['servico_nome'] ?? '—') ?> · <?= $ag['duracao_min'] ?? 30 ?>min
              </div>
            </div>
            <span style="background:<?= $sb ?>;color:<?= $sc ?>;border-radius:20px;
                         padding:.2rem .6rem;font-size:.7rem;font-weight:700;flex-shrink:0">
              <?= ucfirst($ag['status']) ?>
            </span>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>

        <!-- Atendimentos do período -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-list-check" style="color:#8b5cf6"></i>
            Atendimentos — <?= $periodo === 'hoje' ? 'Hoje' : ($periodo === 'semana' ? 'Esta Semana' : 'Este Mês') ?>
            <span style="background:rgba(139,92,246,.12);color:#a78bfa;border-radius:20px;
              padding:.1rem .5rem;font-size:.72rem;margin-left:auto"><?= $totalAtend ?></span>
          </div>
          <div style="max-height:340px;overflow-y:auto">
          <?php if (empty($atendimentos)): ?>
          <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.85rem">
            <i class="bi bi-inbox" style="font-size:1.8rem;display:block;margin-bottom:.4rem"></i>
            Nenhum atendimento neste período
          </div>
          <?php else: ?>
          <?php foreach ($atendimentos as $at):
            $comissao = $at['valor'] * $at['pct_comissao'] / 100;
          ?>
          <div style="display:flex;align-items:center;gap:.65rem;padding:.55rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <div style="width:32px;height:32px;border-radius:8px;background:<?= htmlspecialchars(($corBar ?? '#e94560')) ?>22;
                        color:<?= htmlspecialchars(($corBar ?? '#e94560')) ?>;display:flex;align-items:center;
                        justify-content:center;font-size:.78rem;font-weight:800;flex-shrink:0">
              <?= mb_strtoupper(mb_substr($at['cliente_nome'] ?? '?', 0, 1)) ?>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:.85rem;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                <?= htmlspecialchars($at['cliente_nome'] ?? '—') ?>
              </div>
              <div style="font-size:.73rem;color:rgba(255,255,255,.35)">
                <?= htmlspecialchars($at['servico_nome'] ?? '—') ?> · <?= date('d/m H:i', strtotime($at['finalizado_em'])) ?>
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-weight:700;color:#4ade80;font-size:.88rem">R$ <?= number_format($comissao,2,',','.') ?></div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.3)"><?= $at['pct_comissao'] ?>% de R$ <?= number_format($at['valor'],2,',','.') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
          </div>
          <?php if (!empty($atendimentos)): ?>
          <div style="border-top:1px solid rgba(255,255,255,.08);padding-top:.75rem;margin-top:.5rem;
                      display:flex;justify-content:space-between">
            <span style="color:rgba(255,255,255,.4);font-size:.82rem">Total comissão</span>
            <strong style="color:#4ade80">R$ <?= number_format($totalComissao,2,',','.') ?></strong>
          </div>
          <?php endif; ?>
        </div>

      </div>

      <!-- Coluna direita -->
      <div class="col-12 col-lg-4">

        <!-- Pausa -->
        <div class="card-sec" style="border-color:rgba(245,158,11,.2)">
          <div class="card-title">
            <i class="bi bi-pause-circle" style="color:#f59e0b"></i>
            Pausa / Intervalo
          </div>

          <?php if ($pausaAtiva): ?>
          <div class="pausa-ativa mb-3">
            <div style="font-size:.75rem;color:#fbbf24;font-weight:700;margin-bottom:.25rem">
              <i class="bi bi-pause-circle-fill me-1"></i>EM PAUSA
            </div>
            <div style="font-weight:700;color:#fff"><?= htmlspecialchars($pausaAtiva['motivo']) ?></div>
            <div style="font-size:.78rem;color:rgba(255,255,255,.45);margin-top:.2rem">
              Desde <?= date('H:i', strtotime($pausaAtiva['inicio'])) ?>
            </div>
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="encerrar_pausa">
            <button type="submit" class="btn-pausa w-100"
              style="background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff">
              <i class="bi bi-play-fill me-1"></i>Encerrar Pausa
            </button>
          </form>

          <?php else: ?>
          <form method="POST">
            <input type="hidden" name="acao" value="iniciar_pausa">
            <select name="motivo" style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
              color:#fff;border-radius:10px;padding:.55rem .85rem;width:100%;font-size:.88rem;margin-bottom:.65rem">
              <option value="Almoço">🍽️ Almoço</option>
              <option value="Lanche">☕ Lanche</option>
              <option value="Banheiro">🚿 Banheiro</option>
              <option value="Pausa">⏸️ Pausa</option>
              <option value="Outro">📌 Outro</option>
            </select>
            <button type="submit" class="btn-pausa w-100"
              style="background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff">
              <i class="bi bi-pause-fill me-1"></i>Iniciar Pausa
            </button>
          </form>
          <?php endif; ?>

          <!-- Pausas do dia -->
          <?php if (!empty($pausas)): ?>
          <div style="margin-top:.85rem;border-top:1px solid rgba(255,255,255,.07);padding-top:.75rem">
            <div style="font-size:.75rem;color:rgba(255,255,255,.35);margin-bottom:.5rem;font-weight:600">
              Pausas hoje · <?= $totalPausaMin ?>min total
            </div>
            <?php foreach ($pausas as $p): ?>
            <div style="display:flex;justify-content:space-between;font-size:.78rem;padding:.2rem 0;
                        color:rgba(255,255,255,.45);border-bottom:1px solid rgba(255,255,255,.04)">
              <span><?= htmlspecialchars($p['motivo']) ?></span>
              <span><?= date('H:i',strtotime($p['inicio'])) ?> → <?= $p['fim'] ? date('H:i',strtotime($p['fim'])) : 'agora' ?>
                (<?= $p['minutos'] ?>min)</span>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>

        <!-- Ranking do mês -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-trophy-fill" style="color:#fbbf24"></i>
            Ranking do Mês
          </div>
          <?php foreach ($ranking as $i => $r):
            $pos  = $i + 1;
            $isMe = $r['id'] == $barId;
            $corR = htmlspecialchars(($r['cor'] ?? '#e94560') ?? '#e94560');
            $maxFat = $ranking[0]['faturado'] ?: 1;
            $pct  = round($r['faturado'] / $maxFat * 100);
            $medal = match($pos) { 1 => '🥇', 2 => '🥈', 3 => '🥉', default => "#{$pos}" };
          ?>
          <div class="rank-item" style="<?= $isMe ? 'background:rgba(255,255,255,.04);border-radius:10px;padding:.5rem .65rem;margin:-.25rem -.25rem;' : '' ?>">
            <div style="width:24px;text-align:center;font-size:<?= $pos <= 3 ? '1.1rem' : '.82rem' ?>;flex-shrink:0;color:rgba(255,255,255,.5)">
              <?= $medal ?>
            </div>
            <div style="width:32px;height:32px;border-radius:50%;background:<?= $corR ?>22;color:<?= $corR ?>;
                        display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.8rem;flex-shrink:0">
              <?= mb_strtoupper(mb_substr($r['nome'],0,1)) ?>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:.85rem;font-weight:<?= $isMe ? '800' : '600' ?>;color:#fff;
                          white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                <?= htmlspecialchars($r['nome']) ?> <?= $isMe ? '← você' : '' ?>
              </div>
              <div style="height:4px;background:rgba(255,255,255,.08);border-radius:10px;margin-top:.25rem;overflow:hidden">
                <div style="height:100%;width:<?= $pct ?>%;background:<?= $corR ?>;border-radius:10px"></div>
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-size:.82rem;font-weight:700;color:#4ade80">R$ <?= number_format($r['faturado'],0,',','.') ?></div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.3)"><?= $r['atend'] ?> atend.</div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
<script>
document.getElementById('btnMenu')?.addEventListener('click', () =>
  document.getElementById('sidebar').classList.toggle('open'));
</script>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body>
</html>
