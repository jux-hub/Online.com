<?php
require_once '../config.php';
function navActive(string $a, string $b): string { return basename($b)===$a?'nav-link-side active':'nav-link-side'; }
$paginaAtual = __FILE__;
requireLogin();
if (!isBarbeiro() && !isAdmin()) { header('Location: ../login.php'); exit; }

$db      = getDB();
$barb_id = $_SESSION['usuario_id'];

// ── Migração: garante coluna motivo_remocao na tabela fila ──
try {
    $db->exec("ALTER TABLE fila ADD COLUMN motivo_remocao TEXT");
} catch(Exception $e) {}

// ── Busca produtos e pacotes separados ──
$produtos = [];
$pacotes  = [];
try {
    $produtos = $db->query("SELECT id, nome, descricao, preco, 'produto' as tipo FROM produtos WHERE ativo=1 ORDER BY nome")->fetchAll();
} catch(Exception $e) {}
try {
    $pacotes = $db->query("SELECT id, nome, descricao, preco, 'pacote' as tipo FROM pacotes WHERE ativo=1 ORDER BY nome")->fetchAll();
} catch(Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'iniciar') {
        $id = (int)$_POST['id'];
        $db->prepare("UPDATE fila SET status='atendendo', iniciado_em=CURRENT_TIMESTAMP WHERE id=? AND barbeiro_id=?")
           ->execute([$id, $barb_id]);
        flash('success','Atendimento iniciado!');
    }

    if ($acao === 'finalizar') {
        $id    = (int)$_POST['id'];
        $valor = (float)str_replace(',','.', $_POST['valor'] ?? 0);
        $pgto  = $_POST['forma_pagamento'] ?? null;
        if (!in_array($pgto, ['pix','dinheiro','debito','credito'])) $pgto = null;

        $extras = $_POST['extras'] ?? '';

        $db->prepare("UPDATE fila SET status='concluido', valor=?, forma_pagamento=?,
                      finalizado_em=CURRENT_TIMESTAMP WHERE id=? AND barbeiro_id=?")
           ->execute([$valor, $pgto, $id, $barb_id]);

        if ($extras) {
            try {
                $itens = json_decode($extras, true);
                foreach ($itens as $item) {
                    $qty = (int)($item['qty'] ?? 1);
$db->prepare("INSERT INTO fila_itens (fila_id, produto_id, pacote_id, nome, preco, quantidade, subtotal) VALUES (?,?,?,?,?,?,?)")
   ->execute([
       $id,
       $item['tipo'] === 'produto' ? ($item['id'] ?? null) : null,
       $item['tipo'] === 'pacote'  ? ($item['id'] ?? null) : null,
       $item['nome'],
       $item['preco'],
       $qty,
       $item['preco'] * $qty,
   ]);
                }
            } catch(Exception $e) {}
        }

        require_once '../whatsapp/config.php';
        $stmtCli = $db->prepare("SELECT c.nome, c.telefone FROM fila f JOIN clientes c ON c.id=f.cliente_id WHERE f.id=?");
        $stmtCli->execute([$id]);
        $cli = $stmtCli->fetch();
        $nomeBarbeariaWa = getConfig('nome_barbearia');
        if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbeariaWa);
        if ($cli && $valor > 0) {
            $keyComp = substr(md5($id . 'barbearia_renato'), 0, 8);
            $urlComp = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'
                     . $_SERVER['HTTP_HOST'] . BASE_URL . "/comprovante.php?id={$id}&key={$keyComp}";
            $msg = montarMensagemConclusao($cli['nome'], $valor, $pgto ?? 'dinheiro');
            $msg .= "\n\n📄 Comprovante: {$urlComp}";
            @enviarWhatsApp($cli['telefone'], $msg);
        }

        $keyLink = substr(md5($id . 'barbearia_renato'), 0, 8);
        flash('success',"Finalizado! <a href='../comprovante.php?id={$id}&key={$keyLink}' target='_blank' class='alert-link'><i class='bi bi-receipt me-1'></i>Ver comprovante</a>");
    }

    if ($acao === 'remover') {
        $id     = (int)$_POST['id'];
        $motivo = $_POST['motivo'] ?? 'desistiu';
        $db->prepare("UPDATE fila SET status=?, motivo_remocao=?, finalizado_em=CURRENT_TIMESTAMP
                      WHERE id=? AND barbeiro_id=?")
           ->execute([$motivo, $motivo, $id, $barb_id]);
        $label = $motivo === 'faltou' ? 'Marcado como Faltou.' : 'Marcado como Desistiu.';
        flash('success', $label);
    }

    if ($acao === 'cancelar') {
        $id = (int)$_POST['id'];
        $db->prepare("UPDATE fila SET status='cancelado' WHERE id=? AND barbeiro_id=? AND status='aguardando'")
           ->execute([$id, $barb_id]);
        flash('success','Cliente removido da fila.');
    }

    header('Location: dashboard.php'); exit;
}

// ── Migração: tabela fila_itens ──
try {
    $db->exec("CREATE TABLE IF NOT EXISTS fila_itens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fila_id INTEGER NOT NULL,
        produto_id INTEGER,
        nome TEXT NOT NULL,
        preco REAL DEFAULT 0,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch(Exception $e) {}

$fila = $db->prepare("
    SELECT f.*, c.nome as cliente_nome, c.telefone, s.nome as servico_nome, s.preco as servico_preco
    FROM fila f JOIN clientes c ON c.id=f.cliente_id LEFT JOIN servicos s ON s.id=f.servico_id
    WHERE f.barbeiro_id=? AND f.status IN ('aguardando','atendendo')
    ORDER BY f.status DESC, f.criado_em ASC
");
$fila->execute([$barb_id]);
$fila = $fila->fetchAll();

$hoje  = date('Y-m-d');
$stmt  = $db->prepare("SELECT COUNT(*) as cortes, COALESCE(SUM(valor),0) as fat FROM fila WHERE barbeiro_id=? AND status='concluido' AND DATE(finalizado_em)=?");
$stmt->execute([$barb_id, $hoje]);
$stats = $stmt->fetch();

$barbInfo      = $db->prepare('SELECT * FROM usuarios WHERE id=?'); $barbInfo->execute([$barb_id]); $barbInfo = $barbInfo->fetch();
$comissao_dia  = $stats['fat'] * ($barbInfo['comissao_percent']/100);
$nomeBarbearia = getConfig('nome_barbearia');
$tempoMedio    = (int)getConfig('tempo_medio_corte');

$stmtProx = $db->prepare("
    SELECT f.id, c.nome as cliente_nome, c.telefone, s.nome as servico_nome
    FROM fila f
    JOIN clientes c ON c.id = f.cliente_id
    LEFT JOIN servicos s ON s.id = f.servico_id
    WHERE f.barbeiro_id = ? AND f.status = 'aguardando'
    ORDER BY f.criado_em ASC LIMIT 1
");
$stmtProx->execute([$barb_id]);
$proximoCliente = $stmtProx->fetch();

$estaAtendendo = count(array_filter($fila, fn($c) => $c['status'] === 'atendendo')) > 0;

$temProdutos = !empty($produtos);
$temPacotes  = !empty($pacotes);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Minha Fila – <?= htmlspecialchars($_SESSION['usuario_nome']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
  .sidebar-user{padding:.75rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:.65rem}
  .sidebar-user-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.95rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.9rem;text-decoration:none}
  .nav-link-side:hover{background:rgba(233,69,96,.12);color:#fff}
  .nav-link-side.active{background:rgba(233,69,96,.18);color:#fff;border-left:3px solid var(--primary)}
  .nav-section{font-size:.68rem;font-weight:700;color:rgba(255,255,255,.28);padding:.85rem 1.5rem .2rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .65rem;cursor:pointer;font-size:1.25rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%);transition:.3s}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}
    .page-body{padding:1rem}
  }
  .card-fila-topo{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:1.25rem 1.5rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:1.25rem}
  .fila-count{display:flex;align-items:center;gap:.85rem}
  .fila-count-num{font-size:2.4rem;font-weight:900;color:#fff;line-height:1}
  .fila-count-lbl{font-size:.85rem;color:rgba(255,255,255,.45);margin-top:.2rem}
  .btn-add-fila{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:12px;padding:.7rem 1.4rem;font-weight:700;font-size:.95rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.5rem;text-decoration:none;white-space:nowrap;flex-shrink:0}
  .btn-add-fila:hover{opacity:.88;transform:translateY(-1px);color:#fff}

  .cliente-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:1.25rem;margin-bottom:.85rem}
  .cliente-card.atendendo{border-color:rgba(34,197,94,.5);background:rgba(34,197,94,.07)}
  .pos-circle{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:1.1rem;flex-shrink:0;background:rgba(233,69,96,.18);color:#e94560}
  .pos-circle.atd{background:rgba(34,197,94,.2);color:#4ade80}
  .btn-iniciar{background:linear-gradient(135deg,#22c55e,#16a34a);border:none;color:#fff;border-radius:10px;padding:.55rem 1.1rem;font-weight:600;transition:.2s;cursor:pointer}
  .btn-iniciar:hover{opacity:.9}
  .btn-finalizar{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;padding:.7rem 1.1rem;font-weight:700;transition:.2s;cursor:pointer;width:100%;font-size:.97rem}
  .btn-finalizar:hover{opacity:.9}
  .btn-cancel{background:rgba(239,68,68,.15);color:#f87171;border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:.5rem .9rem;cursor:pointer}
  .btn-cancel:hover{background:rgba(239,68,68,.25);color:#fca5a5}
  .form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.12);border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.4)}
  .form-select option{background:#1a1a2e}
  .pgto-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);color:rgba(255,255,255,.7);border-radius:8px;padding:.4rem .75rem;font-size:.85rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.35rem}
  .pgto-btn:hover,.pgto-btn.sel{background:rgba(233,69,96,.2);border-color:var(--primary);color:#fff}
  .pgto-btn input{display:none}
  label{color:rgba(255,255,255,.8)}
  h4,h5,h6{color:#fff}
  .alert a{color:#fff;font-weight:700}

  .btn-produtos{background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.35);color:#60a5fa;border-radius:10px;padding:.6rem 1rem;font-weight:600;font-size:.88rem;cursor:pointer;transition:.2s;width:100%;display:flex;align-items:center;justify-content:center;gap:.45rem;margin-bottom:.6rem}
  .btn-produtos:hover{background:rgba(59,130,246,.28);border-color:rgba(59,130,246,.6);color:#93c5fd}

  .extras-badge{background:rgba(59,130,246,.15);border:1px dashed rgba(59,130,246,.4);border-radius:8px;padding:.5rem .75rem;margin-bottom:.6rem;font-size:.83rem;color:#93c5fd;display:none}
  .extras-badge .extra-item{display:flex;justify-content:space-between;align-items:center;padding:.2rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
  .extras-badge .extra-item:last-child{border-bottom:none}

  .btn-remover-atd{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.2);color:rgba(239,68,68,.7);border-radius:10px;padding:.55rem 1rem;font-weight:600;font-size:.85rem;cursor:pointer;transition:.2s;width:100%;display:flex;align-items:center;justify-content:center;gap:.45rem;margin-top:.5rem}
  .btn-remover-atd:hover{background:rgba(239,68,68,.18);border-color:rgba(239,68,68,.45);color:#f87171}

  .modal-dark .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.1);color:#e0e0e0;border-radius:18px}
  .modal-dark .modal-header{border-bottom:1px solid rgba(255,255,255,.08);padding:1.1rem 1.4rem .9rem}
  .modal-dark .modal-footer{border-top:1px solid rgba(255,255,255,.08);padding:.9rem 1.4rem}
  .modal-dark .modal-title{color:#fff;font-weight:700}
  .modal-dark .btn-close{filter:invert(1) opacity(.5)}
  .modal-dark .btn-close:hover{filter:invert(1) opacity(.9)}

  .produto-tipo-titulo{font-size:.72rem;font-weight:700;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.08em;margin:1rem 0 .4rem}
  .produto-item{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:.65rem .9rem;margin-bottom:.35rem;cursor:pointer;transition:.2s;gap:.75rem}
  .produto-item:hover{background:rgba(59,130,246,.12);border-color:rgba(59,130,246,.3)}
  .produto-item.selecionado{background:rgba(59,130,246,.18);border-color:rgba(59,130,246,.5)}
  .produto-item-nome{font-weight:600;color:#fff;font-size:.9rem}
  .produto-item-preco{color:#60a5fa;font-weight:700;font-size:.9rem;white-space:nowrap}
  .produto-item-qty{display:flex;align-items:center;gap:.4rem;background:rgba(255,255,255,.07);border-radius:8px;padding:.2rem .4rem}
  .qty-btn{background:none;border:none;color:#fff;cursor:pointer;font-size:1.1rem;line-height:1;padding:0 .2rem;transition:.15s}
  .qty-btn:hover{color:#e94560}
  .qty-num{min-width:18px;text-align:center;font-weight:700;color:#fff;font-size:.9rem}

  .motivo-btn{background:rgba(255,255,255,.05);border:2px solid rgba(255,255,255,.1);border-radius:14px;padding:1.1rem 1rem;cursor:pointer;transition:.25s;text-align:center;width:100%;color:#e0e0e0}
  .motivo-btn:hover{background:rgba(255,255,255,.1)}
  .motivo-btn.sel-faltou{background:rgba(234,179,8,.12);border-color:rgba(234,179,8,.5);color:#fde047}
  .motivo-btn.sel-desistiu{background:rgba(239,68,68,.12);border-color:rgba(239,68,68,.5);color:#f87171}
  .motivo-btn .motivo-icon{font-size:2rem;display:block;margin-bottom:.4rem}
  .motivo-btn .motivo-label{font-weight:700;font-size:1rem}
  .motivo-btn .motivo-desc{font-size:.78rem;opacity:.6;margin-top:.2rem}
  .btn-confirmar-remocao{background:linear-gradient(135deg,#ef4444,#b91c1c);border:none;color:#fff;border-radius:10px;padding:.7rem 1.4rem;font-weight:700;cursor:pointer;transition:.2s;width:100%;display:none}
  .btn-confirmar-remocao:hover{opacity:.9}
  .btn-confirmar-remocao.visivel{display:block}

  .btn-chamar-proximo{background:linear-gradient(135deg,#25d366,#128c7e);border:none;color:#fff;border-radius:12px;padding:.7rem 1.4rem;font-weight:700;font-size:.95rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.5rem;width:100%;justify-content:center}
  .btn-chamar-proximo:hover{opacity:.9;transform:translateY(-1px)}
  .chamar-banner{background:linear-gradient(135deg,rgba(37,211,102,.12),rgba(18,140,126,.12));border:1px solid rgba(37,211,102,.35);border-radius:16px;padding:1.1rem 1.25rem;margin-bottom:1.25rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap}
  .chamar-info{flex:1;min-width:0}
  .chamar-titulo{font-size:.78rem;color:rgba(255,255,255,.5);margin-bottom:.2rem}
  .chamar-nome{font-weight:700;color:#fff;font-size:1rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .chamar-servico{font-size:.8rem;color:rgba(255,255,255,.45);margin-top:.15rem}

  .btn-historico{display:flex;align-items:center;justify-content:center;gap:.6rem;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.18);color:rgba(255,255,255,.8);border-radius:12px;padding:.85rem 1rem;text-decoration:none;font-size:.95rem;font-weight:600;transition:.2s;margin-top:1.5rem}
  .btn-historico:hover{background:rgba(255,255,255,.13);border-color:rgba(255,255,255,.35);color:#fff;transform:translateY(-1px)}
  .btn-historico i{font-size:1.1rem;color:#e94560}

  @media(max-width:576px){}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel do Barbeiro</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="sidebar-user-avatar" style="background:rgba(233,69,96,.2);color:#e94560">
      <?= mb_strtoupper(mb_substr($_SESSION['usuario_nome']??'?',0,1)) ?>
    </div>
    <div style="min-width:0">
      <div style="color:#fff;font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($_SESSION['usuario_nome']??'Barbeiro') ?></div>
      <div style="color:rgba(255,255,255,.3);font-size:.68rem">Barbeiro</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Meu Painel</div>
    <a href="dashboard.php"         class="<?= navActive('dashboard.php',         $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="minha-agenda.php"      class="<?= navActive('minha-agenda.php',      $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Minha Agenda</a>
    <a href="comissoes.php"         class="<?= navActive('comissoes.php',         $paginaAtual) ?>"><i class="bi bi-percent"></i>Comissões</a>
    <a href="historico.php"         class="<?= navActive('historico.php',         $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="adicionar_cliente.php" class="<?= navActive('adicionar_cliente.php', $paginaAtual) ?>"><i class="bi bi-person-plus-fill"></i>Adicionar Cliente</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700">Minha Fila</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="color:rgba(255,255,255,.5);font-size:.82rem"><?= htmlspecialchars($_SESSION['usuario_nome']??'') ?></span>
  </div>
</div>
<div class="page-body">

  <?= renderFlash() ?>

  <div class="card-fila-topo">
    <div class="fila-count">
      <div class="fila-count-num"><?= count($fila) ?></div>
      <div>
        <div style="color:#fff;font-weight:700;font-size:1rem">Na fila agora</div>
        <div class="fila-count-lbl">cliente<?= count($fila) !== 1 ? 's' : '' ?> aguardando</div>
      </div>
    </div>
    <a href="adicionar_cliente.php" class="btn-add-fila">
      <i class="bi bi-person-plus-fill"></i>Adicionar
    </a>
  </div>

  <?php
  if ($estaAtendendo && $proximoCliente && !empty($proximoCliente['telefone'])):
    $telLimpo = preg_replace('/\D/', '', $proximoCliente['telefone']);
    if (strlen($telLimpo) <= 11) $telLimpo = '55' . $telLimpo;
    $nomeBarb    = htmlspecialchars($_SESSION['usuario_nome']);
    $nomeProximo = $proximoCliente['cliente_nome'];
    $servicoTxt  = $proximoCliente['servico_nome'] ? ' para ' . $proximoCliente['servico_nome'] : '';
    $msgWa = "✂️ *{$nomeBarbearia}*\n\nOlá, *{$nomeProximo}*! 👋\n\nÉ *quase a sua vez*! 🔔\nBarbeiro *{$nomeBarb}* está terminando o atendimento atual.\n\nPor favor, *dirija-se à barbearia* agora{$servicoTxt}. ✂️\n\nAté já! 💈";
    $urlWa = 'https://wa.me/' . $telLimpo . '?text=' . rawurlencode($msgWa);
  ?>
  <div class="chamar-banner">
    <div class="chamar-info">
      <div class="chamar-titulo"><i class="bi bi-person-fill me-1"></i>Próximo na fila</div>
      <div class="chamar-nome"><?= htmlspecialchars($nomeProximo) ?></div>
      <?php if($proximoCliente['servico_nome']): ?>
      <div class="chamar-servico"><i class="bi bi-scissors me-1"></i><?= htmlspecialchars($proximoCliente['servico_nome']) ?></div>
      <?php endif; ?>
    </div>
    <a href="<?= $urlWa ?>" target="_blank" class="btn-chamar-proximo" style="width:auto;flex-shrink:0">
      <i class="bi bi-whatsapp"></i>Chamar Próximo
    </a>
  </div>
  <?php elseif($estaAtendendo && $proximoCliente && empty($proximoCliente['telefone'])): ?>
  <div class="chamar-banner">
    <div class="chamar-info">
      <div class="chamar-titulo"><i class="bi bi-person-fill me-1"></i>Próximo na fila</div>
      <div class="chamar-nome"><?= htmlspecialchars($proximoCliente['cliente_nome']) ?></div>
      <?php if($proximoCliente['servico_nome']): ?>
      <div class="chamar-servico"><i class="bi bi-scissors me-1"></i><?= htmlspecialchars($proximoCliente['servico_nome']) ?></div>
      <?php endif; ?>
    </div>
    <span style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.45);border-radius:10px;padding:.55rem 1rem;font-size:.82rem;white-space:nowrap">
      <i class="bi bi-telephone-slash me-1"></i>Sem telefone
    </span>
  </div>
  <?php endif; ?>

  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0 fw-bold"><i class="bi bi-list-ol me-2" style="color:#e94560"></i>Minha Fila</h5>
    <small style="color:rgba(255,255,255,.35)">Atualiza em 2min</small>
  </div>

  <?php if(empty($fila)): ?>
    <div class="text-center py-5" style="color:rgba(255,255,255,.3)">
      <i class="bi bi-check2-all" style="font-size:3rem;display:block;margin-bottom:1rem"></i>
      Fila vazia! Aproveite o descanso ✂️
    </div>
  <?php endif; ?>

  <?php foreach($fila as $i => $c): ?>
  <div class="cliente-card <?= $c['status']==='atendendo'?'atendendo':'' ?>">
    <div class="d-flex gap-3 align-items-start">
      <div class="pos-circle <?= $c['status']==='atendendo'?'atd':'' ?>">
        <?= $c['status']==='atendendo' ? '<i class="bi bi-scissors" style="font-size:.85rem"></i>' : ($i+1) ?>
      </div>
      <div class="flex-grow-1">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-1 mb-1">
          <div>
            <span style="font-weight:700;color:#fff;font-size:1.05rem"><?= htmlspecialchars($c['cliente_nome']) ?></span>
            <span class="ms-2" style="font-size:.85rem;color:rgba(255,255,255,.5)"><?= htmlspecialchars($c['telefone']) ?></span>
          </div>
          <small style="color:rgba(255,255,255,.35)">Entrou <?= date('H:i', strtotime($c['criado_em'])) ?></small>
        </div>

        <?php if($c['servico_nome']): ?>
        <div class="mb-2">
          <span style="background:rgba(59,130,246,.2);color:#60a5fa;border-radius:6px;padding:.25rem .65rem;font-size:.82rem">
            <i class="bi bi-scissors me-1"></i><?= htmlspecialchars($c['servico_nome']) ?> – <?= formatMoney($c['servico_preco']) ?>
          </span>
        </div>
        <?php endif; ?>

        <?php if($c['status']==='aguardando'): ?>
        <div class="d-flex gap-2 mt-2 flex-wrap">
          <form method="POST" class="d-inline">
            <input type="hidden" name="acao" value="iniciar">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button class="btn-iniciar"><i class="bi bi-play-fill me-1"></i>Iniciar</button>
          </form>
          <form method="POST" class="d-inline">
            <input type="hidden" name="acao" value="cancelar">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button class="btn-cancel" type="submit" onclick="return confirm('Remover cliente da fila?')">
              <i class="bi bi-x-lg"></i>
            </button>
          </form>
        </div>

        <?php elseif($c['status']==='atendendo'): ?>
        <div class="mt-2 p-3" style="background:rgba(255,255,255,.04);border-radius:12px">
          <form method="POST" id="formFinalizar_<?= $c['id'] ?>">
            <input type="hidden" name="acao" value="finalizar">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <input type="hidden" name="extras" id="extrasInput_<?= $c['id'] ?>" value="[]">

            <div class="row g-2 align-items-end">
              <div class="col-12 col-sm-5">
                <label class="form-label" style="font-size:.85rem">Valor cobrado (R$)</label>
                <input type="text" name="valor" class="form-control form-control-sm mascara-valor"
                  placeholder="0,00" id="valor_<?= $c['id'] ?>"
                  value="<?= $c['servico_preco'] ? number_format($c['servico_preco'],2,',','.') : '' ?>">
              </div>
              <div class="col-12 col-sm-7">
                <label class="form-label" style="font-size:.85rem">Forma de pagamento</label>
                <div class="d-flex gap-1 flex-wrap">
                  <?php foreach(['pix'=>'PIX','dinheiro'=>'Dinheiro','debito'=>'Débito','credito'=>'Crédito'] as $v=>$l): ?>
                  <label class="pgto-btn">
                    <input type="radio" name="forma_pagamento" value="<?= $v ?>" form="formFinalizar_<?= $c['id'] ?>">
                    <?= $l ?>
                  </label>
                  <?php endforeach; ?>
                </div>
              </div>

              <div class="col-12">
                <button type="button" class="btn-produtos"
                  onclick="abrirModalProdutos(<?= $c['id'] ?>, '<?= addslashes(htmlspecialchars($c['cliente_nome'])) ?>')">
                  <i class="bi bi-bag-plus-fill"></i>Adicionar Produtos / Pacotes
                </button>
                <div class="extras-badge" id="extrasBadge_<?= $c['id'] ?>">
                  <div style="font-size:.75rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;font-weight:700">
                    <i class="bi bi-bag-check-fill me-1"></i>ITENS ADICIONADOS
                  </div>
                  <div id="extrasLista_<?= $c['id'] ?>"></div>
                  <div style="border-top:1px solid rgba(255,255,255,.08);margin-top:.4rem;padding-top:.4rem;display:flex;justify-content:space-between">
                    <span style="color:rgba(255,255,255,.5);font-size:.8rem">Total extras</span>
                    <span style="color:#60a5fa;font-weight:700" id="extrasTotal_<?= $c['id'] ?>">R$ 0,00</span>
                  </div>
                </div>
              </div>

              <div class="col-12">
                <button type="submit" class="btn-finalizar">
                  <i class="bi bi-check-lg me-1"></i>Finalizar Atendimento
                </button>
              </div>

              <div class="col-12">
                <button type="button" class="btn-remover-atd"
                  onclick="abrirModalRemover(<?= $c['id'] ?>, '<?= addslashes(htmlspecialchars($c['cliente_nome'])) ?>')">
                  <i class="bi bi-person-dash-fill"></i>Remover Atendimento
                </button>
              </div>
            </div>
          </form>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>

  <a href="historico.php" class="btn-historico">
    <i class="bi bi-clock-history"></i>
    Ver meu histórico
    <i class="bi bi-chevron-right ms-auto" style="color:rgba(255,255,255,.3);font-size:.85rem"></i>
  </a>

  <!-- Links rapidos bloco 3 -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem;margin-top:.65rem">
    <a href="minha-agenda.php" style="display:flex;align-items:center;gap:.5rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:12px;padding:.65rem .85rem;color:rgba(255,255,255,.7);text-decoration:none;font-size:.85rem;font-weight:600">
      <i class="bi bi-calendar3" style="color:#e94560"></i>Minha Agenda
    </a>
    <a href="comissoes.php" style="display:flex;align-items:center;gap:.5rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:12px;padding:.65rem .85rem;color:rgba(255,255,255,.7);text-decoration:none;font-size:.85rem;font-weight:600">
      <i class="bi bi-percent" style="color:#4ade80"></i>Comissoes
    </a>
  </div>
</div>

<!-- MODAL: Produtos / Pacotes -->
<div class="modal fade modal-dark" id="modalProdutos" tabindex="-1">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-bag-plus-fill me-2" style="color:#60a5fa"></i>Produtos & Pacotes</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="padding:1rem 1.25rem">
        <div style="font-size:.85rem;color:rgba(255,255,255,.45);margin-bottom:1rem" id="modalProdutosCliente"></div>

        <?php if (!$temProdutos && !$temPacotes): ?>
          <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.3)">
            <i class="bi bi-bag-x" style="font-size:2.5rem;display:block;margin-bottom:.75rem"></i>
            Nenhum produto ou pacote cadastrado.<br>
            <a href="../admin/produtos.php" style="color:#60a5fa;font-size:.85rem">Cadastrar agora →</a>
          </div>
        <?php else: ?>
          <?php if ($temProdutos): ?>
            <div class="produto-tipo-titulo">🧴 PRODUTOS</div>
            <?php foreach($produtos as $p): ?>
            <div class="produto-item" id="prodItem_<?= $p['id'] ?>_produto"
                 onclick="toggleItem('produto', <?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['nome'])) ?>', <?= $p['preco'] ?>)">
              <div>
                <div class="produto-item-nome"><?= htmlspecialchars($p['nome']) ?></div>
                <?php if(!empty($p['descricao'])): ?>
                <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-top:.15rem"><?= htmlspecialchars($p['descricao']) ?></div>
                <?php endif; ?>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span class="produto-item-preco"><?= formatMoney($p['preco']) ?></span>
                <div class="produto-item-qty" id="qtyBox_produto_<?= $p['id'] ?>" style="display:none!important">
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('produto',<?= $p['id'] ?>,-1)">−</button>
                  <span class="qty-num" id="qty_produto_<?= $p['id'] ?>">1</span>
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('produto',<?= $p['id'] ?>,+1)">+</button>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>

          <?php if ($temPacotes): ?>
            <div class="produto-tipo-titulo" style="margin-top:<?= $temProdutos ? '1.25rem' : '0' ?>">📦 PACOTES</div>
            <?php foreach($pacotes as $p): ?>
            <div class="produto-item" id="prodItem_<?= $p['id'] ?>_pacote"
                 onclick="toggleItem('pacote', <?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['nome'])) ?>', <?= $p['preco'] ?>)">
              <div>
                <div class="produto-item-nome"><?= htmlspecialchars($p['nome']) ?></div>
                <?php if(!empty($p['descricao'])): ?>
                <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-top:.15rem"><?= htmlspecialchars($p['descricao']) ?></div>
                <?php endif; ?>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span class="produto-item-preco"><?= formatMoney($p['preco']) ?></span>
                <div class="produto-item-qty" id="qtyBox_pacote_<?= $p['id'] ?>" style="display:none!important">
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('pacote',<?= $p['id'] ?>,-1)">−</button>
                  <span class="qty-num" id="qty_pacote_<?= $p['id'] ?>">1</span>
                  <button type="button" class="qty-btn" onclick="event.stopPropagation();alterarQtyItem('pacote',<?= $p['id'] ?>,+1)">+</button>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
      <div class="modal-footer justify-content-between align-items-center">
        <div>
          <span style="font-size:.8rem;color:rgba(255,255,255,.45)">Total selecionado</span><br>
          <span style="font-weight:800;color:#60a5fa;font-size:1.1rem" id="modalTotalProdutos">R$ 0,00</span>
        </div>
        <div class="d-flex gap-2">
          <button type="button" class="btn btn-sm"
            style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.6);border:none;border-radius:8px"
            data-bs-dismiss="modal">Cancelar</button>
          <button type="button" class="btn btn-sm"
            style="background:linear-gradient(135deg,#3b82f6,#1d4ed8);color:#fff;border:none;border-radius:8px;font-weight:700;padding:.5rem 1.1rem"
            onclick="confirmarProdutos()">
            <i class="bi bi-check-lg me-1"></i>Confirmar
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL: Remover Atendimento -->
<div class="modal fade modal-dark" id="modalRemover" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-person-dash-fill me-2" style="color:#f87171"></i>Remover Atendimento</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="padding:1.25rem">
        <p style="color:rgba(255,255,255,.6);font-size:.9rem;margin-bottom:1.1rem">
          Selecione o motivo da remoção de <strong id="modalRemoverNome" style="color:#fff"></strong>:
        </p>
        <div class="row g-3">
          <div class="col-6">
            <button type="button" class="motivo-btn" id="btnFaltou" onclick="selecionarMotivo('faltou')">
              <span class="motivo-icon">⏰</span>
              <span class="motivo-label">Faltou</span>
              <div class="motivo-desc">Cliente não compareceu</div>
            </button>
          </div>
          <div class="col-6">
            <button type="button" class="motivo-btn" id="btnDesistiu" onclick="selecionarMotivo('desistiu')">
              <span class="motivo-icon">🚪</span>
              <span class="motivo-label">Desistiu</span>
              <div class="motivo-desc">Cliente desistiu da vez</div>
            </button>
          </div>
        </div>
        <form method="POST" id="formRemover" style="margin-top:1rem">
          <input type="hidden" name="acao" value="remover">
          <input type="hidden" name="id" id="removerIdInput">
          <input type="hidden" name="motivo" id="removerMotivoInput">
          <button type="submit" class="btn-confirmar-remocao" id="btnConfirmarRemocao">
            <i class="bi bi-trash3-fill me-2"></i>Confirmar Remoção
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('btnMenu')?.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
<script>
document.querySelectorAll('.pgto-btn input').forEach(r => {
  r.addEventListener('change', function() {
    this.closest('.d-flex').querySelectorAll('.pgto-btn').forEach(b => b.classList.remove('sel'));
    this.closest('.pgto-btn').classList.add('sel');
  });
});

document.querySelectorAll('.mascara-valor').forEach(i => {
  i.addEventListener('input', function() {
    let v = this.value.replace(/\D/g,'');
    v = (parseInt(v||0)/100).toFixed(2).replace('.',',');
    this.value = v;
  });
});

setTimeout(() => location.reload(), 120000);

let modalFilaId = null;
let itensSel    = {};

function abrirModalProdutos(filaId, nomeCliente) {
  modalFilaId = filaId;
  document.getElementById('modalProdutosCliente').textContent = 'Adicionando para: ' + nomeCliente;
  const extrasRaw = document.getElementById('extrasInput_' + filaId).value;
  const extras    = JSON.parse(extrasRaw || '[]');
  document.querySelectorAll('.produto-item').forEach(el => el.classList.remove('selecionado'));
  document.querySelectorAll('[id^="qtyBox_"]').forEach(el => el.style.setProperty('display','none','important'));
  itensSel = {};
  extras.forEach(item => {
    const key = item.tipo + '_' + item.id;
    itensSel[key] = { id: item.id, tipo: item.tipo, nome: item.nome, preco: item.preco, qty: item.qty || 1 };
    const el = document.getElementById('prodItem_' + item.id + '_' + item.tipo);
    if (el) {
      el.classList.add('selecionado');
      const qtyBox = document.getElementById('qtyBox_' + item.tipo + '_' + item.id);
      if (qtyBox) qtyBox.style.removeProperty('display');
      const qtyNum = document.getElementById('qty_' + item.tipo + '_' + item.id);
      if (qtyNum) qtyNum.textContent = item.qty || 1;
    }
  });
  atualizarTotalModal();
  new bootstrap.Modal(document.getElementById('modalProdutos')).show();
}

function toggleItem(tipo, id, nome, preco) {
  const key = tipo + '_' + id;
  if (itensSel[key]) {
    delete itensSel[key];
    document.getElementById('prodItem_' + id + '_' + tipo).classList.remove('selecionado');
    document.getElementById('qtyBox_' + tipo + '_' + id).style.setProperty('display','none','important');
  } else {
    itensSel[key] = { id, tipo, nome, preco, qty: 1 };
    document.getElementById('prodItem_' + id + '_' + tipo).classList.add('selecionado');
    document.getElementById('qtyBox_' + tipo + '_' + id).style.removeProperty('display');
    document.getElementById('qty_' + tipo + '_' + id).textContent = 1;
  }
  atualizarTotalModal();
}

function alterarQtyItem(tipo, id, delta) {
  const key = tipo + '_' + id;
  if (!itensSel[key]) return;
  let q = itensSel[key].qty + delta;
  if (q < 1) { toggleItem(tipo, id, itensSel[key].nome, itensSel[key].preco); return; }
  itensSel[key].qty = q;
  document.getElementById('qty_' + tipo + '_' + id).textContent = q;
  atualizarTotalModal();
}

function atualizarTotalModal() {
  let total = 0;
  Object.values(itensSel).forEach(p => total += p.preco * p.qty);
  document.getElementById('modalTotalProdutos').textContent = 'R$ ' + total.toFixed(2).replace('.',',');
}

function confirmarProdutos() {
  if (!modalFilaId) return;
  const itens = Object.values(itensSel);
  document.getElementById('extrasInput_' + modalFilaId).value = JSON.stringify(itens);
  const badge = document.getElementById('extrasBadge_' + modalFilaId);
  const lista = document.getElementById('extrasLista_'  + modalFilaId);
  const tot   = document.getElementById('extrasTotal_'  + modalFilaId);
  if (itens.length === 0) {
    badge.style.display = 'none';
  } else {
    badge.style.display = 'block';
    lista.innerHTML = '';
    let totalExtras = 0;
    itens.forEach(item => {
      totalExtras += item.preco * item.qty;
      const div = document.createElement('div');
      div.className = 'extra-item';
      const tipoIcon = item.tipo === 'pacote' ? '📦 ' : '🧴 ';
      div.innerHTML = `<span>${tipoIcon}${item.qty > 1 ? item.qty + 'x ' : ''}${item.nome}</span>
        <span style="color:#60a5fa;font-weight:700">R$ ${(item.preco * item.qty).toFixed(2).replace('.',',')}</span>`;
      lista.appendChild(div);
    });
    tot.textContent = 'R$ ' + totalExtras.toFixed(2).replace('.',',');
    const inputValor = document.getElementById('valor_' + modalFilaId);
    if (!inputValor.dataset.base) inputValor.dataset.base = parseFloat(inputValor.value.replace(',','.')) || 0;
    const novoTotal = parseFloat(inputValor.dataset.base) + totalExtras;
    inputValor.value = novoTotal.toFixed(2).replace('.',',');
  }
  bootstrap.Modal.getInstance(document.getElementById('modalProdutos')).hide();
}

let motivoSelecionado = null;

function abrirModalRemover(filaId, nomeCliente) {
  motivoSelecionado = null;
  document.getElementById('removerIdInput').value = filaId;
  document.getElementById('modalRemoverNome').textContent = nomeCliente;
  document.getElementById('btnConfirmarRemocao').classList.remove('visivel');
  document.getElementById('btnFaltou').className   = 'motivo-btn';
  document.getElementById('btnDesistiu').className = 'motivo-btn';
  new bootstrap.Modal(document.getElementById('modalRemover')).show();
}

function selecionarMotivo(motivo) {
  motivoSelecionado = motivo;
  document.getElementById('removerMotivoInput').value = motivo;
  document.getElementById('btnFaltou').className   = 'motivo-btn' + (motivo==='faltou'   ? ' sel-faltou'   : '');
  document.getElementById('btnDesistiu').className = 'motivo-btn' + (motivo==='desistiu' ? ' sel-desistiu' : '');
  document.getElementById('btnConfirmarRemocao').classList.add('visivel');
}
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</div><!-- /page-body -->
</div><!-- /main-content -->
</body>
</html>