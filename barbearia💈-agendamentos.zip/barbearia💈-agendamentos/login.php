<?php
require_once 'config.php';

// Redireciona se já logado
if (isLoggedIn()) {
    if (isAdmin())          header('Location: ' . BASE_URL . '/admin/dashboard.php');
    elseif (isBarbeiro())   header('Location: ' . BASE_URL . '/barbeiro/dashboard.php');
    elseif (isAssistente()) header('Location: ' . BASE_URL . '/assistente/dashboard.php');
    else                    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

// ── Proteção brute force ──
$maxTentativas = 5;
$bloqueioMin   = 15;

if (!isset($_SESSION['login_tentativas']))    $_SESSION['login_tentativas']    = 0;
if (!isset($_SESSION['login_bloqueado_ate'])) $_SESSION['login_bloqueado_ate'] = 0;

$bloqueado    = false;
$segundosRest = 0;
if ($_SESSION['login_bloqueado_ate'] > time()) {
    $bloqueado    = true;
    $segundosRest = $_SESSION['login_bloqueado_ate'] - time();
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$bloqueado) {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (!$email || !$senha) {
        $erro = 'Preencha e-mail e senha.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare('SELECT * FROM usuarios WHERE email=? AND ativo=1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($senha, $user['senha'])) {
            $_SESSION['login_tentativas']    = 0;
            $_SESSION['login_bloqueado_ate'] = 0;
            $_SESSION['usuario_id']          = $user['id'];
            $_SESSION['usuario_nome']        = $user['nome'];
            $_SESSION['nome']                = $user['nome'];
            $_SESSION['tipo']                = $user['tipo'];

            if ($user['tipo'] === 'admin') {
                header('Location: ' . BASE_URL . '/admin/dashboard.php');
            } elseif ($user['tipo'] === 'barbeiro') {
                header('Location: ' . BASE_URL . '/barbeiro/dashboard.php');
            } elseif ($user['tipo'] === 'assistente') {
                header('Location: ' . BASE_URL . '/assistente/dashboard.php');
            } else {
                header('Location: ' . BASE_URL . '/login.php');
            }
            exit;

        } else {
            $_SESSION['login_tentativas']++;
            $restantes = $maxTentativas - $_SESSION['login_tentativas'];

            if ($_SESSION['login_tentativas'] >= $maxTentativas) {
                $_SESSION['login_bloqueado_ate'] = time() + ($bloqueioMin * 60);
                $bloqueado    = true;
                $segundosRest = $bloqueioMin * 60;
                $erro = "Muitas tentativas! Aguarde {$bloqueioMin} minutos para tentar novamente.";
            } else {
                $erro = "E-mail ou senha incorretos. "
                      . ($restantes > 0 ? "Restam {$restantes} tentativa(s)." : '');
            }
        }
    }
}

$minutosRest = $segundosRest > 0 ? ceil($segundosRest / 60) : 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login – Barbearia</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  *{box-sizing:border-box}
  body{
    background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);
    min-height:100vh;display:flex;align-items:center;justify-content:center;
    font-family:'Segoe UI',sans-serif;padding:1rem;
  }
  .card-login{
    border-radius:20px;
    box-shadow:0 20px 60px rgba(0,0,0,.5);
    background:rgba(255,255,255,.05);
    backdrop-filter:blur(20px);
    border:1px solid rgba(255,255,255,.1);
    width:100%;max-width:420px;padding:2.5rem;
  }
  .logo-icon{
    width:80px;height:80px;
    background:linear-gradient(135deg,#e94560,#c41230);
    border-radius:50%;display:flex;align-items:center;justify-content:center;
    margin:0 auto 1rem;font-size:2rem;color:#fff;
    box-shadow:0 0 30px rgba(233,69,96,.4);
  }
  .form-control{
    background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);
    color:#fff;border-radius:10px;padding:.7rem 1rem;
  }
  .form-control:focus{
    background:rgba(255,255,255,.15);border-color:#e94560;
    color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.25);
  }
  .form-control::placeholder{color:rgba(255,255,255,.45)}
  .form-control:disabled{opacity:.5}
  .btn-entrar{
    background:linear-gradient(135deg,#e94560,#c41230);border:none;
    border-radius:10px;padding:.75rem;font-weight:700;font-size:1.05rem;
    transition:all .3s;color:#fff;width:100%;cursor:pointer;
  }
  .btn-entrar:hover:not(:disabled){
    transform:translateY(-2px);
    box-shadow:0 8px 25px rgba(233,69,96,.4);
  }
  .btn-entrar:disabled{opacity:.5;cursor:not-allowed}
  .btn-cliente{
    background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);
    color:rgba(255,255,255,.8);border-radius:10px;padding:.65rem;
    transition:all .3s;width:100%;text-decoration:none;
    display:block;text-align:center;font-size:.95rem;
  }
  .btn-cliente:hover{background:rgba(233,69,96,.15);border-color:#e94560;color:#fff}
  label{color:rgba(255,255,255,.8);font-size:.88rem}
  h2{color:#fff;font-weight:800}
  .subtitle{color:rgba(255,255,255,.5);font-size:.9rem}
  .alert-danger-custom{
    background:rgba(220,53,69,.2);border:1px solid rgba(220,53,69,.35);
    color:#ff8fa3;border-radius:10px;padding:.75rem 1rem;
    font-size:.88rem;margin-bottom:1rem;
  }
  .alert-block{
    background:rgba(245,158,11,.15);border:1px solid rgba(245,158,11,.3);
    color:#fbbf24;border-radius:10px;padding:.75rem 1rem;
    font-size:.88rem;margin-bottom:1rem;
  }
  .tentativas-bar{
    height:4px;border-radius:2px;background:rgba(255,255,255,.1);
    margin-top:.5rem;overflow:hidden;
  }
  .tentativas-fill{
    height:100%;border-radius:2px;
    background:linear-gradient(90deg,#22c55e,#e94560);transition:.3s;
  }
  .divider{border-color:rgba(255,255,255,.1);margin:1.25rem 0}
  .countdown{font-weight:700;color:#fbbf24}
  .tipo-badge{
    display:inline-flex;align-items:center;gap:.4rem;
    padding:.3rem .8rem;border-radius:99px;font-size:.72rem;font-weight:600;
    margin-bottom:1.25rem;
  }
  .tipo-admin     {background:rgba(233,69,96,.15);   color:#e94560;  border:1px solid rgba(233,69,96,.3)}
  .tipo-barbeiro  {background:rgba(251,191,36,.15);  color:#fbbf24;  border:1px solid rgba(251,191,36,.3)}
  .tipo-assistente{background:rgba(96,165,250,.15);  color:#60a5fa;  border:1px solid rgba(96,165,250,.3)}
</style>
</head>
<body>
<div class="card-login">

  <div class="logo-icon"><i class="bi bi-scissors"></i></div>
  <h2 class="text-center mb-1">Barbearia</h2>
  <p class="subtitle text-center mb-4">Acesso ao Sistema de Gestão</p>

  <div class="text-center mb-3 d-flex gap-2 justify-content-center flex-wrap">
    <span class="tipo-badge tipo-admin">
      <i class="bi bi-shield-fill"></i>Admin
    </span>
    <span class="tipo-badge tipo-barbeiro">
      <i class="bi bi-scissors"></i>Barbeiro
    </span>
    <span class="tipo-badge tipo-assistente">
      <i class="bi bi-person-badge"></i>Assistente
    </span>
  </div>

  <?php if ($bloqueado): ?>
  <div class="alert-block">
    <i class="bi bi-shield-lock me-2"></i>
    Acesso bloqueado por <span class="countdown" id="countdown"><?= $minutosRest ?> min</span>.
    <br><small>Muitas tentativas incorretas foram detectadas.</small>
  </div>
  <?php elseif ($erro): ?>
  <div class="alert-danger-custom">
    <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($erro) ?>
    <?php if ($_SESSION['login_tentativas'] > 0): ?>
    <div class="tentativas-bar mt-2">
      <div class="tentativas-fill"
           style="width:<?= ($_SESSION['login_tentativas'] / $maxTentativas) * 100 ?>%"></div>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <form method="POST" novalidate>
    <div class="mb-3">
      <label class="form-label mb-1">
        <i class="bi bi-envelope me-1"></i>E-mail
      </label>
      <input type="email" name="email" class="form-control"
             placeholder="seu@email.com"
             value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
             <?= $bloqueado ? 'disabled' : '' ?>
             required autofocus>
    </div>
    <div class="mb-4">
      <label class="form-label mb-1">
        <i class="bi bi-lock me-1"></i>Senha
      </label>
      <div style="position:relative">
        <input type="password" name="senha" class="form-control"
               placeholder="••••••••" id="senhaInput"
               <?= $bloqueado ? 'disabled' : '' ?>
               required>
        <button type="button" id="toggleSenha"
          style="position:absolute;right:.75rem;top:50%;transform:translateY(-50%);
                 background:none;border:none;color:rgba(255,255,255,.4);cursor:pointer;padding:0">
          <i class="bi bi-eye" id="eyeIcon"></i>
        </button>
      </div>
    </div>
    <button type="submit" class="btn-entrar" <?= $bloqueado ? 'disabled' : '' ?>>
      <i class="bi bi-box-arrow-in-right me-2"></i>
      <?= $bloqueado ? 'Acesso Bloqueado' : 'Entrar' ?>
    </button>
  </form>

  <hr class="divider">

  <a href="<?= BASE_URL ?>/index.php" class="btn-cliente">
    <i class="bi bi-person-plus me-2"></i>Sou Cliente – Entrar na Fila
  </a>

  <?php if (!$bloqueado): ?>
  <p class="text-center mt-3 mb-0"
     style="font-size:.75rem;color:rgba(255,255,255,.25)">
    Acesso protegido · <?= $maxTentativas ?> tentativas máximas
  </p>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('toggleSenha')?.addEventListener('click', function() {
  const inp = document.getElementById('senhaInput');
  const ico = document.getElementById('eyeIcon');
  if (inp.type === 'password') {
    inp.type = 'text';
    ico.className = 'bi bi-eye-slash';
  } else {
    inp.type = 'password';
    ico.className = 'bi bi-eye';
  }
});

<?php if ($bloqueado && $segundosRest > 0): ?>
let segs = <?= $segundosRest ?>;
const el = document.getElementById('countdown');
const timer = setInterval(() => {
  segs--;
  if (segs <= 0) {
    clearInterval(timer);
    location.reload();
    return;
  }
  const m = Math.floor(segs / 60);
  const s = segs % 60;
  if (el) el.textContent = m > 0
    ? m + ' min ' + String(s).padStart(2,'0') + 's'
    : String(s) + 's';
}, 1000);
<?php endif; ?>
</script>
<?php if (file_exists(__DIR__ . '/sw.js')): ?>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope))
      .catch(e => console.log('SW erro:', e));
  });
}
</script>
<?php endif; ?>
</body>
</html>