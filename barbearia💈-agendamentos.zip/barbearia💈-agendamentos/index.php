<?php
require_once 'config.php';
$db = getDB();

$erro = '';

// ── Verifica disponibilidade da fila ──
$filaAtiva     = getConfig('fila_ativa')              ?? '1';
$filaModo      = getConfig('fila_modo')               ?? 'auto';
$horAbert      = trim(getConfig('horario_abertura')   ?? '08:00');
$horFech       = trim(getConfig('horario_fechamento') ?? '18:00');
$diasConf      = getConfig('dias_semana')             ?? '1,2,3,4,5,6';
$diasAtivos    = array_map('trim', explode(',', $diasConf));
$numHoje       = (string)date('w');

$abreHoje   = trim(getConfig("horario_abertura_$numHoje")   ?: $horAbert);
$fechaHoje  = trim(getConfig("horario_fechamento_$numHoje") ?: $horFech);
$motivoHoje = trim(getConfig("motivo_fechamento_$numHoje")  ?? '');

$diaOk      = in_array($numHoje, $diasAtivos);
$horarioOk  = date('H:i') >= $abreHoje && date('H:i') <= $fechaHoje;
    // Modo manual sobrepõe tudo
if ($filaModo === 'aberta') {
    $filaAberta = true;
} elseif ($filaModo === 'fechada') {
    $filaAberta = false;
} else {
    // modo auto: respeita dia + horário + toggle
    $filaAberta = $filaAtiva === '1' && $diaOk && $horarioOk;
}

$diasNomesExib = ['0'=>'Dom','1'=>'Seg','2'=>'Ter','3'=>'Qua','4'=>'Qui','5'=>'Sex','6'=>'Sáb'];

$lojaBotaoIndex    = getConfig('loja_botao_index')         ?? '1';
$agendaAtivo       = getConfig('agenda_ativo')              ?? '0'; // ativa/desativa agendamento
$agendaBotao       = getConfig('agenda_botao_index')        ?? '1'; // mostra/oculta botão na index
$minhaConta        = getConfig('minha_conta_botao_index')  ?? '1';
$mostrarServIndex  = getConfig('servicos_index_ativo')     ?? '1';

// ── Serviços e pacotes para a fila ──
$servicos = $db->query("SELECT id, nome, preco, duracao_min FROM servicos ORDER BY nome")->fetchAll();
try {
    $pacotes = $db->query("SELECT id, nome, preco FROM pacotes WHERE ativo=1 ORDER BY nome")->fetchAll();
} catch (Exception $e) { $pacotes = []; }

// ── Motivo detalhado do fechamento ──
$motivoFechamento = '';
$proximaAbertura  = '';
if (!$filaAberta) {
    if ($filaModo === 'fechada' || $filaAtiva !== '1') {
        $motivoFechamento = 'manual';
    } elseif (!$diaOk) {
        $motivoFechamento = 'dia';
        for ($i = 1; $i <= 7; $i++) {
            $proxDia = ($numHoje + $i) % 7;
            if (in_array((string)$proxDia, $diasAtivos)) {
                $abreProx        = trim(getConfig("horario_abertura_$proxDia") ?: $horAbert);
                $proximaAbertura = $diasNomesExib[$proxDia] . ' às ' . $abreProx;
                break;
            }
        }
    } elseif (!$horarioOk) {
        $motivoFechamento = 'horario';
        if (date('H:i') < $abreHoje) {
            $proximaAbertura = 'hoje às ' . $abreHoje;
        } else {
            for ($i = 1; $i <= 7; $i++) {
                $proxDia = ($numHoje + $i) % 7;
                if (in_array((string)$proxDia, $diasAtivos)) {
                    $abreProx        = trim(getConfig("horario_abertura_$proxDia") ?: $horAbert);
                    $proximaAbertura = $diasNomesExib[$proxDia] . ' às ' . $abreProx;
                    break;
                }
            }
        }
    }
}

// ── POST: entrar na fila ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'entrar_fila' && !$filaAberta) {
        $erro = 'A fila está fechada no momento.';
    } elseif ($acao === 'entrar_fila') {
        $nome        = trim($_POST['nome'] ?? '');
        $telefone    = trim($_POST['telefone'] ?? '');
        $barbeiro_id = (int)($_POST['barbeiro_id'] ?? 0);
        $servico_id  = (int)($_POST['servico_id'] ?? 0) ?: null;
        $pacote_id   = (int)($_POST['pacote_id']  ?? 0) ?: null;
        // Se pacote selecionado, não precisa de serviço
        if ($pacote_id) $servico_id = null;

        if (!$nome || !$telefone || !$barbeiro_id) {
            $erro = 'Preencha todos os campos obrigatórios.';
        } else {
            $limite = (int)getConfig('limite_fila');
            $stmt   = $db->prepare("SELECT COUNT(*) as c FROM fila
                WHERE barbeiro_id=? AND status IN ('aguardando','atendendo')");
            $stmt->execute([$barbeiro_id]);
            $total = (int)$stmt->fetch()['c'];

            if ($total >= $limite) {
                $erro = 'A fila deste barbeiro está cheia. Tente outro ou volte mais tarde.';
            } else {
                $stmt = $db->prepare('SELECT id FROM clientes WHERE telefone=?');
                $stmt->execute([$telefone]);
                $cliente = $stmt->fetch();
                if ($cliente) {
                    $cliente_id = $cliente['id'];
                    $db->prepare('UPDATE clientes SET nome=? WHERE id=?')
                       ->execute([$nome, $cliente_id]);
                } else {
                    $db->prepare('INSERT INTO clientes (nome,telefone) VALUES (?,?)')
                       ->execute([$nome, $telefone]);
                    $cliente_id = $db->lastInsertId();
                }

                $stmt = $db->prepare("SELECT id FROM fila
                    WHERE cliente_id=? AND status IN ('aguardando','atendendo')");
                $stmt->execute([$cliente_id]);
                if ($stmt->fetch()) {
                    $erro = 'Você já está em uma fila ativa. Aguarde seu atendimento.';
                } else {
                    $stmt = $db->prepare("SELECT COALESCE(MAX(posicao),0)+1 as prox
                        FROM fila WHERE barbeiro_id=? AND status='aguardando'");
                    $stmt->execute([$barbeiro_id]);
                    $posicao = (int)$stmt->fetch()['prox'];

                    // ── Gera token único e seguro ──
                    $token = bin2hex(random_bytes(16));

                    $db->prepare("INSERT INTO fila (cliente_id,barbeiro_id,servico_id,posicao,token)
                        VALUES (?,?,?,?,?)")
                       ->execute([$cliente_id, $barbeiro_id, $servico_id, $posicao, $token]);

                    // Registrar pacote como item da fila se selecionado
                    if ($pacote_id) {
                        $pkRow = $db->prepare("SELECT nome, preco FROM pacotes WHERE id=?");
                        $pkRow->execute([$pacote_id]);
                        $pk = $pkRow->fetch();
                        if ($pk) {
                            $db->prepare("INSERT INTO fila_itens (fila_id, nome, preco) VALUES (?,?,?)")
                               ->execute([$db->lastInsertId(), '📦 '.$pk['nome'], $pk['preco']]);
                        }
                    }

                    $fila_id = $db->lastInsertId();

                    if (file_exists(__DIR__ . '/whatsapp/config.php')) {
                        require_once 'whatsapp/config.php';
                        $stmtB = $db->prepare('SELECT nome FROM usuarios WHERE id=?');
                        $stmtB->execute([$barbeiro_id]);
                        $nomeBarbeiro   = $stmtB->fetch()['nome'] ?? '';
                        $tempoMedioWa   = (int)getConfig('tempo_medio_corte');
                        $nomeBarbeariaW = getConfig('nome_barbearia');
                        if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbeariaW);
                        $msg     = montarMensagemEntrada($nome, $nomeBarbeiro, $posicao, $posicao * $tempoMedioWa);
                        $urlStat = (isset($_SERVER['HTTPS']) ? 'https' : 'http')
                                 . '://' . $_SERVER['HTTP_HOST']
                                 . BASE_URL . "/cliente/status.php?id={$fila_id}&token={$token}";
                        $msg    .= "\n\n👁️ Acompanhe: {$urlStat}";
                        @enviarWhatsApp($telefone, $msg);
                    }

                    $_SESSION['fila_id']    = $fila_id;
                    $_SESSION['fila_token'] = $token;
                    $_SESSION['cliente_id'] = $cliente_id;
                    header("Location: cliente/status.php?id={$fila_id}&token={$token}");
                    exit;
                }
            }
        }
    }
}

$barbeiros = $db->query("
    SELECT u.id, u.nome, u.foto,
        (SELECT COUNT(*) FROM fila f
         WHERE f.barbeiro_id=u.id
         AND f.status IN ('aguardando','atendendo')) as na_fila
    FROM usuarios u
    WHERE u.tipo='barbeiro' AND u.ativo=1
    ORDER BY u.nome
")->fetchAll();

$tempoMedio    = (int)getConfig('tempo_medio_corte');
$limite        = (int)getConfig('limite_fila');
$nomeBarbearia = getConfig('nome_barbearia');
$logoPath      = getConfig('logo_path')    ?? '';
$capaBgPath    = getConfig('capa_bg_path') ?? '';

$barbDataJson = json_encode(array_map(function($b) use ($tempoMedio) {
    return [
        'id'    => (int)$b['id'],
        'fila'  => (int)$b['na_fila'],
        'tempo' => (int)$b['na_fila'] * $tempoMedio,
    ];
}, $barbeiros));

$promocoesIndex = [];
try {
    $promocoesIndex = $db->query("SELECT * FROM promocoes WHERE ativo=1 ORDER BY criado_em DESC")->fetchAll();
} catch (Exception $e) { $promocoesIndex = []; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($nomeBarbearia) ?> – Fila Online</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--dark:#1a1a2e;--darker:#0f3460}
  *{box-sizing:border-box}
  body{background:linear-gradient(135deg,var(--dark) 0%,#16213e 50%,var(--darker) 100%);min-height:100vh;color:#fff;font-family:'Segoe UI',sans-serif;}

  .hero{position:relative;min-height:300px;display:flex;align-items:center;justify-content:center;text-align:center;overflow:hidden;padding:60px 20px 70px;}
  .hero-bg{position:absolute;inset:0;background-size:cover;background-position:center;background-repeat:no-repeat;filter:brightness(.3);transition:filter .3s;}
  .hero-bg-default{background:linear-gradient(135deg,var(--dark) 0%,#16213e 50%,var(--darker) 100%);}
  .hero-overlay{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(0,0,0,.05) 0%,rgba(0,0,0,.65) 100%);}
  .hero-content{position:relative;z-index:2}
  .hero-logo-img{width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid var(--primary);box-shadow:0 0 35px rgba(233,69,96,.5);margin:0 auto 16px;display:block;}
  .hero-logo-ph{width:100px;height:100px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:2.6rem;box-shadow:0 0 40px rgba(233,69,96,.4);}
  .hero h1{font-size:clamp(1.7rem,5vw,2.5rem);font-weight:800;color:#fff;margin-bottom:8px;text-shadow:0 2px 10px rgba(0,0,0,.4);}
  .hero p{color:rgba(255,255,255,.7);font-size:1rem;margin:0}

  .hero-btns{display:flex;flex-wrap:wrap;gap:.6rem;justify-content:center;margin-top:1.1rem;}
  .btn-loja{display:inline-flex;align-items:center;gap:.6rem;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);backdrop-filter:blur(10px);color:#fff;border-radius:50px;padding:.6rem 1.5rem;font-size:.88rem;font-weight:700;text-decoration:none;transition:all .25s;box-shadow:0 4px 20px rgba(0,0,0,.25);letter-spacing:.3px;}
  .btn-loja:hover{background:rgba(233,69,96,.25);border-color:rgba(233,69,96,.6);color:#fff;transform:translateY(-2px);box-shadow:0 8px 28px rgba(233,69,96,.3);}
  .btn-loja .loja-dot{width:7px;height:7px;border-radius:50%;background:var(--primary);box-shadow:0 0 6px var(--primary);animation:pulse-dot 1.8s ease-in-out infinite;flex-shrink:0;}
  @keyframes pulse-dot{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.65)}}

  .promos-wrap{position:relative;z-index:10;margin-top:-36px;padding:0 16px;max-width:700px;margin-left:auto;margin-right:auto;margin-bottom:0;}
  .promo-float-card{animation:promoSlideIn .4s ease}
  @keyframes promoSlideIn{from{opacity:0;transform:translateY(-12px)}to{opacity:1;transform:translateY(0)}}
  .promo-inner{border-radius:16px;padding:1rem 1.15rem;backdrop-filter:blur(20px);transition:transform .2s}
  .promo-inner:hover{transform:translateY(-1px)}
  .promo-icon-box{width:44px;height:44px;border-radius:11px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:1.2rem}
  .promo-titulo{font-weight:800;color:#fff;font-size:.95rem;line-height:1.3;margin-bottom:.2rem}
  .promo-msg{font-size:.83rem;color:rgba(255,255,255,.68);line-height:1.45}
  .promo-wa-btn{display:inline-flex;align-items:center;gap:.4rem;margin-top:.6rem;background:#25d366;color:#fff;border-radius:8px;padding:.35rem .85rem;font-size:.8rem;font-weight:700;text-decoration:none;box-shadow:0 3px 12px rgba(37,211,102,.3);transition:.2s}
  .promo-wa-btn:hover{background:#1da851;color:#fff;transform:translateY(-1px)}
  .promo-close-btn{background:rgba(255,255,255,.1);border:none;border-radius:7px;width:28px;height:28px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:rgba(255,255,255,.5);flex-shrink:0;font-size:.85rem;transition:.2s}
  .promo-close-btn:hover{background:rgba(255,255,255,.2);color:#fff}
  .promo-dots{display:flex;gap:.3rem;align-items:center}
  .promo-dot{height:7px;border-radius:4px;cursor:pointer;transition:all .3s;background:rgba(255,255,255,.25);width:7px}
  .promo-dot.active{width:20px;background:var(--primary)}

  .card-form{background:rgba(255,255,255,.05);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.1);border-radius:20px;}
  .form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px;padding:.65rem 1rem;transition:.2s;}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.13);border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2);}
  .form-control::placeholder{color:rgba(255,255,255,.4)}
  .form-select option{background:#1a1a2e;color:#fff}
  .form-control:disabled,.form-select:disabled{background:rgba(255,255,255,.04)!important;border:1px solid rgba(255,255,255,.1)!important;color:rgba(255,255,255,.3)!important;cursor:not-allowed;opacity:1!important;}
  .form-control:disabled::placeholder{color:rgba(255,255,255,.2)!important}
  .form-label{color:rgba(255,255,255,.5);font-weight:600;font-size:.9rem;margin-bottom:.45rem;display:flex;align-items:center;gap:.4rem;}
  .fila-aberta .form-label{color:rgba(255,255,255,.85)}

  .input-wrap{position:relative}
  .input-wrap .input-icon{position:absolute;left:.9rem;top:50%;transform:translateY(-50%);color:rgba(255,255,255,.25);font-size:1rem;pointer-events:none;}
  .fila-aberta .input-wrap .input-icon{color:rgba(255,255,255,.4)}
  .input-wrap .form-control{padding-left:2.5rem}
  .form-section-dim{opacity:.45;pointer-events:none;user-select:none}

  .card-barbeiro{background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.09);border-radius:14px;cursor:pointer;transition:all .25s;padding:.9rem;user-select:none;}
  .card-barbeiro:hover{background:rgba(233,69,96,.1);border-color:rgba(233,69,96,.4);transform:translateY(-2px)}
  .card-barbeiro.selecionado{background:rgba(233,69,96,.15);border-color:var(--primary);box-shadow:0 6px 20px rgba(233,69,96,.2)}
  .card-barbeiro input[type=radio]{display:none}
  .barb-foto{width:54px;height:54px;border-radius:50%;object-fit:cover;border:2px solid rgba(233,69,96,.45);flex-shrink:0}
  .barb-foto-ph{width:54px;height:54px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:flex;align-items:center;justify-content:center;flex-shrink:0;border:2px solid rgba(233,69,96,.35)}
  .badge-fila{background:rgba(233,69,96,.25);color:#ff8fa3;border-radius:20px;padding:.2rem .65rem;font-size:.76rem;font-weight:600}
  .badge-livre{background:rgba(34,197,94,.2);color:#4ade80;border-radius:20px;padding:.2rem .65rem;font-size:.76rem;font-weight:600}
  .nome-barbeiro{font-weight:700;color:#fff;font-size:.95rem;line-height:1.2}
  .check-circle{width:24px;height:24px;border-radius:50%;border:2px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:.2s}
  .check-circle i{font-size:.85rem;display:none;color:#fff}
  .card-barbeiro.selecionado .check-circle{background:var(--primary);border-color:var(--primary)}
  .card-barbeiro.selecionado .check-circle i{display:block}

  .fila-info-box{background:rgba(233,69,96,.07);border:1px solid rgba(233,69,96,.2);border-radius:12px;padding:12px 16px;margin-top:10px}
  .fi-item{display:flex;align-items:center;gap:6px;font-size:.83rem;color:rgba(255,255,255,.65)}
  .fi-val{color:#fff;font-weight:700}

  .fila-fechada-wrap{border-radius:16px;overflow:hidden;margin-bottom:1.75rem;border:1px solid rgba(233,69,96,.25)}
  .ff-header{background:linear-gradient(135deg,rgba(233,69,96,.25),rgba(196,18,48,.2));padding:1.5rem 1.25rem 1.25rem;text-align:center;border-bottom:1px solid rgba(233,69,96,.2)}
  .ff-icon-wrap{width:72px;height:72px;border-radius:50%;background:rgba(233,69,96,.15);border:2px solid rgba(233,69,96,.35);display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;font-size:2rem}
  .ff-title{font-size:1.25rem;font-weight:800;color:#fff;margin-bottom:.3rem}
  .ff-subtitle{color:rgba(255,255,255,.6);font-size:.88rem}
  .ff-body{background:rgba(0,0,0,.2);padding:1.25rem}
  .ff-info-row{display:flex;align-items:flex-start;gap:.75rem;padding:.75rem;border-radius:10px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);margin-bottom:.6rem}
  .ff-info-row:last-child{margin-bottom:0}
  .ff-info-icon{width:36px;height:36px;border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:1rem}
  .ff-info-icon.red{background:rgba(233,69,96,.15);color:var(--primary)}
  .ff-info-icon.blue{background:rgba(59,130,246,.15);color:#60a5fa}
  .ff-info-icon.green{background:rgba(34,197,94,.15);color:#4ade80}
  .ff-info-icon.yellow{background:rgba(234,179,8,.15);color:#fbbf24}
  .ff-info-icon.purple{background:rgba(167,139,250,.15);color:#a78bfa}
  .ff-info-label{font-size:.72rem;color:rgba(255,255,255,.4);margin-bottom:.15rem;text-transform:uppercase;letter-spacing:.5px}
  .ff-info-value{font-size:.9rem;color:#fff;font-weight:600}
  .ff-info-value small{font-weight:400;color:rgba(255,255,255,.5);font-size:.78rem}
  .dias-row{display:flex;gap:.35rem;flex-wrap:wrap;margin-top:.5rem}
  .dia-chip{border-radius:7px;padding:.25rem .6rem;font-size:.75rem;font-weight:700;display:inline-flex;align-items:center;gap:.25rem}
  .dia-chip.ativo{background:rgba(233,69,96,.2);border:1px solid rgba(233,69,96,.4);color:#fff}
  .dia-chip.hoje-ativo{background:rgba(233,69,96,.4);border:1px solid rgba(233,69,96,.7);color:#fff;box-shadow:0 0 8px rgba(233,69,96,.3)}
  .dia-chip.inativo{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);color:rgba(255,255,255,.2)}
  .ff-prox{margin-top:.75rem;padding:.6rem .9rem;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);border-radius:9px;display:flex;align-items:center;gap:.5rem;font-size:.83rem;color:rgba(255,255,255,.7)}
  .ff-prox strong{color:#4ade80}

  .btn-entrar{background:linear-gradient(135deg,var(--primary),#c41230);border:none;border-radius:12px;padding:.9rem;font-size:1.05rem;font-weight:700;transition:all .3s;color:#fff;width:100%;letter-spacing:.3px;}
  .btn-entrar:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 10px 30px rgba(233,69,96,.4);color:#fff}
  .btn-entrar:disabled{opacity:.3;transform:none;cursor:not-allowed;background:rgba(255,255,255,.1)!important;border:1px solid rgba(255,255,255,.1)!important;color:rgba(255,255,255,.3)!important}
  .alert-danger{background:rgba(220,53,69,.15);border:1px solid rgba(220,53,69,.35);color:#ff8a8a;border-radius:12px;display:flex;align-items:center;gap:.6rem}
  .secao-titulo{font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:rgba(255,255,255,.35);font-weight:600;display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem}
  .secao-titulo::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.08)}
  .secao-titulo.dim{color:rgba(255,255,255,.15)}
  .secao-titulo.dim::after{background:rgba(255,255,255,.04)}

  /* Serviços/Pacotes na fila */
  .serv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:.5rem;margin-bottom:.5rem}
  .serv-card{background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.09);
    border-radius:12px;padding:.7rem .75rem;cursor:pointer;transition:all .2s;
    display:flex;flex-direction:column;gap:.2rem;position:relative}
  .serv-card:hover{border-color:rgba(233,69,96,.35);background:rgba(233,69,96,.06)}
  .serv-card.selected{border-color:var(--primary);background:rgba(233,69,96,.1)}
  .serv-card.decidir{border-style:dashed;border-color:rgba(255,255,255,.15)}
  .serv-card.decidir:hover{border-color:rgba(255,255,255,.35);background:rgba(255,255,255,.05)}
  .serv-card.decidir.selected{border-color:rgba(255,255,255,.5);background:rgba(255,255,255,.08);border-style:dashed}
  .serv-card input[type=radio]{display:none}
  .serv-check{position:absolute;top:.45rem;right:.5rem;width:18px;height:18px;border-radius:50%;
    background:var(--primary);display:none;align-items:center;justify-content:center;font-size:.65rem;color:#fff}
  .serv-card.selected .serv-check{display:flex}
  .serv-nome{font-size:.82rem;font-weight:700;color:#fff;line-height:1.2}
  .serv-preco{font-size:.78rem;color:#4ade80;font-weight:700}
  .serv-tipo-badge{font-size:.62rem;font-weight:700;padding:.1rem .4rem;border-radius:6px;
    display:inline-block;margin-bottom:.15rem}
  h4,h5,h6{color:#fff}

  @media(max-width:576px){
    .hero{min-height:240px;padding:44px 16px 60px}
    .hero-logo-img,.hero-logo-ph{width:82px;height:82px}
    .promos-wrap{margin-top:-28px}
    .btn-loja{font-size:.84rem;padding:.55rem 1.2rem}
  }
</style>
</head>
<body>

<div class="hero">
  <?php if ($capaBgPath && file_exists(__DIR__.'/'.$capaBgPath)): ?>
    <div class="hero-bg" style="background-image:url('<?= htmlspecialchars($capaBgPath) ?>')"></div>
  <?php else: ?>
    <div class="hero-bg hero-bg-default"></div>
  <?php endif; ?>
  <div class="hero-overlay"></div>
  <div class="hero-content">
    <?php if ($logoPath && file_exists(__DIR__.'/'.$logoPath)): ?>
      <img src="<?= htmlspecialchars($logoPath) ?>" class="hero-logo-img" alt="Logo">
    <?php else: ?>
      <div class="hero-logo-ph"><i class="bi bi-scissors"></i></div>
    <?php endif; ?>
    <h1><?= htmlspecialchars($nomeBarbearia) ?></h1>
    <p>Entre na fila online e economize seu tempo!</p>
    <?php if ($lojaBotaoIndex === '1' || $minhaConta === '1'): ?>
    <div class="hero-btns">
      <?php if ($lojaBotaoIndex === '1'): ?>
      <a href="loja.php" class="btn-loja">
        <span class="loja-dot"></span>
        <i class="bi bi-shop-window"></i>Vitrine de Produtos à Venda
        <i class="bi bi-chevron-right" style="font-size:.75rem;opacity:.6"></i>
      </a>
      <?php endif; ?>
      <?php if ($minhaConta === '1'): ?>
      <a href="cliente/minha-conta.php" class="btn-loja">
        <i class="bi bi-person-circle" style="color:rgba(255,255,255,.7)"></i>Minha Conta
        <i class="bi bi-chevron-right" style="font-size:.75rem;opacity:.6"></i>
      </a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($agendaBotao === '1'): ?>
    <div class="hero-btns">
      <a href="agendar.php" class="btn-loja" style="background:rgba(233,69,96,.15);border-color:rgba(233,69,96,.4)">
        <span class="loja-dot" style="background:#e94560"></span>
        <i class="bi bi-calendar-check"></i>Agendar Horário
        <i class="bi bi-chevron-right" style="font-size:.75rem;opacity:.6"></i>
      </a>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($promocoesIndex)): ?>
<div class="promos-wrap" id="promosWrap">
  <?php foreach ($promocoesIndex as $idx => $p):
    $waLink = '';
    if ($p['whatsapp_numero'] && $p['whatsapp_ativo']) {
        $waTexto = $p['whatsapp_texto'] ?: 'Olá! Vi a promoção e quero saber mais.';
        $waLink  = 'https://wa.me/' . $p['whatsapp_numero'] . '?text=' . urlencode($waTexto);
    }
    $corHex = htmlspecialchars($p['cor']);
  ?>
  <div class="promo-float-card" id="promoCard<?= $idx ?>"
       style="<?= $idx > 0 ? 'display:none;' : '' ?>margin-bottom:.5rem">
    <div class="promo-inner"
         style="background:<?= $corHex ?>18;border:1px solid <?= $corHex ?>45;
                box-shadow:0 8px 32px <?= $corHex ?>28, 0 2px 8px rgba(0,0,0,.35)">
      <div style="display:flex;align-items:flex-start;gap:.85rem">
        <div class="promo-icon-box" style="background:<?= $corHex ?>28;border:1.5px solid <?= $corHex ?>55">
          <i class="bi <?= htmlspecialchars($p['icone']) ?>" style="color:<?= $corHex ?>"></i>
        </div>
        <div style="flex:1;min-width:0">
          <div class="promo-titulo"><?= htmlspecialchars($p['titulo']) ?></div>
          <div class="promo-msg"><?= nl2br(htmlspecialchars($p['mensagem'])) ?></div>
          <?php if ($waLink): ?>
          <a href="<?= htmlspecialchars($waLink) ?>" target="_blank" rel="noopener" class="promo-wa-btn">
            <i class="bi bi-whatsapp"></i> Falar no WhatsApp
          </a>
          <?php endif; ?>
        </div>
        <button class="promo-close-btn" onclick="fecharPromo(<?= $idx ?>)" aria-label="Fechar">
          <i class="bi bi-x-lg"></i>
        </button>
      </div>
      <?php if (count($promocoesIndex) > 1): ?>
      <div style="display:flex;justify-content:space-between;align-items:center;
                  margin-top:.75rem;padding-top:.6rem;border-top:1px solid rgba(255,255,255,.07)">
        <div class="promo-dots" id="promoDots">
          <?php foreach ($promocoesIndex as $di => $_): ?>
          <div class="promo-dot <?= $di === 0 ? 'active' : '' ?>"
               id="promoDot<?= $di ?>"
               onclick="irParaPromo(<?= $di ?>)"
               style="<?= $di === 0 ? 'width:20px;background:'.$corHex : '' ?>"></div>
          <?php endforeach; ?>
        </div>
        <div style="font-size:.72rem;color:rgba(255,255,255,.3)" id="promoContador">
          1/<?= count($promocoesIndex) ?>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="container pb-5 pt-4">
  <div class="row justify-content-center">
    <div class="col-12 col-lg-8 col-xl-7">
      <div class="card-form p-4 p-md-5 <?= $filaAberta ? 'fila-aberta' : '' ?>">

        <h4 class="fw-bold mb-4">
          <i class="bi bi-person-plus me-2" style="color:var(--primary)"></i>Entrar na Fila
        </h4>

        <?php if ($erro): ?>
          <div class="alert alert-danger mb-3">
            <i class="bi bi-exclamation-circle-fill"></i><?= htmlspecialchars($erro) ?>
          </div>
        <?php endif; ?>

        <?php if (!$filaAberta): ?>
        <div class="fila-fechada-wrap">
          <div class="ff-header">
            <div class="ff-icon-wrap">
              <?php if ($motivoFechamento === 'manual'): ?>
                <i class="bi bi-lock-fill" style="color:var(--primary)"></i>
              <?php elseif ($motivoFechamento === 'dia'): ?>
                <i class="bi bi-calendar-x" style="color:#60a5fa"></i>
              <?php else: ?>
                <i class="bi bi-clock" style="color:#fbbf24"></i>
              <?php endif; ?>
            </div>
            <div class="ff-title">
              <?php if ($motivoFechamento === 'manual'): ?>
                <?= $motivoHoje ? htmlspecialchars($motivoHoje) : 'Fila Temporariamente Fechada' ?>
              <?php elseif ($motivoFechamento === 'dia'): ?>
                <?= $motivoHoje ? htmlspecialchars($motivoHoje) : 'Não Atendemos Hoje' ?>
              <?php else: ?>
                Fora do Horário de Atendimento
              <?php endif; ?>
            </div>
            <div class="ff-subtitle">
              <?php if ($motivoFechamento === 'manual'): ?>
                O estabelecimento encerrou a fila manualmente
              <?php elseif ($motivoFechamento === 'dia'): ?>
                <?php $diasSemNomesCompletos = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado']; echo $diasSemNomesCompletos[$numHoje]; ?> não é um dia de atendimento
              <?php else: ?>
                <?= date('H:i') < $abreHoje ? 'Ainda não abrimos hoje' : 'Encerramos o atendimento de hoje' ?>
              <?php endif; ?>
            </div>
          </div>
          <div class="ff-body">
            <?php if ($motivoFechamento === 'manual'): ?>
              <?php if ($motivoHoje): ?>
              <div class="ff-info-row">
                <div class="ff-info-icon purple"><i class="bi bi-chat-left-text-fill"></i></div>
                <div><div class="ff-info-label">Motivo</div><div class="ff-info-value"><?= htmlspecialchars($motivoHoje) ?></div></div>
              </div>
              <?php endif; ?>
              <div class="ff-info-row">
                <div class="ff-info-icon red"><i class="bi bi-info-circle-fill"></i></div>
                <div><div class="ff-info-label">Situação</div><div class="ff-info-value">Fila encerrada pelo estabelecimento</div></div>
              </div>
              <div class="ff-info-row">
                <div class="ff-info-icon yellow"><i class="bi bi-bell-fill"></i></div>
                <div><div class="ff-info-label">O que fazer</div><div class="ff-info-value">Tente novamente mais tarde ou entre em contato com a barbearia</div></div>
              </div>
            <?php elseif ($motivoFechamento === 'dia'): ?>
              <?php if ($motivoHoje): ?>
              <div class="ff-info-row">
                <div class="ff-info-icon purple"><i class="bi bi-chat-left-text-fill"></i></div>
                <div><div class="ff-info-label">Motivo</div><div class="ff-info-value"><?= htmlspecialchars($motivoHoje) ?></div></div>
              </div>
              <?php endif; ?>
              <div class="ff-info-row">
                <div class="ff-info-icon blue"><i class="bi bi-calendar3"></i></div>
                <div>
                  <div class="ff-info-label">Hoje é</div>
                  <div class="ff-info-value"><?= $diasSemNomesCompletos[$numHoje] ?>, <?= date('d/m/Y') ?> <small>— dia sem atendimento</small></div>
                </div>
              </div>
              <div class="ff-info-row">
                <div class="ff-info-icon green"><i class="bi bi-clock-history"></i></div>
                <div><div class="ff-info-label">Horário de funcionamento</div><div class="ff-info-value"><?= $abreHoje ?> às <?= $fechaHoje ?></div></div>
              </div>
              <div class="ff-info-row">
                <div class="ff-info-icon yellow"><i class="bi bi-calendar-week"></i></div>
                <div>
                  <div class="ff-info-label">Dias de atendimento</div>
                  <div class="dias-row">
                    <?php foreach ($diasNomesExib as $num => $nomeDia):
                      $ativo  = in_array($num, $diasAtivos);
                      $hoje   = ((int)date('w') === (int)$num);
                      $classe = !$ativo ? 'inativo' : ($hoje ? 'hoje-ativo' : 'ativo');
                    ?>
                    <span class="dia-chip <?= $classe ?>"><?php if($hoje): ?><i class="bi bi-arrow-right" style="font-size:.6rem"></i><?php endif; ?><?= $nomeDia ?></span>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            <?php else: ?>
              <div class="ff-info-row">
                <div class="ff-info-icon yellow"><i class="bi bi-clock-fill"></i></div>
                <div>
                  <div class="ff-info-label">Agora são</div>
                  <div class="ff-info-value"><?= date('H:i') ?> <small>— <?= date('H:i') < $abreHoje ? 'ainda não abrimos' : 'já encerramos hoje' ?></small></div>
                </div>
              </div>
              <div class="ff-info-row">
                <div class="ff-info-icon green"><i class="bi bi-door-open-fill"></i></div>
                <div>
                  <div class="ff-info-label">Horário de atendimento hoje</div>
                  <div class="ff-info-value"><?= $abreHoje ?> <small>abertura</small> &nbsp;→&nbsp; <?= $fechaHoje ?> <small>encerramento</small></div>
                </div>
              </div>
              <div class="ff-info-row">
                <div class="ff-info-icon blue"><i class="bi bi-calendar-week"></i></div>
                <div>
                  <div class="ff-info-label">Dias de atendimento</div>
                  <div class="dias-row">
                    <?php foreach ($diasNomesExib as $num => $nomeDia):
                      $ativo  = in_array($num, $diasAtivos);
                      $hoje   = ((int)date('w') === (int)$num);
                      $classe = !$ativo ? 'inativo' : ($hoje ? 'hoje-ativo' : 'ativo');
                    ?>
                    <span class="dia-chip <?= $classe ?>"><?php if($hoje): ?><i class="bi bi-arrow-right" style="font-size:.6rem"></i><?php endif; ?><?= $nomeDia ?></span>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            <?php endif; ?>
            <?php if ($proximaAbertura): ?>
            <div class="ff-prox">
              <i class="bi bi-alarm-fill" style="color:#4ade80"></i>
              Próxima abertura: <strong><?= htmlspecialchars($proximaAbertura) ?></strong>
            </div>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>

        <form method="POST" id="formFila" novalidate>
          <input type="hidden" name="acao" value="entrar_fila">

          <div class="<?= !$filaAberta ? 'form-section-dim' : '' ?>">
            <div class="secao-titulo <?= !$filaAberta ? 'dim' : '' ?>">
              <i class="bi bi-person-vcard"></i>Seus dados
            </div>
            <div class="row g-3 mb-4">
              <div class="col-12 col-md-6">
                <label class="form-label"><i class="bi bi-person"></i>Nome *</label>
                <div class="input-wrap">
                  <i class="bi bi-person input-icon"></i>
                  <input type="text" name="nome" class="form-control" placeholder="Digite seu nome" required
                         <?= !$filaAberta ? 'disabled' : '' ?>
                         value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>">
                </div>
              </div>
              <div class="col-12 col-md-6">
                <label class="form-label"><i class="bi bi-whatsapp"></i>WhatsApp *</label>
                <div class="input-wrap">
                  <i class="bi bi-telephone input-icon"></i>
                  <input type="tel" name="telefone" class="form-control" placeholder="(00) 00000-0000"
                         id="tel" required <?= !$filaAberta ? 'disabled' : '' ?>
                         value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>">
                </div>
              </div>
            </div>
          </div>

          <div class="<?= !$filaAberta ? 'form-section-dim' : '' ?>">
            <div class="secao-titulo <?= !$filaAberta ? 'dim' : '' ?>">
              <i class="bi bi-scissors"></i>Barbeiro
            </div>
            <div class="mb-1">
              <label class="form-label"><i class="bi bi-scissors"></i>Escolha o barbeiro *</label>
              <?php if (empty($barbeiros)): ?>
                <div class="text-center py-4" style="color:rgba(255,255,255,.35)">
                  <i class="bi bi-exclamation-circle fs-2 d-block mb-2"></i>Nenhum barbeiro disponível no momento.
                </div>
              <?php else: ?>
                <div class="row g-2" id="barbeiros-container">
                  <?php foreach ($barbeiros as $b):
                    $cheio   = $b['na_fila'] >= $limite;
                    $temFoto = !empty($b['foto']) && file_exists(__DIR__.'/uploads/barbeiros/'.$b['foto']);
                    $fotoUrl = $temFoto ? BASE_URL.'/uploads/barbeiros/'.htmlspecialchars($b['foto']) : null;
                    $livre   = $b['na_fila'] === 0;
                    $desabil = $cheio || !$filaAberta;
                  ?>
                  <div class="col-12 col-sm-6">
                    <label class="card-barbeiro d-block <?= $desabil ? 'opacity-50' : '' ?>">
                      <input type="radio" name="barbeiro_id" value="<?= $b['id'] ?>"
                             <?= $desabil ? 'disabled' : '' ?> required>
                      <div class="d-flex align-items-center gap-2">
                        <?php if ($fotoUrl): ?>
                          <img src="<?= $fotoUrl ?>" alt="" class="barb-foto">
                        <?php else: ?>
                          <div class="barb-foto-ph"><i class="bi bi-person-fill text-white fs-5"></i></div>
                        <?php endif; ?>
                        <div class="flex-grow-1" style="min-width:0">
                          <div class="nome-barbeiro text-truncate mb-1"><?= htmlspecialchars($b['nome']) ?></div>
                          <?php if ($cheio): ?>
                            <span class="badge bg-secondary" style="font-size:.72rem">Fila cheia</span>
                          <?php elseif ($livre): ?>
                            <span class="badge-livre"><i class="bi bi-lightning-fill me-1"></i>Disponível agora</span>
                          <?php else: ?>
                            <span class="badge-fila"><i class="bi bi-people me-1"></i><?= $b['na_fila'] ?> na fila</span>
                            <small style="color:rgba(255,255,255,.4);font-size:.73rem;margin-left:.35rem">~<?= $b['na_fila'] * $tempoMedio ?>min</small>
                          <?php endif; ?>
                        </div>
                        <div class="check-circle"><i class="bi bi-check2"></i></div>
                      </div>
                    </label>
                  </div>
                  <?php endforeach; ?>
                </div>
                <div id="fila-info" style="display:none" class="fila-info-box mt-2">
                  <div class="d-flex flex-wrap gap-3">
                    <div class="fi-item"><i class="bi bi-people" style="color:var(--primary)"></i>Na fila: <span class="fi-val ms-1" id="info-fila-num">0</span></div>
                    <div class="fi-item"><i class="bi bi-clock" style="color:var(--primary)"></i>Espera: <span class="fi-val ms-1" id="info-tempo">—</span></div>
                    <div class="fi-item"><i class="bi bi-arrow-right-circle" style="color:var(--primary)"></i>Sua posição: <span class="fi-val ms-1" id="info-pos">—</span></div>
                  </div>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <?php if ($mostrarServIndex === '1' && (!empty($servicos) || !empty($pacotes))): ?>
          <div class="<?= !$filaAberta ? 'form-section-dim' : '' ?>" style="margin-bottom:1rem">
            <div class="secao-titulo <?= !$filaAberta ? 'dim' : '' ?>">
              <i class="bi bi-scissors"></i>Serviço / Pacote
              <span style="font-size:.68rem;color:rgba(255,255,255,.25);text-transform:none;letter-spacing:0;font-weight:400">— opcional</span>
            </div>

            <input type="hidden" name="servico_id" id="hidServico" value="">
            <input type="hidden" name="pacote_id"  id="hidPacote"  value="">

            <div class="serv-grid" id="servGrid">

              <!-- Serviços -->
              <?php foreach ($servicos as $sv): ?>
              <label class="serv-card" id="sc_s_<?= $sv['id'] ?>" onclick="selecionarItem('s',<?= $sv['id'] ?>)">
                <input type="radio" name="_srv_radio" value="s_<?= $sv['id'] ?>">
                <div class="serv-check"><i class="bi bi-check2"></i></div>
                <span class="serv-tipo-badge" style="background:rgba(233,69,96,.15);color:#e94560">✂️ Serviço</span>
                <div class="serv-nome"><?= htmlspecialchars($sv['nome']) ?></div>
                <div class="serv-preco"><?= formatMoney($sv['preco']) ?></div>
              </label>
              <?php endforeach; ?>

              <!-- Pacotes -->
              <?php foreach ($pacotes as $pk): ?>
              <label class="serv-card" id="sc_p_<?= $pk['id'] ?>" onclick="selecionarItem('p',<?= $pk['id'] ?>)">
                <input type="radio" name="_srv_radio" value="p_<?= $pk['id'] ?>">
                <div class="serv-check"><i class="bi bi-check2"></i></div>
                <span class="serv-tipo-badge" style="background:rgba(99,102,241,.15);color:#a78bfa">📦 Pacote</span>
                <div class="serv-nome"><?= htmlspecialchars($pk['nome']) ?></div>
                <div class="serv-preco"><?= formatMoney($pk['preco']) ?></div>
              </label>
              <?php endforeach; ?>

              <!-- Decidir na hora -->
              <label class="serv-card decidir selected" id="sc_decidir" onclick="selecionarItem('decidir',0)">
                <input type="radio" name="_srv_radio" value="decidir" checked>
                <div class="serv-check"><i class="bi bi-check2"></i></div>
                <span class="serv-tipo-badge" style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.45)">⏱️ Livre</span>
                <div class="serv-nome" style="color:rgba(255,255,255,.7)">Decidir na hora</div>
                <div style="font-size:.7rem;color:rgba(255,255,255,.3)">Sem compromisso</div>
              </label>

            </div>
          </div>
          <?php endif; ?>

          <button type="submit" class="btn-entrar btn mt-4" id="btnEntrar"
            <?= (empty($barbeiros) || !$filaAberta) ? 'disabled' : '' ?>>
            <?php if (!$filaAberta): ?>
              <i class="bi bi-lock me-2"></i>Fila Indisponível no Momento
            <?php else: ?>
              <i class="bi bi-arrow-right-circle me-2"></i>Entrar na Fila Agora
            <?php endif; ?>
          </button>
        </form>
      </div>

      <div class="text-center mt-3">
        <a href="login.php" style="color:rgba(255,255,255,.35);font-size:.83rem;text-decoration:none;transition:.2s"
           onmouseover="this.style.color='rgba(255,255,255,.65)'"
           onmouseout="this.style.color='rgba(255,255,255,.35)'">
          <i class="bi bi-lock me-1"></i>Acesso Barbeiro / Administrador
        </a>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const barbData = <?= $barbDataJson ?>;

const telInput = document.getElementById('tel');
if (telInput) {
  telInput.addEventListener('input', function() {
    let v = this.value.replace(/\D/g,'');
    if (v.length <= 10) v = v.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
    else                v = v.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
    this.value = v;
  });
}

document.querySelectorAll('#barbeiros-container label.card-barbeiro').forEach(lbl => {
  lbl.addEventListener('click', function() {
    const radio = this.querySelector('input[type=radio]');
    if (radio?.disabled) return;
    document.querySelectorAll('#barbeiros-container label.card-barbeiro').forEach(l => l.classList.remove('selecionado'));
    radio.checked = true;
    this.classList.add('selecionado');
    const id = parseInt(radio.value);
    const d  = barbData.find(b => b.id === id);
    if (d) {
      const pos   = d.fila + 1;
      const tempo = d.tempo;
      document.getElementById('info-fila-num').textContent = d.fila;
      document.getElementById('info-pos').textContent      = pos + 'º lugar';
      document.getElementById('info-tempo').textContent    =
        tempo === 0 ? 'Imediato ⚡' :
        tempo >= 60 ? Math.floor(tempo/60)+'h'+String(tempo%60).padStart(2,'0')+'min' :
        tempo + 'min';
      document.getElementById('fila-info').style.display = 'block';
    }
  });
});

document.getElementById('formFila').addEventListener('submit', function(e) {
  const nome = this.querySelector('[name=nome]')?.value.trim();
  const tel  = this.querySelector('[name=telefone]')?.value.trim();
  const barb = this.querySelector('[name=barbeiro_id]:checked');
  if (!nome || !tel || !barb) { e.preventDefault(); return; }
  const btn = document.getElementById('btnEntrar');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Entrando na fila...';
});

<?php if (!empty($promocoesIndex)): ?>
const totalPromos = <?= count($promocoesIndex) ?>;
let   promoAtual  = 0;
let   promoTimer  = null;
const promoCores  = <?= json_encode(array_column($promocoesIndex, 'cor')) ?>;

function irParaPromo(idx) {
  const atual = document.getElementById('promoCard' + promoAtual);
  if (atual) {
    atual.style.transition = 'opacity .25s';
    atual.style.opacity    = '0';
    setTimeout(() => {
      atual.style.display = 'none';
      atual.style.opacity = '1';
      const prox = document.getElementById('promoCard' + idx);
      if (prox) {
        prox.style.opacity    = '0';
        prox.style.display    = 'block';
        prox.style.transition = 'opacity .25s';
        setTimeout(() => prox.style.opacity = '1', 20);
      }
      promoAtual = idx;
      atualizarDots();
      reiniciarTimer();
    }, 250);
  }
}

function fecharPromo(idx) {
  const card = document.getElementById('promoCard' + idx);
  if (!card) return;
  card.style.transition = 'opacity .3s, transform .3s';
  card.style.opacity    = '0';
  card.style.transform  = 'translateY(-10px)';
  setTimeout(() => {
    card.style.display = 'none';
    let achou = false;
    for (let i = 0; i < totalPromos; i++) {
      const c = document.getElementById('promoCard' + i);
      if (c && c.style.display !== 'none' && i !== idx) { promoAtual = i; achou = true; break; }
    }
    if (!achou) { const wrap = document.getElementById('promosWrap'); if (wrap) wrap.remove(); }
    else { atualizarDots(); }
  }, 300);
}

function atualizarDots() {
  for (let i = 0; i < totalPromos; i++) {
    const dot = document.getElementById('promoDot' + i);
    if (!dot) continue;
    if (i === promoAtual) {
      dot.style.width = '20px'; dot.style.background = promoCores[i] || '#e94560'; dot.classList.add('active');
    } else {
      dot.style.width = '7px'; dot.style.background = 'rgba(255,255,255,.25)'; dot.classList.remove('active');
    }
  }
  const contador = document.getElementById('promoContador');
  if (contador) contador.textContent = (promoAtual + 1) + '/' + totalPromos;
}

function reiniciarTimer() {
  if (promoTimer) clearInterval(promoTimer);
  if (totalPromos > 1) promoTimer = setInterval(() => irParaPromo((promoAtual + 1) % totalPromos), 6000);
}
reiniciarTimer();
<?php endif; ?>

setTimeout(() => location.reload(), 120000);
</script>
<?php if (file_exists(__DIR__ . '/sw.js')): ?>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
<?php endif; ?>
</body>
</html>