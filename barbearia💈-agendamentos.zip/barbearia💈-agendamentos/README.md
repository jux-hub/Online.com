# 💈 Barbearia Renato Barber — Sistema de Fila & Gestão

Sistema completo de fila de espera e gestão para barbearia, desenvolvido em PHP + SQLite, com suporte a PWA, WhatsApp, loja online e painel multi-perfil.

---

## 🚀 Funcionalidades Principais

### 👥 Perfis de Acesso
| Perfil | Acesso |
|---|---|
| **Admin** | Controle total do sistema |
| **Barbeiro** | Painel próprio de fila e atendimento |
| **Assistente** | Gerencia fila de todos os barbeiros |
| **Cliente** | Entra na fila e acompanha posição |

---

## 📋 Módulos do Sistema

### 1. 🔢 Fila de Espera
- Cliente entra na fila escolhendo o barbeiro
- Acompanhamento em tempo real da posição
- Token de segurança por cliente (link único)
- Estimativa de tempo de espera
- Limite máximo de clientes por fila configurável
- Fila abre/fecha automaticamente por horário

### 2. 💈 Painel do Barbeiro (`barbeiro/dashboard.php`)
- Visualiza fila própria em tempo real
- Botão **Iniciar Atendimento**
- Botão **Finalizar Atendimento** com registro de produtos/pacotes vendidos
- Botão **Remover Atendimento** (cancelar sem finalizar)
- Atualização automática a cada 30 segundos

### 3. 🗂️ Painel da Assistente (`assistente/dashboard.php`)
- Visualiza fila de **todos os barbeiros**
- Adicionar clientes na fila manualmente
- Botão **Mover** — transfere cliente entre barbeiros (mesmo durante atendimento)
- Botão **Adicionar Produtos/Pacotes** igual ao painel do barbeiro
- Finalizar e remover atendimentos

### 4. 🛡️ Painel Admin (`admin/`)
- **Dashboard** — visão geral do sistema
- **Fila Geral** — visualização de todas as filas
- **Barbeiros** — cadastro e gestão
- **Assistentes** — cadastro e gestão
- **Serviços** — cadastro de serviços oferecidos
- **Clientes** — cadastro, perfil, VIP, histórico, exportação CSV
- **Pacotes & Créditos** — criação de pacotes de serviços
- **Produtos p/ Venda** — cadastro de produtos
- **Vendas** — histórico de vendas
- **Pedidos Online** — gestão de pedidos da loja
- **Relatórios** — gráficos e estatísticas
- **Histórico** — histórico completo de atendimentos
- **Promoções** — criação e gestão de promoções
- **WhatsApp** — envio de mensagens para clientes
- **PWA & Ícones** — upload e gestão de ícones do app
- **Configurações** — todas as configurações do sistema

---

## ⚙️ Configurações do Sistema

### Configurações Gerais
| Campo | Descrição |
|---|---|
| Nome da Barbearia | Nome exibido em todo o sistema |
| Tempo médio por corte | Usado para calcular estimativa de espera |
| Limite máximo por fila | Máximo de clientes por barbeiro |
| Notificar quando restarem X pessoas | Gatilho para notificação WhatsApp |

### Horários & Controle da Fila
- Toggle geral (abre/fecha fila manualmente)
- Horário padrão de abertura e fechamento
- Configuração individual por dia da semana
- Motivo de fechamento por dia (ex: Feriado, Folga)
- Status em tempo real (Aberta / Fechada)

### Loja Online
- Ativar/desativar botão Vitrine na página inicial
- Ativar/desativar botão "Minha Conta"
- Controle de status da loja
- Retirada na barbearia ou entrega em domicílio
- Taxa de entrega configurável

---

## 📱 PWA (Progressive Web App)
- Instalável no celular como app nativo
- Funciona offline (service worker)
- Ícones em 8 tamanhos gerados automaticamente
- Manifest.json configurado
- Tema e splash screen personalizados

---

## 📲 Notificações WhatsApp

### Provedores Suportados
| Provedor | Tipo |
|---|---|
| **CallMeBot** | Gratuito |
| **Z-API** | Pago |
| **Evolution API** | Self-hosted |

### Como Funciona a Notificação Automática (CRON)
1. O CRON roda a cada 1 minuto
2. Verifica todos os clientes aguardando na fila
3. Conta quantas pessoas estão à frente de cada cliente, **por barbeiro**
4. Quando atingir o limite configurado → envia WhatsApp
5. Se a posição piorar → reseta e notifica de novo quando voltar

### Configuração do CRON
```bash
* * * * * /usr/local/bin/lsphp -q /home/SEU_USUARIO/public_html/barbearia/api/notificar_fila.php >> /home/SEU_USUARIO/public_html/barbearia/logs/notif.log 2>&1
```

> ⚠️ Substitua `SEU_USUARIO` pelo seu usuário da hospedagem.

---

## 🔒 Segurança
- Token único por cliente na fila (link intransferível)
- Validação via `hash_equals()` contra timing attacks
- Acesso sem token retorna HTTP 403
- Senhas com `password_hash()` / `password_verify()`
- Proteção de pasta `logs/` via `.htaccess`

---

## 🗂️ Estrutura de Arquivos
```
barbearia/
├── index.php                  # Página do cliente (entrar na fila)
├── config.php                 # Configurações globais e funções
├── logout.php
├── manifest.json              # PWA
├── sw.js                      # Service Worker
│
├── admin/
│   ├── dashboard.php
│   ├── configuracoes.php
│   ├── barbeiros.php
│   ├── assistentes.php
│   ├── clientes_cadastrados.php
│   ├── servicos.php
│   ├── produtos.php
│   ├── pacotes_produtos.php
│   ├── vendas.php
│   ├── pedidos.php
│   ├── relatorios.php
│   ├── historico.php
│   ├── promocoes.php
│   ├── whatsapp_clientes.php
│   └── pwa.php
│
├── barbeiro/
│   └── dashboard.php
│
├── assistente/
│   └── dashboard.php
│
├── cliente/
│   ├── status.php             # Acompanhar posição na fila
│   └── minha-conta.php
│
├── api/
│   └── notificar_fila.php     # CRON de notificações WhatsApp
│
├── whatsapp/
│   └── config.php             # Integração WhatsApp
│
├── uploads/                   # Logos e imagens
└── logs/
    └── notif.log              # Log do CRON
```

---

## 🛠️ Requisitos do Servidor
| Requisito | Versão |
|---|---|
| PHP | 8.1+ |
| PDO SQLite | Ativado |
| cURL | Ativado |
| Permissão de escrita | `/uploads/` e banco de dados |

---

## 📦 Instalação

1. Faça upload dos arquivos para `public_html/barbearia/`
2. Acesse `seusite.com/barbearia/` — o banco é criado automaticamente
3. Crie o admin inicial direto no banco ou pelo instalador
4. Configure os horários em **Admin → Configurações**
5. Cadastre os barbeiros em **Admin → Barbeiros**
6. Configure o WhatsApp em **Admin → Configurações → WhatsApp**
7. Configure o CRON no cPanel conforme acima
8. Crie a pasta `logs/` com `.htaccess` contendo `Deny from all`

---

## 👨‍💻 Tecnologias Utilizadas
- **PHP 8.1** — backend
- **SQLite** — banco de dados
- **Bootstrap 5.3** — interface
- **Bootstrap Icons** — ícones
- **PWA** — instalação como app
- **WhatsApp API** — notificações

---

*Sistema desenvolvido sob medida para a Barbearia Renato Barber* 💈