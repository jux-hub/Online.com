<?php
require_once '../config.php';
$db = getDB();

$nomeBarbearia = getConfig('nome_barbearia') ?? 'Barbearia';
$logoPath      = getConfig('logo_path')      ?? '';

// ── Logout ──
if (($_GET['acao'] ?? '') === 'sair') {
    unset($_SESSION['conta_cliente_id']);
    header('Location: minha-conta.php');
    exit;
}

// ── Avaliação via POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'avaliar') {
    $fila_id = (int)($_POST['fila_id'] ?? 0);
    $nota    = (int)($_POST['nota']    ?? 0);
    $obs     = trim($_POST['obs']      ?? '');
    $cli_id  = $_SESSION['conta_cliente_id'] ?? 0;

    if ($fila_id && $nota >= 1 && $nota <= 5 && $cli_id) {
        $chk = $db->prepare("SELECT id FROM fila WHERE id=? AND cliente_id=? AND status='concluido'");
        $chk->execute([$fila_id, $cli_id]);
        if ($chk->fetch()) {
            $db->prepare("UPDATE fila SET avaliacao_nota=?, avaliacao_obs=? WHERE id=?")
               ->execute([$nota, $obs, $fila_id]);
        }
    }
    header('Location: minha-conta.php#servicos');
    exit;
}

$clienteLogado = null;
$erro          = '';
$sucesso       = '';
$etapa         = 'login'; // login | codigo | conta

// ── Já logado ──
if (!empty($_SESSION['conta_cliente_id'])) {
    $stmt = $db->prepare("SELECT * FROM clientes WHERE id = ? LIMIT 1");
    $stmt->execute([$_SESSION['conta_cliente_id']]);
    $clienteLogado = $stmt->fetch();
    if ($clienteLogado) $etapa = 'conta';
}

// ── POST: verificar código ──
if ($etapa === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao     = $_POST['acao'] ?? '';
    $telefone = preg_replace('/\D/', '', trim($_POST['telefone'] ?? ''));
    $email    = strtolower(trim($_POST['email'] ?? ''));

    if ($acao === 'verificar_codigo') {
        $digitado = trim($_POST['codigo'] ?? '');
        $cli_id   = (int)($_POST['cli_id'] ?? 0);

        $stmt = $db->prepare("
            SELECT * FROM codigos_acesso
            WHERE cliente_id = ? AND usado = 0 AND expira_em >= datetime('now')
            ORDER BY criado_em DESC LIMIT 5
        ");
        $stmt->execute([$cli_id]);
        $codigos = $stmt->fetchAll();

        $valido = false;
        foreach ($codigos as $cod) {
            if (password_verify($digitado, $cod['codigo'])) {
                $valido   = true;
                $codigoId = $cod['id'];
                break;
            }
        }

        if ($valido) {
            $db->prepare("UPDATE codigos_acesso SET usado=1 WHERE id=?")->execute([$codigoId]);
            $_SESSION['conta_cliente_id'] = $cli_id;
            header('Location: minha-conta.php');
            exit;
        } else {
            $etapa = 'codigo';
            $erro  = 'Código inválido ou expirado. Tente novamente.';
            $_SESSION['conta_pending_id']  = $cli_id;
            $_SESSION['conta_pending_tel'] = $telefone;
        }
    }

    if ($acao === 'solicitar_codigo') {
        $stmt = $db->prepare("SELECT * FROM clientes WHERE telefone = ? LIMIT 1");
        $stmt->execute([$telefone]);
        $cli = $stmt->fetch();

        if ($cli && (!empty($cli['email']) ? strtolower($cli['email']) === $email : true)) {
            $_SESSION['conta_pending_id']  = $cli['id'];
            $_SESSION['conta_pending_tel'] = $telefone;
            $etapa = 'codigo';
        } else {
            $erro = 'Dados não conferem ou cliente não encontrado.';
        }
    }
}

if ($etapa === 'codigo' && empty($_SESSION['conta_pending_id'])) $etapa = 'login';

// ── Dados do cliente logado ──
$historico_servicos = [];
$historico_pedidos  = [];
$pacotes_ativos     = [];
$stats              = [];

if ($etapa === 'conta' && $clienteLogado) {
    $cid = $clienteLogado['id'];
    $tel = $clienteLogado['telefone'];

    // Histórico de serviços
    $historico_servicos = $db->prepare("
        SELECT f.*,
               u.nome  AS barbeiro_nome,
               s.nome  AS servico_nome,
               s.preco AS servico_preco,
               ROUND((JULIANDAY(f.finalizado_em) - JULIANDAY(f.criado_em)) * 1440) AS minutos_espera
        FROM fila f
        LEFT JOIN usuarios u ON u.id = f.barbeiro_id
        LEFT JOIN servicos  s ON s.id = f.servico_id
        WHERE f.cliente_id = ? AND f.status = 'concluido'
        ORDER BY f.finalizado_em DESC
        LIMIT 50
    ");
    $historico_servicos->execute([$cid]);
    $historico_servicos = $historico_servicos->fetchAll();

    // Histórico de pedidos
    $historico_pedidos = $db->prepare("
        SELECT p.*,
               (SELECT GROUP_CONCAT(pi.nome || ' x' || pi.quantidade, ', ')
                FROM pedidos_itens pi WHERE pi.pedido_id = p.id) AS itens_resumo
        FROM pedidos p
        WHERE p.cliente_tel = ?
        ORDER BY p.criado_em DESC
        LIMIT 50
    ");
    $historico_pedidos->execute([$tel]);
    $historico_pedidos = $historico_pedidos->fetchAll();

    // Pacotes ativos
    $pacotes_ativos = $db->prepare("
        SELECT cp.*, pk.nome AS pacote_nome, pk.descricao AS pacote_desc
        FROM clientes_pacotes cp
        JOIN pacotes pk ON pk.id = cp.pacote_id
        WHERE cp.cliente_id = ? AND cp.ativo = 1 AND cp.creditos_restantes > 0
        ORDER BY cp.criado_em DESC
    ");
    $pacotes_ativos->execute([$cid]);
    $pacotes_ativos = $pacotes_ativos->fetchAll();

    // Stats
    $stats['total_servicos'] = count($historico_servicos);
    $stats['total_pedidos']  = count($historico_pedidos);
    $stats['total_gasto_srv'] = array_sum(array_column($historico_servicos, 'valor'));
    $stats['total_gasto_ped'] = array_sum(array_column($historico_pedidos,  'total'));
    $stats['ultimo_servico']  = $historico_servicos[0]['finalizado_em'] ?? null;
    $stats['creditos']        = array_sum(array_column($pacotes_ativos, 'creditos_restantes'));
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Minha Conta – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--dark:#1a1a2e;--darker:#0f3460}
  *{box-sizing:border-box}
  body{
    background:linear-gradient(135deg,var(--dark) 0%,#16213e 50%,var(--darker) 100%);
    min-height:100vh;color:#fff;font-family:'Segoe UI',sans-serif;
  }

  /* ── HERO ── */
  .hero{
    background:linear-gradient(135deg,rgba(233,69,96,.15),rgba(15,52,96,.3));
    border-bottom:1px solid rgba(255,255,255,.07);
    padding:2rem 1rem 1.5rem;text-align:center;
  }
  .hero-logo{
    width:72px;height:72px;border-radius:50%;object-fit:cover;
    border:2px solid var(--primary);box-shadow:0 0 24px rgba(233,69,96,.4);
    margin:0 auto .75rem;display:block;
  }
  .hero-logo-ph{
    width:72px;height:72px;border-radius:50%;
    background:linear-gradient(135deg,var(--primary),#c41230);
    display:flex;align-items:center;justify-content:center;
    margin:0 auto .75rem;font-size:2rem;
    box-shadow:0 0 24px rgba(233,69,96,.4);
  }
  .hero h1{font-size:1.4rem;font-weight:800;margin-bottom:.2rem}
  .hero p{color:rgba(255,255,255,.55);font-size:.88rem;margin:0}

  /* ── CARD ── */
  .card-dark{
    background:rgba(255,255,255,.05);backdrop-filter:blur(20px);
    border:1px solid rgba(255,255,255,.09);border-radius:18px;
  }

  /* ── INPUTS ── */
  .form-control{
    background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:10px;padding:.7rem 1rem;transition:.2s;
  }
  .form-control:focus{
    background:rgba(255,255,255,.13);border-color:var(--primary);color:#fff;
    box-shadow:0 0 0 .2rem rgba(233,69,96,.2);
  }
  .form-control::placeholder{color:rgba(255,255,255,.35)}
  .form-label{color:rgba(255,255,255,.7);font-size:.88rem;font-weight:600;margin-bottom:.4rem}

  /* ── BOTÕES ── */
  .btn-primary-custom{
    background:linear-gradient(135deg,var(--primary),#c41230);
    border:none;border-radius:10px;padding:.75rem;
    font-weight:700;color:#fff;width:100%;transition:.2s;
  }
  .btn-primary-custom:hover{transform:translateY(-1px);box-shadow:0 8px 24px rgba(233,69,96,.35);color:#fff}
  .btn-outline-custom{
    background:transparent;border:1px solid rgba(255,255,255,.2);
    border-radius:10px;padding:.65rem;font-weight:600;
    color:rgba(255,255,255,.7);width:100%;transition:.2s;
  }
  .btn-outline-custom:hover{border-color:var(--primary);color:#fff;background:rgba(233,69,96,.1)}

  /* ── CÓDIGO OTP ── */
  .otp-wrap{display:flex;gap:.5rem;justify-content:center;margin:.75rem 0}
  .otp-input{
    width:46px;height:54px;text-align:center;font-size:1.4rem;font-weight:800;
    background:rgba(255,255,255,.08);border:1.5px solid rgba(255,255,255,.2);
    border-radius:10px;color:#fff;transition:.2s;
  }
  .otp-input:focus{
    border-color:var(--primary);background:rgba(233,69,96,.1);
    box-shadow:0 0 0 .2rem rgba(233,69,96,.2);outline:none;
  }

  /* ── TABS ── */
  .tabs-wrap{
    display:flex;gap:.35rem;padding:.5rem;
    background:rgba(0,0,0,.2);border-radius:12px;margin-bottom:1.25rem;
  }
  .tab-btn{
    flex:1;padding:.6rem;border:none;border-radius:8px;
    background:transparent;color:rgba(255,255,255,.45);
    font-size:.83rem;font-weight:600;cursor:pointer;transition:.2s;
  }
  .tab-btn.active{background:var(--primary);color:#fff;box-shadow:0 4px 12px rgba(233,69,96,.3)}

  /* ── STATS ── */
  .stat-card{
    background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
    border-radius:12px;padding:.85rem;text-align:center;
  }
  .stat-val{font-size:1.5rem;font-weight:800;color:#fff;line-height:1}
  .stat-lbl{font-size:.72rem;color:rgba(255,255,255,.4);margin-top:.3rem;text-transform:uppercase;letter-spacing:.5px}

  /* ── ITEM HISTÓRICO ── */
  .hist-item{
    background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);
    border-radius:12px;padding:.9rem 1rem;margin-bottom:.6rem;transition:.2s;
  }
  .hist-item:hover{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.12)}
  .hist-icon{
    width:40px;height:40px;border-radius:10px;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;font-size:1.1rem;
  }
  .hist-data{font-size:.75rem;color:rgba(255,255,255,.35)}
  .hist-titulo{font-weight:700;color:#fff;font-size:.93rem}
  .hist-sub{font-size:.8rem;color:rgba(255,255,255,.5)}

  /* ── BADGE STATUS ── */
  .badge-status{border-radius:20px;padding:.2rem .7rem;font-size:.72rem;font-weight:700}
  .s-pendente  {background:rgba(234,179,8,.15);  color:#fbbf24;border:1px solid rgba(234,179,8,.3)}
  .s-confirmado{background:rgba(59,130,246,.15); color:#60a5fa;border:1px solid rgba(59,130,246,.3)}
  .s-pronto    {background:rgba(168,85,247,.15); color:#c084fc;border:1px solid rgba(168,85,247,.3)}
  .s-entregue  {background:rgba(34,197,94,.15);  color:#4ade80;border:1px solid rgba(34,197,94,.3)}
  .s-cancelado {background:rgba(239,68,68,.15);  color:#f87171;border:1px solid rgba(239,68,68,.3)}
  .s-concluido {background:rgba(34,197,94,.15);  color:#4ade80;border:1px solid rgba(34,197,94,.3)}

  /* ── ESTRELAS ── */
  .star-btn{background:none;border:none;font-size:1.4rem;cursor:pointer;padding:.1rem;transition:.15s;color:rgba(255,255,255,.2)}
  .star-btn:hover,.star-btn.on{color:#fbbf24}

  /* ── PACOTE CARD ── */
  .pac-card{
    background:linear-gradient(135deg,rgba(233,69,96,.12),rgba(196,18,48,.06));
    border:1px solid rgba(233,69,96,.25);border-radius:12px;padding:.9rem 1rem;
    margin-bottom:.6rem;
  }
  .pac-bar-bg{height:6px;background:rgba(255,255,255,.08);border-radius:4px;margin-top:.5rem}
  .pac-bar-fill{height:6px;background:linear-gradient(90deg,var(--primary),#ff6b8a);border-radius:4px;transition:.6s}

  /* ── ALERTA ── */
  .alerta-erro{background:rgba(220,53,69,.12);border:1px solid rgba(220,53,69,.3);color:#ff8a8a;border-radius:10px;padding:.75rem 1rem;font-size:.88rem}
  .alerta-ok  {background:rgba(34,197,94,.1); border:1px solid rgba(34,197,94,.25);color:#4ade80;border-radius:10px;padding:.75rem 1rem;font-size:.88rem}

  /* ── VOLTAR ── */
  .btn-voltar{
    display:inline-flex;align-items:center;gap:.4rem;
    color:rgba(255,255,255,.45);font-size:.83rem;text-decoration:none;
    padding:.4rem .75rem;border-radius:8px;transition:.2s;
  }
  .btn-voltar:hover{color:#fff;background:rgba(255,255,255,.07)}

  /* ── EMPTY STATE ── */
  .empty-state{text-align:center;padding:2.5rem 1rem;color:rgba(255,255,255,.3)}
  .empty-state i{font-size:2.5rem;display:block;margin-bottom:.75rem;opacity:.4}

  @media(max-width:480px){
    .otp-input{width:40px;height:48px;font-size:1.2rem}
    .stat-val{font-size:1.2rem}
  }
</style>
</head>
<body>

<!-- ── HERO ── -->
<div class="hero">
  <?php if ($logoPath && file_exists(__DIR__.'/../'.$logoPath)): ?>
    <img src="<?= htmlspecialchars('../'.$logoPath) ?>" class="hero-logo" alt="Logo">
  <?php else: ?>
    <div class="hero-logo-ph"><i class="bi bi-scissors text-white"></i></div>
  <?php endif; ?>
  <h1><?= htmlspecialchars($nomeBarbearia) ?></h1>
  <p><?= $etapa === 'conta' ? 'Minha Conta' : 'Acesse seu histórico' ?></p>
</div>

<div class="container py-4" style="max-width:560px">

  <a href="../index.php" class="btn-voltar mb-3 d-inline-flex">
    <i class="bi bi-arrow-left"></i> Voltar
  </a>

  <?php if ($erro): ?>
    <div class="alerta-erro mb-3"><i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($erro) ?></div>
  <?php endif; ?>

  <!-- ════════════════════════════════
       ETAPA 1 — LOGIN
  ════════════════════════════════ -->
  <?php if ($etapa === 'login'): ?>
  <div class="card-dark p-4">
    <h5 class="fw-bold mb-1"><i class="bi bi-person-circle me-2" style="color:var(--primary)"></i>Acessar Minha Conta</h5>
    <p style="color:rgba(255,255,255,.45);font-size:.85rem;margin-bottom:1.5rem">
      Informe seus dados para receber o código de acesso via WhatsApp
    </p>

    <form method="POST" id="formLogin">
      <input type="hidden" name="acao" value="solicitar_codigo">

      <div class="mb-3">
        <label class="form-label"><i class="bi bi-telephone me-1"></i>WhatsApp cadastrado</label>
        <input type="tel" name="telefone" id="telLogin" class="form-control"
               placeholder="(00) 00000-0000" required
               value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>">
      </div>

      <div class="mb-4">
        <label class="form-label"><i class="bi bi-envelope me-1"></i>E-mail</label>
        <input type="email" name="email" class="form-control"
               placeholder="seu@email.com" required
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        <div style="font-size:.75rem;color:rgba(255,255,255,.3);margin-top:.35rem">
          <i class="bi bi-info-circle me-1"></i>
          Na primeira vez, o e-mail será vinculado ao seu cadastro
        </div>
      </div>

      <button type="submit" class="btn-primary-custom" id="btnEnviarCod">
        <span id="btnEnviarTxt"><i class="bi bi-whatsapp me-2"></i>Enviar Código via WhatsApp</span>
      </button>
    </form>

    <div class="text-center mt-3" style="font-size:.78rem;color:rgba(255,255,255,.25)">
      <i class="bi bi-shield-lock me-1"></i>
      Acesso exclusivo para clientes com histórico na barbearia
    </div>
  </div>

  <!-- ════════════════════════════════
       ETAPA 2 — CÓDIGO OTP
  ════════════════════════════════ -->
  <?php elseif ($etapa === 'codigo'): ?>
  <div class="card-dark p-4">
    <div class="text-center mb-3">
      <div style="width:60px;height:60px;border-radius:50%;background:rgba(233,69,96,.15);
                  border:2px solid rgba(233,69,96,.35);display:flex;align-items:center;
                  justify-content:center;margin:0 auto .75rem;font-size:1.6rem">
        <i class="bi bi-chat-dots-fill" style="color:var(--primary)"></i>
      </div>
      <h5 class="fw-bold mb-1">Código Enviado!</h5>
      <p style="color:rgba(255,255,255,.45);font-size:.85rem">
        Digite o código de 6 dígitos enviado para seu WhatsApp.<br>
        <strong style="color:rgba(255,255,255,.6)">Válido por 10 minutos.</strong>
      </p>
    </div>

    <form method="POST" id="formCodigo">
      <input type="hidden" name="acao"   value="verificar_codigo">
      <input type="hidden" name="cli_id" value="<?= (int)($_SESSION['conta_pending_id'] ?? 0) ?>">
      <input type="hidden" name="telefone" value="<?= htmlspecialchars($_SESSION['conta_pending_tel'] ?? '') ?>">
      <input type="hidden" name="codigo" id="codigoHidden">

      <div class="otp-wrap">
        <?php for ($i = 0; $i < 6; $i++): ?>
        <input type="text" maxlength="1" class="otp-input form-control"
               inputmode="numeric" pattern="[0-9]"
               data-index="<?= $i ?>" autocomplete="off">
        <?php endfor; ?>
      </div>

      <button type="submit" class="btn-primary-custom mt-2" id="btnVerificar" disabled>
        <i class="bi bi-unlock me-2"></i>Verificar Código
      </button>
    </form>

    <div class="text-center mt-3">
      <span style="font-size:.82rem;color:rgba(255,255,255,.35)">Não recebeu? </span>
      <button onclick="reenviarCodigo()" id="btnReenviar"
              style="background:none;border:none;color:var(--primary);font-size:.82rem;
                     font-weight:700;cursor:pointer;padding:0">
        Reenviar código
      </button>
      <div id="countdownWrap" style="font-size:.75rem;color:rgba(255,255,255,.3);margin-top:.3rem;display:none">
        Aguarde <span id="countdownNum">60</span>s para reenviar
      </div>
    </div>

    <div class="text-center mt-2">
      <a href="minha-conta.php" style="font-size:.8rem;color:rgba(255,255,255,.3);text-decoration:none">
        <i class="bi bi-arrow-left me-1"></i>Usar outros dados
      </a>
    </div>
  </div>

  <!-- ════════════════════════════════
       ETAPA 3 — CONTA DO CLIENTE
  ════════════════════════════════ -->
  <?php elseif ($etapa === 'conta' && $clienteLogado): ?>

  <!-- Header do cliente -->
  <div class="card-dark p-3 mb-3 d-flex align-items-center gap-3">
    <div style="width:50px;height:50px;border-radius:50%;
                background:linear-gradient(135deg,var(--primary),#c41230);
                display:flex;align-items:center;justify-content:center;
                font-size:1.3rem;flex-shrink:0">
      <i class="bi bi-person-fill text-white"></i>
    </div>
    <div class="flex-grow-1">
      <div style="font-weight:800;font-size:1rem"><?= htmlspecialchars($clienteLogado['nome']) ?></div>
      <div style="font-size:.8rem;color:rgba(255,255,255,.4)">
        <i class="bi bi-telephone me-1"></i><?= htmlspecialchars($clienteLogado['telefone']) ?>
        <?php if ($clienteLogado['email']): ?>
        &nbsp;·&nbsp;<i class="bi bi-envelope me-1"></i><?= htmlspecialchars($clienteLogado['email']) ?>
        <?php endif; ?>
      </div>
    </div>
    <a href="minha-conta.php?acao=sair"
       style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
              color:rgba(255,255,255,.5);border-radius:8px;padding:.4rem .7rem;
              font-size:.78rem;text-decoration:none;transition:.2s;white-space:nowrap"
       onmouseover="this.style.color='#fff'" onmouseout="this.style.color='rgba(255,255,255,.5)'">
      <i class="bi bi-box-arrow-right"></i> Sair
    </a>
  </div>

  <!-- Stats -->
  <div class="row g-2 mb-3">
    <div class="col-3">
      <div class="stat-card">
        <div class="stat-val"><?= $stats['total_servicos'] ?></div>
        <div class="stat-lbl">Cortes</div>
      </div>
    </div>
    <div class="col-3">
      <div class="stat-card">
        <div class="stat-val"><?= $stats['total_pedidos'] ?></div>
        <div class="stat-lbl">Pedidos</div>
      </div>
    </div>
    <div class="col-3">
      <div class="stat-card">
        <div class="stat-val"><?= $stats['creditos'] ?></div>
        <div class="stat-lbl">Créditos</div>
      </div>
    </div>
    <div class="col-3">
      <div class="stat-card">
        <div class="stat-val" style="font-size:1rem">
          R$<?= number_format($stats['total_gasto_srv'] + $stats['total_gasto_ped'], 0, ',', '.') ?>
        </div>
        <div class="stat-lbl">Total</div>
      </div>
    </div>
  </div>

  <!-- Pacotes ativos -->
  <?php if (!empty($pacotes_ativos)): ?>
  <div class="card-dark p-3 mb-3">
    <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:.8px;
                color:rgba(255,255,255,.35);font-weight:600;margin-bottom:.75rem">
      <i class="bi bi-stars me-1" style="color:var(--primary)"></i>Pacotes Ativos
    </div>
    <?php foreach ($pacotes_ativos as $pac):
      $perc = $pac['creditos_total'] > 0
            ? round(($pac['creditos_restantes'] / $pac['creditos_total']) * 100) : 0;
    ?>
    <div class="pac-card">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <div style="font-weight:700;font-size:.92rem"><?= htmlspecialchars($pac['pacote_nome']) ?></div>
          <div style="font-size:.78rem;color:rgba(255,255,255,.45);margin-top:.15rem">
            <?= htmlspecialchars($pac['pacote_desc'] ?? '') ?>
          </div>
        </div>
        <div style="text-align:right;flex-shrink:0;margin-left:.75rem">
          <span style="font-size:1.3rem;font-weight:800;color:var(--primary)"><?= $pac['creditos_restantes'] ?></span>
          <span style="font-size:.75rem;color:rgba(255,255,255,.4)"> / <?= $pac['creditos_total'] ?></span>
          <div style="font-size:.7rem;color:rgba(255,255,255,.3)">créditos</div>
        </div>
      </div>
      <div class="pac-bar-bg">
        <div class="pac-bar-fill" style="width:<?= $perc ?>%"></div>
      </div>
      <?php if ($pac['validade_em']): ?>
      <div style="font-size:.72rem;color:rgba(255,255,255,.3);margin-top:.4rem">
        <i class="bi bi-calendar2 me-1"></i>Válido até <?= date('d/m/Y', strtotime($pac['validade_em'])) ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Tabs -->
  <div class="card-dark p-3">
    <div class="tabs-wrap">
      <button class="tab-btn active" onclick="abrirTab('servicos',this)" id="tabServicos">
        <i class="bi bi-scissors me-1"></i>Serviços
        <span style="background:rgba(255,255,255,.15);border-radius:10px;
                     padding:.05rem .45rem;font-size:.72rem;margin-left:.3rem">
          <?= count($historico_servicos) ?>
        </span>
      </button>
      <button class="tab-btn" onclick="abrirTab('pedidos',this)" id="tabPedidos">
        <i class="bi bi-bag me-1"></i>Pedidos
        <span style="background:rgba(255,255,255,.15);border-radius:10px;
                     padding:.05rem .45rem;font-size:.72rem;margin-left:.3rem">
          <?= count($historico_pedidos) ?>
        </span>
      </button>
    </div>

    <!-- Tab: Serviços -->
    <div id="tabServicos-content">
      <?php if (empty($historico_servicos)): ?>
        <div class="empty-state">
          <i class="bi bi-scissors"></i>
          Nenhum serviço realizado ainda.
        </div>
      <?php else: ?>
        <?php foreach ($historico_servicos as $s):
          $temAvaliacao = !empty($s['avaliacao_nota']);
        ?>
        <div class="hist-item" id="srv<?= $s['id'] ?>">
          <div class="d-flex align-items-start gap-2">
            <div class="hist-icon" style="background:rgba(233,69,96,.12);border:1px solid rgba(233,69,96,.25)">
              <i class="bi bi-scissors" style="color:var(--primary)"></i>
            </div>
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between align-items-start">
                <div>
                  <div class="hist-titulo"><?= htmlspecialchars($s['servico_nome'] ?? 'Serviço') ?></div>
                  <div class="hist-sub">
                    <i class="bi bi-person me-1"></i><?= htmlspecialchars($s['barbeiro_nome'] ?? '—') ?>
                  </div>
                </div>
                <div style="text-align:right;flex-shrink:0;margin-left:.5rem">
                  <?php if ($s['valor']): ?>
                  <div style="font-weight:800;color:#4ade80;font-size:.9rem">
                    R$ <?= number_format($s['valor'], 2, ',', '.') ?>
                  </div>
                  <?php endif; ?>
                  <div class="hist-data"><?= $s['finalizado_em'] ? date('d/m/Y', strtotime($s['finalizado_em'])) : '—' ?></div>
                </div>
              </div>

              <!-- Detalhes -->
              <div class="d-flex flex-wrap gap-2 mt-1" style="font-size:.75rem;color:rgba(255,255,255,.4)">
                <?php if ($s['forma_pagamento']): ?>
                <span><i class="bi bi-credit-card me-1"></i><?= ucfirst($s['forma_pagamento']) ?></span>
                <?php endif; ?>
                <?php if ($s['minutos_espera'] !== null && $s['minutos_espera'] >= 0): ?>
                <span><i class="bi bi-clock me-1"></i>
                  <?= $s['minutos_espera'] >= 60
                    ? floor($s['minutos_espera']/60).'h '.($s['minutos_espera']%60).'min'
                    : $s['minutos_espera'].'min' ?> espera
                </span>
                <?php endif; ?>
              </div>

              <!-- Avaliação -->
              <?php if ($temAvaliacao): ?>
              <div class="mt-1" style="font-size:.8rem">
                <?php for ($n = 1; $n <= 5; $n++): ?>
                  <i class="bi bi-star-fill" style="color:<?= $n <= $s['avaliacao_nota'] ? '#fbbf24' : 'rgba(255,255,255,.15)' ?>;font-size:.85rem"></i>
                <?php endfor; ?>
                <?php if ($s['avaliacao_obs']): ?>
                  <span style="color:rgba(255,255,255,.4);margin-left:.35rem;font-style:italic">
                    "<?= htmlspecialchars($s['avaliacao_obs']) ?>"
                  </span>
                <?php endif; ?>
              </div>
              <?php else: ?>
              <!-- Formulário de avaliação -->
              <div class="mt-2" id="avalForm<?= $s['id'] ?>">
                <div style="font-size:.75rem;color:rgba(255,255,255,.3);margin-bottom:.3rem">
                  <i class="bi bi-star me-1"></i>Avalie este atendimento:
                </div>
                <form method="POST" class="d-flex align-items-center gap-2 flex-wrap">
                  <input type="hidden" name="acao"    value="avaliar">
                  <input type="hidden" name="fila_id" value="<?= $s['id'] ?>">
                  <input type="hidden" name="nota"    id="nota<?= $s['id'] ?>" value="">
                  <div>
                    <?php for ($n = 1; $n <= 5; $n++): ?>
                    <button type="button" class="star-btn" data-fila="<?= $s['id'] ?>" data-val="<?= $n ?>">
                      <i class="bi bi-star-fill"></i>
                    </button>
                    <?php endfor; ?>
                  </div>
                  <input type="text" name="obs" class="form-control"
                         style="height:32px;font-size:.78rem;padding:.3rem .7rem;flex:1;min-width:120px"
                         placeholder="Comentário (opcional)">
                  <button type="submit"
                          style="background:var(--primary);border:none;border-radius:8px;
                                 padding:.3rem .8rem;color:#fff;font-size:.78rem;font-weight:700;
                                 cursor:pointer;white-space:nowrap">
                    Enviar
                  </button>
                </form>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Tab: Pedidos -->
    <div id="tabPedidos-content" style="display:none">
      <?php if (empty($historico_pedidos)): ?>
        <div class="empty-state">
          <i class="bi bi-bag"></i>
          Nenhum pedido realizado ainda.
        </div>
      <?php else: ?>
        <?php foreach ($historico_pedidos as $p): ?>
        <div class="hist-item">
          <div class="d-flex align-items-start gap-2">
            <div class="hist-icon" style="background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.25)">
              <i class="bi bi-bag-fill" style="color:#60a5fa"></i>
            </div>
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between align-items-start">
                <div>
                  <div class="hist-titulo">Pedido #<?= $p['id'] ?></div>
                  <div class="hist-sub" style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                    <?= htmlspecialchars($p['itens_resumo'] ?? '—') ?>
                  </div>
                </div>
                <div style="text-align:right;flex-shrink:0;margin-left:.5rem">
                  <div style="font-weight:800;color:#4ade80;font-size:.9rem">
                    R$ <?= number_format($p['total'], 2, ',', '.') ?>
                  </div>
                  <div class="hist-data"><?= date('d/m/Y', strtotime($p['criado_em'])) ?></div>
                </div>
              </div>
              <div class="d-flex gap-2 mt-1 flex-wrap align-items-center">
                <span class="badge-status s-<?= $p['status'] ?>">
                  <?= ucfirst($p['status']) ?>
                </span>
                <span style="font-size:.75rem;color:rgba(255,255,255,.35)">
                  <i class="bi bi-<?= $p['tipo_entrega'] === 'entrega' ? 'truck' : 'shop' ?> me-1"></i>
                  <?= $p['tipo_entrega'] === 'entrega' ? 'Entrega' : 'Retirada' ?>
                </span>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

  </div><!-- /.card-dark tabs -->

  <?php endif; ?>
</div><!-- /.container -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ── Máscara telefone ──
const telLogin = document.getElementById('telLogin');
if (telLogin) {
  telLogin.addEventListener('input', function() {
    let v = this.value.replace(/\D/g,'');
    if (v.length <= 10) v = v.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
    else                v = v.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
    this.value = v;
  });
}

// ── Submit login com fetch (AJAX) ──
const formLogin = document.getElementById('formLogin');
if (formLogin) {
  formLogin.addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn  = document.getElementById('btnEnviarCod');
    const txt  = document.getElementById('btnEnviarTxt');
    btn.disabled = true;
    txt.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Enviando...';

    const fd = new FormData(this);
    // Remove máscara do telefone antes de enviar
    fd.set('telefone', fd.get('telefone').replace(/\D/g,''));

    try {
      const res  = await fetch('../api/enviar_codigo.php', { method:'POST', body: fd });
      const data = await res.json();

      if (data.ok) {
        // Submete o form PHP para mudar a etapa para 'codigo'
        const hidden = document.createElement('input');
        hidden.type  = 'hidden';
        hidden.name  = 'acao';
        hidden.value = 'solicitar_codigo';
        this.appendChild(hidden);
        this.submit();
      } else {
        txt.innerHTML = '<i class="bi bi-whatsapp me-2"></i>Enviar Código via WhatsApp';
        btn.disabled  = false;
        // Mostra erro
        let el = document.getElementById('erroLogin');
        if (!el) {
          el = document.createElement('div');
          el.id = 'erroLogin';
          el.className = 'alerta-erro mt-3';
          formLogin.appendChild(el);
        }
        el.innerHTML = '<i class="bi bi-exclamation-circle me-2"></i>' + data.msg;
      }
    } catch(err) {
      btn.disabled  = false;
      txt.innerHTML = '<i class="bi bi-whatsapp me-2"></i>Enviar Código via WhatsApp';
    }
  });
}

// ── OTP inputs ──
const otpInputs = document.querySelectorAll('.otp-input');
const codigoHidden = document.getElementById('codigoHidden');
const btnVerificar = document.getElementById('btnVerificar');

otpInputs.forEach((inp, i) => {
  inp.addEventListener('input', function() {
    this.value = this.value.replace(/\D/g,'').slice(-1);
    if (this.value && i < otpInputs.length - 1) otpInputs[i+1].focus();
    verificarOtpCompleto();
  });
  inp.addEventListener('keydown', function(e) {
    if (e.key === 'Backspace' && !this.value && i > 0) otpInputs[i-1].focus();
  });
  inp.addEventListener('paste', function(e) {
    const txt = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g,'');
    if (txt.length === 6) {
      otpInputs.forEach((el, idx) => el.value = txt[idx] || '');
      verificarOtpCompleto();
      e.preventDefault();
    }
  });
});

function verificarOtpCompleto() {
  const codigo = Array.from(otpInputs).map(i => i.value).join('');
  if (codigoHidden) codigoHidden.value = codigo;
  if (btnVerificar) btnVerificar.disabled = codigo.length < 6;
}

// ── Reenviar código ──
let reenviarTimer = null;
function reenviarCodigo() {
  const btn = document.getElementById('btnReenviar');
  const wrap = document.getElementById('countdownWrap');
  const num  = document.getElementById('countdownNum');
  if (!btn) return;

  btn.disabled = true;
  wrap.style.display = 'block';
  let seg = 60;
  num.textContent = seg;
  reenviarTimer = setInterval(() => {
    seg--;
    num.textContent = seg;
    if (seg <= 0) {
      clearInterval(reenviarTimer);
      btn.disabled = false;
      wrap.style.display = 'none';
    }
  }, 1000);

  // Re-submete o form de login via fetch
  fetch('../api/enviar_codigo.php', {
    method: 'POST',
    body: new URLSearchParams({
      telefone: '<?= preg_replace('/\D/','',$_SESSION['conta_pending_tel'] ?? '') ?>',
      email: ''
    })
  });
}

// ── Tabs ──
function abrirTab(nome, btn) {
  document.querySelectorAll('[id$="-content"]').forEach(el => el.style.display = 'none');
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  const content = document.getElementById(nome + '-content');
  if (content) content.style.display = 'block';
  if (btn) btn.classList.add('active');
}

// ── Estrelas de avaliação ──
document.querySelectorAll('.star-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    const fila = this.dataset.fila;
    const val  = parseInt(this.dataset.val);
    document.getElementById('nota' + fila).value = val;
    document.querySelectorAll(`.star-btn[data-fila="${fila}"]`).forEach(b => {
      b.classList.toggle('on', parseInt(b.dataset.val) <= val);
    });
  });
});

// ── Âncora para tab ──
if (window.location.hash === '#servicos') abrirTab('servicos', document.getElementById('tabServicos'));
if (window.location.hash === '#pedidos')  abrirTab('pedidos',  document.getElementById('tabPedidos'));
</script>
</body>
</html>