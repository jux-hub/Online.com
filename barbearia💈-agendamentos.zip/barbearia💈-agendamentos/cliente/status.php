<?php
require_once '../config.php';
$db = getDB();

$fila_id    = (int)($_GET['id']    ?? 0);
$tokenParam = trim($_GET['token'] ?? '');

if (!$fila_id) { header('Location: ../index.php'); exit; }

$stmt = $db->prepare("
    SELECT f.*, c.nome as cliente_nome, c.telefone,
           u.nome as barbeiro_nome,
           s.nome as servico_nome, s.preco as servico_preco,
           s.tempo_minutos
    FROM fila f
    JOIN clientes c ON c.id = f.cliente_id
    JOIN usuarios u ON u.id = f.barbeiro_id
    LEFT JOIN servicos s ON s.id = f.servico_id
    WHERE f.id = ?
");
$stmt->execute([$fila_id]);
$fila = $stmt->fetch();

if (!$fila) { header('Location: ../index.php'); exit; }

// ══ VALIDAÇÃO DE TOKEN ══
$tokenSessao       = $_SESSION['fila_token'] ?? '';
$tokenBanco        = $fila['token'] ?? '';
$tokenUrlValido    = $tokenParam && $tokenBanco && hash_equals($tokenBanco, $tokenParam);
$tokenSessaoValido = $tokenSessao && $tokenBanco && hash_equals($tokenBanco, $tokenSessao);

if (!$tokenUrlValido && !$tokenSessaoValido) {
    http_response_code(403);
    $nomeBarbearia = getConfig('nome_barbearia');
    ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Acesso negado – <?= htmlspecialchars($nomeBarbearia) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
      *{box-sizing:border-box}
      body{background:linear-gradient(135deg,#1a1a2e,#0f3460);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff;font-family:'Segoe UI',sans-serif;padding:1rem}
      .card-erro{background:rgba(255,255,255,.07);backdrop-filter:blur(20px);border:1px solid rgba(239,68,68,.25);border-radius:24px;padding:2.5rem 2rem;max-width:420px;width:100%;text-align:center;box-shadow:0 25px 60px rgba(0,0,0,.5)}
      .erro-icon{width:88px;height:88px;background:rgba(239,68,68,.12);border:2px solid rgba(239,68,68,.3);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;font-size:2.4rem;color:#f87171}
      .erro-titulo{font-size:1.35rem;font-weight:800;color:#fff;margin-bottom:.6rem}
      .erro-msg{color:rgba(255,255,255,.55);font-size:.92rem;line-height:1.6}
      .erro-dica{background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.2);border-radius:12px;padding:.85rem 1rem;margin-top:1.25rem;font-size:.84rem;color:rgba(251,191,36,.85);text-align:left;display:flex;gap:.6rem;align-items:flex-start}
      .btn-inicio{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:12px;padding:.75rem 2rem;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:.5rem;transition:.2s;margin-top:1.5rem;font-size:.95rem}
      .btn-inicio:hover{opacity:.88;color:#fff;transform:translateY(-1px)}
    </style>
    </head>
    <body>
    <div class="card-erro">
      <div class="erro-icon"><i class="bi bi-shield-lock-fill"></i></div>
      <div class="erro-titulo">Acesso não autorizado</div>
      <div class="erro-msg">
        Este link não é válido ou você não tem permissão para visualizar esta posição na fila.
      </div>
      <div class="erro-dica">
        <i class="bi bi-lightbulb-fill" style="color:#fbbf24;flex-shrink:0;margin-top:.1rem"></i>
        <span>Se você entrou na fila, use o link completo que recebeu via <strong>WhatsApp</strong> ou que foi salvo no seu navegador.</span>
      </div>
      <a href="../index.php" class="btn-inicio">
        <i class="bi bi-house-fill"></i>Voltar ao início
      </a>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// Mantém token na sessão para recargas sem parâmetro na URL
if ($tokenUrlValido) {
    $_SESSION['fila_token'] = $tokenBanco;
}

$stmt2 = $db->prepare("SELECT COUNT(*) as c FROM fila WHERE barbeiro_id=? AND status='aguardando' AND criado_em < (SELECT criado_em FROM fila WHERE id=?)");
$stmt2->execute([$fila['barbeiro_id'], $fila_id]);
$frente = (int)$stmt2->fetch()['c'];

$tempoMedio    = (int)getConfig('tempo_medio_corte');
$tempoEstimado = $frente * $tempoMedio;
$notifPos      = (int)getConfig('notificacao_posicoes');
$nomeBarbearia = getConfig('nome_barbearia');

$statusLabel = [
    'aguardando' => ['Aguardando','warning'],
    'atendendo'  => ['Em Atendimento','success'],
    'concluido'  => ['Concluído','info'],
    'cancelado'  => ['Cancelado','danger'],
];
[$statusTxt, $statusCor] = $statusLabel[$fila['status']] ?? ['Desconhecido','secondary'];

$keyComp = $fila['status'] === 'concluido'
    ? substr(md5($fila_id . date('Y-m-d', strtotime($fila['finalizado_em']))), 0, 8)
    : '';

$protocol  = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$urlStatus = $protocol . '://' . $_SERVER['HTTP_HOST']
           . BASE_URL . "/cliente/status.php?id={$fila_id}&token=" . urlencode($tokenBanco);
$msgWaShare = "✂️ *{$nomeBarbearia}*\n\nEstou na fila e você pode acompanhar minha vez aqui:\n👉 {$urlStatus}";
$urlWaShare = 'https://wa.me/?text=' . rawurlencode($msgWaShare);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Minha Vez – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--green:#22c55e;--blue:#38bdf8}
  *{box-sizing:border-box}
  body{background:linear-gradient(135deg,#1a1a2e 0%,#0f3460 100%);min-height:100vh;color:#fff;font-family:'Segoe UI',sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:1rem}

  .card-status{background:rgba(255,255,255,.07);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.12);border-radius:24px;padding:2rem;max-width:480px;width:100%;box-shadow:0 25px 60px rgba(0,0,0,.4)}

  .brand-circle{width:64px;height:64px;background:linear-gradient(135deg,#e94560,#c41230);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto .75rem;font-size:1.6rem;box-shadow:0 0 30px rgba(233,69,96,.4)}

  .posicao-num{font-size:5.5rem;font-weight:900;color:#e94560;line-height:1;text-shadow:0 0 50px rgba(233,69,96,.6)}
  .pulse{animation:pulse 2s infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.55}}

  .notif-banner{background:linear-gradient(135deg,rgba(233,69,96,.3),rgba(196,18,48,.3));border:1px solid rgba(233,69,96,.5);border-radius:14px;padding:1rem 1.25rem;text-align:center;animation:pulse 1.2s infinite}
  .notif-banner-next{background:linear-gradient(135deg,rgba(251,191,36,.2),rgba(217,119,6,.2));border:1px solid rgba(251,191,36,.4);border-radius:14px;padding:.85rem 1.25rem;text-align:center}

  .progress-wrap{background:rgba(255,255,255,.08);border-radius:99px;height:8px;overflow:hidden;margin:.5rem 0 1rem}
  .progress-bar-custom{height:100%;border-radius:99px;background:linear-gradient(90deg,#e94560,#ff8fa3);transition:width .5s ease}

  .info-row{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:.85rem 1rem;margin-bottom:.5rem;display:flex;justify-content:space-between;align-items:center;gap:.5rem}
  .info-label{color:rgba(255,255,255,.55);font-size:.88rem;display:flex;align-items:center;gap:.4rem}
  .info-val{font-weight:600;color:#fff;font-size:.92rem;text-align:right}

  .atend-card{background:linear-gradient(135deg,rgba(34,197,94,.15),rgba(22,163,74,.1));border:1px solid rgba(34,197,94,.4);border-radius:18px;padding:1.5rem;text-align:center}
  .atend-icon{font-size:4.5rem;color:#22c55e;animation:pulse 1s infinite}
  .concluido-card{background:linear-gradient(135deg,rgba(56,189,248,.12),rgba(14,165,233,.08));border:1px solid rgba(56,189,248,.3);border-radius:18px;padding:1.5rem;text-align:center}
  .cancelado-card{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:18px;padding:1.5rem;text-align:center}

  /* ══ CARD COMPARTILHAR ══ */
  .share-card{background:linear-gradient(135deg,rgba(59,130,246,.12),rgba(37,99,235,.08));border:1px solid rgba(59,130,246,.3);border-radius:18px;padding:1.1rem 1.2rem;margin-top:1.25rem}
  .share-title{display:flex;align-items:center;gap:.5rem;font-size:.82rem;font-weight:700;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.7px;margin-bottom:.85rem}
  .share-url-box{display:flex;align-items:center;gap:.5rem;background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:.5rem .7rem .5rem 1rem;margin-bottom:.85rem}
  .share-url-text{flex:1;font-size:.78rem;color:rgba(255,255,255,.55);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:monospace}
  .btn-copy{background:rgba(59,130,246,.25);border:1px solid rgba(59,130,246,.4);color:#60a5fa;border-radius:7px;padding:.32rem .75rem;font-size:.78rem;font-weight:700;cursor:pointer;transition:.2s;white-space:nowrap;display:flex;align-items:center;gap:.35rem;flex-shrink:0}
  .btn-copy:hover{background:rgba(59,130,246,.45);color:#93c5fd}
  .btn-copy.copiado{background:rgba(34,197,94,.25);border-color:rgba(34,197,94,.4);color:#4ade80}
  .share-btns{display:flex;gap:.6rem}
  .btn-share-wa{flex:1;background:linear-gradient(135deg,#25d366,#1da851);border:none;color:#fff;border-radius:10px;padding:.6rem .9rem;font-size:.88rem;font-weight:700;cursor:pointer;transition:.2s;display:flex;align-items:center;justify-content:center;gap:.45rem;text-decoration:none}
  .btn-share-wa:hover{opacity:.88;transform:translateY(-1px);color:#fff}
  .btn-share-native{flex:1;background:rgba(255,255,255,.09);border:1px solid rgba(255,255,255,.15);color:rgba(255,255,255,.8);border-radius:10px;padding:.6rem .9rem;font-size:.88rem;font-weight:600;cursor:pointer;transition:.2s;display:flex;align-items:center;justify-content:center;gap:.45rem}
  .btn-share-native:hover{background:rgba(255,255,255,.16);color:#fff}

  .btn-voltar{background:rgba(255,255,255,.09);border:1px solid rgba(255,255,255,.18);color:#fff;border-radius:12px;padding:.7rem 1.25rem;transition:all .25s;display:flex;align-items:center;gap:.45rem;text-decoration:none;font-weight:600;justify-content:center}
  .btn-voltar:hover{background:rgba(233,69,96,.2);border-color:#e94560;color:#fff}
  .btn-comprovante{background:linear-gradient(135deg,#22c55e,#16a34a);border:none;color:#fff;border-radius:12px;padding:.7rem 1.25rem;font-weight:700;text-decoration:none;display:flex;align-items:center;gap:.45rem;justify-content:center;transition:.2s}
  .btn-comprovante:hover{opacity:.88;color:#fff;transform:translateY(-1px)}

  .refresh-hint{font-size:.72rem;color:rgba(255,255,255,.25);display:flex;align-items:center;gap:.35rem;justify-content:center}

  h4,h5,h3{color:#fff}

  @media(max-width:400px){
    .card-status{padding:1.4rem 1.1rem}
    .posicao-num{font-size:4.5rem}
    .share-btns{flex-direction:column}
  }
</style>
</head>
<body>
<div class="card-status">

  <div class="text-center mb-4">
    <div class="brand-circle"><i class="bi bi-scissors"></i></div>
    <h4 class="fw-bold mb-0"><?= htmlspecialchars($nomeBarbearia) ?></h4>
    <small style="color:rgba(255,255,255,.45)">Acompanhe sua vez em tempo real</small>
  </div>

  <?php if ($fila['status'] === 'aguardando'): ?>
    <?php if ($frente === 0): ?>
      <div class="notif-banner mb-3">
        <i class="bi bi-bell-fill me-2"></i><strong>É a sua vez em breve!</strong> Prepare-se! ✂️
      </div>
    <?php elseif ($frente <= $notifPos): ?>
      <div class="notif-banner-next mb-3">
        <i class="bi bi-exclamation-circle-fill me-2" style="color:#fbbf24"></i>
        Faltam apenas <strong style="color:#fbbf24"><?= $frente ?></strong> pessoa<?= $frente > 1 ? 's' : '' ?> à sua frente!
      </div>
    <?php endif; ?>
    <div class="text-center mb-2">
      <p style="color:rgba(255,255,255,.55);font-size:.88rem;margin-bottom:.25rem">
        <i class="bi bi-people me-1"></i>Pessoas à sua frente
      </p>
      <div class="posicao-num pulse"><?= $frente ?></div>
    </div>
    <?php $posInicial = $frente + 1; $pct = $posInicial > 0 ? max(5, min(95, round((1/$posInicial)*100))) : 95; ?>
    <div class="progress-wrap">
      <div class="progress-bar-custom" style="width:<?= $pct ?>%"></div>
    </div>
    <div class="text-center mb-3">
      <span style="color:rgba(255,255,255,.55);font-size:.9rem">Tempo estimado: </span>
      <strong style="color:#fff;font-size:1rem">
        <?= $tempoEstimado === 0 ? 'Imediato ⚡' : '~' . $tempoEstimado . ' min' ?>
      </strong>
    </div>

  <?php elseif ($fila['status'] === 'atendendo'): ?>
    <div class="atend-card mb-3">
      <div class="atend-icon"><i class="bi bi-scissors"></i></div>
      <h4 class="fw-bold mt-2 mb-1">É a sua vez!</h4>
      <p style="color:rgba(255,255,255,.65);margin:0">Seu atendimento está em andamento</p>
    </div>

  <?php elseif ($fila['status'] === 'concluido'): ?>
    <div class="concluido-card mb-3">
      <div style="font-size:4rem;color:#38bdf8"><i class="bi bi-check-circle-fill"></i></div>
      <h4 class="fw-bold mt-2 mb-1">Atendimento concluído!</h4>
      <p style="color:rgba(255,255,255,.6);margin:0">Obrigado pela preferência. Volte sempre! 💈</p>
    </div>

  <?php elseif ($fila['status'] === 'cancelado'): ?>
    <div class="cancelado-card mb-3">
      <div style="font-size:4rem;color:#ef4444"><i class="bi bi-x-circle-fill"></i></div>
      <h4 class="fw-bold mt-2 mb-1">Atendimento cancelado</h4>
      <p style="color:rgba(255,255,255,.55);margin:0">Entre em contato com a barbearia se precisar.</p>
    </div>
  <?php endif; ?>

  <div class="mt-2">
    <div class="info-row">
      <span class="info-label"><i class="bi bi-person-fill"></i>Cliente</span>
      <span class="info-val"><?= htmlspecialchars($fila['cliente_nome']) ?></span>
    </div>
    <div class="info-row">
      <span class="info-label"><i class="bi bi-scissors"></i>Barbeiro</span>
      <span class="info-val"><?= htmlspecialchars($fila['barbeiro_nome']) ?></span>
    </div>
    <?php if ($fila['servico_nome']): ?>
    <div class="info-row">
      <span class="info-label"><i class="bi bi-list-check"></i>Serviço</span>
      <span class="info-val"><?= htmlspecialchars($fila['servico_nome']) ?> – <?= formatMoney($fila['servico_preco']) ?></span>
    </div>
    <?php endif; ?>
    <div class="info-row">
      <span class="info-label"><i class="bi bi-circle-fill"></i>Status</span>
      <span class="badge bg-<?= $statusCor ?> fs-6"><?= $statusTxt ?></span>
    </div>
    <?php if ($fila['forma_pagamento'] && $fila['status'] === 'concluido'): ?>
    <div class="info-row">
      <span class="info-label"><i class="bi bi-credit-card"></i>Pagamento</span>
      <span class="info-val"><?= ucfirst($fila['forma_pagamento']) ?></span>
    </div>
    <?php endif; ?>
  </div>

  <!-- ══ CARD COMPARTILHAR (só quando ativo) ══ -->
  <?php if (in_array($fila['status'], ['aguardando','atendendo'])): ?>
  <div class="share-card">
    <div class="share-title">
      <i class="bi bi-link-45deg" style="color:#60a5fa;font-size:1rem"></i>
      Salve o link da sua vez
    </div>
    <div class="share-url-box">
      <span class="share-url-text" id="urlTexto"><?= htmlspecialchars($urlStatus) ?></span>
      <button class="btn-copy" id="btnCopy" onclick="copiarLink()">
        <i class="bi bi-copy" id="iconCopy"></i>
        <span id="txtCopy">Copiar</span>
      </button>
    </div>
    <div class="share-btns">
      <a href="<?= htmlspecialchars($urlWaShare) ?>" target="_blank" rel="noopener" class="btn-share-wa">
        <i class="bi bi-whatsapp"></i>Compartilhar no WhatsApp
      </a>
      <button class="btn-share-native" id="btnShareNative" onclick="compartilharNativo()" style="display:none">
        <i class="bi bi-share-fill"></i>Compartilhar
      </button>
    </div>
  </div>
  <?php endif; ?>

  <?php if (in_array($fila['status'], ['aguardando','atendendo'])): ?>
  <div class="refresh-hint mt-3">
    <i class="bi bi-arrow-clockwise"></i>Atualiza automaticamente a cada 15s
  </div>
  <?php endif; ?>

  <div class="d-flex gap-2 mt-3 flex-wrap">
    <a href="../index.php" class="btn-voltar flex-grow-1">
      <i class="bi bi-house-fill"></i>Início
    </a>
    <?php if ($fila['status'] === 'concluido' && $keyComp): ?>
    <a href="../comprovante.php?id=<?= $fila_id ?>&key=<?= $keyComp ?>" class="btn-comprovante flex-grow-1" target="_blank">
      <i class="bi bi-receipt"></i>Ver Comprovante
    </a>
    <?php endif; ?>
  </div>

</div>

<script>
<?php if (in_array($fila['status'],['aguardando','atendendo'])): ?>
setTimeout(() => location.reload(), 15000);
<?php endif; ?>

<?php if ($frente <= 2 && $fila['status'] === 'aguardando'): ?>
if ('Notification' in window && Notification.permission !== 'denied') {
  Notification.requestPermission().then(p => {
    if (p === 'granted') {
      new Notification('✂️ <?= addslashes($nomeBarbearia) ?> – Quase sua vez!', {
        body: 'Faltam apenas <?= $frente ?> pessoa(s) na sua frente!',
        icon: '<?= BASE_URL ?>/icons/icon-192.png'
      });
    }
  });
}
<?php endif; ?>

function copiarLink() {
  const url  = <?= json_encode($urlStatus) ?>;
  const btn  = document.getElementById('btnCopy');
  const icon = document.getElementById('iconCopy');
  const txt  = document.getElementById('txtCopy');
  const reset = () => {
    btn.classList.remove('copiado');
    icon.className = 'bi bi-copy';
    txt.textContent = 'Copiar';
  };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(url).then(() => {
      btn.classList.add('copiado'); icon.className = 'bi bi-check2'; txt.textContent = 'Copiado!';
      setTimeout(reset, 2500);
    }).catch(() => fallbackCopy(url, btn, txt, reset));
  } else {
    fallbackCopy(url, btn, txt, reset);
  }
}

function fallbackCopy(url, btn, txt, reset) {
  const el = document.createElement('textarea');
  el.value = url; el.style.position = 'fixed'; el.style.opacity = '0';
  document.body.appendChild(el); el.select();
  try { document.execCommand('copy'); txt.textContent = 'Copiado!'; setTimeout(reset, 2000); } catch(e) {}
  document.body.removeChild(el);
}

if (navigator.share) {
  document.getElementById('btnShareNative').style.display = 'flex';
}
function compartilharNativo() {
  navigator.share({
    title: '<?= addslashes($nomeBarbearia) ?> – Minha Vez',
    text:  'Acompanhe minha vez na fila da barbearia!',
    url:   <?= json_encode($urlStatus) ?>
  }).catch(() => {});
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</body>
</html>