<?php
/**
 * cliente/avaliacoes.php
 * Cliente acessa via link enviado por WhatsApp após atendimento
 * GET: token=xxx (identifica o atendimento) ou cliente_tel=xxx
 */
require_once '../config.php';
$db = getDB();

$nomeBarbearia = getConfig('nome_barbearia') ?: 'Barbearia';
$logoBarbearia = getConfig('logo_barbearia') ?: '';

// ── Criar tabela de avaliações ──
$db->exec("
    CREATE TABLE IF NOT EXISTS avaliacoes (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        fila_id      INTEGER,
        cliente_id   INTEGER,
        barbeiro_id  INTEGER,
        nota         INTEGER NOT NULL CHECK(nota BETWEEN 1 AND 5),
        comentario   TEXT,
        token        TEXT UNIQUE,
        criado_em    DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
// Adicionar coluna avaliacao_token em fila se não existir
try { $db->exec("ALTER TABLE fila ADD COLUMN avaliacao_token TEXT"); } catch(Exception $e) {}
try { $db->exec("ALTER TABLE fila ADD COLUMN avaliado INTEGER DEFAULT 0"); } catch(Exception $e) {}

$token     = trim($_GET['token'] ?? '');
$clienteTel = trim($_GET['tel'] ?? '');
$erro      = '';
$sucesso   = false;
$atendimento = null;
$jaAvaliou = false;

// ── Buscar atendimento pelo token ──
if ($token) {
    $stmt = $db->prepare("
        SELECT f.*, c.nome AS cliente_nome, c.telefone AS cliente_tel,
               b.nome AS barbeiro_nome, b.cor AS barbeiro_cor,
               s.nome AS servico_nome
        FROM fila f
        LEFT JOIN clientes c ON c.id = f.cliente_id
        LEFT JOIN usuarios b ON b.id = f.barbeiro_id
        LEFT JOIN servicos s ON s.id = f.servico_id
        WHERE f.avaliacao_token = ? AND f.status = 'concluido'
    ");
    $stmt->execute([$token]);
    $atendimento = $stmt->fetch();

    if ($atendimento) {
        $jaAvaliou = (bool)$atendimento['avaliado'];
        // Verificar se já existe avaliação
        $av = $db->prepare("SELECT id FROM avaliacoes WHERE fila_id=?");
        $av->execute([$atendimento['id']]);
        if ($av->fetch()) $jaAvaliou = true;
    }
}

// ── POST: salvar avaliação ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $atendimento && !$jaAvaliou) {
    $nota      = (int)($_POST['nota']       ?? 0);
    $comentario = trim($_POST['comentario'] ?? '');

    if ($nota < 1 || $nota > 5) {
        $erro = 'Selecione uma nota de 1 a 5 estrelas.';
    } else {
        $db->prepare("
            INSERT INTO avaliacoes (fila_id, cliente_id, barbeiro_id, nota, comentario, token)
            VALUES (?,?,?,?,?,?)
        ")->execute([
            $atendimento['id'],
            $atendimento['cliente_id'],
            $atendimento['barbeiro_id'],
            $nota,
            $comentario,
            bin2hex(random_bytes(8))
        ]);
        $db->prepare("UPDATE fila SET avaliado=1 WHERE id=?")->execute([$atendimento['id']]);
        $sucesso = true;
    }
}

// ── Últimas avaliações públicas (para exibir na página) ──
$ultimasAv = $db->query("
    SELECT av.nota, av.comentario, av.criado_em,
           b.nome AS barbeiro_nome, b.cor AS barbeiro_cor,
           c.nome AS cliente_nome
    FROM avaliacoes av
    LEFT JOIN usuarios b ON b.id = av.barbeiro_id
    LEFT JOIN clientes c ON c.id = av.cliente_id
    WHERE av.nota >= 4 AND av.comentario != ''
    ORDER BY av.criado_em DESC
    LIMIT 6
")->fetchAll();

// ── Média geral ──
$media = $db->query("SELECT ROUND(AVG(nota),1) AS media, COUNT(*) AS total FROM avaliacoes")->fetch();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Avaliação – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--primary:#e94560}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0;min-height:100vh}
.hero{background:linear-gradient(135deg,#1a1a2e,#16213e);padding:2rem 1rem 1.5rem;text-align:center;
  border-bottom:1px solid rgba(255,255,255,.08)}
.hero-icon{width:68px;height:68px;border-radius:18px;background:linear-gradient(135deg,var(--primary),#c41230);
  display:inline-flex;align-items:center;justify-content:center;font-size:1.9rem;margin-bottom:.75rem}
.container-av{max-width:480px;margin:0 auto;padding:1.5rem 1rem}
.card-av{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1rem}

/* Estrelas */
.stars-input{display:flex;flex-direction:row-reverse;justify-content:center;gap:.3rem;margin:1rem 0}
.stars-input input{display:none}
.stars-input label{font-size:2.5rem;cursor:pointer;color:rgba(255,255,255,.15);transition:all .2s;line-height:1}
.stars-input label:hover,.stars-input label:hover~label,
.stars-input input:checked~label{color:#fbbf24;transform:scale(1.1)}

/* Estrelas estáticas */
.star-static{color:#fbbf24;font-size:1rem}
.star-empty{color:rgba(255,255,255,.15);font-size:1rem}

.msg-area{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
  color:#fff;border-radius:12px;padding:.8rem 1rem;width:100%;font-size:.9rem;
  resize:vertical;min-height:90px;font-family:inherit;transition:.2s}
.msg-area:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
.msg-area::placeholder{color:rgba(255,255,255,.3)}

.btn-avaliar{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;
  width:100%;border-radius:14px;padding:.95rem;font-weight:800;font-size:1rem;cursor:pointer;transition:all .3s}
.btn-avaliar:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(233,69,96,.4)}

.av-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
  border-radius:14px;padding:1rem;margin-bottom:.6rem}
.nav-public{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
  padding:.65rem 1.25rem;display:flex;align-items:center;justify-content:space-between}
h3,h4,h5{color:#fff;margin:0}
</style>
</head>
<body>

<div class="nav-public">
  <a href="<?= BASE_URL ?>/" style="color:rgba(255,255,255,.5);text-decoration:none;font-size:.88rem">
    <i class="bi bi-arrow-left me-1"></i>Início
  </a>
  <span style="color:rgba(255,255,255,.35);font-size:.82rem"><i class="bi bi-star me-1"></i>Avaliações</span>
  <span></span>
</div>

<div class="hero">
  <?php if ($logoBarbearia && file_exists('../' . $logoBarbearia)): ?>
  <img src="<?= BASE_URL . '/' . htmlspecialchars($logoBarbearia) ?>" style="width:68px;height:68px;border-radius:18px;object-fit:cover;margin-bottom:.75rem" alt="">
  <?php else: ?>
  <div class="hero-icon"><i class="bi bi-scissors text-white"></i></div>
  <?php endif; ?>
  <h3><?= htmlspecialchars($nomeBarbearia) ?></h3>
  <?php if ($media['total'] > 0): ?>
  <div style="margin-top:.5rem;display:flex;align-items:center;justify-content:center;gap:.4rem">
    <span style="font-size:1.3rem;font-weight:800;color:#fbbf24"><?= $media['media'] ?></span>
    <div>
      <?php for ($i=1;$i<=5;$i++): ?>
      <i class="bi bi-star<?= $i <= round($media['media']) ? '-fill' : '' ?>" style="color:#fbbf24;font-size:.9rem"></i>
      <?php endfor; ?>
    </div>
    <span style="color:rgba(255,255,255,.35);font-size:.82rem">(<?= $media['total'] ?> avaliações)</span>
  </div>
  <?php endif; ?>
</div>

<div class="container-av">

<?php if ($sucesso): ?>
<!-- Confirmação -->
<div style="text-align:center;padding:2.5rem 1rem">
  <div style="font-size:3.5rem;margin-bottom:.75rem">🙏</div>
  <h4 style="color:#4ade80;margin-bottom:.5rem">Obrigado pela avaliação!</h4>
  <p style="color:rgba(255,255,255,.5);font-size:.9rem;max-width:300px;margin:0 auto .5rem">
    Seu feedback nos ajuda a melhorar cada dia mais.
  </p>
  <p style="color:rgba(255,255,255,.35);font-size:.82rem">Até a próxima visita! ✂️💈</p>
  <a href="<?= BASE_URL ?>/"
     style="display:inline-block;margin-top:1.25rem;background:linear-gradient(135deg,var(--primary),#c41230);
            color:#fff;border-radius:12px;padding:.7rem 1.5rem;text-decoration:none;font-weight:700">
    <i class="bi bi-house me-1"></i>Voltar ao início
  </a>
</div>

<?php elseif ($jaAvaliou): ?>
<div class="card-av" style="text-align:center;padding:2rem;border-color:rgba(34,197,94,.2)">
  <div style="font-size:2.5rem;margin-bottom:.5rem">✅</div>
  <h5 style="color:#4ade80;margin-bottom:.4rem">Avaliação já registrada!</h5>
  <p style="color:rgba(255,255,255,.45);font-size:.88rem">Você já avaliou este atendimento. Obrigado!</p>
</div>

<?php elseif ($atendimento): ?>
<!-- Formulário de avaliação -->
<div class="card-av" style="border-color:rgba(233,69,96,.15)">
  <!-- Info do atendimento -->
  <div style="display:flex;align-items:center;gap:.85rem;padding-bottom:1rem;margin-bottom:1rem;
              border-bottom:1px solid rgba(255,255,255,.07)">
    <div style="width:44px;height:44px;border-radius:50%;flex-shrink:0;
                background:<?= htmlspecialchars($atendimento['barbeiro_cor'] ?? '#e94560') ?>22;
                color:<?= htmlspecialchars($atendimento['barbeiro_cor'] ?? '#e94560') ?>;
                display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.1rem">
      <?= mb_strtoupper(mb_substr($atendimento['barbeiro_nome'] ?? '?', 0, 1)) ?>
    </div>
    <div>
      <div style="font-weight:700;color:#fff"><?= htmlspecialchars($atendimento['barbeiro_nome'] ?? '—') ?></div>
      <div style="font-size:.78rem;color:rgba(255,255,255,.4)">
        <?= htmlspecialchars($atendimento['servico_nome'] ?? '—') ?> ·
        <?= date('d/m/Y H:i', strtotime($atendimento['finalizado_em'])) ?>
      </div>
    </div>
  </div>

  <?php if ($erro): ?>
  <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:10px;
              padding:.65rem 1rem;margin-bottom:.85rem;color:#f87171;font-size:.85rem">
    <i class="bi bi-exclamation-triangle me-1"></i><?= htmlspecialchars($erro) ?>
  </div>
  <?php endif; ?>

  <form method="POST">
    <div style="text-align:center;margin-bottom:.5rem">
      <div style="font-size:.9rem;color:rgba(255,255,255,.6);margin-bottom:.25rem">
        Como foi seu atendimento com <strong style="color:#fff"><?= htmlspecialchars(explode(' ', $atendimento['barbeiro_nome'] ?? 'o barbeiro')[0]) ?></strong>?
      </div>
      <div class="stars-input" id="starsWrap">
        <?php for ($i=5;$i>=1;$i--): ?>
        <input type="radio" name="nota" id="star<?= $i ?>" value="<?= $i ?>" required>
        <label for="star<?= $i ?>" title="<?= $i ?> estrela<?= $i>1?'s':'' ?>">⭐</label>
        <?php endfor; ?>
      </div>
      <div id="notaLabel" style="font-size:.82rem;color:rgba(255,255,255,.35);min-height:1.2em"></div>
    </div>

    <div style="margin-bottom:.85rem">
      <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">
        Comentário <span style="color:rgba(255,255,255,.3);font-weight:400">(opcional)</span>
      </label>
      <textarea name="comentario" class="msg-area"
        placeholder="Conta como foi o atendimento, o serviço, o ambiente…"></textarea>
    </div>

    <button type="submit" class="btn-avaliar">
      <i class="bi bi-star-fill me-2"></i>Enviar Avaliação
    </button>
  </form>
</div>

<?php else: ?>
<!-- Sem token: mostrar avaliações públicas -->
<div style="text-align:center;padding:1.5rem 0 .75rem">
  <div style="font-size:.88rem;color:rgba(255,255,255,.4);margin-bottom:.3rem">
    Avaliações recentes dos nossos clientes
  </div>
</div>
<?php endif; ?>

<!-- Avaliações recentes (sempre visíveis) -->
<?php if (!empty($ultimasAv)): ?>
<div style="margin-top:<?= $atendimento ? '1.5rem' : '0' ?>">
  <div style="font-size:.82rem;font-weight:700;color:rgba(255,255,255,.35);
              text-transform:uppercase;letter-spacing:.5px;margin-bottom:.75rem">
    O que nossos clientes dizem
  </div>
  <?php foreach ($ultimasAv as $av):
    $cor = htmlspecialchars($av['barbeiro_cor'] ?? '#e94560');
  ?>
  <div class="av-card">
    <div style="display:flex;align-items:center;gap:.65rem;margin-bottom:.5rem">
      <div style="width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,.1);
                  color:rgba(255,255,255,.5);display:flex;align-items:center;justify-content:center;
                  font-weight:800;font-size:.8rem;flex-shrink:0">
        <?= mb_strtoupper(mb_substr($av['cliente_nome'] ?? '?', 0, 1)) ?>
      </div>
      <div style="flex:1">
        <div style="font-size:.85rem;font-weight:600;color:#fff">
          <?= htmlspecialchars($av['cliente_nome'] ?? 'Cliente') ?>
        </div>
        <div style="font-size:.72rem;color:rgba(255,255,255,.3)">
          <?= date('d/m/Y', strtotime($av['criado_em'])) ?>
          <?php if ($av['barbeiro_nome']): ?>
          · <span style="color:<?= $cor ?>">✂️ <?= htmlspecialchars($av['barbeiro_nome']) ?></span>
          <?php endif; ?>
        </div>
      </div>
      <div style="flex-shrink:0">
        <?php for ($i=1;$i<=5;$i++): ?>
        <i class="bi bi-star<?= $i<=$av['nota']?'-fill':'' ?>" style="color:#fbbf24;font-size:.82rem"></i>
        <?php endfor; ?>
      </div>
    </div>
    <?php if ($av['comentario']): ?>
    <div style="font-size:.83rem;color:rgba(255,255,255,.55);font-style:italic;line-height:1.5">
      "<?= htmlspecialchars($av['comentario']) ?>"
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div style="text-align:center;padding:1.5rem 0;color:rgba(255,255,255,.2);font-size:.75rem">
  <?= htmlspecialchars($nomeBarbearia) ?> · Agendamento online em
  <a href="<?= BASE_URL ?>/agendar.php" style="color:rgba(233,69,96,.6);text-decoration:none"><?= $_SERVER['HTTP_HOST'] ?></a>
</div>

</div><!-- /container -->

<script>
const notaLabels = {1:'😕 Ruim',2:'😐 Regular',3:'🙂 Bom',4:'😊 Muito bom',5:'🤩 Excelente!'};
document.querySelectorAll('.stars-input input').forEach(r => {
  r.addEventListener('change', () => {
    document.getElementById('notaLabel').textContent = notaLabels[r.value] || '';
  });
});
</script>
</body>
</html>
