<?php
/**
 * cliente/indique.php
 * Programa de indicação — cliente gera link único, indica amigos,
 * acumula pontos quando o indicado visita pela primeira vez.
 */
require_once '../config.php';
$db = getDB();

$nomeBarbearia = getConfig('nome_barbearia') ?: 'Barbearia';
$logoBarbearia = getConfig('logo_barbearia') ?: '';
$pontosRecompensa = (int)(getConfig('indica_pontos_recompensa') ?: 1);
$descricaoRecompensa = getConfig('indica_descricao_recompensa') ?: 'desconto ou brinde na próxima visita';

// ── Criar tabelas ──
$db->exec("
    CREATE TABLE IF NOT EXISTS indicacoes (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        indicador_id    INTEGER NOT NULL,
        indicado_tel    TEXT,
        indicado_nome   TEXT,
        status          TEXT DEFAULT 'pendente' CHECK(status IN ('pendente','visitou','recompensado')),
        criado_em       DATETIME DEFAULT CURRENT_TIMESTAMP,
        visitou_em      DATETIME
    )
");
$db->exec("
    CREATE TABLE IF NOT EXISTS indica_pontos (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente_id  INTEGER NOT NULL UNIQUE,
        pontos      INTEGER DEFAULT 0,
        usado_em    DATETIME
    )
");
// Adicionar coluna indica_token em clientes se não existir
try { $db->exec("ALTER TABLE clientes ADD COLUMN indica_token TEXT"); } catch(Exception $e) {}

// ── Identificar cliente ──
// Via token na URL (link de indicação DO cliente) ou via ?tel=
$meuToken  = trim($_GET['ref']  ?? '');  // cliente acessando com seu próprio token
$refToken  = trim($_GET['from'] ?? '');  // novo visitante vindo de indicação
$clienteTel = trim($_GET['tel'] ?? '');

$cliente = null;

// Se tem ref= é o próprio dono acessando o painel
if ($meuToken) {
    $stmt = $db->prepare("SELECT * FROM clientes WHERE indica_token=?");
    $stmt->execute([$meuToken]);
    $cliente = $stmt->fetch();
}

// Se tem tel= buscar por telefone (vindo de minha-conta)
if (!$cliente && $clienteTel) {
    $telLimpo = preg_replace('/\D/','',$clienteTel);
    $stmt = $db->prepare("SELECT * FROM clientes WHERE telefone=?");
    $stmt->execute([$telLimpo]);
    $cliente = $stmt->fetch();
}

// Gerar token se não tem
if ($cliente && !$cliente['indica_token']) {
    $novoToken = bin2hex(random_bytes(10));
    $db->prepare("UPDATE clientes SET indica_token=? WHERE id=?")->execute([$novoToken, $cliente['id']]);
    $cliente['indica_token'] = $novoToken;
}

// ── Processar visita de indicado (from= na URL) ──
$mensagemBoas = '';
if ($refToken && !$meuToken) {
    // Alguém acessou via link de indicação
    $indicador = $db->prepare("SELECT * FROM clientes WHERE indica_token=?");
    $indicador->execute([$refToken]);
    $indicador = $indicador->fetch();

    if ($indicador) {
        // Registrar indicação pendente (será confirmada quando o indicado entrar na fila)
        $sessToken = session_id() . $refToken;
        setcookie('indica_ref', $refToken, time() + 86400 * 30, '/');
        $mensagemBoas = "Você foi indicado por um amigo! Agende ou entre na fila para que {$indicador['nome']} receba os pontos.";
    }
    // Redirecionar para agendar com referência
    header("Location: " . BASE_URL . "/agendar.php?from=" . urlencode($refToken));
    exit;
}

// ── Pontos do cliente ──
$pontos = 0;
$indicacoesFeitas = [];
if ($cliente) {
    $pRow = $db->prepare("SELECT pontos FROM indica_pontos WHERE cliente_id=?");
    $pRow->execute([$cliente['id']]);
    $pRow = $pRow->fetch();
    $pontos = $pRow['pontos'] ?? 0;

    $indicacoesFeitas = $db->prepare("
        SELECT * FROM indicacoes WHERE indicador_id=? ORDER BY criado_em DESC LIMIT 20
    ");
    $indicacoesFeitas->execute([$cliente['id']]);
    $indicacoesFeitas = $indicacoesFeitas->fetchAll();
}

// ── Stats globais (para mostrar ao cliente) ──
$topIndicadores = $db->query("
    SELECT c.nome, ip.pontos
    FROM indica_pontos ip
    JOIN clientes c ON c.id = ip.cliente_id
    WHERE ip.pontos > 0
    ORDER BY ip.pontos DESC
    LIMIT 5
")->fetchAll();

$proto    = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$baseUrl  = $proto . '://' . $_SERVER['HTTP_HOST'] . BASE_URL;
$linkIndique = $cliente ? $baseUrl . '/cliente/indique.php?from=' . $cliente['indica_token'] : '';
$linkAgendarCom = $cliente ? $baseUrl . '/agendar.php?from=' . $cliente['indica_token'] : '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Indique & Ganhe – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--primary:#e94560;--gold:#f59e0b}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0;min-height:100vh}
.hero{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 60%,#1a1020 100%);
  padding:2.5rem 1rem 2rem;text-align:center;position:relative;overflow:hidden}
.hero::before{content:'';position:absolute;top:-40px;right:-40px;width:200px;height:200px;
  border-radius:50%;background:radial-gradient(rgba(245,158,11,.12),transparent);pointer-events:none}
.hero-badge{background:linear-gradient(135deg,var(--gold),#d97706);color:#000;
  border-radius:20px;padding:.35rem .9rem;font-size:.78rem;font-weight:800;
  display:inline-block;margin-bottom:.75rem;letter-spacing:.3px}
.hero h1{font-size:1.6rem;font-weight:900;color:#fff;margin:0 0 .4rem}
.hero p{color:rgba(255,255,255,.5);font-size:.9rem;margin:0}
.pontos-badge{background:linear-gradient(135deg,rgba(245,158,11,.15),rgba(245,158,11,.05));
  border:2px solid rgba(245,158,11,.3);border-radius:20px;padding:1.25rem 1.5rem;
  text-align:center;margin:1.25rem 0}
.container-main{max-width:500px;margin:0 auto;padding:1.25rem 1rem}
.card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1rem}
.card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
.link-box{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);
  border-radius:12px;padding:.75rem 1rem;display:flex;align-items:center;gap:.65rem;
  font-family:monospace;font-size:.8rem;color:rgba(255,255,255,.6);word-break:break-all}
.btn-copy{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);
  color:rgba(255,255,255,.7);border-radius:8px;padding:.35rem .75rem;cursor:pointer;
  font-size:.78rem;font-weight:700;flex-shrink:0;transition:.2s;white-space:nowrap}
.btn-copy:hover{background:rgba(255,255,255,.18);color:#fff}
.btn-wa{background:linear-gradient(135deg,#25d366,#1da851);border:none;color:#fff;
  width:100%;border-radius:12px;padding:.8rem;font-weight:800;font-size:.92rem;
  cursor:pointer;transition:all .3s;display:flex;align-items:center;justify-content:center;gap:.5rem;
  text-decoration:none}
.btn-wa:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(37,211,102,.3);color:#fff}
.indic-item{display:flex;align-items:center;gap:.65rem;padding:.5rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
.indic-item:last-child{border-bottom:none}
.step-row{display:flex;align-items:flex-start;gap:.85rem;margin-bottom:.85rem}
.step-num{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--gold),#d97706);
  color:#000;font-weight:900;font-size:.85rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:.1rem}
.nav-public{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
  padding:.65rem 1.25rem;display:flex;align-items:center;justify-content:space-between}
.top-item{display:flex;align-items:center;gap:.6rem;padding:.4rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
h3,h4,h5{color:#fff;margin:0}
</style>
</head>
<body>

<div class="nav-public">
  <a href="<?= BASE_URL ?>/" style="color:rgba(255,255,255,.5);text-decoration:none;font-size:.88rem">
    <i class="bi bi-arrow-left me-1"></i>Início
  </a>
  <span style="color:rgba(255,255,255,.35);font-size:.82rem"><i class="bi bi-gift me-1"></i>Indique & Ganhe</span>
  <span></span>
</div>

<!-- Hero -->
<div class="hero">
  <div class="hero-badge">🎁 INDIQUE & GANHE</div>
  <h1>Indique amigos<br>e seja recompensado!</h1>
  <p>A cada amigo que visitar a <?= htmlspecialchars($nomeBarbearia) ?>,<br>você ganha pontos para trocar por recompensas.</p>
</div>

<div class="container-main">

<?php if ($mensagemBoas): ?>
<div style="background:rgba(37,211,102,.08);border:1px solid rgba(37,211,102,.25);border-radius:14px;
            padding:1rem;margin-bottom:1rem;text-align:center;color:#4ade80;font-size:.88rem">
  <i class="bi bi-gift-fill me-1"></i><?= htmlspecialchars($mensagemBoas) ?>
</div>
<?php endif; ?>

<?php if ($cliente): ?>

<!-- Pontos do cliente -->
<div class="pontos-badge">
  <div style="font-size:.78rem;color:rgba(245,158,11,.7);font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:.3rem">
    Seus pontos
  </div>
  <div style="font-size:3rem;font-weight:900;color:#fbbf24;line-height:1"><?= $pontos ?></div>
  <div style="font-size:.82rem;color:rgba(255,255,255,.45);margin-top:.25rem">
    <?php if ($pontos >= $pontosRecompensa): ?>
    🎉 Você tem pontos suficientes para resgatar!
    <?php else: ?>
    Precisa de <?= $pontosRecompensa - $pontos ?> ponto<?= ($pontosRecompensa - $pontos) > 1 ? 's' : '' ?> para: <?= htmlspecialchars($descricaoRecompensa) ?>
    <?php endif; ?>
  </div>
</div>

<!-- Seu link de indicação -->
<div class="card-sec" style="border-color:rgba(37,211,102,.2)">
  <div class="card-title">
    <i class="bi bi-link-45deg" style="color:#25d366"></i>
    Seu link de indicação
  </div>
  <div class="link-box" id="linkBox">
    <i class="bi bi-link" style="flex-shrink:0;color:rgba(255,255,255,.3)"></i>
    <span id="linkTexto"><?= htmlspecialchars($linkAgendarCom) ?></span>
    <button class="btn-copy" onclick="copiarLink()">
      <i class="bi bi-copy me-1"></i>Copiar
    </button>
  </div>
  <div style="margin-top:.75rem;display:flex;flex-direction:column;gap:.5rem">
    <a href="https://wa.me/?text=<?= urlencode("Oi! Agende seu horário na {$nomeBarbearia} pelo link: {$linkAgendarCom} — Fica ótimo! ✂️💈") ?>"
       target="_blank" class="btn-wa">
      <i class="bi bi-whatsapp" style="font-size:1.1rem"></i>
      Compartilhar no WhatsApp
    </a>
    <button onclick="compartilhar()"
      style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.7);
             width:100%;border-radius:12px;padding:.7rem;font-weight:700;cursor:pointer;font-size:.88rem">
      <i class="bi bi-share me-1"></i>Outras formas de compartilhar
    </button>
  </div>
</div>

<!-- Como funciona -->
<div class="card-sec">
  <div class="card-title"><i class="bi bi-info-circle" style="color:#60a5fa"></i>Como funciona</div>
  <div class="step-row">
    <div class="step-num">1</div>
    <div>
      <div style="font-weight:700;color:#fff;font-size:.9rem">Compartilhe seu link</div>
      <div style="font-size:.8rem;color:rgba(255,255,255,.45);margin-top:.15rem">Mande para amigos pelo WhatsApp, Instagram ou onde quiser</div>
    </div>
  </div>
  <div class="step-row">
    <div class="step-num">2</div>
    <div>
      <div style="font-weight:700;color:#fff;font-size:.9rem">Amigo visita a barbearia</div>
      <div style="font-size:.8rem;color:rgba(255,255,255,.45);margin-top:.15rem">Quando ele agendar ou entrar na fila pelo seu link, o sistema registra automaticamente</div>
    </div>
  </div>
  <div class="step-row" style="margin-bottom:0">
    <div class="step-num">3</div>
    <div>
      <div style="font-weight:700;color:#fff;font-size:.9rem">Você ganha pontos! 🎁</div>
      <div style="font-size:.8rem;color:rgba(255,255,255,.45);margin-top:.15rem">
        Acumule <?= $pontosRecompensa ?> ponto<?= $pontosRecompensa > 1 ? 's' : '' ?> e resgate: <strong style="color:#fbbf24"><?= htmlspecialchars($descricaoRecompensa) ?></strong>
      </div>
    </div>
  </div>
</div>

<!-- Suas indicações -->
<div class="card-sec">
  <div class="card-title">
    <i class="bi bi-people-fill" style="color:#8b5cf6"></i>
    Suas indicações
    <span style="background:rgba(139,92,246,.12);color:#a78bfa;border-radius:20px;
      padding:.1rem .5rem;font-size:.72rem;margin-left:auto"><?= count($indicacoesFeitas) ?></span>
  </div>
  <?php if (empty($indicacoesFeitas)): ?>
  <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.85rem">
    <i class="bi bi-people" style="font-size:2rem;display:block;margin-bottom:.4rem"></i>
    Nenhuma indicação ainda. Compartilhe seu link!
  </div>
  <?php else: ?>
  <?php foreach ($indicacoesFeitas as $ind):
    if ($ind['status'] === 'visitou') {
        $statusCfg = ['✅ Visitou', '#4ade80', 'rgba(34,197,94,.15)'];
    } elseif ($ind['status'] === 'recompensado') {
        $statusCfg = ['🎁 Recompensado', '#fbbf24', 'rgba(245,158,11,.15)'];
    } else {
        $statusCfg = ['⏳ Pendente', '#9ca3af', 'rgba(107,114,128,.12)'];
    }
  ?>
  <div class="indic-item">
    <div style="width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.08);
                color:rgba(255,255,255,.5);display:flex;align-items:center;justify-content:center;
                font-weight:800;font-size:.82rem;flex-shrink:0">
      <?= mb_strtoupper(mb_substr($ind['indicado_nome'] ?? '?', 0, 1)) ?>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-size:.85rem;font-weight:600;color:#fff">
        <?= htmlspecialchars($ind['indicado_nome'] ?? $ind['indicado_tel'] ?? 'Convidado') ?>
      </div>
      <div style="font-size:.72rem;color:rgba(255,255,255,.35)"><?= date('d/m/Y', strtotime($ind['criado_em'])) ?></div>
    </div>
    <span style="background:<?= $statusCfg[2] ?>;color:<?= $statusCfg[1] ?>;
                 border-radius:20px;padding:.15rem .6rem;font-size:.7rem;font-weight:700;flex-shrink:0">
      <?= $statusCfg[0] ?>
    </span>
  </div>
  <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php else: ?>
<!-- Sem cliente identificado: mostrar página informativa -->
<div class="card-sec" style="text-align:center;padding:2rem">
  <div style="font-size:3rem;margin-bottom:.75rem">🎁</div>
  <h4 style="margin-bottom:.5rem">Ganhe recompensas indicando amigos!</h4>
  <p style="color:rgba(255,255,255,.45);font-size:.88rem;margin-bottom:1.25rem">
    Cada amigo que visitar a <?= htmlspecialchars($nomeBarbearia) ?> pelo seu link<br>vale <strong style="color:#fbbf24"><?= htmlspecialchars($descricaoRecompensa) ?></strong> para você.
  </p>
  <a href="<?= BASE_URL ?>/cliente/minha-conta.php"
     style="background:linear-gradient(135deg,var(--primary),#c41230);color:#fff;
            border-radius:12px;padding:.75rem 1.5rem;text-decoration:none;font-weight:800;
            display:inline-block">
    <i class="bi bi-person-circle me-1"></i>Entrar na minha conta
  </a>
</div>
<?php endif; ?>

<!-- Ranking de indicadores -->
<?php if (!empty($topIndicadores)): ?>
<div class="card-sec">
  <div class="card-title"><i class="bi bi-trophy-fill" style="color:#fbbf24"></i>Top indicadores</div>
  <?php foreach ($topIndicadores as $i => $top): $pos = $i + 1; ?>
  <div class="top-item">
    <div style="width:24px;text-align:center;font-size:<?= $pos<=3?'1.1rem':'.82rem' ?>;flex-shrink:0">
      <?php
      if ($pos === 1) echo '🥇';
      elseif ($pos === 2) echo '🥈';
      elseif ($pos === 3) echo '🥉';
      else echo "#{$pos}";
      ?>
    </div>
    <div style="flex:1;font-size:.88rem;font-weight:600;color:#fff"><?= htmlspecialchars($top['nome']) ?></div>
    <div style="font-weight:800;color:#fbbf24"><?= $top['pontos'] ?> pts</div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div style="text-align:center;padding:1rem 0 2rem;color:rgba(255,255,255,.2);font-size:.75rem">
  <?= htmlspecialchars($nomeBarbearia) ?> · Programa de indicações
</div>

</div><!-- /container -->

<div id="toastCopy" style="position:fixed;bottom:1.5rem;left:50%;transform:translateX(-50%) translateY(20px);
  background:#1a1a2e;border:1px solid rgba(34,197,94,.3);color:#4ade80;border-radius:12px;
  padding:.6rem 1.25rem;font-size:.85rem;font-weight:700;opacity:0;transition:all .3s;pointer-events:none;z-index:9999">
  <i class="bi bi-check2 me-1"></i>Link copiado!
</div>

<script>
function copiarLink() {
  const link = document.getElementById('linkTexto').textContent;
  navigator.clipboard.writeText(link).then(() => {
    const t = document.getElementById('toastCopy');
    t.style.opacity = '1'; t.style.transform = 'translateX(-50%) translateY(0)';
    setTimeout(() => { t.style.opacity='0'; t.style.transform='translateX(-50%) translateY(20px)'; }, 2000);
  });
}

async function compartilhar() {
  const link = document.getElementById('linkTexto').textContent;
  const text = `Agende seu horário na <?= htmlspecialchars(addslashes($nomeBarbearia)) ?>! ✂️\n${link}`;
  if (navigator.share) {
    await navigator.share({ title: '<?= htmlspecialchars(addslashes($nomeBarbearia)) ?>', text, url: link });
  } else {
    copiarLink();
  }
}
</script>
</body>
</html>
