<?php
/**
 * Cron: Lembrete de retorno para clientes sumidos
 * Configurar no cPanel para rodar 1x por dia:
 * 0 10 * * * /usr/local/bin/lsphp -q /home/SEU_USUARIO/public_html/SUA_PASTA/api/cron_retorno.php
 */
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/whatsapp/config.php';

$db = getDB();

// Migração
$db->exec("CREATE TABLE IF NOT EXISTS lembrete_retorno_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    enviado_em DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$nomeBarbearia = getConfig('nome_barbearia');
if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbearia);

// Configurável: quantos dias sem visita para enviar lembrete (padrão: 30)
$diasSemVisita = (int)(getConfig('lembrete_retorno_dias') ?: 30);

// Intervalo mínimo entre lembretes para o mesmo cliente (padrão: 30 dias)
$intervaloEnvio = $diasSemVisita;

echo date('H:i:s') . " – Lembrete de retorno (clientes sumidos há {$diasSemVisita}+ dias)\n";

// Busca clientes que:
// 1. Têm telefone
// 2. Tiveram pelo menos 1 visita concluída
// 3. Última visita foi há mais de X dias
// 4. Não receberam lembrete nos últimos X dias
$clientes = $db->prepare("
    SELECT c.id, c.nome, c.telefone,
           MAX(f.finalizado_em) AS ultima_visita,
           COUNT(f.id) AS total_visitas,
           (julianday('now') - julianday(MAX(f.finalizado_em))) AS dias_ausente
    FROM clientes c
    JOIN fila f ON f.cliente_id = c.id
    WHERE f.status = 'concluido'
      AND c.telefone != ''
    GROUP BY c.id
    HAVING dias_ausente >= ?
       AND c.id NOT IN (
           SELECT cliente_id FROM lembrete_retorno_log
           WHERE enviado_em >= datetime('now', '-' || ? || ' days')
       )
    ORDER BY dias_ausente DESC
    LIMIT 50
");
$clientes->execute([$diasSemVisita, $intervaloEnvio]);
$lista = $clientes->fetchAll();

$enviados = 0;

foreach ($lista as $cli) {
    $diasInt = (int)$cli['dias_ausente'];

    // Monta mensagem personalizada conforme tempo ausente
    if ($diasInt >= 90) {
        $saudade = "Faz *{$diasInt} dias* que não te vemos! Sentimos sua falta. 😢";
    } elseif ($diasInt >= 60) {
        $saudade = "Já faz *{$diasInt} dias* sem sua visita! A barbearia não é a mesma sem você. 😄";
    } else {
        $saudade = "Faz *{$diasInt} dias* desde sua última visita!";
    }

    $msg = "✂️ *{$nomeBarbearia}*\n\n"
         . "Olá, *{$cli['nome']}*! 👋\n\n"
         . $saudade . "\n\n"
         . "Que tal agendar um horário? Sua vez pode estar esperando! 💈\n\n"
         . "🔗 Entre na fila: " . (getConfig('site_url') ?: ('https://' . ($_SERVER['HTTP_HOST'] ?? 'seusite.com'))) . '/';

    $enviou = enviarWhatsApp($cli['telefone'], $msg);

    if ($enviou) {
        $db->prepare("INSERT INTO lembrete_retorno_log (cliente_id) VALUES (?)")
           ->execute([$cli['id']]);
        echo date('H:i:s') . " – Lembrete enviado para {$cli['nome']} ({$diasInt} dias ausente)\n";
        $enviados++;

        // Pausa entre envios para não sobrecarregar a API
        usleep(800000); // 0.8 segundo
    }
}

echo date('H:i:s') . " – Concluído. {$enviados} lembretes enviados de " . count($lista) . " elegíveis.\n";