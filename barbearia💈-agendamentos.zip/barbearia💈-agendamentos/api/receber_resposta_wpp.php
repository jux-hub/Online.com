<?php
/**
 * Webhook para receber respostas do WhatsApp (Z-API / Evolution API / uazapi)
 * Processa: "1" = confirma presença | "2" = cancela | "1-5" = avaliação
 *
 * Configurar o webhook no painel da sua API apontando para:
 * https://seusite.com/SUA_PASTA/api/receber_resposta_wpp.php
 */
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/whatsapp/config.php';

header('Content-Type: application/json');

$db = getDB();

// Migrações
try { $db->exec("ALTER TABLE fila ADD COLUMN confirmado INTEGER DEFAULT 0"); } catch(Exception $e) {}
try { $db->exec("ALTER TABLE fila ADD COLUMN avaliacao_enviada INTEGER DEFAULT 0"); } catch(Exception $e) {}
$db->exec("CREATE TABLE IF NOT EXISTS avaliacoes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fila_id INTEGER NOT NULL,
    cliente_id INTEGER NOT NULL,
    barbeiro_id INTEGER NOT NULL,
    nota INTEGER,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// ── Lê o payload ──
$raw     = file_get_contents('php://input');
$payload = json_decode($raw, true);

// Tenta extrair telefone e mensagem dos formatos mais comuns (Z-API, Evolution, uazapi)
$telefone = null;
$texto    = null;

// Z-API
if (isset($payload['phone']) && isset($payload['text']['message'])) {
    $telefone = preg_replace(''" . $base_url . "/\\D/"', '', $payload['phone']);
    $texto    = trim($payload['text']['message']);
}
// Evolution API
elseif (isset($payload['data']['key']['remoteJid']) && isset($payload['data']['message']['conversation'])) {
    $telefone = preg_replace(''" . $base_url . "/\\D/"', '', explode('@', $payload['data']['key']['remoteJid'])[0]);
    $texto    = trim($payload['data']['message']['conversation']);
}
// uazapi
elseif (isset($payload['message']['from']) && isset($payload['message']['body'])) {
    $telefone = preg_replace(''" . $base_url . "/\\D/"', '', $payload['message']['from']);
    $texto    = trim($payload['message']['body']);
}
// Fallback genérico
elseif (isset($payload['from']) && isset($payload['body'])) {
    $telefone = preg_replace(''" . $base_url . "/\\D/"', '', $payload['from']);
    $texto    = trim($payload['body']);
}

if (!$telefone || !$texto) {
    echo json_encode(['ok' => false, 'motivo' => 'payload_nao_reconhecido']);
    exit;
}

// Remove DDI 55 se tiver, para buscar no banco
$telBusca = $telefone;
if (strlen($telBusca) === 13 && substr($telBusca, 0, 2) === '55') {
    $telBusca = substr($telBusca, 2); // remove DDI
}

// Busca cliente pelo telefone
$stmtCli = $db->prepare("
    SELECT id, nome FROM clientes
    WHERE REPLACE(REPLACE(REPLACE(REPLACE(telefone,' ',''),'-',''),'(',''),')','') LIKE ?
       OR REPLACE(REPLACE(REPLACE(REPLACE(telefone,' ',''),'-',''),'(',''),')','') LIKE ?
    LIMIT 1
");
$stmtCli->execute(['%' . substr($telBusca, -9) . '%', '%' . substr($telBusca, -8) . '%']);
$cliente = $stmtCli->fetch();

if (!$cliente) {
    echo json_encode(['ok' => false, 'motivo' => 'cliente_nao_encontrado', 'tel' => $telBusca]);
    exit;
}

$nomeBarbearia = getConfig('nome_barbearia');
if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbearia);

// ══════════════════════════════════════════════
// RESPOSTA "1" ou "2" = Confirmação de presença
// ══════════════════════════════════════════════
if ($texto === '1' || $texto === '2') {

    // Busca fila aguardando com confirmação enviada
    $stmtFila = $db->prepare("
        SELECT f.id, f.barbeiro_id, u.nome AS barbeiro_nome
        FROM fila f
        JOIN usuarios u ON u.id = f.barbeiro_id
        WHERE f.cliente_id = ? AND f.status = 'aguardando' AND f.confirmacao_enviada = 1
        ORDER BY f.criado_em DESC LIMIT 1
    ");
    $stmtFila->execute([$cliente['id']]);
    $fila = $stmtFila->fetch();

    if ($fila) {
        if ($texto === '1') {
            // Confirma presença
            $db->prepare("UPDATE fila SET confirmado=1 WHERE id=?")->execute([$fila['id']]);

            $msg = "✅ *{$nomeBarbearia}*\n\n"
                 . "Ótimo, *{$cliente['nome']}*! Sua presença foi confirmada. 🙌\n\n"
                 . "O barbeiro *{$fila['barbeiro_nome']}* está te aguardando.\n"
                 . "Dirija-se à barbearia! ✂️💈";
            enviarWhatsApp($telefone, $msg);
            echo json_encode(['ok' => true, 'acao' => 'confirmado', 'cliente' => $cliente['nome']]);

        } else {
            // Cancela — remove da fila
            $db->prepare("UPDATE fila SET status='cancelado', finalizado_em=CURRENT_TIMESTAMP WHERE id=?")
               ->execute([$fila['id']]);

            $msg = "😔 *{$nomeBarbearia}*\n\n"
                 . "Tudo bem, *{$cliente['nome']}*! Sua posição foi liberada.\n\n"
                 . "Quando quiser, entre na fila novamente. Até logo! 💈";
            enviarWhatsApp($telefone, $msg);
            echo json_encode(['ok' => true, 'acao' => 'cancelado', 'cliente' => $cliente['nome']]);
        }
        exit;
    }
}

// ══════════════════════════════════════════════
// RESPOSTA "1" a "5" = Avaliação pós-atendimento
// ══════════════════════════════════════════════
if (in_array($texto, ['1','2','3','4','5'])) {
    $nota = (int)$texto;

    // Busca atendimento concluído recente que aguarda avaliação
    $stmtAv = $db->prepare("
        SELECT f.id, f.barbeiro_id, u.nome AS barbeiro_nome
        FROM fila f
        JOIN usuarios u ON u.id = f.barbeiro_id
        WHERE f.cliente_id = ?
          AND f.status = 'concluido'
          AND f.avaliacao_enviada = 1
          AND f.finalizado_em >= datetime('now', '-24 hours')
        ORDER BY f.finalizado_em DESC LIMIT 1
    ");
    $stmtAv->execute([$cliente['id']]);
    $atend = $stmtAv->fetch();

    if ($atend) {
        // Salva avaliação
        $db->prepare("INSERT OR IGNORE INTO avaliacoes (fila_id, cliente_id, barbeiro_id, nota)
                      VALUES (?,?,?,?)")
           ->execute([$atend['id'], $cliente['id'], $atend['barbeiro_id'], $nota]);

        // Marca como avaliado (usa campo extra)
        try { $db->exec("ALTER TABLE fila ADD COLUMN avaliado INTEGER DEFAULT 0"); } catch(Exception $e) {}
        $db->prepare("UPDATE fila SET avaliado=1 WHERE id=?")->execute([$atend['id']]);

        $estrelas = str_repeat('⭐', $nota);
        $msg = "💈 *{$nomeBarbearia}*\n\n"
             . "Obrigado pela avaliação, *{$cliente['nome']}*! {$estrelas}\n\n";

        if ($nota >= 4) {
            $msg .= "Ficamos felizes que tenha gostado! Até a próxima. 😊✂️";
        } elseif ($nota === 3) {
            $msg .= "Agradecemos o feedback! Continuaremos melhorando. ✂️";
        } else {
            $msg .= "Sentimos muito pela experiência. Iremos melhorar! 🙏";
        }

        enviarWhatsApp($telefone, $msg);
        echo json_encode(['ok' => true, 'acao' => 'avaliacao_salva', 'nota' => $nota]);
        exit;
    }
}

echo json_encode(['ok' => false, 'motivo' => 'nenhuma_acao_aplicavel', 'texto' => $texto]);