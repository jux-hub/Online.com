<?php
/**
 * api/slots.php
 * Retorna horários disponíveis para agendamento
 * GET params: data, barbeiro_id (opcional), servico_id (opcional)
 */
require_once '../config.php';
$db = getDB();

header('Content-Type: application/json');

$data       = $_GET['data']        ?? date('Y-m-d');
$barId      = (int)($_GET['barbeiro_id'] ?? 0);
$servicoId  = (int)($_GET['servico_id']  ?? 0);

// Validar data
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
    echo json_encode(['error' => 'Data inválida']); exit;
}
$ts = strtotime($data);
if ($ts < strtotime('today')) {
    echo json_encode(['slots' => [], 'motivo' => 'Data no passado']); exit;
}

$diaSemana = (int)date('N', $ts); // 1=seg ... 7=dom

// ── Configs ──
$modoSlots      = getConfig('agenda_modo_slots')     ?: 'fixo'; // fixo | servico | manual | livre
$intervaloMin   = (int)(getConfig('agenda_intervalo') ?: 30);
$antecMin       = (int)(getConfig('agenda_antecedencia_min') ?: 60);
$maxDias        = (int)(getConfig('agenda_max_dias')  ?: 30);

// Verificar antecedência mínima
$agora     = time();
$dataTs    = $ts;
$ehHoje    = date('Y-m-d') === $data;

// Verificar se barbearia abre nesse dia
$diasMap  = ['1'=>'seg','2'=>'ter','3'=>'qua','4'=>'qui','5'=>'sex','6'=>'sab','7'=>'dom'];
$diaKey   = $diasMap[$diaSemana] ?? '';
$aberto   = getConfig("hora_{$diaKey}_aberto") ?: '1';
$horaAbre = getConfig("hora_{$diaKey}_inicio") ?: '09:00';
$horaFecha= getConfig("hora_{$diaKey}_fim")    ?: '18:00';

if ($aberto !== '1') {
    echo json_encode(['slots' => [], 'motivo' => 'Barbearia fechada neste dia']); exit;
}

// Verificar limite de antecedência
if (($ts - strtotime('today')) / 86400 > $maxDias) {
    echo json_encode(['slots' => [], 'motivo' => "Agendamento disponível apenas para os próximos {$maxDias} dias"]); exit;
}

// ── Duração do serviço ──
$duracaoServico = $intervaloMin;
if ($servicoId && $modoSlots === 'servico') {
    $svc = $db->prepare("SELECT duracao_min FROM servicos WHERE id=?")->execute([$servicoId]);
    $svc = $db->prepare("SELECT duracao_min FROM servicos WHERE id=?");
    $svc->execute([$servicoId]);
    $svcRow = $svc->fetch();
    if ($svcRow && $svcRow['duracao_min'] > 0) {
        $duracaoServico = (int)$svcRow['duracao_min'];
    }
}

// ── Gerar todos os slots possíveis ──
$slots = [];

if ($modoSlots === 'manual') {
    // Slots manuais cadastrados pelo admin
    $stmt = $db->prepare("
        SELECT hora FROM agenda_slots_manuais
        WHERE dia_semana = ? OR dia_especifico = ?
        ORDER BY hora ASC
    ");
    $stmt->execute([$diaSemana, $data]);
    foreach ($stmt->fetchAll() as $row) {
        $slots[] = $row['hora'];
    }
} else {
    // Gerar slots automaticamente pelo intervalo
    $inicio = strtotime($data . ' ' . $horaAbre);
    $fim    = strtotime($data . ' ' . $horaFecha) - ($duracaoServico * 60);

    $passo = ($modoSlots === 'servico') ? $duracaoServico : $intervaloMin;
    if ($passo < 15) $passo = 15;

    $cursor = $inicio;
    while ($cursor <= $fim) {
        $slots[] = date('H:i', $cursor);
        $cursor += $passo * 60;
    }
}

// ── Remover slots já agendados ──
$conditions = ["DATE(ag.data_hora) = ?", "ag.status NOT IN ('cancelado','faltou')"];
$params     = [$data];

if ($barId) {
    $conditions[] = "ag.barbeiro_id = ?";
    $params[]     = $barId;
}

$agendados = $db->prepare("
    SELECT strftime('%H:%M', ag.data_hora) AS hora, ag.duracao_min, ag.barbeiro_id
    FROM agendamentos ag
    WHERE " . implode(' AND ', $conditions)
);
$agendados->execute($params);
$ocupados = $agendados->fetchAll();

// Mapear ocupados com duração
$bloqueados = [];
foreach ($ocupados as $oc) {
    $horaOc  = strtotime($data . ' ' . $oc['hora']);
    $durOc   = max($intervaloMin, (int)($oc['duracao_min'] ?: $intervaloMin));
    $fimOc   = $horaOc + ($durOc * 60);
    $bloqueados[] = ['inicio' => $horaOc, 'fim' => $fimOc, 'barbeiro_id' => $oc['barbeiro_id']];
}

// ── Barbeiros disponíveis por slot ──
$barbeirosAtivos = $db->query("SELECT id, nome, NULL as cor FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();

$slotsDisponiveis = [];
foreach ($slots as $hora) {
    $tsSlot    = strtotime($data . ' ' . $hora);
    $fimSlot   = $tsSlot + ($duracaoServico * 60);

    // Filtrar antecedência mínima
    if ($ehHoje && ($tsSlot - $agora) < ($antecMin * 60)) continue;

    if ($barId) {
        // Verificar se barbeiro específico está livre
        $livre = true;
        foreach ($bloqueados as $b) {
            if ($b['barbeiro_id'] == $barId) {
                if ($tsSlot < $b['fim'] && $fimSlot > $b['inicio']) {
                    $livre = false; break;
                }
            }
        }
        if ($livre) {
            $slotsDisponiveis[] = ['hora' => $hora, 'disponivel' => true];
        }
    } else {
        // Contar barbeiros livres neste slot
        $livres = [];
        foreach ($barbeirosAtivos as $bar) {
            $ocupado = false;
            foreach ($bloqueados as $b) {
                if ($b['barbeiro_id'] == $bar['id']) {
                    if ($tsSlot < $b['fim'] && $fimSlot > $b['inicio']) {
                        $ocupado = true; break;
                    }
                }
            }
            if (!$ocupado) $livres[] = ['id' => $bar['id'], 'nome' => $bar['nome'], 'cor' => $bar['cor']];
        }
        if (!empty($livres)) {
            $slotsDisponiveis[] = ['hora' => $hora, 'disponivel' => true, 'barbeiros_livres' => count($livres)];
        }
    }
}

echo json_encode([
    'slots'    => $slotsDisponiveis,
    'duracao'  => $duracaoServico,
    'modo'     => $modoSlots,
    'dia_aberto' => true,
]);
