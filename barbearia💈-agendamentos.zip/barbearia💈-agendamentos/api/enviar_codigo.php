<?php
require_once '../config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false, 'msg' => 'Método inválido.']);
    exit;
}

$telefone = preg_replace('/\D/', '', trim($_POST['telefone'] ?? ''));
$email    = strtolower(trim($_POST['email'] ?? ''));

if (!$telefone || !$email) {
    echo json_encode(['ok' => false, 'msg' => 'Preencha telefone e e-mail.']);
    exit;
}

$db = getDB();

// ── Busca cliente pelo telefone ──
$stmt = $db->prepare("SELECT * FROM clientes WHERE telefone = ? LIMIT 1");
$stmt->execute([$telefone]);
$cliente = $stmt->fetch();

if (!$cliente) {
    echo json_encode(['ok' => false, 'msg' => 'Telefone não encontrado. Você precisa ter realizado um serviço ou pedido na barbearia.']);
    exit;
}

// ── Verifica se tem histórico (serviço ou pedido) ──
$temServico = $db->prepare("SELECT id FROM fila WHERE cliente_id = ? AND status = 'concluido' LIMIT 1");
$temServico->execute([$cliente['id']]);

$temPedido = $db->prepare("SELECT id FROM pedidos WHERE cliente_tel = ? AND status != 'cancelado' LIMIT 1");
$temPedido->execute([$telefone]);

if (!$temServico->fetch() && !$temPedido->fetch()) {
    echo json_encode(['ok' => false, 'msg' => 'Nenhum histórico encontrado. Você precisa ter realizado ao menos um serviço ou pedido na barbearia.']);
    exit;
}

// ── Salva/atualiza e-mail do cliente ──
if (empty($cliente['email'])) {
    $db->prepare("UPDATE clientes SET email = ? WHERE id = ?")->execute([$email, $cliente['id']]);
} elseif (strtolower($cliente['email']) !== $email) {
    echo json_encode(['ok' => false, 'msg' => 'E-mail não confere com o cadastro.']);
    exit;
}

// ── Limita tentativas: máx 3 códigos nos últimos 10 min ──
$tentativas = $db->prepare("
    SELECT COUNT(*) as c FROM codigos_acesso
    WHERE cliente_id = ? AND criado_em >= datetime('now','-10 minutes')
");
$tentativas->execute([$cliente['id']]);
if ((int)$tentativas->fetch()['c'] >= 3) {
    echo json_encode(['ok' => false, 'msg' => 'Muitas tentativas. Aguarde 10 minutos.']);
    exit;
}

// ── Gera código de 6 dígitos ──
$codigo = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);

// ── Salva no banco (expira em 10 min) ──
$db->prepare("
    INSERT INTO codigos_acesso (cliente_id, codigo, usado, expira_em)
    VALUES (?, ?, 0, datetime('now','+10 minutes'))
")->execute([$cliente['id'], password_hash($codigo, PASSWORD_DEFAULT)]);

// ── Envia via WhatsApp ──
$nomeBarbearia = getConfig('nome_barbearia') ?? 'Barbearia';
$msg = "🔐 *{$nomeBarbearia}*\n\n"
     . "Seu código de acesso é:\n\n"
     . "     *{$codigo}*\n\n"
     . "⏱️ Válido por 10 minutos.\n"
     . "Não compartilhe com ninguém.";

$enviado = false;
if (file_exists(__DIR__ . '/../whatsapp/config.php')) {
    require_once '../whatsapp/config.php';
    if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbearia);
    $enviado = @enviarWhatsApp($telefone, $msg);
}

if ($enviado) {
    echo json_encode(['ok' => true, 'msg' => 'Código enviado via WhatsApp!']);
} else {
    // fallback: retorna código no JSON só em dev (remova em produção)
    echo json_encode(['ok' => true, 'msg' => 'Código enviado! Verifique seu WhatsApp.', 'dev_codigo' => $codigo]);
}