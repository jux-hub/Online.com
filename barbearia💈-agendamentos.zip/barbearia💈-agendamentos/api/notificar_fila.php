<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/whatsapp/config.php';

$db = getDB();

// Garante que a coluna existe ANTES de qualquer SELECT
try {
    $db->exec("ALTER TABLE fila ADD COLUMN notificado INTEGER DEFAULT 0");
} catch(Exception $e) {}

$notifPos      = (int)getConfig('notificacao_posicoes');
$nomeBarbearia = getConfig('nome_barbearia');

if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbearia);

// Se notificação não configurada, encerra
if ($notifPos <= 0) {
    echo date('H:i:s') . " – Notificações desativadas.\n";
    exit;
}

// Busca clientes aguardando
$aguardando = $db->query("
    SELECT f.id, f.barbeiro_id, f.cliente_id, f.notificado,
           c.nome AS cliente_nome, c.telefone,
           u.nome AS barbeiro_nome
    FROM fila f
    JOIN clientes c ON c.id = f.cliente_id
    JOIN usuarios u ON u.id = f.barbeiro_id
    WHERE f.status = 'aguardando'
")->fetchAll();

foreach ($aguardando as $item) {
    // Conta quantos estão à frente
    $stmt = $db->prepare("
        SELECT COUNT(*) AS c FROM fila
        WHERE barbeiro_id = ?
          AND status = 'aguardando'
          AND criado_em < (SELECT criado_em FROM fila WHERE id = ?)
    ");
    $stmt->execute([$item['barbeiro_id'], $item['id']]);
    $frente = (int)$stmt->fetch()['c'];

    // Notifica quando atingir o limite E ainda não notificou
    if ($frente <= $notifPos && !$item['notificado']) {
        $msg    = montarMensagemAviso($item['cliente_nome'], $frente);
        $enviou = enviarWhatsApp($item['telefone'], $msg);
        if ($enviou) {
            $db->prepare("UPDATE fila SET notificado=1 WHERE id=?")
               ->execute([$item['id']]);
        }
    }

    // Reseta se a posição piorou (entrou mais gente à frente)
    if ($frente > $notifPos && $item['notificado']) {
        $db->prepare("UPDATE fila SET notificado=0 WHERE id=?")
           ->execute([$item['id']]);
    }
}

echo date('H:i:s') . " – Verificação concluída. " . count($aguardando) . " na fila.\n";