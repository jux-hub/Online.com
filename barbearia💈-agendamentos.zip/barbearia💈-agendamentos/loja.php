<?php
require_once 'config.php';
$db = getDB();

$lojaAtiva = getConfig('loja_ativa') ?? '1';
if ($lojaAtiva !== '1') {
    die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Loja Fechada</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@800&family=DM+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>*{margin:0;padding:0;box-sizing:border-box}body{background:#080814;color:#fff;font-family:"DM Sans",sans-serif;display:flex;
    align-items:center;justify-content:center;min-height:100vh;text-align:center;
    background-image:radial-gradient(ellipse 60% 50% at 50% 0%,rgba(233,69,96,.15),transparent)}
    .card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:24px;padding:3rem 2.5rem;max-width:380px}
    .icon{font-size:3.5rem;margin-bottom:1.25rem}
    h2{font-family:"Syne",sans-serif;font-size:1.6rem;color:#fff;margin-bottom:.5rem}
    p{color:rgba(255,255,255,.45);font-size:.9rem;margin-bottom:1.5rem;line-height:1.55}
    a{display:inline-flex;align-items:center;gap:.4rem;background:rgba(233,69,96,.15);border:1px solid rgba(233,69,96,.3);
    color:#e94560;border-radius:50px;padding:.55rem 1.25rem;font-size:.88rem;font-weight:700;text-decoration:none;transition:.2s}
    a:hover{background:rgba(233,69,96,.28)}</style></head><body>
    <div class="card"><div class="icon">🔒</div><h2>Loja Fechada</h2>
    <p>Nossa loja está temporariamente fechada. Voltamos em breve!</p>
    <a href="index.php">← Voltar ao início</a></div></body></html>');
}

$nomeBarbearia = getConfig('nome_barbearia')     ?? 'Barbearia';
$taxaEntrega   = (float)(getConfig('loja_taxa_entrega')   ?? 5);
$entregaAtiva  = (getConfig('loja_entrega_ativa')  ?? '1') === '1';
$retiradaAtiva = (getConfig('loja_retirada_ativa') ?? '1') === '1';
$logoPath      = getConfig('logo_path') ?? '';

$pedidoSucesso = null;
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'fazer_pedido') {
    $nome    = trim($_POST['nome']        ?? '');
    $tel     = trim($_POST['telefone']    ?? '');
    $end     = trim($_POST['endereco']    ?? '');
    $bairro  = trim($_POST['bairro']      ?? '');
    $ref     = trim($_POST['referencia']  ?? '');
    $tipoEnt = $_POST['tipo_entrega']     ?? 'retirada';
    $obs     = trim($_POST['observacoes'] ?? '');
    $itens   = json_decode($_POST['itens'] ?? '[]', true);

    if (!$nome)                              $erros[] = 'Informe seu nome.';
    if (!$tel)                               $erros[] = 'Informe seu WhatsApp.';
    if (!$itens)                             $erros[] = 'Carrinho vazio.';
    if ($tipoEnt === 'entrega' && !$end)     $erros[] = 'Informe o endereço para entrega.';

    if (!$erros) {
        $taxa     = ($tipoEnt === 'entrega' && $entregaAtiva) ? $taxaEntrega : 0;
        $subtotal = array_sum(array_column($itens, 'total'));
        $total    = $subtotal + $taxa;

        $db->prepare("
            INSERT INTO pedidos
                (cliente_nome,cliente_tel,cliente_end,cliente_bairro,cliente_ref,
                 tipo_entrega,taxa_entrega,subtotal,total,status,observacoes)
            VALUES (?,?,?,?,?,?,?,?,?,'pendente',?)
        ")->execute([$nome,$tel,$end,$bairro,$ref,$tipoEnt,$taxa,$subtotal,$total,$obs]);

        $pedidoId = $db->lastInsertId();

        foreach ($itens as $item) {
            $db->prepare("
                INSERT INTO pedidos_itens
                    (pedido_id,tipo,produto_id,pacote_id,nome,quantidade,valor_unit,valor_total)
                VALUES (?,?,?,?,?,?,?,?)
            ")->execute([
                $pedidoId,
                $item['tipo'],
                $item['tipo'] === 'produto' ? ($item['id'] ?? null) : null,
                $item['tipo'] === 'pacote'  ? ($item['id'] ?? null) : null,
                $item['nome'],
                $item['qtd'],
                $item['preco'],
                $item['total'],
            ]);
        }

        $telLimpo = preg_replace('/\D/', '', $tel);
        $existe = $db->prepare("SELECT id FROM clientes WHERE telefone=? LIMIT 1");
        $existe->execute([$telLimpo]);
        if (!$existe->fetch()) {
            $db->prepare("INSERT INTO clientes (nome,telefone) VALUES (?,?)")
               ->execute([$nome, $telLimpo]);
        }

        $pedidoSucesso = $pedidoId;
    }
}

$produtos = $db->query("SELECT * FROM produtos WHERE ativo=1 ORDER BY categoria, nome")->fetchAll();
$pacotes  = $db->query("
    SELECT p.*, s.nome AS servico_nome
    FROM pacotes p LEFT JOIN servicos s ON s.id = p.servico_id
    WHERE p.ativo=1 ORDER BY p.nome
")->fetchAll();

$porCategoria = [];
foreach ($produtos as $prod) {
    $porCategoria[$prod['categoria']][] = $prod;
}
ksort($porCategoria);

$catIcons = [
    'pomada'=>'🪮','shampoo'=>'🧴','condicionador'=>'💧','balm'=>'✨',
    'oleo'=>'💆','perfume'=>'🌸','navalha'=>'🪒','outros'=>'📦'
];

$totalProdutos = count($produtos);
$totalPacotes  = count($pacotes);
$totalItens    = $totalProdutos + $totalPacotes;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Loja — <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800;900&family=DM+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
<style>
/* ══════════════════════════════════════════
   VARIÁVEIS & RESET
══════════════════════════════════════════ */
:root{
  --P:#e94560;--Pd:#c41230;--Pg:rgba(233,69,96,.3);
  --bg:#07070f;--s1:#0f0f20;--s2:#141425;
  --bd:rgba(255,255,255,.07);--bd2:rgba(255,255,255,.13);
  --t1:#eeeef8;--t2:rgba(238,238,248,.5);--t3:rgba(238,238,248,.22);
  --grn:#4ade80;--grnd:#16a34a;
  --r-card:20px;--r-btn:12px;--r-pill:50px;
  --shadow-red:0 8px 32px rgba(233,69,96,.25);
  --shadow-card:0 4px 24px rgba(0,0,0,.35);
}
*{box-sizing:border-box;margin:0;padding:0}
body{
  background:var(--bg);color:var(--t1);
  font-family:'DM Sans',sans-serif;min-height:100vh;
  background-image:
    radial-gradient(ellipse 100% 40% at 50% 0%,rgba(233,69,96,.1),transparent),
    radial-gradient(ellipse 60% 30% at 80% 80%,rgba(100,60,180,.06),transparent)
}
h1,h2,h3,h4,h5,h6{font-family:'Syne',sans-serif;color:#fff}

/* ══ HEADER ══ */
.loja-header{
  background:rgba(7,7,15,.88);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
  border-bottom:1px solid var(--bd);padding:.7rem 1.25rem;
  position:sticky;top:0;z-index:200;
  display:flex;align-items:center;justify-content:space-between;gap:1rem
}
.loja-brand{display:flex;align-items:center;gap:.75rem;text-decoration:none}
.brand-logo{
  width:40px;height:40px;border-radius:13px;flex-shrink:0;object-fit:cover;
  background:linear-gradient(135deg,var(--P),var(--Pd));
  display:flex;align-items:center;justify-content:center;font-size:1.1rem;
  box-shadow:0 4px 16px var(--Pg)
}
.brand-text-name{
  font-family:'Syne',sans-serif;font-weight:800;color:#fff;
  font-size:.92rem;line-height:1.1;letter-spacing:-.3px
}
.brand-text-sub{font-size:.65rem;color:var(--t3);letter-spacing:.8px;text-transform:uppercase;margin-top:.1rem}
.header-right{display:flex;align-items:center;gap:.5rem}

/* botão Fila */
.btn-fila{
  display:flex;align-items:center;gap:.4rem;
  background:rgba(255,255,255,.05);border:1px solid var(--bd2);
  color:var(--t2);border-radius:var(--r-pill);padding:.38rem .85rem;
  font-size:.76rem;font-weight:600;text-decoration:none;transition:all .2s
}
.btn-fila:hover{background:rgba(255,255,255,.1);color:#fff;border-color:rgba(255,255,255,.2)}

/* botão Carrinho */
.btn-cart{
  background:rgba(233,69,96,.12);border:1px solid rgba(233,69,96,.28);
  color:#fff;border-radius:var(--r-pill);padding:.42rem 1rem;
  font-weight:700;font-size:.8rem;cursor:pointer;
  display:flex;align-items:center;gap:.45rem;transition:all .2s;
  position:relative;white-space:nowrap;font-family:'DM Sans',sans-serif
}
.btn-cart:hover{background:rgba(233,69,96,.24);box-shadow:var(--shadow-red)}
.cart-badge{
  background:var(--P);color:#fff;border-radius:50%;
  width:17px;height:17px;display:none;align-items:center;justify-content:center;
  font-size:.58rem;font-weight:900;position:absolute;top:-4px;right:-4px;
  box-shadow:0 2px 8px var(--Pg)
}

/* ══ HERO ══ */
.loja-hero{
  padding:3rem 1.5rem 2.25rem;text-align:center;
  position:relative;overflow:hidden
}
.loja-hero::before{
  content:'';position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(ellipse 70% 120% at 50% -10%,rgba(233,69,96,.13),transparent)
}
.hero-eyebrow{
  display:inline-flex;align-items:center;gap:.45rem;
  background:rgba(233,69,96,.1);border:1px solid rgba(233,69,96,.25);
  color:var(--P);border-radius:var(--r-pill);
  padding:.28rem .9rem;font-size:.68rem;font-weight:700;
  letter-spacing:1px;text-transform:uppercase;margin-bottom:1.1rem
}
.hero-title{
  font-family:'Syne',sans-serif;font-size:clamp(1.75rem,5.5vw,2.6rem);
  font-weight:900;letter-spacing:-1.5px;line-height:1.08;color:#fff;margin-bottom:.5rem
}
.hero-title .hl{
  background:linear-gradient(135deg,var(--P) 0%,#ff8fa3 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text
}
.hero-sub{color:var(--t2);font-size:.9rem;line-height:1.6;max-width:400px;margin:0 auto 1.75rem}

/* stats do hero */
.hero-stats{
  display:inline-flex;align-items:center;gap:0;
  background:rgba(255,255,255,.04);border:1px solid var(--bd);
  border-radius:16px;overflow:hidden;margin:0 auto
}
.hs{
  display:flex;flex-direction:column;align-items:center;
  padding:.65rem 1.35rem;gap:.15rem
}
.hs+.hs{border-left:1px solid var(--bd)}
.hs-val{font-family:'Syne',sans-serif;font-size:1.25rem;font-weight:900;color:#fff;line-height:1}
.hs-lbl{font-size:.62rem;color:var(--t3);letter-spacing:.6px;text-transform:uppercase}

/* ══ TABS ══ */
.loja-tabs{
  display:flex;gap:.35rem;padding:.65rem 1.25rem;
  border-bottom:1px solid var(--bd);overflow-x:auto;scrollbar-width:none;
  position:sticky;top:57px;z-index:100;
  background:rgba(7,7,15,.92);backdrop-filter:blur(16px)
}
.loja-tabs::-webkit-scrollbar{display:none}
.tab-btn{
  background:rgba(255,255,255,.04);border:1px solid var(--bd);
  color:var(--t2);border-radius:var(--r-pill);padding:.35rem .85rem;
  font-size:.76rem;font-weight:600;white-space:nowrap;cursor:pointer;
  transition:all .18s;font-family:'DM Sans',sans-serif
}
.tab-btn:hover{background:rgba(255,255,255,.09);color:#fff;border-color:var(--bd2)}
.tab-btn.active{
  background:var(--P);color:#fff;border-color:transparent;
  box-shadow:0 4px 16px var(--Pg)
}

/* ══ BODY PRODUTOS ══ */
.loja-body{max-width:980px;margin:0 auto;padding:1.5rem 1.25rem 3rem}

/* section title */
.sec-title{
  display:flex;align-items:center;gap:.8rem;margin:2.5rem 0 1.25rem
}
.sec-title-icon{
  width:36px;height:36px;border-radius:11px;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;font-size:1.05rem;
}
.sec-title-icon.red{background:rgba(233,69,96,.15);border:1px solid rgba(233,69,96,.22)}
.sec-title-icon.purple{background:rgba(139,92,246,.15);border:1px solid rgba(139,92,246,.22)}
.sec-title-txt{
  font-family:'Syne',sans-serif;font-size:.75rem;font-weight:800;
  color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:1.8px
}
.sec-title::after{content:'';flex:1;height:1px;background:var(--bd)}

/* ══ CARD PACOTE ══ */
.pac-card{
  background:linear-gradient(150deg,rgba(233,69,96,.1) 0%,rgba(233,69,96,.03) 60%,rgba(255,255,255,.02) 100%);
  border:1px solid rgba(233,69,96,.2);border-radius:var(--r-card);
  padding:1.25rem;display:flex;flex-direction:column;gap:.8rem;
  transition:all .25s;position:relative;overflow:hidden;height:100%
}
.pac-card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:2px;
  background:linear-gradient(90deg,var(--P) 0%,rgba(233,69,96,.3) 60%,transparent 100%)
}
.pac-card:hover{
  border-color:rgba(233,69,96,.45);transform:translateY(-3px);
  box-shadow:0 16px 48px rgba(233,69,96,.2)
}
.pac-head{display:flex;align-items:flex-start;gap:.85rem}
.pac-icon{
  width:52px;height:52px;flex-shrink:0;border-radius:15px;
  background:linear-gradient(135deg,rgba(233,69,96,.22),rgba(233,69,96,.08));
  border:1px solid rgba(233,69,96,.22);
  display:flex;align-items:center;justify-content:center;font-size:1.55rem
}
.pac-info{flex:1;min-width:0}
.pac-name{font-family:'Syne',sans-serif;font-weight:800;color:#fff;font-size:.98rem;line-height:1.25;margin-bottom:.2rem}
.pac-desc{font-size:.78rem;color:var(--t2);line-height:1.5}
.pac-price-row{display:flex;align-items:baseline;gap:.6rem;flex-wrap:wrap}
.pac-price{font-family:'Syne',sans-serif;font-size:1.45rem;font-weight:900;color:var(--P);line-height:1}
.pac-per{font-size:.72rem;color:var(--t3)}
.pac-chips{display:flex;gap:.5rem;flex-wrap:wrap}
.chip{
  display:inline-flex;align-items:center;gap:.3rem;
  background:rgba(233,69,96,.1);border:1px solid rgba(233,69,96,.2);
  color:#ff9db0;border-radius:var(--r-pill);padding:.2rem .65rem;
  font-size:.7rem;font-weight:700
}
.chip.green{background:rgba(34,197,94,.1);border-color:rgba(34,197,94,.2);color:#86efac}
.chip.blue{background:rgba(96,165,250,.1);border-color:rgba(96,165,250,.2);color:#93c5fd}
.pac-meta{display:flex;gap:.85rem;flex-wrap:wrap}
.pac-meta-item{font-size:.72rem;color:var(--t3);display:flex;align-items:center;gap:.3rem}

/* ══ CARD PRODUTO ══ */
.prod-card{
  background:linear-gradient(150deg,rgba(255,255,255,.055) 0%,rgba(255,255,255,.02) 100%);
  border:1px solid var(--bd);border-radius:var(--r-card);
  padding:1.1rem;display:flex;flex-direction:column;gap:.7rem;
  transition:all .25s;position:relative;overflow:hidden;height:100%
}
.prod-card:hover:not(.esgotado){
  border-color:rgba(233,69,96,.28);transform:translateY(-3px);
  box-shadow:0 12px 36px rgba(0,0,0,.4)
}
.prod-card.esgotado{opacity:.4;filter:grayscale(.5)}
.prod-head{display:flex;align-items:flex-start;gap:.85rem}
.prod-icon{
  width:56px;height:56px;border-radius:15px;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  font-size:1.7rem;background:rgba(255,255,255,.06);border:1px solid var(--bd)
}
.prod-info{flex:1;min-width:0}
.prod-name{font-family:'Syne',sans-serif;font-weight:800;color:#fff;font-size:.93rem;line-height:1.3;margin-bottom:.2rem}
.prod-desc{font-size:.77rem;color:var(--t2);line-height:1.5}
.prod-price-row{display:flex;align-items:center;gap:.6rem;flex-wrap:wrap}
.prod-price{font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:900;color:var(--P)}
.stock-tag{
  display:inline-flex;align-items:center;gap:.28rem;
  font-size:.68rem;color:var(--t3)
}
.out-tag{
  display:inline-flex;align-items:center;gap:.3rem;
  font-size:.7rem;color:#f87171;font-weight:700;
  background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);
  border-radius:var(--r-pill);padding:.2rem .65rem
}

/* ══ BTN ADICIONAR ══ */
.btn-add{
  background:linear-gradient(135deg,var(--P),var(--Pd));
  border:none;color:#fff;border-radius:var(--r-btn);padding:.65rem 1rem;
  font-size:.86rem;font-weight:700;cursor:pointer;font-family:'DM Sans',sans-serif;
  width:100%;display:flex;align-items:center;justify-content:center;gap:.45rem;
  transition:all .2s;box-shadow:0 4px 16px rgba(233,69,96,.25);margin-top:auto
}
.btn-add:hover{box-shadow:0 8px 24px var(--Pg);transform:translateY(-1px)}
.btn-add:active{transform:scale(.98);opacity:.9}
.btn-add.added{
  background:linear-gradient(135deg,#15803d,#166534);
  box-shadow:0 4px 16px rgba(34,197,94,.25)
}
.btn-add-disabled{
  background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.15);
  border-radius:var(--r-btn);padding:.5rem;text-align:center;
  font-size:.78rem;color:rgba(255,255,255,.3)
}

/* ══ EMPTY STATE ══ */
.empty-state{
  text-align:center;padding:4rem 1rem;color:var(--t3)
}
.empty-state i{font-size:3rem;display:block;margin-bottom:1rem;opacity:.5}

/* ══ DRAWER CARRINHO ══ */
.overlay{
  position:fixed;inset:0;background:rgba(0,0,0,.75);backdrop-filter:blur(6px);
  z-index:990;opacity:0;pointer-events:none;transition:.3s
}
.overlay.open{opacity:1;pointer-events:all}
.drawer{
  position:fixed;top:0;right:-110%;width:min(460px,100vw);height:100vh;
  background:var(--s1);border-left:1px solid var(--bd);
  z-index:1000;transition:.38s cubic-bezier(.4,0,.2,1);
  display:flex;flex-direction:column
}
.drawer.open{right:0;box-shadow:-24px 0 80px rgba(0,0,0,.6)}
.drawer-head{
  padding:1rem 1.25rem;border-bottom:1px solid var(--bd);
  display:flex;justify-content:space-between;align-items:center;flex-shrink:0;
  background:rgba(255,255,255,.025)
}
.drawer-title{
  font-family:'Syne',sans-serif;font-size:.98rem;font-weight:800;color:#fff;
  display:flex;align-items:center;gap:.5rem
}
.drawer-body{flex:1;overflow-y:auto;padding:1rem 1.25rem;-webkit-overflow-scrolling:touch}
.drawer-foot{
  padding:1rem 1.25rem;border-top:1px solid var(--bd);flex-shrink:0;
  background:rgba(255,255,255,.025)
}
.btn-close-drawer{
  background:rgba(255,255,255,.07);border:1px solid var(--bd);color:var(--t2);
  border-radius:9px;padding:.35rem .65rem;cursor:pointer;font-size:.88rem;transition:.2s
}
.btn-close-drawer:hover{background:rgba(239,68,68,.12);border-color:rgba(239,68,68,.3);color:#f87171}

/* cart items */
.cart-item{
  display:flex;align-items:center;gap:.65rem;
  padding:.7rem 0;border-bottom:1px solid rgba(255,255,255,.04)
}
.cart-item:last-child{border-bottom:none}
.ci-emoji{font-size:1.15rem;flex-shrink:0}
.ci-info{flex:1;min-width:0}
.ci-name{font-size:.86rem;color:#fff;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ci-sub{font-size:.7rem;color:var(--t3);margin-top:.1rem}
.ci-qtd{display:flex;align-items:center;gap:.3rem;flex-shrink:0}
.ci-qtd button{
  background:rgba(255,255,255,.07);border:1px solid var(--bd);color:#fff;
  width:26px;height:26px;border-radius:7px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;transition:.15s;font-size:.78rem
}
.ci-qtd button:hover{background:rgba(233,69,96,.22);border-color:rgba(233,69,96,.35)}
.ci-qtd span{font-weight:700;color:#fff;min-width:22px;text-align:center;font-size:.86rem}
.ci-price{font-weight:800;color:var(--grn);font-size:.86rem;white-space:nowrap;flex-shrink:0}
.ci-rm{background:none;border:none;color:rgba(255,255,255,.18);cursor:pointer;font-size:.88rem;padding:.2rem .35rem;transition:.15s}
.ci-rm:hover{color:#f87171}

/* resumo carrinho */
.cart-summary{
  background:rgba(255,255,255,.04);border:1px solid var(--bd);
  border-radius:14px;padding:.9rem 1rem;margin-bottom:.8rem
}
.sum-line{display:flex;justify-content:space-between;font-size:.82rem;color:var(--t2);margin-bottom:.3rem}
.sum-total{
  display:flex;justify-content:space-between;
  font-family:'Syne',sans-serif;font-weight:800;color:#fff;font-size:1.05rem;
  margin-top:.55rem;padding-top:.55rem;border-top:1px solid var(--bd)
}
.btn-checkout{
  background:linear-gradient(135deg,var(--P),var(--Pd));
  border:none;color:#fff;border-radius:var(--r-btn);padding:.75rem;
  font-weight:800;font-size:.92rem;cursor:pointer;width:100%;
  display:flex;align-items:center;justify-content:center;gap:.5rem;
  font-family:'DM Sans',sans-serif;transition:all .2s;
  box-shadow:0 6px 20px var(--Pg)
}
.btn-checkout:hover{transform:translateY(-1px);box-shadow:0 8px 28px var(--Pg)}
.btn-checkout:active{opacity:.9;transform:scale(.99)}

/* ══ CHECKOUT PAGE ══ */
.co-page{
  position:fixed;inset:0;background:var(--bg);
  z-index:1100;overflow-y:auto;-webkit-overflow-scrolling:touch;display:none
}
.co-page.open{display:block}
.co-head{
  background:rgba(7,7,15,.92);backdrop-filter:blur(20px);
  border-bottom:1px solid var(--bd);padding:.8rem 1.25rem;
  display:flex;align-items:center;gap:.85rem;position:sticky;top:0;z-index:10
}
.co-head-info{flex:1}
.co-head-title{font-family:'Syne',sans-serif;font-weight:800;color:#fff;font-size:.95rem}
.co-head-sub{font-size:.68rem;color:var(--t3);margin-top:.1rem}
.btn-back{
  background:rgba(255,255,255,.07);border:1px solid var(--bd);color:var(--t2);
  border-radius:9px;padding:.4rem .7rem;cursor:pointer;font-size:.88rem;
  display:flex;align-items:center;gap:.35rem;transition:.2s;font-family:'DM Sans',sans-serif
}
.btn-back:hover{background:rgba(255,255,255,.12);color:#fff}
.co-inner{max-width:560px;margin:0 auto;padding:1.5rem 1.25rem}

/* resumo pedido */
.order-summary{
  background:rgba(255,255,255,.04);border:1px solid var(--bd);
  border-radius:18px;padding:1.1rem;margin-bottom:1.5rem
}
.os-title{
  font-family:'Syne',sans-serif;font-size:.7rem;font-weight:800;
  color:var(--t3);text-transform:uppercase;letter-spacing:1.2px;margin-bottom:.9rem;
  display:flex;align-items:center;gap:.5rem
}
.os-item{
  display:flex;justify-content:space-between;
  font-size:.84rem;padding:.35rem 0;border-bottom:1px solid rgba(255,255,255,.04)
}
.os-item:last-child{border-bottom:none}
.os-total{
  display:flex;justify-content:space-between;
  font-family:'Syne',sans-serif;font-weight:900;font-size:1.05rem;color:#fff;
  margin-top:.75rem;padding-top:.75rem;border-top:1px solid var(--bd)
}

/* form */
.form-section{
  background:rgba(255,255,255,.03);border:1px solid var(--bd);
  border-radius:18px;padding:1.1rem;margin-bottom:1rem
}
.form-section-title{
  font-family:'Syne',sans-serif;font-size:.7rem;font-weight:800;
  color:var(--t3);text-transform:uppercase;letter-spacing:1.2px;
  margin-bottom:.9rem;display:flex;align-items:center;gap:.5rem
}
.fg{margin-bottom:.85rem}
.fg:last-child{margin-bottom:0}
.flbl{color:rgba(255,255,255,.6);font-size:.8rem;font-weight:600;margin-bottom:.35rem;display:block}
.finput{
  background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  color:#fff;border-radius:11px;padding:.68rem 1rem;width:100%;
  font-size:.9rem;transition:.2s;-webkit-appearance:none;font-family:'DM Sans',sans-serif
}
.finput:focus{
  outline:none;border-color:var(--P);
  box-shadow:0 0 0 3px rgba(233,69,96,.14);background:rgba(255,255,255,.09)
}
.finput::placeholder{color:rgba(255,255,255,.22)}
select.finput option{background:#1a1a2e}

/* entrega cards */
.entrega-grid{display:flex;gap:.65rem;margin-bottom:.5rem}
.entrega-card{
  flex:1;background:rgba(255,255,255,.04);border:2px solid var(--bd);
  border-radius:15px;padding:.9rem .75rem;text-align:center;cursor:pointer;transition:all .22s
}
.entrega-card:hover{border-color:var(--bd2);background:rgba(255,255,255,.07)}
.entrega-card.sel{
  border-color:var(--P);background:rgba(233,69,96,.1);
  box-shadow:0 4px 20px rgba(233,69,96,.2)
}
.entrega-card i{font-size:1.45rem;display:block;margin-bottom:.4rem;color:var(--t2)}
.entrega-card.sel i{color:var(--P)}
.ec-lbl{font-size:.83rem;font-weight:700;color:var(--t2)}
.entrega-card.sel .ec-lbl{color:#fff}
.ec-sub{font-size:.69rem;color:var(--t3);margin-top:.15rem}

/* alerta endereço */
.addr-alert{
  background:rgba(59,130,246,.07);border:1px solid rgba(59,130,246,.18);
  border-radius:11px;padding:.75rem .9rem;margin-bottom:.85rem;
  display:flex;align-items:flex-start;gap:.6rem
}
.addr-alert i{color:#60a5fa;font-size:1rem;flex-shrink:0;margin-top:.1rem}
.addr-alert-txt p{font-size:.78rem;color:#93c5fd;font-weight:600;margin-bottom:.1rem}
.addr-alert-txt span{font-size:.72rem;color:rgba(255,255,255,.35)}

/* btn confirmar */
.btn-confirm{
  background:linear-gradient(135deg,var(--P),var(--Pd));
  border:none;color:#fff;border-radius:15px;padding:.9rem;
  font-weight:800;font-size:1rem;cursor:pointer;width:100%;
  display:flex;align-items:center;justify-content:center;gap:.55rem;
  margin-top:1.25rem;transition:all .2s;font-family:'DM Sans',sans-serif;
  box-shadow:0 6px 24px var(--Pg)
}
.btn-confirm:hover{transform:translateY(-1px);box-shadow:0 10px 32px var(--Pg)}
.btn-confirm:active{opacity:.9;transform:scale(.99)}
.btn-confirm:disabled{opacity:.5;cursor:not-allowed;transform:none;box-shadow:none}

/* ══ TOAST ══ */
.toast-pop{
  position:fixed;bottom:1.5rem;left:50%;
  transform:translateX(-50%) translateY(120px);
  background:rgba(15,15,32,.97);border:1px solid rgba(74,222,128,.35);color:var(--grn);
  border-radius:14px;padding:.6rem 1.25rem;font-size:.83rem;font-weight:700;
  z-index:3000;transition:.32s cubic-bezier(.34,1.56,.64,1);white-space:nowrap;
  box-shadow:0 12px 48px rgba(0,0,0,.6);pointer-events:none;
  display:flex;align-items:center;gap:.5rem
}
.toast-pop.show{transform:translateX(-50%) translateY(0)}
.toast-pop.erro{border-color:rgba(239,68,68,.35);color:#f87171}

/* ══ ERROS ══ */
.erro-box{
  background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.22);
  border-radius:13px;padding:.85rem 1.1rem;margin-bottom:1rem
}
.erro-box li{color:#f87171;font-size:.84rem;margin-bottom:.2rem}

/* ══ SUCESSO ══ */
.sucesso-wrap{max-width:560px;margin:0 auto;padding:2.5rem 1.25rem}
.sucesso-card{
  background:linear-gradient(145deg,rgba(34,197,94,.08),rgba(34,197,94,.02));
  border:1px solid rgba(34,197,94,.22);border-radius:24px;
  padding:2.5rem 2rem;text-align:center;position:relative;overflow:hidden
}
.sucesso-card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:2px;
  background:linear-gradient(90deg,transparent,var(--grn),transparent)
}
.sucesso-icon{font-size:4rem;margin-bottom:1.25rem;display:block;line-height:1}
.sucesso-title{
  font-family:'Syne',sans-serif;font-size:1.65rem;font-weight:900;
  color:#fff;margin-bottom:.4rem
}
.sucesso-num{
  display:inline-flex;align-items:center;gap:.5rem;
  background:rgba(74,222,128,.12);border:1px solid rgba(74,222,128,.25);
  border-radius:var(--r-pill);padding:.3rem .9rem;
  font-family:'Syne',sans-serif;font-size:1rem;font-weight:800;color:var(--grn);
  margin-bottom:1.5rem
}
.sucesso-steps{
  background:rgba(255,255,255,.04);border-radius:14px;
  padding:1rem;margin-bottom:1.5rem;text-align:left
}
.ss-label{
  font-size:.68rem;color:var(--t3);text-transform:uppercase;
  letter-spacing:.8px;font-weight:700;margin-bottom:.65rem
}
.ss-step{
  display:flex;align-items:flex-start;gap:.75rem;
  padding:.5rem 0;border-bottom:1px solid rgba(255,255,255,.04)
}
.ss-step:last-child{border-bottom:none}
.ss-step-num{
  width:24px;height:24px;border-radius:50%;flex-shrink:0;
  background:rgba(74,222,128,.15);border:1px solid rgba(74,222,128,.3);
  display:flex;align-items:center;justify-content:center;
  font-size:.7rem;font-weight:800;color:var(--grn);margin-top:.05rem
}
.ss-step-txt{font-size:.84rem;color:var(--t2);line-height:1.45}

/* ══ MISC ══ */
@media(max-width:575px){
  .loja-hero{padding:2rem 1.25rem 1.75rem}
  .hs{padding:.55rem 1rem}
}
</style>
</head>
<body>

<?php if ($pedidoSucesso): ?>
<!-- ══════════ SUCESSO ══════════ -->
<div class="loja-header">
  <a href="loja.php" class="loja-brand">
    <?php if ($logoPath): ?>
      <img src="<?= BASE_URL.'/'.$logoPath ?>" alt="logo" class="brand-logo">
    <?php else: ?>
      <div class="brand-logo"><i class="bi bi-scissors text-white"></i></div>
    <?php endif; ?>
    <div>
      <div class="brand-text-name"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div class="brand-text-sub">Loja Online</div>
    </div>
  </a>
</div>

<div class="sucesso-wrap">
  <div class="sucesso-card">
    <span class="sucesso-icon">🎉</span>
    <div class="sucesso-title">Pedido Recebido!</div>
    <div class="sucesso-num">
      <i class="bi bi-check-circle-fill"></i>
      Pedido #<?= $pedidoSucesso ?>
    </div>
    <p style="color:var(--t2);font-size:.9rem;margin-bottom:1.5rem;line-height:1.6">
      Seu pedido foi enviado com sucesso!<br>Em breve entraremos em contato para confirmar.
    </p>
    <div class="sucesso-steps">
      <div class="ss-label"><i class="bi bi-list-check me-1"></i>Próximos passos</div>
      <?php foreach ([
        'Aguarde nossa confirmação via WhatsApp',
        'O pagamento é feito na retirada ou entrega',
        'Dúvidas? Nos chame no WhatsApp',
      ] as $i => $passo): ?>
      <div class="ss-step">
        <div class="ss-step-num"><?= $i+1 ?></div>
        <div class="ss-step-txt"><?= $passo ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <a href="loja.php"
       style="display:inline-flex;align-items:center;gap:.5rem;
              background:linear-gradient(135deg,var(--P),var(--Pd));
              color:#fff;border-radius:var(--r-btn);padding:.75rem 1.75rem;
              font-weight:800;font-size:.92rem;text-decoration:none;
              box-shadow:var(--shadow-red)">
      <i class="bi bi-bag-heart"></i>Continuar Comprando
    </a>
  </div>
</div>

<?php else: ?>
<!-- ══════════ LOJA ══════════ -->

<div class="loja-header">
  <a href="index.php" class="loja-brand">
    <?php if ($logoPath): ?>
      <img src="<?= BASE_URL.'/'.$logoPath ?>" alt="logo" class="brand-logo">
    <?php else: ?>
      <div class="brand-logo"><i class="bi bi-scissors text-white"></i></div>
    <?php endif; ?>
    <div>
      <div class="brand-text-name"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div class="brand-text-sub">Loja Online</div>
    </div>
  </a>
  <div class="header-right">
    <a href="index.php" class="btn-fila">
      <i class="bi bi-people-fill"></i>
      <span class="d-none d-sm-inline">Fila</span>
    </a>
    <button class="btn-cart" onclick="abrirCarrinho()">
      <i class="bi bi-bag-heart"></i>
      <span id="btnCartTxt">Carrinho</span>
      <span class="cart-badge" id="carBadge">0</span>
    </button>
  </div>
</div>

<!-- HERO -->
<div class="loja-hero">
  <div class="hero-eyebrow"><i class="bi bi-stars"></i>Loja Oficial</div>
  <h1 class="hero-title">
    Produtos &<br><span class="hl">Pacotes Premium</span>
  </h1>
  <p class="hero-sub">Os melhores produtos para seu estilo. Retire na barbearia ou receba em casa.</p>
  <?php if ($totalItens > 0): ?>
  <div class="hero-stats">
    <?php if ($totalPacotes > 0): ?>
    <div class="hs">
      <div class="hs-val"><?= $totalPacotes ?></div>
      <div class="hs-lbl">Pacote<?= $totalPacotes != 1 ? 's' : '' ?></div>
    </div>
    <?php endif; ?>
    <?php if ($totalPacotes > 0 && $totalProdutos > 0): ?>
    <div class="hs" style="padding:0;width:1px;background:var(--bd)"></div>
    <?php endif; ?>
    <?php if ($totalProdutos > 0): ?>
    <div class="hs">
      <div class="hs-val"><?= $totalProdutos ?></div>
      <div class="hs-lbl">Produto<?= $totalProdutos != 1 ? 's' : '' ?></div>
    </div>
    <div class="hs" style="padding:0;width:1px;background:var(--bd)"></div>
    <div class="hs">
      <div class="hs-val"><?= count($porCategoria) ?></div>
      <div class="hs-lbl">Categoria<?= count($porCategoria) != 1 ? 's' : '' ?></div>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<?php if ($erros): ?>
<div style="max-width:980px;margin:.75rem auto;padding:0 1.25rem">
  <div class="erro-box">
    <ul style="margin:0;padding-left:1.25rem">
      <?php foreach ($erros as $e): ?>
        <li><?= htmlspecialchars($e) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
</div>
<?php endif; ?>

<!-- TABS -->
<div class="loja-tabs" id="lojaTabs">
  <?php if (!empty($pacotes)): ?>
    <button class="tab-btn active" onclick="scrollSec('sec-pacotes',this)">
      <i class="bi bi-ticket-perforated-fill me-1"></i>Pacotes
    </button>
  <?php endif; ?>
  <?php foreach (array_keys($porCategoria) as $cat): ?>
    <button class="tab-btn" onclick="scrollSec('sec-<?= htmlspecialchars($cat) ?>',this)">
      <?= ($catIcons[$cat] ?? '📦') . ' ' . ucfirst($cat) ?>
    </button>
  <?php endforeach; ?>
</div>

<!-- CATÁLOGO -->
<div class="loja-body">

  <?php if (empty($pacotes) && empty($produtos)): ?>
    <div class="empty-state">
      <i class="bi bi-bag-x"></i>
      <h5 style="font-family:'Syne',sans-serif;margin-bottom:.5rem">Nada por aqui ainda</h5>
      <p style="font-size:.85rem">Em breve teremos produtos e pacotes disponíveis!</p>
    </div>
  <?php endif; ?>

  <!-- PACOTES -->
  <?php if (!empty($pacotes)): ?>
  <div id="sec-pacotes">
    <div class="sec-title">
      <div class="sec-title-icon red"><i class="bi bi-ticket-perforated-fill" style="color:#ff8fa3"></i></div>
      <span class="sec-title-txt">Pacotes de Corte</span>
    </div>
    <div class="row g-3">
      <?php foreach ($pacotes as $pac):
        $precoUni = $pac['creditos'] > 0 ? $pac['preco'] / $pac['creditos'] : $pac['preco'];
      ?>
      <div class="col-12 col-md-6">
        <div class="pac-card">
          <div class="pac-head">
            <div class="pac-icon">✂️</div>
            <div class="pac-info">
              <div class="pac-name"><?= htmlspecialchars($pac['nome']) ?></div>
              <?php if ($pac['descricao']): ?>
                <div class="pac-desc"><?= htmlspecialchars($pac['descricao']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div>
            <div class="pac-price-row">
              <div class="pac-price"><?= formatMoney($pac['preco']) ?></div>
              <div class="pac-per"><?= formatMoney($precoUni) ?>/corte</div>
            </div>
          </div>

          <div class="pac-chips">
            <span class="chip">
              <i class="bi bi-scissors"></i>
              <?= $pac['creditos'] ?> corte<?= $pac['creditos'] != 1 ? 's' : '' ?>
            </span>
            <?php if ($pac['validade_dias'] > 0): ?>
            <span class="chip blue">
              <i class="bi bi-calendar3"></i>
              <?= $pac['validade_dias'] ?> dias
            </span>
            <?php endif; ?>
            <?php if ($pac['servico_nome']): ?>
            <span class="chip green">
              <i class="bi bi-check-circle"></i>
              <?= htmlspecialchars($pac['servico_nome']) ?>
            </span>
            <?php endif; ?>
          </div>

          <button class="btn-add"
                  onclick="addCarrinho('pacote',<?= $pac['id'] ?>,'<?= addslashes(htmlspecialchars($pac['nome'])) ?>',<?= $pac['preco'] ?>,this)">
            <i class="bi bi-bag-plus-fill"></i>Adicionar ao Carrinho
          </button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- PRODUTOS POR CATEGORIA -->
  <?php foreach ($porCategoria as $cat => $prods): ?>
  <div id="sec-<?= htmlspecialchars($cat) ?>">
    <div class="sec-title">
      <div class="sec-title-icon purple" style="font-size:1.1rem"><?= $catIcons[$cat] ?? '📦' ?></div>
      <span class="sec-title-txt"><?= ucfirst($cat) ?></span>
    </div>
    <div class="row g-3">
      <?php foreach ($prods as $prod):
        $semEstoque = $prod['estoque'] <= 0;
      ?>
      <div class="col-12 col-md-6">
        <div class="prod-card <?= $semEstoque ? 'esgotado' : '' ?>">
          <div class="prod-head">
            <div class="prod-icon"><?= $catIcons[$prod['categoria']] ?? '📦' ?></div>
            <div class="prod-info">
              <div class="prod-name"><?= htmlspecialchars($prod['nome']) ?></div>
              <?php if ($prod['descricao']): ?>
                <div class="prod-desc"><?= htmlspecialchars($prod['descricao']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <div class="prod-price-row">
            <div class="prod-price"><?= formatMoney($prod['preco']) ?></div>
            <?php if ($semEstoque): ?>
              <span class="out-tag"><i class="bi bi-x-circle-fill"></i>Indisponível</span>
            <?php else: ?>
              <span class="stock-tag"><i class="bi bi-box-seam"></i><?= $prod['estoque'] ?> disponíveis</span>
            <?php endif; ?>
          </div>

          <?php if (!$semEstoque): ?>
          <button class="btn-add"
                  onclick="addCarrinho('produto',<?= $prod['id'] ?>,'<?= addslashes(htmlspecialchars($prod['nome'])) ?>',<?= $prod['preco'] ?>,this)">
            <i class="bi bi-bag-plus-fill"></i>Adicionar ao Carrinho
          </button>
          <?php else: ?>
          <div class="btn-add-disabled">Produto indisponível no momento</div>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endforeach; ?>

</div><!-- /loja-body -->

<!-- ══ OVERLAY + DRAWER ══ -->
<div class="overlay" id="carOverlay" onclick="fecharCarrinho()"></div>
<div class="drawer" id="carDrawer">
  <div class="drawer-head">
    <div class="drawer-title">
      <i class="bi bi-bag-heart" style="color:var(--P)"></i>
      Meu Carrinho
    </div>
    <button class="btn-close-drawer" onclick="fecharCarrinho()">
      <i class="bi bi-x-lg"></i>
    </button>
  </div>
  <div class="drawer-body">
    <div class="empty-state" id="carEmpty">
      <i class="bi bi-bag-x" style="font-size:2.5rem;margin-bottom:.75rem;opacity:.4;color:var(--t3)"></i>
      <p style="font-size:.86rem;color:var(--t3)">Seu carrinho está vazio</p>
    </div>
    <div id="carItens"></div>
  </div>
  <div class="drawer-foot" id="carFooter" style="display:none">
    <div class="cart-summary">
      <div class="sum-line">
        <span>Subtotal</span>
        <span id="carSubtotal">R$ 0,00</span>
      </div>
      <div class="sum-total">
        <span>Total</span>
        <span id="carTotal">R$ 0,00</span>
      </div>
    </div>
    <button class="btn-checkout" onclick="abrirCheckout()">
      <i class="bi bi-arrow-right-circle-fill"></i>Finalizar Pedido
    </button>
  </div>
</div>

<!-- ══ CHECKOUT PAGE ══ -->
<div class="co-page" id="checkoutPage">
  <div class="co-head">
    <button class="btn-back" onclick="fecharCheckout()">
      <i class="bi bi-arrow-left"></i><span class="d-none d-sm-inline">Voltar</span>
    </button>
    <div class="co-head-info">
      <div class="co-head-title">Finalizar Pedido</div>
      <div class="co-head-sub">Preencha seus dados abaixo</div>
    </div>
  </div>

  <div class="co-inner">

    <!-- Resumo -->
    <div class="order-summary" id="checkoutResumo">
      <div class="os-title"><i class="bi bi-bag-heart"></i>Resumo do Pedido</div>
      <div id="checkoutItensLista"></div>
      <div class="os-item" id="checkoutLinhaEntrega" style="display:none">
        <span style="color:var(--t2)"><i class="bi bi-bicycle me-1"></i>Taxa de entrega</span>
        <span style="color:var(--t2)">R$ <?= number_format($taxaEntrega,2,',','.') ?></span>
      </div>
      <div class="os-total">
        <span>Total</span>
        <span id="checkoutTotal" style="color:var(--grn)">R$ 0,00</span>
      </div>
    </div>

    <!-- Form -->
    <form method="POST" id="formPedido" onsubmit="return prepararPedido(event)">
      <input type="hidden" name="acao"         value="fazer_pedido">
      <input type="hidden" name="itens"        id="inputItens">
      <input type="hidden" name="tipo_entrega" id="inputTipoEntrega"
             value="<?= $retiradaAtiva ? 'retirada' : 'entrega' ?>">

      <!-- Entrega -->
      <div class="form-section">
        <div class="form-section-title"><i class="bi bi-truck"></i>Como prefere receber?</div>
        <div class="entrega-grid">
          <?php if ($retiradaAtiva): ?>
          <div class="entrega-card sel" id="optRetirada" onclick="selecionarEntrega('retirada')">
            <i class="bi bi-shop"></i>
            <div class="ec-lbl">Retirar</div>
            <div class="ec-sub">Na barbearia</div>
          </div>
          <?php endif; ?>
          <?php if ($entregaAtiva): ?>
          <div class="entrega-card <?= !$retiradaAtiva ? 'sel' : '' ?>"
               id="optEntrega" onclick="selecionarEntrega('entrega')">
            <i class="bi bi-bicycle"></i>
            <div class="ec-lbl">Entrega</div>
            <div class="ec-sub">+R$ <?= number_format($taxaEntrega,2,',','.') ?></div>
          </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Dados pessoais -->
      <div class="form-section">
        <div class="form-section-title"><i class="bi bi-person"></i>Seus dados</div>
        <div class="fg">
          <label class="flbl">Nome completo *</label>
          <input type="text" name="nome" class="finput"
                 placeholder="Como devemos te chamar?" required autocomplete="name">
        </div>
        <div class="fg">
          <label class="flbl">WhatsApp *</label>
          <input type="tel" name="telefone" class="finput"
                 placeholder="(00) 00000-0000" required autocomplete="tel"
                 oninput="maskTel(this)">
        </div>
        <div class="fg">
          <label class="flbl">Observações</label>
          <textarea name="observacoes" class="finput" rows="2"
                    placeholder="Alguma observação sobre o pedido?"
                    style="resize:none"></textarea>
        </div>
      </div>

      <!-- Endereço (entrega) -->
      <div id="camposEntrega" style="display:none">
        <div class="form-section">
          <div class="form-section-title"><i class="bi bi-geo-alt"></i>Endereço de entrega</div>
          <div class="addr-alert">
            <i class="bi bi-info-circle-fill"></i>
            <div class="addr-alert-txt">
              <p>Preencha o endereço completo</p>
              <span>Para garantir uma entrega precisa e rápida</span>
            </div>
          </div>
          <div class="fg">
            <label class="flbl">Rua e número *</label>
            <input type="text" name="endereco" id="inputEnd" class="finput"
                   placeholder="Ex: Rua das Flores, 123" autocomplete="street-address">
          </div>
          <div class="fg">
            <label class="flbl">Bairro</label>
            <input type="text" name="bairro" class="finput"
                   placeholder="Nome do bairro" autocomplete="address-level3">
          </div>
          <div class="fg">
            <label class="flbl">Ponto de referência</label>
            <input type="text" name="referencia" class="finput"
                   placeholder="Ex: Próximo ao mercado X">
          </div>
        </div>
      </div>

      <button type="submit" class="btn-confirm" id="btnConfirmar">
        <i class="bi bi-check2-circle"></i>Confirmar Pedido
      </button>
      <div style="height:2.5rem"></div>
    </form>
  </div>
</div>

<!-- Toast -->
<div class="toast-pop" id="toastPop"></div>

<?php endif; ?>

<script>
const TAXA_ENTREGA = <?= $taxaEntrega ?>;
let carrinho     = [];
let tipoEntrega  = '<?= $retiradaAtiva ? "retirada" : "entrega" ?>';

try {
  const s = localStorage.getItem('loja_carrinho');
  if (s) carrinho = JSON.parse(s);
} catch(e){ carrinho = []; }

/* ── DRAWER ── */
function abrirCarrinho(){
  document.getElementById('carDrawer').classList.add('open');
  document.getElementById('carOverlay').classList.add('open');
  document.body.style.overflow='hidden';
}
function fecharCarrinho(){
  document.getElementById('carDrawer').classList.remove('open');
  document.getElementById('carOverlay').classList.remove('open');
  document.body.style.overflow='';
}

/* ── CHECKOUT ── */
function abrirCheckout(){
  if(!carrinho.length){ toast('⚠️ Carrinho vazio!',true); return; }
  fecharCarrinho();
  renderCheckoutResumo();
  const pg=document.getElementById('checkoutPage');
  pg.classList.add('open'); pg.scrollTop=0;
  document.body.style.overflow='hidden';
}
function fecharCheckout(){
  document.getElementById('checkoutPage').classList.remove('open');
  document.body.style.overflow='';
}

/* ── ADD CARRINHO ── */
function addCarrinho(tipo,id,nome,preco,btn){
  const idx=carrinho.findIndex(i=>i.tipo===tipo&&i.id===id);
  if(idx>=0){
    carrinho[idx].qtd++;
    carrinho[idx].total=+(carrinho[idx].preco*carrinho[idx].qtd).toFixed(2);
  } else {
    carrinho.push({tipo,id,nome,preco:+preco,qtd:1,total:+preco});
  }
  salvar(); renderCarrinho();
  toast('✅ '+nome+' adicionado!');
  if(btn){
    const orig=btn.innerHTML;
    btn.classList.add('added');
    btn.innerHTML='<i class="bi bi-check-lg"></i>Adicionado!';
    setTimeout(()=>{ btn.innerHTML=orig; btn.classList.remove('added'); },1400);
  }
  setTimeout(abrirCarrinho,350);
}

function removerItem(idx){ carrinho.splice(idx,1); salvar(); renderCarrinho(); }
function alterarQtd(idx,delta){
  carrinho[idx].qtd=Math.max(1,carrinho[idx].qtd+delta);
  carrinho[idx].total=+(carrinho[idx].preco*carrinho[idx].qtd).toFixed(2);
  salvar(); renderCarrinho();
}
function salvar(){ try{ localStorage.setItem('loja_carrinho',JSON.stringify(carrinho)); }catch(e){} }

/* ── RENDER CARRINHO ── */
function renderCarrinho(){
  const empty=document.getElementById('carEmpty');
  const itensEl=document.getElementById('carItens');
  const footer=document.getElementById('carFooter');
  const badge=document.getElementById('carBadge');
  const btnTxt=document.getElementById('btnCartTxt');

  const subtotal=carrinho.reduce((s,i)=>s+i.total,0);
  const qtdTotal=carrinho.reduce((s,i)=>s+i.qtd,0);

  badge.textContent=qtdTotal;
  badge.style.display=qtdTotal>0?'flex':'none';
  btnTxt.textContent=qtdTotal>0?`Carrinho (${qtdTotal})`:'Carrinho';

  if(!carrinho.length){
    empty.style.display='block';
    itensEl.innerHTML='';
    footer.style.display='none';
    return;
  }
  empty.style.display='none';
  footer.style.display='block';

  itensEl.innerHTML=carrinho.map((item,idx)=>`
    <div class="cart-item">
      <div class="ci-emoji">${item.tipo==='pacote'?'✂️':'📦'}</div>
      <div class="ci-info">
        <div class="ci-name">${escHtml(item.nome)}</div>
        <div class="ci-sub">${item.tipo==='pacote'?'Pacote':'Produto'} · R$ ${item.preco.toFixed(2).replace('.',',')} /un</div>
      </div>
      <div class="ci-qtd">
        <button type="button" onclick="alterarQtd(${idx},-1)"><i class="bi bi-dash"></i></button>
        <span>${item.qtd}</span>
        <button type="button" onclick="alterarQtd(${idx},1)"><i class="bi bi-plus"></i></button>
      </div>
      <div class="ci-price">R$ ${item.total.toFixed(2).replace('.',',')}</div>
      <button class="ci-rm" type="button" onclick="removerItem(${idx})"><i class="bi bi-x-lg"></i></button>
    </div>`).join('');

  document.getElementById('carSubtotal').textContent='R$ '+subtotal.toFixed(2).replace('.',',');
  document.getElementById('carTotal').textContent='R$ '+subtotal.toFixed(2).replace('.',',');
}

function renderCheckoutResumo(){
  const subtotal=carrinho.reduce((s,i)=>s+i.total,0);
  const taxa=tipoEntrega==='entrega'?TAXA_ENTREGA:0;
  const total=subtotal+taxa;
  document.getElementById('checkoutItensLista').innerHTML=
    carrinho.map(item=>`
      <div class="os-item">
        <span style="color:var(--t2)">${item.tipo==='pacote'?'✂️':'📦'} ${escHtml(item.nome)}<span style="color:var(--t3)"> ×${item.qtd}</span></span>
        <span style="color:var(--grn);font-weight:700">R$ ${item.total.toFixed(2).replace('.',',')}</span>
      </div>`).join('');
  document.getElementById('checkoutLinhaEntrega').style.display=tipoEntrega==='entrega'?'flex':'none';
  document.getElementById('checkoutTotal').textContent='R$ '+total.toFixed(2).replace('.',',');
}

/* ── ENTREGA ── */
function selecionarEntrega(tipo){
  tipoEntrega=tipo;
  document.getElementById('inputTipoEntrega').value=tipo;
  document.getElementById('optRetirada')?.classList.toggle('sel',tipo==='retirada');
  document.getElementById('optEntrega')?.classList.toggle('sel',tipo==='entrega');
  document.getElementById('camposEntrega').style.display=tipo==='entrega'?'block':'none';
  const endInput=document.getElementById('inputEnd');
  if(endInput) endInput.required=(tipo==='entrega');
  renderCheckoutResumo();
}

/* ── SUBMIT ── */
function prepararPedido(e){
  if(!carrinho.length){ toast('⚠️ Carrinho vazio!',true); e.preventDefault(); return false; }
  const nome=document.querySelector('input[name="nome"]').value.trim();
  const tel=document.querySelector('input[name="telefone"]').value.trim();
  if(!nome){ toast('⚠️ Informe seu nome!',true); e.preventDefault(); return false; }
  if(!tel){ toast('⚠️ Informe seu WhatsApp!',true); e.preventDefault(); return false; }
  if(tipoEntrega==='entrega'){
    const end=document.getElementById('inputEnd').value.trim();
    if(!end){ toast('⚠️ Informe o endereço!',true); e.preventDefault(); return false; }
  }
  const btn=document.getElementById('btnConfirmar');
  btn.disabled=true;
  btn.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>Enviando...';
  document.getElementById('inputItens').value=JSON.stringify(carrinho);
  localStorage.removeItem('loja_carrinho');
  return true;
}

/* ── TABS ── */
function scrollSec(id,btn){
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  if(btn) btn.classList.add('active');
  const el=document.getElementById(id);
  if(el){ window.scrollTo({top:el.getBoundingClientRect().top+window.scrollY-130,behavior:'smooth'}); }
}

/* ── MASK TEL ── */
function maskTel(input){
  let v=input.value.replace(/\D/g,'').slice(0,11);
  if(v.length>6) v=`(${v.slice(0,2)}) ${v.slice(2,7)}-${v.slice(7)}`;
  else if(v.length>2) v=`(${v.slice(0,2)}) ${v.slice(2)}`;
  else if(v.length>0) v=`(${v}`;
  input.value=v;
}

/* ── TOAST ── */
function toast(msg,erro=false){
  const t=document.getElementById('toastPop');
  t.innerHTML=msg;
  t.className='toast-pop'+(erro?' erro':'');
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2500);
}

/* ── ESC ── */
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){ fecharCheckout(); fecharCarrinho(); }
});

function escHtml(s){
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;')
                      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

renderCarrinho();
</script>
</body>
</html>
