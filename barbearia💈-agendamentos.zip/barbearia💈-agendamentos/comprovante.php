<?php
require_once 'config.php';

$id  = (int)($_GET['id'] ?? 0);
$key = $_GET['key'] ?? '';

if (!$id) die('Comprovante inválido.');

$db   = getDB();
$stmt = $db->prepare("
    SELECT f.*, c.nome as cliente_nome, c.telefone,
           u.nome as barbeiro_nome,
           s.nome as servico_nome, s.preco as servico_preco
    FROM fila f
    JOIN clientes c ON c.id = f.cliente_id
    JOIN usuarios u ON u.id = f.barbeiro_id
    LEFT JOIN servicos s ON s.id = f.servico_id
    WHERE f.id = ? AND f.status = 'concluido'
");
$stmt->execute([$id]);
$atend = $stmt->fetch();

if (!$atend) die('Comprovante não encontrado.');

// ── Chave padronizada ──
$keyEsperada = substr(md5($id . 'barbearia_renato'), 0, 8);
if ($key && $key !== $keyEsperada) die('Chave inválida.');

// ── Itens extras ──
$itensExtras = [];
try {
    $stmtItens = $db->prepare("SELECT * FROM fila_itens WHERE fila_id = ? ORDER BY id");
    $stmtItens->execute([$id]);
    $itensExtras = $stmtItens->fetchAll();
} catch(Exception $e) {}
$totalExtras = array_sum(array_map(fn($i) => (float)$i['preco'] * (int)($i['qty'] ?? 1), $itensExtras));
$temExtras   = !empty($itensExtras);

$nomeBarbearia = getConfig('nome_barbearia');
$dur = 0;
if ($atend['iniciado_em'] && $atend['finalizado_em'])
    $dur = round((strtotime($atend['finalizado_em']) - strtotime($atend['iniciado_em'])) / 60);

$pgtoLabels = ['pix'=>'PIX','dinheiro'=>'Dinheiro','debito'=>'Débito','credito'=>'Crédito'];
$pgtoIcons  = ['pix'=>'bi-qr-code','dinheiro'=>'bi-cash-coin','debito'=>'bi-credit-card','credito'=>'bi-credit-card-2-front'];
$pgtoLabel  = $pgtoLabels[$atend['forma_pagamento'] ?? ''] ?? ucfirst($atend['forma_pagamento'] ?? '');
$pgtoIcon   = $pgtoIcons[$atend['forma_pagamento']  ?? ''] ?? 'bi-cash';

$urlBase = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
$urlComp = $urlBase . BASE_URL . "/comprovante.php?id={$id}&key={$keyEsperada}";
$msgWa   = urlencode("Meu comprovante da {$nomeBarbearia}: {$urlComp}");
$numComp = '#' . str_pad($id, 5, '0', STR_PAD_LEFT);
$hashComp= strtoupper(substr(md5($id . $atend['finalizado_em']), 0, 16));

$valorServico = $atend['servico_preco'] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Comprovante <?= $numComp ?> – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
@import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;600;700&family=Inter:wght@400;500;600;700&display=swap');

:root{
  --primary:#e94560;--primary-dark:#c41230;
  --bg:#0f0f23;--card:#1a1a2e;--card2:#16213e;
  --border:rgba(255,255,255,.08);--text:#e0e0e0;--muted:rgba(255,255,255,.4);
}

@media print{
  body{background:#fff!important;padding:0!important}
  .no-print{display:none!important}
  .recibo{box-shadow:none!important;max-width:100%!important;border-radius:0!important}
  .recibo-header,.total-box{-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .linha-label{color:#666!important}
}

*{box-sizing:border-box;margin:0;padding:0}
body{
  background:var(--bg);min-height:100vh;
  display:flex;flex-direction:column;align-items:center;
  justify-content:flex-start;padding:2rem 1rem;
  font-family:'Inter',sans-serif;color:var(--text);
}

.recibo{background:var(--card);width:100%;max-width:420px;border-radius:20px;overflow:hidden;box-shadow:0 25px 60px rgba(0,0,0,.6),0 0 0 1px var(--border)}

.recibo-header{background:linear-gradient(135deg,#1a1a2e 0%,#0f3460 60%,#162447 100%);padding:2rem 1.5rem 1.5rem;text-align:center;position:relative;overflow:hidden}
.recibo-header::before{content:'✂';position:absolute;font-size:12rem;color:rgba(255,255,255,.03);top:-2rem;right:-2rem;line-height:1;pointer-events:none}
.recibo-logo{width:72px;height:72px;background:linear-gradient(135deg,var(--primary),var(--primary-dark));border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;font-size:1.8rem;box-shadow:0 8px 25px rgba(233,69,96,.4)}
.recibo-nome{font-family:'Oswald',sans-serif;font-size:1.5rem;font-weight:700;color:#fff;letter-spacing:.5px;margin-bottom:.2rem}
.recibo-sub{font-size:.8rem;color:rgba(255,255,255,.5);letter-spacing:1px;text-transform:uppercase}
.status-badge{display:inline-flex;align-items:center;gap:.4rem;background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.35);color:#4ade80;border-radius:20px;padding:.35rem 1rem;font-size:.8rem;font-weight:600;margin-top:.85rem}

.comp-num{background:rgba(233,69,96,.15);border:1px solid rgba(233,69,96,.25);border-radius:8px;padding:.5rem 1rem;margin:1rem 1.5rem 0;display:flex;justify-content:space-between;align-items:center}
.comp-num-label{font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}
.comp-num-val{font-family:'Oswald',sans-serif;font-size:1.1rem;color:var(--primary);font-weight:600}

.recibo-body{padding:1.25rem 1.5rem}
.section-title{font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--muted);font-weight:600;margin-bottom:.75rem;margin-top:1rem;display:flex;align-items:center;gap:.5rem}
.section-title:first-child{margin-top:0}
.section-title::after{content:'';flex:1;height:1px;background:var(--border)}
.info-grid{display:flex;flex-direction:column;gap:.5rem}
.info-row{display:flex;justify-content:space-between;align-items:center;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:10px;padding:.65rem 1rem}
.info-label{display:flex;align-items:center;gap:.5rem;font-size:.82rem;color:var(--muted)}
.info-label i{font-size:.9rem}
.info-val{font-size:.88rem;font-weight:600;color:#fff;text-align:right;max-width:55%}

.itens-section{margin-top:1rem}
.item-linha{
  display:flex;justify-content:space-between;align-items:center;
  padding:.55rem .75rem;border-radius:9px;
  background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);
  margin-bottom:.35rem;font-size:.88rem;
}
.item-nome{color:rgba(255,255,255,.8);display:flex;align-items:center;gap:.45rem;flex:1;min-width:0}
.item-qty{background:rgba(59,130,246,.2);color:#93c5fd;border-radius:4px;padding:.1rem .4rem;font-size:.72rem;font-weight:700;white-space:nowrap;flex-shrink:0}
.item-preco{color:#a5b4fc;font-weight:700;white-space:nowrap;margin-left:.75rem}
.item-servico .item-preco{color:#60a5fa}

.breakdown{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:.75rem 1rem;margin-top:.75rem}
.breakdown-linha{display:flex;justify-content:space-between;font-size:.83rem;padding:.2rem 0}
.breakdown-linha span:first-child{color:var(--muted)}
.breakdown-linha span:last-child{color:#fff;font-weight:600}
.breakdown-linha.destaque span:first-child{color:rgba(255,255,255,.7);font-weight:700}
.breakdown-linha.destaque span:last-child{color:#4ade80;font-weight:800;font-size:.95rem}
.breakdown-sep{border:none;border-top:1px dashed rgba(255,255,255,.1);margin:.4rem 0}

.total-box{margin:0 1.5rem 1.5rem;background:linear-gradient(135deg,rgba(233,69,96,.2),rgba(196,18,48,.2));border:1px solid rgba(233,69,96,.3);border-radius:14px;padding:1.25rem;text-align:center}
.total-label{font-size:.72rem;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1px;margin-bottom:.4rem}
.total-val{font-family:'Oswald',sans-serif;font-size:2.8rem;font-weight:700;color:#4ade80;line-height:1;text-shadow:0 0 30px rgba(74,222,128,.3)}
.total-pgto{display:inline-flex;align-items:center;gap:.4rem;background:rgba(255,255,255,.08);border-radius:20px;padding:.3rem .85rem;font-size:.78rem;color:rgba(255,255,255,.6);margin-top:.6rem}

.divisor{border:none;border-top:2px dashed rgba(255,255,255,.08);margin:0 1.5rem}

.recibo-footer{padding:1.25rem 1.5rem;text-align:center}
.hash-code{font-family:'Courier New',monospace;font-size:.7rem;color:rgba(255,255,255,.2);letter-spacing:2px;word-break:break-all;margin-top:.5rem}
.selo-ok{display:inline-flex;align-items:center;gap:.4rem;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:8px;padding:.5rem 1.2rem;font-size:.8rem;color:#4ade80;font-weight:600;margin-bottom:.75rem}
.obrigado{font-size:.82rem;color:var(--muted);margin-top:.5rem}

.btns-wrap{display:flex;gap:.65rem;margin-top:1.25rem;max-width:420px;width:100%;flex-wrap:wrap}
.btn-imp{flex:1;background:linear-gradient(135deg,var(--primary),var(--primary-dark));border:none;color:#fff;border-radius:12px;padding:.75rem 1rem;font-weight:700;font-size:.9rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;justify-content:center;gap:.4rem}
.btn-imp:hover{opacity:.9;transform:translateY(-1px)}
.btn-wa{flex:1;background:linear-gradient(135deg,#25d366,#128c7e);border:none;color:#fff;border-radius:12px;padding:.75rem 1rem;font-weight:700;font-size:.9rem;cursor:pointer;transition:.2s;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:.4rem}
.btn-wa:hover{opacity:.9;transform:translateY(-1px);color:#fff}
.btn-home{width:100%;background:rgba(255,255,255,.06);border:1px solid var(--border);color:rgba(255,255,255,.6);border-radius:12px;padding:.65rem 1rem;font-weight:600;font-size:.88rem;text-decoration:none;transition:.2s;display:inline-flex;align-items:center;justify-content:center;gap:.4rem}
.btn-home:hover{background:rgba(255,255,255,.1);color:#fff}
</style>
</head>
<body>

<div class="recibo">

  <!-- Header -->
  <div class="recibo-header">
    <div class="recibo-logo"><i class="bi bi-scissors text-white"></i></div>
    <div class="recibo-nome"><?= htmlspecialchars($nomeBarbearia) ?></div>
    <div class="recibo-sub">Comprovante de Atendimento</div>
    <div class="status-badge"><i class="bi bi-check-circle-fill"></i>Atendimento Concluído</div>
  </div>

  <!-- Número -->
  <div class="comp-num">
    <div>
      <div class="comp-num-label">Comprovante</div>
      <div class="comp-num-val"><?= $numComp ?></div>
    </div>
    <div style="text-align:right">
      <div class="comp-num-label">Data</div>
      <div style="color:#fff;font-weight:600;font-size:.9rem">
        <?= $atend['finalizado_em'] ? date('d/m/Y', strtotime($atend['finalizado_em'])) : '–' ?>
      </div>
      <div style="color:var(--muted);font-size:.78rem">
        <?= $atend['finalizado_em'] ? date('H:i', strtotime($atend['finalizado_em'])) : '' ?>
      </div>
    </div>
  </div>

  <!-- Corpo -->
  <div class="recibo-body">

    <div class="section-title"><i class="bi bi-person-lines-fill"></i>Informações</div>
    <div class="info-grid">
      <div class="info-row">
        <span class="info-label"><i class="bi bi-person-fill"></i>Cliente</span>
        <span class="info-val"><?= htmlspecialchars($atend['cliente_nome']) ?></span>
      </div>
      <div class="info-row">
        <span class="info-label"><i class="bi bi-scissors"></i>Barbeiro</span>
        <span class="info-val"><?= htmlspecialchars($atend['barbeiro_nome']) ?></span>
      </div>
      <?php if($dur > 0): ?>
      <div class="info-row">
        <span class="info-label"><i class="bi bi-stopwatch"></i>Duração</span>
        <span class="info-val"><?= $dur ?> minutos</span>
      </div>
      <?php endif; ?>
    </div>

    <div class="section-title" style="margin-top:1.1rem">
      <i class="bi bi-receipt"></i>Detalhes do Consumo
    </div>

    <!-- Serviço principal -->
    <?php if($atend['servico_nome']): ?>
    <div class="item-linha item-servico">
      <span class="item-nome">
        <i class="bi bi-scissors" style="color:#60a5fa;flex-shrink:0"></i>
        <?= htmlspecialchars($atend['servico_nome']) ?>
      </span>
      <span class="item-preco"><?= formatMoney($valorServico) ?></span>
    </div>
    <?php endif; ?>

    <!-- Produtos/Pacotes extras -->
    <?php if($temExtras): ?>
      <div style="font-size:.72rem;color:rgba(255,255,255,.3);text-transform:uppercase;
                  letter-spacing:.07em;margin:.7rem 0 .35rem;font-weight:700">
        <i class="bi bi-bag-fill me-1" style="color:rgba(165,180,252,.6)"></i>Produtos & Pacotes
      </div>
      <?php foreach($itensExtras as $item):
        $qty      = (int)($item['qty'] ?? 1);
        $subtotal = (float)$item['preco'] * $qty;
      ?>
      <div class="item-linha">
        <span class="item-nome">
          <i class="bi bi-bag" style="color:#a5b4fc;flex-shrink:0"></i>
          <?= htmlspecialchars($item['nome']) ?>
        </span>
        <?php if($qty > 1): ?>
          <span class="item-qty"><?= $qty ?>x</span>
        <?php endif; ?>
        <span class="item-preco"><?= formatMoney($subtotal) ?></span>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <!-- Breakdown -->
    <?php if($temExtras && $atend['servico_nome']): ?>
    <div class="breakdown">
      <?php if($valorServico > 0): ?>
      <div class="breakdown-linha">
        <span>Serviço</span>
        <span><?= formatMoney($valorServico) ?></span>
      </div>
      <?php endif; ?>
      <div class="breakdown-linha">
        <span>Produtos/Pacotes</span>
        <span><?= formatMoney($totalExtras) ?></span>
      </div>
      <hr class="breakdown-sep">
      <div class="breakdown-linha destaque">
        <span>Total</span>
        <span><?= formatMoney($atend['valor']) ?></span>
      </div>
    </div>
    <?php endif; ?>

  </div>

  <!-- Total -->
  <div class="total-box">
    <div class="total-label">Total Pago</div>
    <div class="total-val">
      <?= $atend['valor'] ? 'R$ ' . number_format((float)$atend['valor'], 2, ',', '.') : '–' ?>
    </div>
    <?php if($atend['forma_pagamento']): ?>
    <div class="total-pgto">
      <i class="bi <?= $pgtoIcon ?>"></i><?= $pgtoLabel ?>
    </div>
    <?php endif; ?>
  </div>

  <hr class="divisor">

  <!-- Rodapé -->
  <div class="recibo-footer">
    <div class="selo-ok"><i class="bi bi-patch-check-fill"></i>Documento Válido</div>
    <div class="hash-code"><?= $hashComp ?></div>
    <div class="obrigado">Obrigado pela preferência! Volte sempre ✂️</div>
  </div>

</div>

<!-- Botões -->
<div class="btns-wrap no-print">
  <button class="btn-imp" onclick="window.print()">
    <i class="bi bi-printer"></i>Imprimir
  </button>
  <a href="https://wa.me/?text=<?= $msgWa ?>" target="_blank" class="btn-wa">
    <i class="bi bi-whatsapp"></i>Compartilhar
  </a>
  <a href="index.php" class="btn-home">
    <i class="bi bi-house"></i>Voltar ao Início
  </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW ok:', r.scope))
      .catch(e => console.log('SW erro:', e));
  });
}
</script>
</body>
</html>