<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

$msg = '';
$editando = null;

// ── AÇÕES POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'salvar') {
        $id             = (int)($_POST['id'] ?? 0);
        $titulo         = trim($_POST['titulo'] ?? '');
        $mensagem       = trim($_POST['mensagem'] ?? '');
        $icone          = trim($_POST['icone'] ?? 'bi-tag-fill');
        $cor            = trim($_POST['cor'] ?? '#e94560');
        $wa_numero      = preg_replace('/\D/','',$_POST['whatsapp_numero'] ?? '');
        $wa_texto       = trim($_POST['whatsapp_texto'] ?? '');
        $wa_ativo       = isset($_POST['whatsapp_ativo']) ? 1 : 0;

        if (!$titulo || !$mensagem) {
            flash('danger','Título e mensagem são obrigatórios.');
        } else {
            if ($id) {
                $db->prepare("UPDATE promocoes SET titulo=?,mensagem=?,icone=?,cor=?,
                    whatsapp_numero=?,whatsapp_texto=?,whatsapp_ativo=? WHERE id=?")
                   ->execute([$titulo,$mensagem,$icone,$cor,$wa_numero,$wa_texto,$wa_ativo,$id]);
                flash('success','Promoção atualizada!');
            } else {
                $db->prepare("INSERT INTO promocoes
                    (titulo,mensagem,icone,cor,whatsapp_numero,whatsapp_texto,whatsapp_ativo)
                    VALUES (?,?,?,?,?,?,?)")
                   ->execute([$titulo,$mensagem,$icone,$cor,$wa_numero,$wa_texto,$wa_ativo]);
                flash('success','Promoção criada com sucesso!');
            }
        }
        header('Location: promocoes.php'); exit;

    } elseif ($acao === 'toggle_ativo') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare("UPDATE promocoes SET ativo = CASE WHEN ativo=1 THEN 0 ELSE 1 END WHERE id=?")
           ->execute([$id]);
        header('Location: promocoes.php'); exit;

    } elseif ($acao === 'toggle_whatsapp') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare("UPDATE promocoes SET whatsapp_ativo = CASE WHEN whatsapp_ativo=1 THEN 0 ELSE 1 END WHERE id=?")
           ->execute([$id]);
        header('Location: promocoes.php'); exit;

    } elseif ($acao === 'excluir') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare("DELETE FROM promocoes WHERE id=?")->execute([$id]);
        flash('warning','Promoção excluída.');
        header('Location: promocoes.php'); exit;
    }
}

// Editar: carrega dados
if (isset($_GET['editar'])) {
    $editando = $db->prepare("SELECT * FROM promocoes WHERE id=?");
    $editando->execute([(int)$_GET['editar']]);
    $editando = $editando->fetch();
}

$promocoes     = $db->query("SELECT * FROM promocoes ORDER BY criado_em DESC")->fetchAll();
$nomeBarbearia = getConfig('nome_barbearia');

$icones = [
    'bi-tag-fill'        => 'Etiqueta',
    'bi-percent'         => 'Porcentagem',
    'bi-gift-fill'       => 'Presente',
    'bi-star-fill'       => 'Estrela',
    'bi-lightning-fill'  => 'Raio',
    'bi-megaphone-fill'  => 'Megafone',
    'bi-scissors'        => 'Tesoura',
    'bi-emoji-smile-fill'=> 'Emoji',
    'bi-fire'            => 'Fogo',
    'bi-bell-fill'       => 'Sino',
    'bi-clock-fill'      => 'Relógio',
    'bi-cash-coin'       => 'Dinheiro',
];

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Promoções – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%);transition:.3s}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  /* ── FORMULÁRIO ── */
  .form-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);
    border-radius:18px;padding:1.5rem}
  .form-control,.form-select{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.65rem 1rem}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.1);
    border-color:var(--primary);color:#fff;box-shadow:0 0 0 .2rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.3)}
  .form-select option{background:#1a1a2e;color:#fff}
  .form-label{color:rgba(255,255,255,.75);font-weight:600;font-size:.88rem;margin-bottom:.4rem}
  textarea.form-control{resize:vertical;min-height:90px}

  /* ── CARDS PROMOÇÃO ── */
  .promo-card{
    background:rgba(255,255,255,.04);
    border:1px solid rgba(255,255,255,.09);
    border-radius:16px;overflow:hidden;
    transition:all .25s;
  }
  .promo-card:hover{border-color:rgba(233,69,96,.3);background:rgba(255,255,255,.06)}
  .promo-card.inativa{opacity:.5}

  .promo-header{
    padding:1rem 1.25rem .85rem;
    display:flex;align-items:flex-start;gap:.85rem;
    border-bottom:1px solid rgba(255,255,255,.06);
  }
  .promo-icon-wrap{
    width:46px;height:46px;border-radius:12px;
    display:flex;align-items:center;justify-content:center;
    font-size:1.3rem;flex-shrink:0;
  }
  .promo-titulo{font-weight:800;color:#fff;font-size:1rem;line-height:1.3;margin-bottom:.25rem}
  .promo-msg{color:rgba(255,255,255,.6);font-size:.85rem;line-height:1.5}

  .promo-footer{
    padding:.75rem 1.25rem;
    display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;
    background:rgba(0,0,0,.15);
  }

  /* Badges de status */
  .badge-on{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.25);
    border-radius:20px;padding:.2rem .7rem;font-size:.75rem;font-weight:700;
    display:inline-flex;align-items:center;gap:.3rem}
  .badge-off{background:rgba(255,255,255,.07);color:rgba(255,255,255,.35);
    border:1px solid rgba(255,255,255,.1);
    border-radius:20px;padding:.2rem .7rem;font-size:.75rem;font-weight:700;
    display:inline-flex;align-items:center;gap:.3rem}
  .badge-wa-on{background:rgba(37,211,102,.15);color:#25d366;border:1px solid rgba(37,211,102,.25);
    border-radius:20px;padding:.2rem .7rem;font-size:.75rem;font-weight:700;
    display:inline-flex;align-items:center;gap:.3rem}
  .badge-wa-off{background:rgba(255,255,255,.06);color:rgba(255,255,255,.3);
    border:1px solid rgba(255,255,255,.08);
    border-radius:20px;padding:.2rem .7rem;font-size:.75rem;font-weight:700;
    display:inline-flex;align-items:center;gap:.3rem}

  /* Botões de ação pequenos */
  .btn-act{border-radius:8px;padding:.3rem .7rem;font-size:.78rem;font-weight:600;
    border:none;cursor:pointer;display:inline-flex;align-items:center;gap:.3rem;transition:.2s}
  .btn-edit{background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.25)}
  .btn-edit:hover{background:rgba(59,130,246,.25);color:#93c5fd}
  .btn-del{background:rgba(239,68,68,.12);color:#f87171;border:1px solid rgba(239,68,68,.2)}
  .btn-del:hover{background:rgba(239,68,68,.22);color:#fca5a5}
  .btn-toggle-on{background:rgba(239,68,68,.12);color:#f87171;border:1px solid rgba(239,68,68,.2)}
  .btn-toggle-on:hover{background:rgba(239,68,68,.22)}
  .btn-toggle-off{background:rgba(34,197,94,.12);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
  .btn-toggle-off:hover{background:rgba(34,197,94,.22)}
  .btn-wa-on{background:rgba(37,211,102,.12);color:#25d366;border:1px solid rgba(37,211,102,.2)}
  .btn-wa-on:hover{background:rgba(37,211,102,.22)}
  .btn-wa-off{background:rgba(255,255,255,.07);color:rgba(255,255,255,.4);border:1px solid rgba(255,255,255,.1)}
  .btn-wa-off:hover{background:rgba(255,255,255,.12);color:#fff}

  /* Preview */
  .preview-wrap{
    background:linear-gradient(135deg,#1a1a2e,#16213e);
    border:1px solid rgba(255,255,255,.08);border-radius:14px;
    padding:1rem;position:relative;overflow:hidden;
  }
  .preview-label{font-size:.7rem;text-transform:uppercase;letter-spacing:1px;
    color:rgba(255,255,255,.3);margin-bottom:.75rem;font-weight:600}
  .preview-card{
    border-radius:14px;padding:1rem 1.25rem;
    display:flex;gap:.85rem;align-items:flex-start;
  }
  .preview-icon{width:42px;height:42px;border-radius:10px;
    display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
  .preview-title{font-weight:800;color:#fff;font-size:.95rem;margin-bottom:.2rem}
  .preview-text{font-size:.83rem;color:rgba(255,255,255,.7);line-height:1.4}
  .preview-wa-btn{
    margin-top:.65rem;display:inline-flex;align-items:center;gap:.4rem;
    background:#25d366;color:#fff;border-radius:8px;padding:.35rem .8rem;
    font-size:.8rem;font-weight:700;text-decoration:none;
  }

  /* Icone picker */
  .icon-picker{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.4rem}
  .icon-opt{
    width:40px;height:40px;border-radius:8px;
    background:rgba(255,255,255,.06);border:1.5px solid rgba(255,255,255,.1);
    display:flex;align-items:center;justify-content:center;
    cursor:pointer;transition:.2s;font-size:1.1rem;color:rgba(255,255,255,.6);
  }
  .icon-opt:hover,.icon-opt.sel{background:rgba(233,69,96,.15);border-color:var(--primary);color:#fff}
  .icon-opt input{display:none}

  h4,h5,h6{color:#fff;margin:0}
  .text-vazio{color:rgba(255,255,255,.3);text-align:center;padding:2.5rem 0;font-size:.95rem}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">Promoções & Avisos</h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">Gerencie banners que aparecem na fila online</div>
      </div>
    </div>
    <a href="dashboard.php"
       style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
              color:rgba(255,255,255,.7);border-radius:10px;padding:.4rem .9rem;
              font-size:.82rem;font-weight:600;text-decoration:none;
              display:flex;align-items:center;gap:.4rem">
      <i class="bi bi-arrow-left"></i> Dashboard
    </a>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <div class="row g-3">

      <!-- ══ COLUNA ESQUERDA: Formulário ══ -->
      <div class="col-12 col-lg-5">
        <div class="form-card">
          <h6 class="fw-bold mb-3" style="font-size:.95rem">
            <i class="bi bi-<?= $editando ? 'pencil-fill' : 'plus-circle-fill' ?> me-2"
               style="color:var(--primary)"></i>
            <?= $editando ? 'Editar Promoção' : 'Nova Promoção / Aviso' ?>
          </h6>

          <form method="POST" id="formPromo">
            <input type="hidden" name="acao" value="salvar">
            <input type="hidden" name="id" value="<?= $editando['id'] ?? 0 ?>">

            <!-- Título -->
            <div class="mb-3">
              <label class="form-label"><i class="bi bi-type me-1"></i>Título *</label>
              <input type="text" name="titulo" class="form-control" required
                     placeholder="Ex: 🔥 Promoção de Segunda!" maxlength="80"
                     id="inpTitulo"
                     value="<?= htmlspecialchars($editando['titulo'] ?? '') ?>">
            </div>

            <!-- Mensagem -->
            <div class="mb-3">
              <label class="form-label"><i class="bi bi-chat-text me-1"></i>Mensagem *</label>
              <textarea name="mensagem" class="form-control" required
                        placeholder="Descreva a promoção em detalhes..." maxlength="300"
                        id="inpMsg"><?= htmlspecialchars($editando['mensagem'] ?? '') ?></textarea>
              <div style="font-size:.73rem;color:rgba(255,255,255,.3);text-align:right;margin-top:.2rem">
                <span id="msgCount">0</span>/300
              </div>
            </div>

            <!-- Ícone -->
            <div class="mb-3">
              <label class="form-label"><i class="bi bi-emoji-smile me-1"></i>Ícone</label>
              <input type="hidden" name="icone" id="iconeVal"
                     value="<?= htmlspecialchars($editando['icone'] ?? 'bi-tag-fill') ?>">
              <div class="icon-picker" id="iconePicker">
                <?php foreach($icones as $cls => $nome): ?>
                <div class="icon-opt <?= ($editando['icone'] ?? 'bi-tag-fill') === $cls ? 'sel' : '' ?>"
                     data-icone="<?= $cls ?>" title="<?= $nome ?>">
                  <i class="bi <?= $cls ?>"></i>
                </div>
                <?php endforeach; ?>
              </div>
            </div>

            <!-- Cor -->
            <div class="mb-3">
              <label class="form-label"><i class="bi bi-palette me-1"></i>Cor do destaque</label>
              <div class="d-flex gap-2 align-items-center flex-wrap">
                <?php
                $cores = ['#e94560'=>'Vermelho','#3b82f6'=>'Azul','#22c55e'=>'Verde',
                          '#f59e0b'=>'Amarelo','#8b5cf6'=>'Roxo','#f97316'=>'Laranja',
                          '#06b6d4'=>'Ciano','#ec4899'=>'Rosa'];
                $corAtual = $editando['cor'] ?? '#e94560';
                foreach($cores as $hex => $label): ?>
                <div class="cor-opt" data-cor="<?= $hex ?>" title="<?= $label ?>"
                     style="width:30px;height:30px;border-radius:7px;background:<?= $hex ?>;
                            cursor:pointer;border:2.5px solid <?= $corAtual===$hex ? '#fff' : 'transparent' ?>;
                            transition:.2s;flex-shrink:0"></div>
                <?php endforeach; ?>
                <input type="hidden" name="cor" id="corVal" value="<?= htmlspecialchars($corAtual) ?>">
              </div>
            </div>

            <!-- WhatsApp -->
            <div style="background:rgba(37,211,102,.05);border:1px solid rgba(37,211,102,.15);
                        border-radius:12px;padding:1rem;margin-bottom:1rem">
              <div class="d-flex align-items-center justify-content-between mb-2">
                <label class="form-label mb-0" style="color:#4ade80">
                  <i class="bi bi-whatsapp me-1"></i>Botão WhatsApp
                </label>
                <div class="form-check form-switch mb-0">
                  <input class="form-check-input" type="checkbox" name="whatsapp_ativo"
                         id="waAtivo" role="switch"
                         <?= ($editando['whatsapp_ativo'] ?? 1) ? 'checked' : '' ?>>
                  <label class="form-check-label" for="waAtivo"
                         style="color:rgba(255,255,255,.5);font-size:.82rem">Ativo</label>
                </div>
              </div>
              <div id="waFields">
                <div class="mb-2">
                  <label class="form-label" style="font-size:.82rem">Número (só dígitos)</label>
                  <input type="text" name="whatsapp_numero" class="form-control"
                         placeholder="5511999990000" maxlength="15" id="inpWaNum"
                         value="<?= htmlspecialchars($editando['whatsapp_numero'] ?? '') ?>">
                </div>
                <div>
                  <label class="form-label" style="font-size:.82rem">Texto pré-preenchido</label>
                  <input type="text" name="whatsapp_texto" class="form-control"
                         placeholder="Oi, vi a promoção e quero saber mais!" maxlength="200"
                         value="<?= htmlspecialchars($editando['whatsapp_texto'] ?? '') ?>">
                </div>
              </div>
            </div>

            <!-- Preview -->
            <div class="preview-wrap mb-3">
              <div class="preview-label"><i class="bi bi-eye me-1"></i>Preview em tempo real</div>
              <div class="preview-card" id="prevCard">
                <div class="preview-icon" id="prevIcon">
                  <i class="bi bi-tag-fill" id="prevIconI"></i>
                </div>
                <div style="flex:1;min-width:0">
                  <div class="preview-title" id="prevTitle">Título da promoção</div>
                  <div class="preview-text" id="prevText">Mensagem da promoção aparecerá aqui...</div>
                  <a href="#" class="preview-wa-btn" id="prevWaBtn">
                    <i class="bi bi-whatsapp"></i> Falar no WhatsApp
                  </a>
                </div>
              </div>
            </div>

            <div class="d-flex gap-2">
              <button type="submit" class="btn fw-700 flex-grow-1"
                style="background:linear-gradient(135deg,var(--primary),#c41230);color:#fff;
                       border:none;border-radius:10px;padding:.7rem;font-weight:700">
                <i class="bi bi-<?= $editando ? 'check2' : 'plus-lg' ?> me-1"></i>
                <?= $editando ? 'Salvar Alterações' : 'Criar Promoção' ?>
              </button>
              <?php if($editando): ?>
              <a href="promocoes.php"
                 style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                        color:rgba(255,255,255,.6);border-radius:10px;padding:.7rem 1rem;
                        font-weight:600;text-decoration:none;display:flex;align-items:center;gap:.3rem;
                        font-size:.9rem">
                <i class="bi bi-x"></i> Cancelar
              </a>
              <?php endif; ?>
            </div>
          </form>
        </div>
      </div>

      <!-- ══ COLUNA DIREITA: Lista ══ -->
      <div class="col-12 col-lg-7">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.85rem">
          <h6 class="fw-bold" style="font-size:.95rem;color:#fff">
            <i class="bi bi-collection me-2" style="color:#3b82f6"></i>
            Promoções Cadastradas
            <span style="background:rgba(59,130,246,.2);color:#60a5fa;border-radius:20px;
              padding:.1rem .55rem;font-size:.75rem;margin-left:.3rem">
              <?= count($promocoes) ?>
            </span>
          </h6>
          <span style="font-size:.75rem;color:rgba(255,255,255,.3)">
            As <span style="color:#4ade80;font-weight:700">ativas</span> aparecem na fila online
          </span>
        </div>

        <?php if(empty($promocoes)): ?>
          <div class="text-vazio" style="background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.07);border-radius:16px">
            <i class="bi bi-megaphone" style="font-size:3rem;display:block;margin-bottom:.75rem;opacity:.3"></i>
            Nenhuma promoção cadastrada ainda.<br>
            <span style="font-size:.82rem">Crie a primeira usando o formulário ao lado!</span>
          </div>
        <?php else: ?>
          <?php foreach($promocoes as $p): ?>
          <div class="promo-card mb-2 <?= $p['ativo'] ? '' : 'inativa' ?>">
            <div class="promo-header">
              <div class="promo-icon-wrap"
                   style="background:<?= htmlspecialchars($p['cor']) ?>22;
                          border:1.5px solid <?= htmlspecialchars($p['cor']) ?>44">
                <i class="bi <?= htmlspecialchars($p['icone']) ?>"
                   style="color:<?= htmlspecialchars($p['cor']) ?>"></i>
              </div>
              <div style="flex:1;min-width:0">
                <div class="promo-titulo"><?= htmlspecialchars($p['titulo']) ?></div>
                <div class="promo-msg"><?= nl2br(htmlspecialchars($p['mensagem'])) ?></div>
                <?php if($p['whatsapp_numero']): ?>
                <div style="margin-top:.5rem;display:flex;align-items:center;gap:.4rem;font-size:.78rem">
                  <i class="bi bi-whatsapp" style="color:<?= $p['whatsapp_ativo'] ? '#25d366' : 'rgba(255,255,255,.25)' ?>"></i>
                  <span style="color:<?= $p['whatsapp_ativo'] ? 'rgba(255,255,255,.55)' : 'rgba(255,255,255,.2)' ?>">
                    +<?= htmlspecialchars($p['whatsapp_numero']) ?>
                    <?= $p['whatsapp_ativo'] ? '' : '<em>(desativado)</em>' ?>
                  </span>
                </div>
                <?php endif; ?>
              </div>
              <div style="display:flex;flex-direction:column;gap:.3rem;align-items:flex-end;flex-shrink:0">
                <?php if($p['ativo']): ?>
                  <span class="badge-on"><span style="width:6px;height:6px;border-radius:50%;background:#4ade80;display:inline-block"></span>Visível</span>
                <?php else: ?>
                  <span class="badge-off">Oculta</span>
                <?php endif; ?>
              </div>
            </div>
            <div class="promo-footer">
              <!-- Editar -->
              <a href="?editar=<?= $p['id'] ?>" class="btn-act btn-edit">
                <i class="bi bi-pencil-fill"></i> Editar
              </a>

              <!-- Toggle visível -->
              <form method="POST" class="d-inline">
                <input type="hidden" name="acao" value="toggle_ativo">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn-act <?= $p['ativo'] ? 'btn-toggle-on' : 'btn-toggle-off' ?>">
                  <i class="bi bi-eye<?= $p['ativo'] ? '-slash' : '' ?>-fill"></i>
                  <?= $p['ativo'] ? 'Ocultar' : 'Mostrar' ?>
                </button>
              </form>

              <!-- Toggle WhatsApp -->
              <?php if($p['whatsapp_numero']): ?>
              <form method="POST" class="d-inline">
                <input type="hidden" name="acao" value="toggle_whatsapp">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit"
                  class="btn-act <?= $p['whatsapp_ativo'] ? 'btn-wa-on' : 'btn-wa-off' ?>"
                  title="<?= $p['whatsapp_ativo'] ? 'Desativar botão WhatsApp' : 'Ativar botão WhatsApp' ?>">
                  <i class="bi bi-whatsapp"></i>
                  <?= $p['whatsapp_ativo'] ? 'WA ON' : 'WA OFF' ?>
                </button>
              </form>
              <?php endif; ?>

              <div style="flex:1"></div>

              <!-- Data -->
              <span style="font-size:.72rem;color:rgba(255,255,255,.25)">
                <?= date('d/m H:i', strtotime($p['criado_em'])) ?>
              </span>

              <!-- Excluir -->
              <form method="POST" class="d-inline"
                    onsubmit="return confirm('Excluir esta promoção definitivamente?')">
                <input type="hidden" name="acao" value="excluir">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn-act btn-del">
                  <i class="bi bi-trash3-fill"></i>
                </button>
              </form>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ── Ícone picker ──
document.querySelectorAll('.icon-opt').forEach(el => {
  el.addEventListener('click', () => {
    document.querySelectorAll('.icon-opt').forEach(e => e.classList.remove('sel'));
    el.classList.add('sel');
    const cls = el.dataset.icone;
    document.getElementById('iconeVal').value = cls;
    document.getElementById('prevIconI').className = 'bi ' + cls;
    updatePreview();
  });
});

// ── Cor picker ──
document.querySelectorAll('.cor-opt').forEach(el => {
  el.addEventListener('click', () => {
    document.querySelectorAll('.cor-opt').forEach(e => e.style.borderColor = 'transparent');
    el.style.borderColor = '#fff';
    document.getElementById('corVal').value = el.dataset.cor;
    updatePreview();
  });
});

// ── Preview em tempo real ──
function updatePreview() {
  const titulo = document.getElementById('inpTitulo').value || 'Título da promoção';
  const msg    = document.getElementById('inpMsg').value    || 'Mensagem da promoção aparecerá aqui...';
  const icone  = document.getElementById('iconeVal').value  || 'bi-tag-fill';
  const cor    = document.getElementById('corVal').value    || '#e94560';
  const waNum  = document.getElementById('inpWaNum')?.value || '';
  const waOn   = document.getElementById('waAtivo')?.checked;

  document.getElementById('prevTitle').textContent = titulo;
  document.getElementById('prevText').textContent  = msg;
  document.getElementById('prevIconI').className   = 'bi ' + icone;
  document.getElementById('prevIcon').style.background = cor + '22';
  document.getElementById('prevIcon').style.border     = '1.5px solid ' + cor + '55';
  document.getElementById('prevIconI').style.color     = cor;
  document.getElementById('prevCard').style.background = cor + '12';
  document.getElementById('prevCard').style.border     = '1px solid ' + cor + '30';
  document.getElementById('prevCard').style.borderRadius = '12px';

  const waBtn = document.getElementById('prevWaBtn');
  waBtn.style.display = (waNum && waOn) ? 'inline-flex' : 'none';
}

// Contador de chars
document.getElementById('inpMsg').addEventListener('input', function() {
  document.getElementById('msgCount').textContent = this.value.length;
  updatePreview();
});
document.getElementById('inpTitulo').addEventListener('input', updatePreview);
document.getElementById('waAtivo').addEventListener('change', updatePreview);
document.getElementById('inpWaNum').addEventListener('input', updatePreview);

// Init preview
updatePreview();
document.getElementById('msgCount').textContent =
  document.getElementById('inpMsg').value.length;

// Toggle sidebar mobile

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});
</script>
</body>
</html>