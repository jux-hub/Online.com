<?php
require_once '../config.php';
requireAdmin();
$db = getDB();
$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia') ?: 'Barbearia';

function navActive(string $p, string $a): string { return $p===$a?'nav-link-side active':'nav-link-side'; }

// ── Criar tabelas se necessário ──
$db->exec("CREATE TABLE IF NOT EXISTS notif_campanhas (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  titulo      TEXT NOT NULL,
  mensagem    TEXT NOT NULL,
  publico     TEXT NOT NULL DEFAULT 'todos',
  status      TEXT NOT NULL DEFAULT 'pendente',
  enviados    INTEGER NOT NULL DEFAULT 0,
  erros       INTEGER NOT NULL DEFAULT 0,
  criado_em   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  enviado_em  TEXT
)");

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    // Salvar nova campanha
    if ($acao === 'criar_campanha') {
        $titulo  = trim($_POST['titulo']   ?? '');
        $msg     = trim($_POST['mensagem'] ?? '');
        $publico = $_POST['publico']       ?? 'todos';
        if ($titulo && $msg) {
            $db->prepare("INSERT INTO notif_campanhas (titulo,mensagem,publico) VALUES (?,?,?)")
               ->execute([$titulo, $msg, $publico]);
            flash('success', 'Campanha criada! Clique em Enviar para disparar.');
        } else {
            flash('danger', 'Preencha título e mensagem.');
        }
    }

    // Disparar campanha
    if ($acao === 'enviar_campanha') {
        $campId = (int)($_POST['campanha_id'] ?? 0);
        $camp   = $db->prepare("SELECT * FROM notif_campanhas WHERE id=?")->execute([$campId]) ? null : null;
        $stmt   = $db->prepare("SELECT * FROM notif_campanhas WHERE id=?");
        $stmt->execute([$campId]);
        $camp = $stmt->fetch();

        if ($camp && $camp['status'] === 'pendente') {
            require_once '../whatsapp/config.php';

            // Buscar destinatários conforme público
            $query = match($camp['publico']) {
                'clientes'   => "SELECT DISTINCT telefone FROM clientes WHERE telefone != '' AND telefone IS NOT NULL",
                'barbeiros'  => "SELECT telefone FROM usuarios WHERE tipo='barbeiro' AND ativo=1 AND telefone != ''",
                'assistentes'=> "SELECT telefone FROM usuarios WHERE tipo='assistente' AND ativo=1 AND telefone != ''",
                default      => "SELECT DISTINCT telefone FROM clientes WHERE telefone != '' UNION SELECT telefone FROM usuarios WHERE ativo=1 AND telefone != ''",
            };
            $destinatarios = $db->query($query)->fetchAll(PDO::FETCH_COLUMN);

            $enviados = 0; $erros = 0;
            foreach ($destinatarios as $tel) {
                $tel = preg_replace('/\D/','',$tel);
                if (strlen($tel) < 10) { $erros++; continue; }
                try {
                    $ok = @enviarWhatsApp($tel, $camp['mensagem']);
                    if ($ok) $enviados++; else $erros++;
                } catch (Exception $e) { $erros++; }
                usleep(600000); // 0.6s entre envios
            }
            $db->prepare("UPDATE notif_campanhas SET status='enviado',enviados=?,erros=?,enviado_em=CURRENT_TIMESTAMP WHERE id=?")
               ->execute([$enviados, $erros, $campId]);
            flash('success', "Campanha enviada! ✅ {$enviados} enviados, ❌ {$erros} erros.");
        } else {
            flash('warning', 'Campanha não encontrada ou já enviada.');
        }
    }

    // Excluir campanha
    if ($acao === 'del_campanha') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare("DELETE FROM notif_campanhas WHERE id=? AND status='pendente'")->execute([$id]);
        flash('success', 'Campanha removida.');
    }

    // Notificação manual rápida
    if ($acao === 'notif_manual') {
        $tel = preg_replace('/\D/', '', $_POST['telefone'] ?? '');
        $msg = trim($_POST['mensagem'] ?? '');
        if (strlen($tel) >= 10 && $msg) {
            require_once '../whatsapp/config.php';
            $ok = @enviarWhatsApp($tel, $msg);
            flash($ok ? 'success' : 'danger', $ok ? 'Mensagem enviada!' : 'Falha ao enviar. Verifique a configuração do WhatsApp.');
        } else {
            flash('danger', 'Telefone ou mensagem inválidos.');
        }
    }

    header('Location: notificacoes.php'); exit;
}

// ── Leitura ──
$campanhas    = $db->query("SELECT * FROM notif_campanhas ORDER BY criado_em DESC LIMIT 50")->fetchAll();
$totalClientes = $db->query("SELECT COUNT(*) FROM clientes WHERE telefone != '' AND telefone IS NOT NULL")->fetchColumn();
$totalBarbeiros= $db->query("SELECT COUNT(*) FROM usuarios WHERE tipo='barbeiro' AND ativo=1 AND telefone != ''")->fetchColumn();

// Últimas notif do log WhatsApp
$ultimasNotif = [];
if ($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='wa_historico'")->fetchColumn()) {
    $ultimasNotif = $db->query("SELECT * FROM wa_historico ORDER BY enviado_em DESC LIMIT 10")->fetchAll();
}

$waProvider = getConfig('wa_provider') ?: 'callmebot';
$waOk = match($waProvider) {
    'callmebot'  => (bool)getConfig('wa_callmebot_apikey'),
    'zapi'       => (bool)getConfig('wa_zapi_instance') && (bool)getConfig('wa_zapi_token'),
    'uazapi'     => (bool)getConfig('wa_uazapi_url')    && (bool)getConfig('wa_uazapi_token'),
    'evolution'  => (bool)getConfig('wa_evolution_url') && (bool)getConfig('wa_evolution_key'),
    default      => false,
};

// Templates salvos
$templates = [];
if ($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='wa_templates'")->fetchColumn()) {
    $templates = $db->query("SELECT * FROM wa_templates ORDER BY usos DESC, criado_em ASC")->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Notificações – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%);transition:.3s}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  /* componente */
  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.25rem}
  .card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
  .form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:10px;padding:.55rem .85rem;font-size:.88rem;width:100%}
  .form-control-dark:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
  .form-control-dark::placeholder{color:rgba(255,255,255,.3)}
  select.form-control-dark option{background:#1a1a2e}
  textarea.form-control-dark{resize:vertical;min-height:90px}
  .btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;border-radius:10px;padding:.6rem 1.25rem;font-weight:700;cursor:pointer;font-size:.9rem;transition:.2s;white-space:nowrap}
  .btn-primary-custom:hover{opacity:.88;transform:translateY(-1px)}
  .btn-wa{background:linear-gradient(135deg,#25d366,#128c7e);border:none;color:#fff;border-radius:10px;padding:.6rem 1.25rem;font-weight:700;cursor:pointer;font-size:.9rem;transition:.2s}
  .btn-wa:hover{opacity:.88}
  .stat-pill{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:.65rem 1rem;text-align:center}
  .stat-pill-val{font-size:1.5rem;font-weight:800;color:#fff}
  .stat-pill-lbl{font-size:.72rem;color:rgba(255,255,255,.4);margin-top:.1rem}
  .camp-row{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:.85rem 1rem;margin-bottom:.6rem;display:flex;align-items:center;gap:.75rem;flex-wrap:wrap}
  .badge-status{border-radius:20px;padding:.15rem .6rem;font-size:.72rem;font-weight:700}
  .bs-pendente{background:rgba(245,158,11,.15);color:#fbbf24}
  .bs-enviado{background:rgba(34,197,94,.12);color:#4ade80}
  .badge-pub{background:rgba(59,130,246,.12);color:#60a5fa;border-radius:20px;padding:.12rem .55rem;font-size:.7rem}
  .wa-status{padding:.5rem .85rem;border-radius:10px;font-size:.82rem;display:flex;align-items:center;gap:.5rem;font-weight:600}
  .wa-ok{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);color:#4ade80}
  .wa-err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);color:#f87171}
  .var-tag{display:inline-flex;align-items:center;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:6px;padding:.1rem .45rem;font-size:.72rem;color:rgba(255,255,255,.6);cursor:pointer;transition:.15s;margin:.1rem}
  .var-tag:hover{background:rgba(233,69,96,.15);border-color:rgba(233,69,96,.35);color:#e94560}
  h4,h5,h6{color:#fff;margin:0}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"            class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"          class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"             class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"     class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"             class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"               class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"         class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"              class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"           class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"            class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"            class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"    class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"                class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"                class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700"><i class="bi bi-bell-fill me-2" style="color:var(--primary)"></i>Notificações</h6>
  </div>
  <div class="<?= $waOk ? 'wa-status wa-ok' : 'wa-status wa-err' ?>">
    <i class="bi bi-whatsapp"></i>
    WhatsApp: <?= $waOk ? 'Configurado ('.strtoupper($waProvider).')' : 'Não configurado' ?>
    <?php if (!$waOk): ?><a href="configuracoes.php" style="color:inherit;margin-left:.4rem;font-size:.78rem">(configurar)</a><?php endif; ?>
  </div>
</div>
<div class="page-body">
  <?= renderFlash() ?>

  <!-- Stats -->
  <div class="row g-3 mb-3">
    <div class="col-6 col-md-3">
      <div class="stat-pill">
        <div class="stat-pill-val"><?= $totalClientes ?></div>
        <div class="stat-pill-lbl">Clientes c/ WhatsApp</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-pill">
        <div class="stat-pill-val"><?= $totalBarbeiros ?></div>
        <div class="stat-pill-lbl">Barbeiros c/ WhatsApp</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-pill">
        <div class="stat-pill-val"><?= count(array_filter($campanhas, fn($c)=>$c['status']==='enviado')) ?></div>
        <div class="stat-pill-lbl">Campanhas enviadas</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-pill">
        <div class="stat-pill-val"><?= array_sum(array_column($campanhas, 'enviados')) ?></div>
        <div class="stat-pill-lbl">Total disparos</div>
      </div>
    </div>
  </div>

  <div class="row g-3">
    <div class="col-lg-7">

      <!-- Nova campanha -->
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-megaphone-fill" style="color:var(--primary)"></i>Nova Campanha em Massa</div>

        <?php if (!$waOk): ?>
        <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);border-radius:12px;padding:1rem;margin-bottom:1rem;font-size:.85rem;color:#f87171">
          <i class="bi bi-exclamation-triangle-fill me-2"></i>
          Configure o WhatsApp em <a href="configuracoes.php" style="color:#f87171;text-decoration:underline">Configurações</a> antes de enviar campanhas.
        </div>
        <?php endif; ?>

        <form method="POST">
          <input type="hidden" name="acao" value="criar_campanha">
          <div class="mb-2">
            <label style="color:rgba(255,255,255,.5);font-size:.78rem;display:block;margin-bottom:.3rem">Título da campanha (interno)</label>
            <input type="text" name="titulo" class="form-control-dark" placeholder="Ex: Promoção Junho, Aviso Recesso…" required>
          </div>
          <div class="mb-2">
            <label style="color:rgba(255,255,255,.5);font-size:.78rem;display:block;margin-bottom:.3rem">Público</label>
            <select name="publico" class="form-control-dark">
              <option value="todos">Todos (clientes + equipe)</option>
              <option value="clientes">Somente clientes</option>
              <option value="barbeiros">Somente barbeiros</option>
              <option value="assistentes">Somente assistentes</option>
            </select>
          </div>
          <div class="mb-2">
            <label style="color:rgba(255,255,255,.5);font-size:.78rem;display:block;margin-bottom:.3rem">Mensagem</label>
            <div style="margin-bottom:.35rem">
              <?php foreach (['{{nome_barbearia}}','{{data}}','{{link}}'] as $v): ?>
              <span class="var-tag" onclick="inserirVar('<?= $v ?>')"><?= $v ?></span>
              <?php endforeach; ?>
            </div>
            <textarea name="mensagem" id="txtMensagem" class="form-control-dark" placeholder="Digite a mensagem que será enviada para todos…" required></textarea>
          </div>
          <?php if (!empty($templates)): ?>
          <div class="mb-2">
            <select id="selTemplate" class="form-control-dark" onchange="usarTemplate(this.value)">
              <option value="">Usar template salvo…</option>
              <?php foreach ($templates as $t): ?>
              <option value="<?= htmlspecialchars($t['mensagem']) ?>"><?= htmlspecialchars($t['titulo']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <?php endif; ?>
          <button type="submit" class="btn-primary-custom w-100 mt-1"><i class="bi bi-plus-lg me-1"></i>Criar Campanha</button>
        </form>
      </div>

      <!-- Notificação manual rápida -->
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-send-fill" style="color:#25d366"></i>Mensagem Rápida (individual)</div>
        <form method="POST">
          <input type="hidden" name="acao" value="notif_manual">
          <div class="row g-2">
            <div class="col-sm-5">
              <label style="color:rgba(255,255,255,.5);font-size:.78rem;display:block;margin-bottom:.3rem">Telefone (com DDD)</label>
              <input type="tel" name="telefone" class="form-control-dark" placeholder="5511999999999">
            </div>
            <div class="col-sm-7">
              <label style="color:rgba(255,255,255,.5);font-size:.78rem;display:block;margin-bottom:.3rem">Mensagem</label>
              <input type="text" name="mensagem" class="form-control-dark" placeholder="Mensagem a enviar…" required>
            </div>
          </div>
          <button type="submit" class="btn-wa mt-2"><i class="bi bi-whatsapp me-1"></i>Enviar agora</button>
        </form>
      </div>

      <!-- Campanhas -->
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-list-task" style="color:var(--primary)"></i>Campanhas
          <span style="background:rgba(255,255,255,.08);border-radius:20px;padding:.1rem .55rem;font-size:.72rem;color:rgba(255,255,255,.5);margin-left:auto"><?= count($campanhas) ?></span>
        </div>
        <?php if (empty($campanhas)): ?>
        <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25)">
          <i class="bi bi-megaphone" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
          Nenhuma campanha criada ainda
        </div>
        <?php else: ?>
        <?php foreach ($campanhas as $c): ?>
        <div class="camp-row">
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;color:#fff;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($c['titulo']) ?></div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.35);margin-top:.15rem">
              <?= date('d/m/Y H:i', strtotime($c['criado_em'])) ?>
              · <span class="badge-pub"><?= htmlspecialchars($c['publico']) ?></span>
              <?php if ($c['status']==='enviado'): ?>
              · <span style="color:#4ade80">✅ <?= $c['enviados'] ?> enviados</span>
              <?php if ($c['erros']): ?><span style="color:#f87171"> · ❌ <?= $c['erros'] ?> erros</span><?php endif; ?>
              <?php endif; ?>
            </div>
          </div>
          <span class="badge-status <?= $c['status']==='enviado'?'bs-enviado':'bs-pendente' ?>">
            <?= $c['status']==='enviado' ? 'Enviado' : 'Pendente' ?>
          </span>
          <?php if ($c['status'] === 'pendente'): ?>
          <form method="POST" onsubmit="return confirm('Disparar campanha para todos os destinatários? Isso enviará mensagens WhatsApp reais.')">
            <input type="hidden" name="acao" value="enviar_campanha">
            <input type="hidden" name="campanha_id" value="<?= $c['id'] ?>">
            <button type="submit" class="btn-wa" style="padding:.3rem .75rem;font-size:.8rem" <?= !$waOk?'disabled':'' ?>>
              <i class="bi bi-send-fill me-1"></i>Disparar
            </button>
          </form>
          <form method="POST" onsubmit="return confirm('Remover campanha?')">
            <input type="hidden" name="acao" value="del_campanha">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button type="submit" style="background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#f87171;border-radius:8px;padding:.28rem .55rem;cursor:pointer;font-size:.82rem">
              <i class="bi bi-trash"></i>
            </button>
          </form>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>

    </div>

    <!-- Coluna direita -->
    <div class="col-lg-5">

      <!-- Histórico WA -->
      <?php if (!empty($ultimasNotif)): ?>
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-clock-history" style="color:#60a5fa"></i>Últimas Notificações Automáticas</div>
        <?php foreach ($ultimasNotif as $n): ?>
        <div style="padding:.5rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
          <div style="font-size:.78rem;color:rgba(255,255,255,.5)"><?= date('d/m H:i', strtotime($n['enviado_em'] ?? 'now')) ?></div>
          <div style="font-size:.82rem;color:#e0e0e0;margin-top:.1rem"><?= htmlspecialchars(mb_substr($n['mensagem'] ?? '', 0, 60)) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <!-- Info automáticas -->
      <div class="card-sec" style="background:rgba(59,130,246,.06);border-color:rgba(59,130,246,.2)">
        <div class="card-title" style="color:#60a5fa"><i class="bi bi-robot"></i>Notificações Automáticas</div>
        <div style="font-size:.82rem;color:rgba(255,255,255,.5);line-height:1.7">
          <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.4rem">
            <i class="bi bi-check-circle-fill" style="color:#4ade80"></i>
            <span>Aviso de vez chegando (cron a cada 2 min)</span>
          </div>
          <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.4rem">
            <i class="bi bi-check-circle-fill" style="color:#4ade80"></i>
            <span>Lembrete de retorno (cron diário 10h)</span>
          </div>
          <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.4rem">
            <i class="bi bi-check-circle-fill" style="color:#4ade80"></i>
            <span>Confirmação de agendamento</span>
          </div>
          <div style="display:flex;align-items:center;gap:.5rem">
            <i class="bi bi-check-circle-fill" style="color:#4ade80"></i>
            <span>Comprovante de atendimento</span>
          </div>
          <div style="margin-top:.85rem;padding:.6rem;background:rgba(255,255,255,.04);border-radius:8px;font-size:.75rem">
            Configure os crons em:<br>
            <code style="color:#a78bfa">*/2 * * * * lsphp -q .../api/notificar_fila.php</code>
          </div>
        </div>
      </div>

    </div>
  </div>
</div><!-- /page-body -->
</div><!-- /main-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
function inserirVar(v){
  const t=document.getElementById('txtMensagem');
  const s=t.selectionStart, e=t.selectionEnd;
  t.value=t.value.substring(0,s)+v+t.value.substring(e);
  t.selectionStart=t.selectionEnd=s+v.length;
  t.focus();
}
function usarTemplate(msg){
  if(msg) document.getElementById('txtMensagem').value=msg;
  document.getElementById('selTemplate').value='';
}
</script>
</body>
</html>
