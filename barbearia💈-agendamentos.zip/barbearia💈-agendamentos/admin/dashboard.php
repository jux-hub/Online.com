<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// Toggle rápido da fila
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'toggle_fila') {
    $modoAtual = getConfig('fila_modo') ?? 'auto';
    // Cicla entre: auto → aberta → fechada → auto
    $proximo = match($modoAtual) {
        'aberta'  => 'fechada',
        'fechada' => 'auto',
        default   => 'aberta',
    };
    setConfig('fila_modo', $proximo);
    setConfig('fila_ativa', $proximo === 'aberta' ? '1' : ($proximo === 'fechada' ? '0' : '1'));
    $msgs = ['aberta'=>'✅ Fila forçada ABERTA!','fechada'=>'🔒 Fila forçada FECHADA!','auto'=>'⚙️ Fila em modo automático (horário)'];
    flash($proximo === 'fechada' ? 'warning' : 'success', $msgs[$proximo]);
    header('Location: dashboard.php'); exit;
}

$hoje   = date('Y-m-d');
$semana = date('Y-m-d', strtotime('-7 days'));
$mes    = date('Y-m-01');

$stats = [];
foreach(['hoje'=>$hoje,'semana'=>$semana,'mes'=>$mes] as $key=>$data) {
    $stmt = $db->prepare("SELECT COUNT(*) as total, COALESCE(SUM(valor),0) as faturamento
        FROM fila WHERE status='concluido' AND DATE(finalizado_em) >= ?");
    $stmt->execute([$data]);
    $stats[$key] = $stmt->fetch();
}

$barbeiros = $db->query("SELECT * FROM usuarios WHERE tipo='barbeiro' AND ativo=1")->fetchAll();

$promocoesAtivas = $db->query("SELECT * FROM promocoes WHERE ativo=1 ORDER BY criado_em DESC LIMIT 3")->fetchAll();
$totalPromos     = $db->query("SELECT COUNT(*) as c FROM promocoes")->fetch()['c'];

$nomeBarbearia = getConfig('nome_barbearia');
$filaAtiva     = getConfig('fila_ativa')          ?? '1';
$filaModo      = getConfig('fila_modo')           ?? 'auto';
$horAbert      = getConfig('horario_abertura')    ?? '08:00';
$horFech       = getConfig('horario_fechamento')  ?? '18:00';
$diasConf      = getConfig('dias_semana')         ?? '1,2,3,4,5,6';
$diasAtivos    = explode(',', $diasConf);
$diaOk         = in_array(date('w'), $diasAtivos);
$horarioOk     = date('H:i') >= $horAbert && date('H:i') <= $horFech;
if ($filaModo === 'aberta')       { $filaAberta = true; }
elseif ($filaModo === 'fechada')  { $filaAberta = false; }
else                              { $filaAberta = $filaAtiva === '1' && $diaOk && $horarioOk; }

// Helper para gerar a classe active
function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%);transition:.3s}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
    border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem;
    position:relative;overflow:hidden}
  .stat-card::after{content:'';position:absolute;top:-15px;right:-15px;
    width:70px;height:70px;border-radius:50%;opacity:.12}
  .stat-card.c1::after{background:#e94560}
  .stat-card.c2::after{background:#22c55e}
  .stat-card.c3::after{background:#3b82f6}
  .stat-card.c4::after{background:#f59e0b}
  .stat-icon{width:46px;height:46px;border-radius:12px;display:flex;
    align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:.85rem}
  .stat-value{font-size:1.6rem;font-weight:800;color:#fff;line-height:1;word-break:break-all}
  .stat-label{color:rgba(255,255,255,.5);font-size:.82rem;margin-top:.3rem}
  .section-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);
    border-radius:16px;padding:1.25rem;margin-bottom:1.25rem}
  .section-title{font-size:.95rem;font-weight:700;color:#fff;
    margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
  .barb-perf{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:1.1rem}
  .barb-avatar{width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid rgba(233,69,96,.4);flex-shrink:0}
  .barb-avatar-ph{width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .dash-promo-item{display:flex;align-items:center;gap:.85rem;padding:.8rem;border-radius:12px;
    background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);margin-bottom:.5rem;transition:.2s}
  .dash-promo-item:last-child{margin-bottom:0}
  .dash-promo-item:hover{background:rgba(255,255,255,.07)}
  .dash-promo-icon{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0}
  .dash-promo-nome{font-weight:600;color:#fff;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dash-promo-msg{font-size:.75rem;color:rgba(255,255,255,.4);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dash-promo-badge{border-radius:20px;padding:.15rem .6rem;font-size:.72rem;font-weight:700;white-space:nowrap;flex-shrink:0}
  h4,h5,h6{color:#fff;margin:0}
  .text-vazio{color:rgba(255,255,255,.3);text-align:center;padding:2rem 0}
  @keyframes pulse-dot{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(1.4)}}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
    .stat-value{font-size:1.3rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">Dashboard</h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)"><?= date('d/m/Y H:i') ?></div>
      </div>
    </div>
    <div class="d-flex align-items-center gap-2 flex-wrap">
      <div style="background:<?= $filaAberta ? 'rgba(34,197,94,.15)' : 'rgba(239,68,68,.15)' ?>;
        border:1px solid <?= $filaAberta ? 'rgba(34,197,94,.3)' : 'rgba(239,68,68,.3)' ?>;
        color:<?= $filaAberta ? '#4ade80' : '#f87171' ?>;
        border-radius:20px;padding:.3rem .85rem;font-size:.8rem;font-weight:700;
        display:flex;align-items:center;gap:.4rem">
        <span style="width:7px;height:7px;border-radius:50%;
          background:<?= $filaAberta ? '#4ade80' : '#f87171' ?>;
          <?= $filaAberta ? 'animation:pulse-dot 1.5s infinite' : '' ?>"></span>
        <?= $filaAberta ? 'Fila Aberta' : 'Fila Fechada' ?>
      </div>
      <form method="POST" class="d-inline">
        <input type="hidden" name="acao" value="toggle_fila">
        <?php
          $btnInfo = match($filaModo ?? 'auto') {
            'aberta'  => ['bg'=>'rgba(239,68,68,.15)', 'border'=>'rgba(239,68,68,.3)',  'color'=>'#f87171', 'icon'=>'lock',       'txt'=>'Fechar Fila'],
            'fechada' => ['bg'=>'rgba(245,158,11,.12)','border'=>'rgba(245,158,11,.3)', 'color'=>'#fbbf24', 'icon'=>'gear',       'txt'=>'Modo Auto'],
            default   => ['bg'=>'rgba(34,197,94,.15)', 'border'=>'rgba(34,197,94,.3)',  'color'=>'#4ade80', 'icon'=>'unlock-fill','txt'=>'Abrir Fila'],
          };
        ?>
        <button type="submit"
          style="background:<?= $btnInfo['bg'] ?>;border:1px solid <?= $btnInfo['border'] ?>;
            color:<?= $btnInfo['color'] ?>;border-radius:10px;padding:.4rem .9rem;
            font-size:.82rem;font-weight:700;cursor:pointer;
            display:flex;align-items:center;gap:.4rem;white-space:nowrap">
          <i class="bi bi-<?= $btnInfo['icon'] ?>"></i>
          <?= $btnInfo['txt'] ?>
        </button>
      </form>
      <a href="<?= BASE_URL ?>/" target="_blank"
        style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);
          color:#fff;border-radius:10px;padding:.4rem .9rem;font-size:.82rem;font-weight:700;
          display:flex;align-items:center;gap:.4rem;white-space:nowrap;text-decoration:none"
        title="Abrir página da fila (Index)">
        <i class="bi bi-box-arrow-up-right"></i>
        <span class="d-none d-sm-inline">Ver Site</span>
      </a>
      <div class="d-none d-sm-block" style="text-align:right">
        <div style="color:#fff;font-weight:600;font-size:.88rem"><?= htmlspecialchars($_SESSION['usuario_nome']) ?></div>
        <div style="font-size:.72rem;color:rgba(255,255,255,.4)">Administrador</div>
      </div>
      <div style="width:36px;height:36px;background:linear-gradient(135deg,#e94560,#c41230);
        border-radius:50%;display:flex;align-items:center;justify-content:center">
        <i class="bi bi-person-fill text-white"></i>
      </div>
    </div>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- ── Stats ── -->
    <div class="row g-2 mb-3">
      <div class="col-6 col-xl-3">
        <div class="stat-card c1">
          <div class="stat-icon" style="background:rgba(233,69,96,.2)">
            <i class="bi bi-scissors" style="color:#e94560"></i>
          </div>
          <div class="stat-value"><?= $stats['hoje']['total'] ?></div>
          <div class="stat-label">Cortes Hoje</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c2">
          <div class="stat-icon" style="background:rgba(34,197,94,.2)">
            <i class="bi bi-cash-coin" style="color:#22c55e"></i>
          </div>
          <div class="stat-value" style="font-size:1.1rem"><?= formatMoney($stats['hoje']['faturamento']) ?></div>
          <div class="stat-label">Faturamento Hoje</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c3">
          <div class="stat-icon" style="background:rgba(59,130,246,.2)">
            <i class="bi bi-calendar-week" style="color:#3b82f6"></i>
          </div>
          <div class="stat-value"><?= $stats['semana']['total'] ?></div>
          <div class="stat-label">Cortes (7 dias)</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c4">
          <div class="stat-icon" style="background:rgba(245,158,11,.2)">
            <i class="bi bi-calendar-month" style="color:#f59e0b"></i>
          </div>
          <div class="stat-value" style="font-size:1.1rem"><?= formatMoney($stats['mes']['faturamento']) ?></div>
          <div class="stat-label">Faturamento do Mês</div>
        </div>
      </div>
    </div>

    <!-- ── Promoções Ativas ── -->
    <div class="section-card" style="border-color:rgba(233,69,96,.2)">
      <div class="section-title" style="margin-bottom:.75rem">
        <i class="bi bi-megaphone-fill" style="color:#e94560"></i>
        Promoções Ativas
        <span style="background:rgba(233,69,96,.2);color:#e94560;border-radius:20px;
          padding:.15rem .6rem;font-size:.78rem;font-weight:700">
          <?= count($promocoesAtivas) ?>
        </span>
        <a href="promocoes.php" class="ms-auto"
           style="background:rgba(233,69,96,.12);border:1px solid rgba(233,69,96,.25);
                  color:#e94560;border-radius:8px;padding:.25rem .75rem;
                  font-size:.78rem;font-weight:700;text-decoration:none;
                  display:flex;align-items:center;gap:.3rem;white-space:nowrap">
          <i class="bi bi-plus-lg"></i> Gerenciar
        </a>
      </div>
      <?php if(empty($promocoesAtivas)): ?>
        <div style="background:rgba(233,69,96,.05);border:1px dashed rgba(233,69,96,.2);
                    border-radius:12px;padding:1.25rem;text-align:center">
          <i class="bi bi-megaphone" style="font-size:2rem;color:rgba(233,69,96,.3);display:block;margin-bottom:.5rem"></i>
          <div style="color:rgba(255,255,255,.4);font-size:.85rem">Nenhuma promoção ativa no momento</div>
          <a href="promocoes.php"
             style="display:inline-flex;align-items:center;gap:.3rem;margin-top:.6rem;
                    background:var(--primary);color:#fff;border-radius:8px;
                    padding:.4rem .9rem;font-size:.8rem;font-weight:700;text-decoration:none">
            <i class="bi bi-plus-lg"></i> Criar primeira promoção
          </a>
        </div>
      <?php else: ?>
        <?php foreach($promocoesAtivas as $p): ?>
        <div class="dash-promo-item">
          <div class="dash-promo-icon"
               style="background:<?= htmlspecialchars($p['cor']) ?>22;border:1.5px solid <?= htmlspecialchars($p['cor']) ?>44">
            <i class="bi <?= htmlspecialchars($p['icone']) ?>" style="color:<?= htmlspecialchars($p['cor']) ?>"></i>
          </div>
          <div style="flex:1;min-width:0">
            <div class="dash-promo-nome"><?= htmlspecialchars($p['titulo']) ?></div>
            <div class="dash-promo-msg"><?= htmlspecialchars($p['mensagem']) ?></div>
          </div>
          <?php if($p['whatsapp_numero'] && $p['whatsapp_ativo']): ?>
          <span class="dash-promo-badge"
                style="background:rgba(37,211,102,.12);color:#25d366;border:1px solid rgba(37,211,102,.2)">
            <i class="bi bi-whatsapp"></i> WA
          </span>
          <?php endif; ?>
          <span class="dash-promo-badge"
                style="background:rgba(34,197,94,.12);color:#4ade80;border:1px solid rgba(34,197,94,.2)">
            <i class="bi bi-eye-fill"></i> Visível
          </span>
        </div>
        <?php endforeach; ?>
        <?php if($totalPromos > 3): ?>
        <div style="text-align:center;margin-top:.6rem">
          <a href="promocoes.php" style="font-size:.78rem;color:rgba(255,255,255,.35);text-decoration:none">
            + <?= $totalPromos - 3 ?> mais → <span style="color:var(--primary)">ver todas</span>
          </a>
        </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>

    <!-- ── Performance Barbeiros ── -->
    <div class="section-card">
      <div class="section-title">
        <i class="bi bi-people-fill" style="color:#3b82f6"></i>
        Performance dos Barbeiros Hoje
      </div>
      <div class="row g-2">
        <?php foreach($barbeiros as $b):
          $stmt = $db->prepare("SELECT COUNT(*) as cortes, COALESCE(SUM(valor),0) as fat
              FROM fila WHERE barbeiro_id=? AND status='concluido' AND DATE(finalizado_em)=?");
          $stmt->execute([$b['id'], $hoje]);
          $perf     = $stmt->fetch();
          $comissao = $perf['fat'] * ($b['comissao_percent']/100);
          $temFoto  = !empty($b['foto']) && file_exists(__DIR__.'/../uploads/barbeiros/'.$b['foto']);
          $fotoUrl  = $temFoto ? BASE_URL.'/uploads/barbeiros/'.htmlspecialchars($b['foto']) : null;
        ?>
        <div class="col-12 col-md-6 col-xl-4">
          <div class="barb-perf">
            <div class="d-flex align-items-center gap-2 mb-2">
              <?php if($fotoUrl): ?>
                <img src="<?= $fotoUrl ?>" alt="" class="barb-avatar">
              <?php else: ?>
                <div class="barb-avatar-ph"><i class="bi bi-person-fill text-white"></i></div>
              <?php endif; ?>
              <div>
                <div style="font-weight:700;color:#fff;font-size:.92rem"><?= htmlspecialchars($b['nome']) ?></div>
                <div style="font-size:.75rem;color:rgba(255,255,255,.4)"><?= $b['comissao_percent'] ?>% comissão</div>
              </div>
            </div>
            <div class="row g-1 text-center">
              <div class="col-4">
                <div style="font-size:1.5rem;font-weight:800;color:#e94560"><?= $perf['cortes'] ?></div>
                <div style="font-size:.72rem;color:rgba(255,255,255,.4)">Cortes</div>
              </div>
              <div class="col-4">
                <div style="font-size:.88rem;font-weight:700;color:#4ade80"><?= formatMoney($perf['fat']) ?></div>
                <div style="font-size:.72rem;color:rgba(255,255,255,.4)">Faturado</div>
              </div>
              <div class="col-4">
                <div style="font-size:.88rem;font-weight:700;color:#fbbf24"><?= formatMoney($comissao) ?></div>
                <div style="font-size:.72rem;color:rgba(255,255,255,.4)">Comissão</div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php if(empty($barbeiros)): ?>
        <div class="col-12">
          <div class="text-vazio">
            <i class="bi bi-people fs-1 d-block mb-2"></i>
            Nenhum barbeiro ativo cadastrado
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});
setTimeout(() => location.reload(), 30000);
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope)).catch(e => console.log('SW erro:', e));
  });
}
</script>
</body>
</html>