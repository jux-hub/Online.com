<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

$paginaAtual = basename($_SERVER['PHP_SELF']);

$uploadDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'salvar_geral') {
        $campos = ['nome_barbearia','tempo_medio_corte','limite_fila','notificacao_posicoes'];
        foreach ($campos as $c) {
            if (isset($_POST[$c])) setConfig($c, trim($_POST[$c]));
        }
        if (!empty($_FILES['logo_file']['tmp_name'])) {
            $ext     = strtolower(pathinfo($_FILES['logo_file']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif','webp'];
            if (!in_array($ext, $allowed)) {
                flash('danger', 'Formato de logo inválido.');
            } elseif ($_FILES['logo_file']['size'] > 2 * 1024 * 1024) {
                flash('danger', 'Logo deve ter no máximo 2MB.');
            } else {
                $oldLogo = getConfig('logo_path');
                if ($oldLogo && file_exists(__DIR__ . '/../' . $oldLogo)) @unlink(__DIR__ . '/../' . $oldLogo);
                $nome = 'logo_' . time() . '.' . $ext;
                if (move_uploaded_file($_FILES['logo_file']['tmp_name'], $uploadDir . $nome))
                    setConfig('logo_path', 'uploads/' . $nome);
            }
        }
        if (isset($_POST['remover_logo'])) {
            $oldLogo = getConfig('logo_path');
            if ($oldLogo && file_exists(__DIR__ . '/../' . $oldLogo)) @unlink(__DIR__ . '/../' . $oldLogo);
            setConfig('logo_path', '');
        }
        if (!empty($_FILES['capa_file']['tmp_name'])) {
            $ext     = strtolower(pathinfo($_FILES['capa_file']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif','webp'];
            if (!in_array($ext, $allowed)) {
                flash('danger', 'Formato de capa inválido.');
            } elseif ($_FILES['capa_file']['size'] > 5 * 1024 * 1024) {
                flash('danger', 'Capa deve ter no máximo 5MB.');
            } else {
                $oldCapa = getConfig('capa_bg_path');
                if ($oldCapa && file_exists(__DIR__ . '/../' . $oldCapa)) @unlink(__DIR__ . '/../' . $oldCapa);
                $nome = 'capa_' . time() . '.' . $ext;
                if (move_uploaded_file($_FILES['capa_file']['tmp_name'], $uploadDir . $nome))
                    setConfig('capa_bg_path', 'uploads/' . $nome);
            }
        }
        if (isset($_POST['remover_capa'])) {
            $oldCapa = getConfig('capa_bg_path');
            if ($oldCapa && file_exists(__DIR__ . '/../' . $oldCapa)) @unlink(__DIR__ . '/../' . $oldCapa);
            setConfig('capa_bg_path', '');
        }
        if (!isset($_SESSION['flash'])) flash('success', 'Configurações gerais salvas!');
    }

    if ($acao === 'salvar_horarios') {
        setConfig('fila_ativa',         $_POST['fila_ativa']         ?? '1');
        setConfig('fila_modo',          $_POST['fila_modo']          ?? 'auto');
        setConfig('fuso_horario',       $_POST['fuso_horario']       ?? 'America/Sao_Paulo');
        setConfig('horario_abertura',   $_POST['horario_abertura']   ?? '08:00');
        setConfig('horario_fechamento', $_POST['horario_fechamento'] ?? '18:00');
        $diasAtivosNovos = [];
        for ($d = 0; $d <= 6; $d++) {
            $ativoD = ($_POST["dia_ativo_$d"] ?? '0') === '1';
            if ($ativoD) $diasAtivosNovos[] = $d;
            setConfig("horario_abertura_$d",   $_POST["horario_abertura_$d"]   ?? '');
            setConfig("horario_fechamento_$d", $_POST["horario_fechamento_$d"] ?? '');
            setConfig("motivo_fechamento_$d",  trim($_POST["motivo_fechamento_$d"] ?? ''));
        }
        setConfig('dias_semana', implode(',', $diasAtivosNovos));
        flash('success', 'Horários salvos com sucesso!');
    }

    if ($acao === 'salvar_loja') {
        $campos = [
            'loja_botao_index','loja_ativa','loja_entrega_ativa',
            'loja_retirada_ativa','loja_taxa_entrega','minha_conta_botao_index',
            'agenda_botao_index','servicos_index_ativo',
        ];
        foreach ($campos as $c) {
            if (isset($_POST[$c])) setConfig($c, trim($_POST[$c]));
        }
        flash('success', 'Configurações da loja salvas!');
    }

    if ($acao === 'salvar_whatsapp') {
        $campos = [
            'wa_provider',
            'wa_callmebot_apikey',
            'wa_zapi_instance',
            'wa_zapi_token',
            'wa_zapi_client_token',
            // ── uazapi ──
            'wa_uazapi_url',
            'wa_uazapi_token',
            'wa_uazapi_instance',
            // ── evolution ──
            'wa_evolution_url',
            'wa_evolution_key',
            'wa_evolution_instance',
            // ── automações ──
            'avaliacao_imediata',
            'lembrete_retorno_dias',
            'confirmacao_antecedencia_min',
        ];
        foreach ($campos as $c) {
            if (isset($_POST[$c])) setConfig($c, trim($_POST[$c]));
        }
        flash('success', 'Configurações do WhatsApp salvas!');
    }

    if ($acao === 'salvar_senha') {
        $senhaAtual = $_POST['senha_atual'] ?? '';
        $novaSenha  = $_POST['nova_senha']  ?? '';
        $confirma   = $_POST['confirma']    ?? '';
        $stmt = $db->prepare('SELECT senha FROM usuarios WHERE id=?');
        $stmt->execute([$_SESSION['usuario_id']]);
        $user = $stmt->fetch();
        if (!password_verify($senhaAtual, $user['senha'])) {
            flash('danger', 'Senha atual incorreta.');
        } elseif (strlen($novaSenha) < 6) {
            flash('danger', 'A nova senha deve ter pelo menos 6 caracteres.');
        } elseif ($novaSenha !== $confirma) {
            flash('danger', 'As senhas não coincidem.');
        } else {
            $db->prepare('UPDATE usuarios SET senha=? WHERE id=?')
               ->execute([password_hash($novaSenha, PASSWORD_DEFAULT), $_SESSION['usuario_id']]);
            flash('success', 'Senha alterada com sucesso!');
        }
    }

    if ($acao === 'testar_whatsapp') {
        $telefone = trim($_POST['tel_teste'] ?? '');
        if ($telefone) {
            require_once '../whatsapp/config.php';
            $nomeBarbeariaWa = getConfig('nome_barbearia');
            if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbeariaWa);
            $msg = "✂️ *{$nomeBarbeariaWa}*\n\nMensagem de teste do sistema!\nSe recebeu isso, o WhatsApp está funcionando. ✅";
            $ok  = enviarWhatsApp($telefone, $msg);
            flash($ok ? 'success' : 'danger',
                  $ok ? 'Mensagem de teste enviada!' : 'Falha ao enviar. Verifique as configurações e o log em logs/whatsapp_debug.log');
        } else {
            flash('danger', 'Informe um telefone para teste.');
        }
    }

    header('Location: configuracoes.php'); exit;
}

// ── Configs ──
$nomeBarbearia      = getConfig('nome_barbearia');
$tempoMedio         = getConfig('tempo_medio_corte');
$limiteFila         = getConfig('limite_fila');
$notifPos           = getConfig('notificacao_posicoes');
$waProvider         = getConfig('wa_provider')              ?? 'callmebot';
$waCallmebotKey     = getConfig('wa_callmebot_apikey')      ?? '';
$waZapiInstance     = getConfig('wa_zapi_instance')         ?? '';
$waZapiToken        = getConfig('wa_zapi_token')            ?? '';
$waZapiClientToken  = getConfig('wa_zapi_client_token')     ?? '';
// ── uazapi ──
$waUazapiUrl        = getConfig('wa_uazapi_url')            ?? '';
$waUazapiToken      = getConfig('wa_uazapi_token')          ?? '';
$waUazapiInstance   = getConfig('wa_uazapi_instance')       ?? '';
// ── evolution ──
$waEvoUrl           = getConfig('wa_evolution_url')         ?? '';
$waEvoKey           = getConfig('wa_evolution_key')         ?? '';
$waEvoInstance      = getConfig('wa_evolution_instance')    ?? '';
// ── automações ──
$avaliacaoImediata      = getConfig('avaliacao_imediata')             ?? '0';
$lembreteRetornoDias    = getConfig('lembrete_retorno_dias')          ?? '30';
$confirmacaoMin         = getConfig('confirmacao_antecedencia_min')   ?? '15';
$logoPath           = getConfig('logo_path')                ?? '';
$capaBgPath         = getConfig('capa_bg_path')             ?? '';

// Horários
$filaAtiva   = getConfig('fila_ativa')          ?? '1';
$filaModo    = getConfig('fila_modo')           ?? 'auto';
$fusoHorario = getConfig('fuso_horario')        ?? 'America/Sao_Paulo';
$horAbert    = trim(getConfig('horario_abertura')    ?? '08:00');
$horFech     = trim(getConfig('horario_fechamento')  ?? '18:00');
$diasConf    = getConfig('dias_semana')         ?? '1,2,3,4,5,6';
$diasAtivos  = array_map('trim', explode(',', $diasConf));
$numHoje     = (string)date('w');

$abreHoje    = trim(getConfig("horario_abertura_$numHoje")   ?: $horAbert);
$fechaHoje   = trim(getConfig("horario_fechamento_$numHoje") ?: $horFech);
$motivoHoje  = trim(getConfig("motivo_fechamento_$numHoje")  ?? '');
$diaOk       = in_array($numHoje, $diasAtivos);
$horarioOk   = date('H:i') >= $abreHoje && date('H:i') <= $fechaHoje;
$filaAberta  = $filaAtiva === '1' && $diaOk && $horarioOk;

// Loja
$lojaBotaoIndex = getConfig('loja_botao_index')         ?? '1';
$lojaAtiva      = getConfig('loja_ativa')               ?? '1';
$entregaAtiva   = getConfig('loja_entrega_ativa')       ?? '1';
$retiradaAtiva  = getConfig('loja_retirada_ativa')      ?? '1';
$taxaEntrega    = getConfig('loja_taxa_entrega')         ?? '5';
$minhaConta     = getConfig('minha_conta_botao_index')  ?? '1';
$agendaAtivo    = getConfig('agenda_ativo')             ?? '0'; // ativa/desativa agendamentos
$agendaBotao    = getConfig('agenda_botao_index')      ?? '1'; // mostra/oculta botão na index
$servIndexAtivo = getConfig('servicos_index_ativo')    ?? '1'; // mostra/oculta serviços na fila

// Stats
$totalClientes  = $db->query("SELECT COUNT(*) as c FROM clientes")->fetch()['c'];
$totalAtend     = $db->query("SELECT COUNT(*) as c FROM fila WHERE status='concluido'")->fetch()['c'];
$totalBarbeiros = $db->query("SELECT COUNT(*) as c FROM usuarios WHERE tipo='barbeiro' AND ativo=1")->fetch()['c'];

$logoReal = $logoPath   ? __DIR__ . '/../' . $logoPath   : '';
$capaReal = $capaBgPath ? __DIR__ . '/../' . $capaBgPath : '';

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}

$diasNomesConfig = [
    '0' => ['Dom', 'Domingo'],
    '1' => ['Seg', 'Segunda-feira'],
    '2' => ['Ter', 'Terça-feira'],
    '3' => ['Qua', 'Quarta-feira'],
    '4' => ['Qui', 'Quinta-feira'],
    '5' => ['Sex', 'Sexta-feira'],
    '6' => ['Sáb', 'Sábado'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Configurações – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<style>
  :root{--primary:#e94560}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  .sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;background:linear-gradient(180deg,#1a1a2e,#16213e);border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:.25s;display:flex;align-items:center;gap:.75rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:260px;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center}
  .page-body{padding:1.5rem}

  .section-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.4rem;margin-bottom:1.25rem}
  .section-title{font-size:1rem;font-weight:700;color:#fff;margin-bottom:1.25rem;display:flex;align-items:center;gap:.6rem}
  .form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px;padding:.55rem .85rem}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.12);border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.35)}
  .form-select option{background:#1a1a2e;color:#fff}
  label.form-label{color:rgba(255,255,255,.8);font-size:.88rem;margin-bottom:.35rem}
  .form-text{color:rgba(255,255,255,.35)!important;font-size:.76rem}
  .btn-save{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;padding:.55rem 1.5rem;font-weight:600;font-size:.9rem;transition:.2s}
  .btn-save:hover{opacity:.9;color:#fff}
  .btn-test{background:linear-gradient(135deg,#25d366,#128c7e);border:none;color:#fff;border-radius:10px;padding:.55rem 1.5rem;font-weight:600;font-size:.9rem;transition:.2s}
  .btn-test:hover{opacity:.9}
  .btn-danger-soft{background:rgba(220,53,69,.15);border:1px solid rgba(220,53,69,.3);color:#f87171;border-radius:8px;padding:.4rem 1rem;font-size:.82rem;transition:.2s}
  .btn-outline-light-soft{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:8px;padding:.45rem 1rem;font-size:.84rem;transition:.2s}
  .btn-outline-light-soft:hover{background:rgba(255,255,255,.14);color:#fff}

  .provider-tab{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:.5rem .6rem;cursor:pointer;transition:.2s;color:rgba(255,255,255,.6);font-size:.82rem;text-align:center}
  .provider-tab.active,.provider-tab:hover{background:rgba(233,69,96,.15);border-color:var(--primary);color:#fff}
  .provider-tab input{display:none}

  .upload-logo-wrap{width:90px;height:90px;border-radius:50%;border:2px dashed rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:pointer;transition:border-color .2s;background:rgba(255,255,255,.05);flex-shrink:0}
  .upload-logo-wrap:hover{border-color:var(--primary)}
  .upload-logo-wrap img{width:100%;height:100%;object-fit:cover}
  .upload-logo-wrap .ph{color:rgba(255,255,255,.25);font-size:1.8rem}
  .upload-capa-wrap{width:100%;height:140px;border-radius:12px;border:2px dashed rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:pointer;transition:border-color .2s;background:rgba(255,255,255,.05);position:relative}
  .upload-capa-wrap:hover{border-color:var(--primary)}
  .upload-capa-wrap img{width:100%;height:100%;object-fit:cover}
  .upload-capa-wrap .ph{color:rgba(255,255,255,.2);text-align:center}
  .upload-capa-wrap .overlay-hint{position:absolute;bottom:0;left:0;right:0;background:rgba(0,0,0,.55);padding:6px;text-align:center;font-size:.74rem;color:rgba(255,255,255,.6)}

  .hero-preview{border-radius:12px;overflow:hidden;min-height:130px;position:relative;display:flex;align-items:center;justify-content:center;text-align:center;background:#111;border:1px solid rgba(255,255,255,.1)}
  .hero-preview .prev-bg{position:absolute;inset:0;background-size:cover;background-position:center;filter:brightness(.35)}
  .hero-preview .prev-overlay{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(0,0,0,.1),rgba(0,0,0,.55))}
  .hero-preview .prev-content{position:relative;z-index:2;padding:16px}
  .hero-preview .prev-logo{width:54px;height:54px;border-radius:50%;object-fit:cover;border:2px solid var(--primary);margin:0 auto 8px;display:block}
  .hero-preview .prev-logo-ph{width:54px;height:54px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#c41230);display:flex;align-items:center;justify-content:center;margin:0 auto 8px;font-size:1.3rem}
  .hero-preview .prev-name{font-size:.95rem;font-weight:800;color:#fff}
  .hero-preview .prev-sub{font-size:.72rem;color:rgba(255,255,255,.55)}

  .info-row{display:flex;justify-content:space-between;align-items:center;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.06)}
  .info-row:last-child{border-bottom:none}
  .info-key{color:rgba(255,255,255,.5);font-size:.85rem}
  .info-val{color:#fff;font-weight:600;font-size:.85rem}
  .stat-inf{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:.85rem;text-align:center}
  .stat-inf-val{font-size:1.5rem;font-weight:800;color:#fff}
  .stat-inf-lbl{font-size:.75rem;color:rgba(255,255,255,.4);margin-top:.2rem}

  .alert-success{background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.3);color:#4ade80}
  .alert-danger{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#f87171}
  h4,h5,h6{color:#fff;margin:0}

  .toggle-wrap{display:flex;align-items:center;gap:.75rem;cursor:pointer}
  .toggle-track{width:52px;height:28px;border-radius:20px;position:relative;transition:.3s;flex-shrink:0;cursor:pointer}
  .toggle-knob{width:22px;height:22px;background:#fff;border-radius:50%;position:absolute;top:3px;transition:.3s}

  .dia-config-row{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;margin-bottom:.5rem;overflow:hidden;transition:.2s}
  .dia-config-row:hover{border-color:rgba(255,255,255,.14)}
  .dia-config-row.open{border-color:rgba(233,69,96,.3)}
  .dia-config-header{display:flex;align-items:center;gap:.75rem;padding:.75rem 1rem;cursor:pointer;transition:.2s}
  .dia-config-header:hover{background:rgba(255,255,255,.03)}
  .dia-config-body{padding:.75rem 1rem 1rem;border-top:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.02)}
  .dia-toggle-wrap{flex-shrink:0}
  .dia-toggle-track{width:38px;height:22px;border-radius:11px;position:relative;cursor:pointer;transition:.3s;flex-shrink:0}
  .dia-toggle-knob{width:18px;height:18px;background:#fff;border-radius:50%;position:absolute;top:2px;transition:.3s}
  .dia-chevron{color:rgba(255,255,255,.3);transition:transform .3s;font-size:.9rem;flex-shrink:0}
  .dia-config-row.open .dia-chevron{transform:rotate(180deg)}
  .dia-hoje-badge{background:rgba(233,69,96,.2);color:#e94560;border-radius:20px;padding:.1rem .5rem;font-size:.67rem;font-weight:700;margin-left:.4rem}

  .loja-toggle-row{display:flex;justify-content:space-between;align-items:center;padding:.75rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:12px;margin-bottom:.75rem}
  .loja-toggle-row:last-of-type{margin-bottom:0}
  .loja-toggle-info .loja-toggle-title{color:#fff;font-weight:700;font-size:.9rem}
  .loja-toggle-info .loja-toggle-sub{font-size:.75rem;color:rgba(255,255,255,.4);margin-top:.15rem}

  .zapi-status{display:inline-flex;align-items:center;gap:.4rem;font-size:.75rem;font-weight:600;padding:.25rem .65rem;border-radius:20px}
  .zapi-status.ok{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.25)}
  .zapi-status.missing{background:rgba(239,68,68,.12);color:#f87171;border:1px solid rgba(239,68,68,.2)}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <h5 class="fw-bold" style="font-size:1rem">
        <i class="bi bi-gear-fill me-2" style="color:#e94560"></i>Configurações do Sistema
      </h5>
    </div>
    <a href="../index.php" target="_blank"
       style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
              color:#fff;border-radius:8px;padding:.4rem .9rem;font-size:.82rem;text-decoration:none">
      <i class="bi bi-eye me-1"></i>Ver Site
    </a>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <div class="row g-3">

      <!-- ══ COLUNA ESQUERDA ══ -->
      <div class="col-12 col-lg-6">

        <!-- Configurações Gerais -->
        <div class="section-card">
          <div class="section-title">
            <i class="bi bi-shop" style="color:#3b82f6"></i>Configurações Gerais
          </div>
          <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="acao" value="salvar_geral">
            <div class="mb-3">
              <label class="form-label">Nome da Barbearia</label>
              <input type="text" name="nome_barbearia" class="form-control"
                value="<?= htmlspecialchars($nomeBarbearia) ?>" required>
            </div>
            <div class="row g-2 mb-3">
              <div class="col-6">
                <label class="form-label">Tempo médio por corte (min)</label>
                <input type="number" name="tempo_medio_corte" class="form-control"
                  min="5" max="120" value="<?= htmlspecialchars($tempoMedio) ?>">
              </div>
              <div class="col-6">
                <label class="form-label">Limite máximo por fila</label>
                <input type="number" name="limite_fila" class="form-control"
                  min="1" max="100" value="<?= htmlspecialchars($limiteFila) ?>">
              </div>
            </div>
            <div class="mb-4">
              <label class="form-label">Notificar cliente quando restarem X pessoas</label>
              <input type="number" name="notificacao_posicoes" class="form-control"
                min="1" max="10" value="<?= htmlspecialchars($notifPos) ?>">
              <div class="form-text">O cliente recebe aviso quando chegar nesta posição</div>
            </div>

            <hr style="border-color:rgba(255,255,255,.08);margin:0 0 1.2rem">
            <div class="section-title" style="margin-bottom:1rem">
              <i class="bi bi-palette" style="color:#a78bfa"></i>Aparência da Página
            </div>

            <!-- Logo -->
            <div class="mb-4">
              <label class="form-label d-block">Logo / Foto da Barbearia</label>
              <div class="d-flex align-items-center gap-3">
                <div class="upload-logo-wrap" id="logoWrap"
                     onclick="document.getElementById('logo_file').click()">
                  <?php if ($logoPath && file_exists($logoReal)): ?>
                    <img src="../<?= htmlspecialchars($logoPath) ?>?t=<?= time() ?>"
                         id="logoPreviewImg" alt="Logo">
                  <?php else: ?>
                    <i class="bi bi-camera-fill ph" id="logoPlaceholder"></i>
                  <?php endif; ?>
                </div>
                <div>
                  <input type="file" name="logo_file" id="logo_file" accept="image/*" class="d-none"
                         onchange="previewImg(this,'logoWrap','logoPlaceholder','logoPreviewImg')">
                  <div class="d-flex gap-2 flex-wrap">
                    <button type="button" class="btn-outline-light-soft btn"
                            onclick="document.getElementById('logo_file').click()">
                      <i class="bi bi-upload me-1"></i>
                      <?= ($logoPath && file_exists($logoReal)) ? 'Trocar' : 'Enviar Logo' ?>
                    </button>
                    <?php if ($logoPath && file_exists($logoReal)): ?>
        
              <button type="submit" name="remover_logo" value="1"
                              class="btn-danger-soft btn"
                              onclick="return confirm('Remover logo?')">
                        <i class="bi bi-trash"></i>
                      </button>
                    <?php endif; ?>
                  </div>
                  <div class="form-text mt-1">300×300px recomendado · Máx 2MB</div>
                </div>
              </div>
            </div>

            <!-- Capa -->
            <div class="mb-4">
              <label class="form-label d-block">Foto de Fundo do Banner</label>
              <div class="upload-capa-wrap" id="capaWrap"
                   onclick="document.getElementById('capa_file').click()">
                <?php if ($capaBgPath && file_exists($capaReal)): ?>
                  <img src="../<?= htmlspecialchars($capaBgPath) ?>?t=<?= time() ?>"
                       id="capaPreviewImg" alt="Capa">
                <?php else: ?>
                  <div class="ph" id="capaPlaceholder">
                    <i class="bi bi-image d-block mb-1" style="font-size:2rem"></i>
                    <span style="font-size:.78rem">Clique para enviar foto de fundo</span>
                  </div>
                <?php endif; ?>
                <div class="overlay-hint"><i class="bi bi-upload me-1"></i>Clique para selecionar</div>
              </div>
              <input type="file" name="capa_file" id="capa_file" accept="image/*" class="d-none"
                     onchange="previewImg(this,'capaWrap','capaPlaceholder','capaPreviewImg')">
              <div class="d-flex gap-2 mt-2 flex-wrap">
                <button type="button" class="btn-outline-light-soft btn"
                        onclick="document.getElementById('capa_file').click()">
                  <i class="bi bi-upload me-1"></i>
                  <?= ($capaBgPath && file_exists($capaReal)) ? 'Trocar Fundo' : 'Enviar Fundo' ?>
                </button>
                <?php if ($capaBgPath && file_exists($capaReal)): ?>
                  <button type="submit" name="remover_capa" value="1"
                          class="btn-danger-soft btn"
                          onclick="return confirm('Remover foto de fundo?')">
                    <i class="bi bi-trash me-1"></i>Remover
                  </button>
                <?php endif; ?>
              </div>
              <div class="form-text mt-1">1920×600px recomendado · Máx 5MB</div>
            </div>

            <!-- Preview -->
            <div class="mb-4">
              <label class="form-label d-block">Prévia do Banner</label>
              <div class="hero-preview" id="heroPreview">
                <?php if ($capaBgPath && file_exists($capaReal)): ?>
                  <div class="prev-bg" id="prevBg"
                       style="background-image:url('../<?= htmlspecialchars($capaBgPath) ?>?t=<?= time() ?>')"></div>
                <?php else: ?>
                  <div class="prev-bg" id="prevBg"
                       style="background:linear-gradient(135deg,#1a1a2e,#16213e,#0f3460)"></div>
                <?php endif; ?>
                <div class="prev-overlay"></div>
                <div class="prev-content">
                  <?php if ($logoPath && file_exists($logoReal)): ?>
                    <img src="../<?= htmlspecialchars($logoPath) ?>?t=<?= time() ?>"
                         class="prev-logo" id="prevLogo" alt="">
                  <?php else: ?>
                    <div class="prev-logo-ph" id="prevLogo">
                      <i class="bi bi-scissors text-white"></i>
                    </div>
                  <?php endif; ?>
                  <div class="prev-name"><?= htmlspecialchars($nomeBarbearia) ?></div>
                  <div class="prev-sub">Entre na fila online e economize seu tempo!</div>
                </div>
              </div>
            </div>

            <button type="submit" class="btn-save w-100">
              <i class="bi bi-check2 me-1"></i>Salvar Configurações Gerais
            </button>
          </form>
        </div>

        <!-- Segurança -->
        <div class="section-card">
          <div class="section-title">
            <i class="bi bi-shield-lock" style="color:#e94560"></i>Alterar Senha do Admin
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_senha">
            <div class="mb-3">
              <label class="form-label">Senha Atual</label>
              <div class="input-group">
                <input type="password" name="senha_atual" class="form-control"
                  placeholder="••••••••" required id="sa">
                <button type="button" class="btn" onclick="togglePass('sa',this)"
                  style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#aaa">
                  <i class="bi bi-eye"></i>
                </button>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label">Nova Senha</label>
              <div class="input-group">
                <input type="password" name="nova_senha" class="form-control"
                  placeholder="Mínimo 6 caracteres" required minlength="6" id="ns">
                <button type="button" class="btn" onclick="togglePass('ns',this)"
                  style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#aaa">
                  <i class="bi bi-eye"></i>
                </button>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label">Confirmar Nova Senha</label>
              <div class="input-group">
                <input type="password" name="confirma" class="form-control"
                  placeholder="Repita a nova senha" required id="cs">
                <button type="button" class="btn" onclick="togglePass('cs',this)"
                  style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#aaa">
                  <i class="bi bi-eye"></i>
                </button>
              </div>
            </div>
            <button type="submit" class="btn-save w-100"
              style="background:linear-gradient(135deg,#7c3aed,#5b21b6)">
              <i class="bi bi-lock me-1"></i>Alterar Senha
            </button>
          </form>
        </div>

      </div><!-- /col esquerda -->

      <!-- ══ COLUNA DIREITA ══ -->
      <div class="col-12 col-lg-6">

        <!-- ══ HORÁRIO & CONTROLE ══ -->
        <div class="section-card">
          <div class="section-title">
            <i class="bi bi-clock-history" style="color:#f59e0b"></i>Horário & Controle da Fila
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_horarios">

            <div class="mb-4 p-3"
                 style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:12px">
              <div style="color:#fff;font-weight:700;font-size:.95rem;margin-bottom:.35rem">
                <i class="bi bi-toggle-on me-2" style="color:#f59e0b"></i>Modo da Fila
              </div>
              <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.85rem">
                <strong style="color:#fbbf24">Auto</strong> = respeita dias e horários configurados &nbsp;·&nbsp;
                <strong style="color:#4ade80">Aberta</strong> = força aberta sempre &nbsp;·&nbsp;
                <strong style="color:#f87171">Fechada</strong> = força fechada sempre
              </div>
              <input type="hidden" name="fila_ativa" value="1">
              <input type="hidden" name="fila_modo" id="filaModoHidden" value="<?= htmlspecialchars($filaModo) ?>">
              <div style="display:flex;gap:.5rem;flex-wrap:wrap">
                <?php
                $modos = [
                  ['auto',    '⚙️ Auto (horário)', 'rgba(245,158,11,.15)', 'rgba(245,158,11,.5)', '#fbbf24'],
                  ['aberta',  '✅ Forçar Aberta',  'rgba(34,197,94,.15)',  'rgba(34,197,94,.5)',  '#4ade80'],
                  ['fechada', '🔒 Forçar Fechada', 'rgba(239,68,68,.1)',   'rgba(239,68,68,.5)',  '#f87171'],
                ];
                foreach ($modos as [$val,$lbl,$bg,$border,$cor]):
                  $sel = $filaModo === $val;
                ?>
                <button type="button"
                  onclick="setFilaModo('<?= $val ?>')"
                  id="btnModo_<?= $val ?>"
                  style="flex:1;min-width:120px;padding:.65rem .5rem;border-radius:12px;font-weight:700;font-size:.85rem;cursor:pointer;transition:.2s;
                         background:<?= $sel?$bg:'rgba(255,255,255,.04)' ?>;
                         border:2px solid <?= $sel?$border:'rgba(255,255,255,.1)' ?>;
                         color:<?= $sel?$cor:'rgba(255,255,255,.45)' ?>">
                  <?= $lbl ?>
                </button>
                <?php endforeach; ?>
              </div>
            </div>


            <!-- Status atual da fila -->
            <div class="mb-3 p-3"
                 style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:12px">
              <div style="font-size:.72rem;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.5px;margin-bottom:.6rem">
                <i class="bi bi-activity me-1"></i>Status atual da fila
              </div>
              <?php
                $statusFila = $filaModo === 'aberta'  ? ['cor'=>'#4ade80','bg'=>'rgba(34,197,94,.12)','border'=>'rgba(34,197,94,.3)',  'icon'=>'unlock-fill','txt'=>'Forçada ABERTA — abre para todos independente do horário']
                           : ($filaModo === 'fechada' ? ['cor'=>'#f87171','bg'=>'rgba(239,68,68,.1)', 'border'=>'rgba(239,68,68,.25)', 'icon'=>'lock-fill',  'txt'=>'Forçada FECHADA — bloqueada independente do horário']
                           :  ($filaAberta           ? ['cor'=>'#4ade80','bg'=>'rgba(34,197,94,.1)', 'border'=>'rgba(34,197,94,.2)',  'icon'=>'clock-fill', 'txt'=>'Aberta agora (dentro do horário configurado)']
                           :                          ['cor'=>'#fbbf24','bg'=>'rgba(245,158,11,.1)','border'=>'rgba(245,158,11,.2)', 'icon'=>'clock',      'txt'=>'Fechada agora (fora do horário configurado)']));
              ?>
              <div style="display:flex;align-items:center;gap:.65rem;
                          background:<?= $statusFila['bg'] ?>;border:1px solid <?= $statusFila['border'] ?>;
                          border-radius:10px;padding:.55rem .8rem">
                <span style="width:9px;height:9px;border-radius:50%;background:<?= $statusFila['cor'] ?>;flex-shrink:0;
                  <?= in_array($filaModo,['aberta']) || ($filaModo==='auto'&&$filaAberta) ? 'box-shadow:0 0 6px '.$statusFila['cor'].';animation:pulse-dot 1.5s infinite' : '' ?>"></span>
                <i class="bi bi-<?= $statusFila['icon'] ?>" style="color:<?= $statusFila['cor'] ?>;font-size:.9rem"></i>
                <span style="color:<?= $statusFila['cor'] ?>;font-weight:700;font-size:.83rem"><?= $statusFila['txt'] ?></span>
              </div>
            </div>

            <!-- Fuso horário -->
            <div class="mb-4 p-3"
                 style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:12px">
              <div style="font-size:.72rem;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.5px;margin-bottom:.6rem">
                <i class="bi bi-clock-history me-1"></i>Fuso Horário
                <span style="font-size:.68rem;color:rgba(255,255,255,.25);text-transform:none;letter-spacing:0">
                  — referência para abrir/fechar a fila e relatórios
                </span>
              </div>
              <select name="fuso_horario" class="form-control"
                style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:10px;padding:.5rem .75rem">
                <?php
                $fusos = [
                  'America/Sao_Paulo'   => '🏙️ São Paulo / Brasília (UTC-3)',
                  'America/Fortaleza'   => '🌊 Fortaleza / Recife (UTC-3)',
                  'America/Belem'       => '🌿 Belém / Manaus (UTC-3)',
                  'America/Manaus'      => '🌳 Manaus (UTC-4)',
                  'America/Porto_Velho' => '🏕️ Porto Velho / Cuiabá (UTC-4)',
                  'America/Cuiaba'      => '🌾 Cuiabá (UTC-4)',
                  'America/Rio_Branco'  => '🦋 Rio Branco / Acre (UTC-5)',
                  'America/Noronha'     => '🏝️ Fernando de Noronha (UTC-2)',
                ];
                foreach ($fusos as $tz => $label):
                ?>
                <option value="<?= $tz ?>" <?= ($fusoHorario??'America/Sao_Paulo')===$tz?'selected':'' ?>
                  style="background:#1a1a2e"><?= $label ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="mb-4 p-3"
                 style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:12px">
              <div style="font-size:.72rem;color:rgba(255,255,255,.4);margin-bottom:.6rem;
                          text-transform:uppercase;letter-spacing:.5px">
                <i class="bi bi-clock me-1"></i>Horário Padrão
                <span style="font-size:.68rem;color:rgba(255,255,255,.25);text-transform:none;letter-spacing:0">
                  — usado quando o dia não tem horário específico
                </span>
              </div>
              <div class="row g-2">
                <div class="col-6">
                  <label class="form-label" style="font-size:.8rem">
                    <i class="bi bi-sunrise me-1"></i>Abertura
                  </label>
                  <input type="time" name="horario_abertura" class="form-control"
                    value="<?= htmlspecialchars($horAbert) ?>">
                </div>
                <div class="col-6">
                  <label class="form-label" style="font-size:.8rem">
                    <i class="bi bi-sunset me-1"></i>Fechamento
                  </label>
                  <input type="time" name="horario_fechamento" class="form-control"
                    value="<?= htmlspecialchars($horFech) ?>">
                </div>
              </div>
            </div>

            <div style="font-size:.72rem;color:rgba(255,255,255,.4);margin-bottom:.75rem;
                        text-transform:uppercase;letter-spacing:.5px;display:flex;align-items:center;gap:.5rem">
              <i class="bi bi-calendar-week"></i>Configuração por Dia da Semana
            </div>

            <?php foreach ($diasNomesConfig as $num => [$abrev, $nomeCompleto]):
              $ativoNoDia = in_array($num, $diasAtivos);
              $abreDia    = getConfig("horario_abertura_$num")   ?: $horAbert;
              $fechaDia   = getConfig("horario_fechamento_$num") ?: $horFech;
              $motivoDia  = getConfig("motivo_fechamento_$num")  ?: '';
              $hojeDia    = ((int)date('w') === (int)$num);
            ?>
            <div class="dia-config-row <?= $hojeDia ? 'open' : '' ?>" id="diaRow<?= $num ?>">
              <div class="dia-config-header" onclick="toggleDiaConfig(<?= $num ?>)">
                <div class="dia-toggle-wrap" onclick="event.stopPropagation()">
                  <input type="hidden" name="dia_ativo_<?= $num ?>"
                         id="diaAtivoHidden<?= $num ?>" value="<?= $ativoNoDia ? '1' : '0' ?>">
                  <div class="dia-toggle-track" id="diaTTrack<?= $num ?>"
                       onclick="toggleDiaAtivo(<?= $num ?>)"
                       style="background:<?= $ativoNoDia
                         ? 'linear-gradient(135deg,#22c55e,#16a34a)'
                         : 'rgba(255,255,255,.12)' ?>">
                    <div class="dia-toggle-knob" id="diaTKnob<?= $num ?>"
                         style="left:<?= $ativoNoDia ? '18px' : '2px' ?>"></div>
                  </div>
                </div>
                <div class="flex-grow-1 d-flex align-items-center flex-wrap gap-1">
                  <span style="font-weight:700;color:#fff;font-size:.9rem"><?= $nomeCompleto ?></span>
                  <?php if ($hojeDia): ?>
                    <span class="dia-hoje-badge">Hoje</span>
                  <?php endif; ?>
                  <span id="diaStatusLabel<?= $num ?>"
                        style="margin-left:auto;font-size:.77rem;font-weight:600;
                               color:<?= $ativoNoDia ? '#4ade80' : 'rgba(255,255,255,.3)' ?>">
                    <?= $ativoNoDia
                      ? htmlspecialchars($abreDia).' – '.htmlspecialchars($fechaDia)
                      : ($motivoDia ? htmlspecialchars($motivoDia) : 'Fechado') ?>
                  </span>
                </div>
                <i class="bi bi-chevron-down dia-chevron" id="diaChevron<?= $num ?>"></i>
              </div>
              <div class="dia-config-body" id="diaBody<?= $num ?>"
                   style="<?= $hojeDia ? '' : 'display:none' ?>">
                <div class="row g-2">
                  <div class="col-6">
                    <label style="font-size:.75rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">
                      <i class="bi bi-sunrise me-1"></i>Abertura
                    </label>
                    <input type="time" name="horario_abertura_<?= $num ?>" class="form-control form-control-sm"
                      value="<?= htmlspecialchars($abreDia) ?>"
                      onchange="atualizarDiaLabel(<?= $num ?>)">
                  </div>
                  <div class="col-6">
                    <label style="font-size:.75rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">
                      <i class="bi bi-sunset me-1"></i>Fechamento
                    </label>
                    <input type="time" name="horario_fechamento_<?= $num ?>" class="form-control form-control-sm"
                      value="<?= htmlspecialchars($fechaDia) ?>"
                      onchange="atualizarDiaLabel(<?= $num ?>)">
                  </div>
                  <div class="col-12">
                    <label style="font-size:.75rem;color:rgba(255,255,255,.5);display:block;margin-bottom:.25rem">
                      <i class="bi bi-chat-left-text me-1"></i>Motivo de fechamento
                      <span style="color:rgba(255,255,255,.25);font-size:.68rem">(opcional)</span>
                    </label>
                    <input type="text" name="motivo_fechamento_<?= $num ?>" class="form-control form-control-sm"
                      placeholder="Ex: Feriado, Folga, Manutenção..."
                      value="<?= htmlspecialchars($motivoDia) ?>"
                      maxlength="80"
                      onchange="atualizarDiaLabel(<?= $num ?>)"
                      oninput="atualizarDiaLabel(<?= $num ?>)">
                    <div class="form-text mt-1">
                      Aparece para o cliente na tela de fila fechada
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; ?>

            <div class="my-4 p-3 text-center"
                 style="background:rgba(255,255,255,.03);border-radius:10px;border:1px solid rgba(255,255,255,.06)">
              <div style="font-size:.72rem;color:rgba(255,255,255,.4);margin-bottom:.5rem;
                          text-transform:uppercase;letter-spacing:.5px">Status Agora</div>
              <?php
                if ($filaModo === 'aberta') {
                    $stCor  = '#4ade80'; $stIcon = 'unlock-fill'; $stTxt = 'Fila Aberta';
                    $stSub  = 'Modo: Forçada aberta';   $stSubCor = '#4ade80';
                } elseif ($filaModo === 'fechada') {
                    $stCor  = '#f87171'; $stIcon = 'lock-fill';   $stTxt = 'Fila Fechada';
                    $stSub  = 'Modo: Forçada fechada';  $stSubCor = '#f87171';
                } elseif ($filaAberta) {
                    $stCor  = '#4ade80'; $stIcon = 'clock-fill';  $stTxt = 'Fila Aberta';
                    $stSub  = 'Dentro do horário configurado';     $stSubCor = '#4ade80';
                } else {
                    $stCor  = '#f87171'; $stIcon = 'lock';        $stTxt = 'Fila Fechada';
                    $stSub  = !$diaOk ? 'Dia não configurado' : 'Fora do horário';
                    $stSubCor = '#f87171';
                }
                $diasSemNomes = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
              ?>
              <div style="display:inline-flex;align-items:center;gap:.5rem;
                          background:<?= $filaModo==='aberta'||$filaAberta ? 'rgba(34,197,94,.1)' : 'rgba(239,68,68,.08)' ?>;
                          border:1px solid <?= $filaModo==='aberta'||$filaAberta ? 'rgba(34,197,94,.25)' : 'rgba(239,68,68,.2)' ?>;
                          border-radius:50px;padding:.4rem 1rem;margin-bottom:.4rem">
                <span style="width:8px;height:8px;border-radius:50%;background:<?= $stCor ?>;flex-shrink:0;
                  <?= $filaModo==='aberta'||($filaModo==='auto'&&$filaAberta) ? 'animation:pulse-dot 1.5s infinite' : '' ?>"></span>
                <i class="bi bi-<?= $stIcon ?>" style="color:<?= $stCor ?>"></i>
                <span style="font-weight:800;font-size:1rem;color:<?= $stCor ?>"><?= $stTxt ?></span>
              </div>
              <div style="font-size:.75rem;color:rgba(255,255,255,.35)">
                <?= date('H:i') ?> · <?= $diasSemNomes[$numHoje] ?> · <?= $abreHoje ?>–<?= $fechaHoje ?>
              </div>
              <div style="font-size:.75rem;color:<?= $stSubCor ?>;margin-top:.15rem;font-weight:600">
                <?= $stSub ?>
              </div>
            </div>

            <button type="submit" class="btn-save w-100"
              style="background:linear-gradient(135deg,#f59e0b,#d97706)">
              <i class="bi bi-clock me-1"></i>Salvar Horários
            </button>
          </form>
        </div>

        <!-- ══ LOJA ONLINE ══ -->
        <div class="section-card">
          <div class="section-title">
            <i class="bi bi-shop-window" style="color:#e94560"></i>Loja Online & Acesso do Cliente
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_loja">

            <div class="loja-toggle-row">
              <div class="loja-toggle-info">
                <div class="loja-toggle-title"><i class="bi bi-shop-window me-2" style="color:#e94560"></i>Botão Vitrine na Página Inicial</div>
                <div class="loja-toggle-sub">Exibe ou oculta o botão "Vitrine de Produtos à Venda"</div>
              </div>
              <div class="toggle-wrap">
                <input type="hidden" name="loja_botao_index" id="lojaBotaoHidden" value="<?= $lojaBotaoIndex ?>">
                <div class="toggle-track" id="toggleLojaBotaoTrack"
                     style="background:<?= $lojaBotaoIndex==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                  <div class="toggle-knob" id="toggleLojaBotaoKnob" style="left:<?= $lojaBotaoIndex==='1' ? '27px' : '3px' ?>"></div>
                </div>
                <span id="toggleLojaBotaoLabel" style="font-weight:700;font-size:.88rem;color:<?= $lojaBotaoIndex==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                  <?= $lojaBotaoIndex==='1' ? 'Visível' : 'Oculto' ?>
                </span>
              </div>
            </div>

            <div class="loja-toggle-row">
              <div class="loja-toggle-info">
                <div class="loja-toggle-title"><i class="bi bi-person-circle me-2" style="color:#a78bfa"></i>Botão "Minha Conta"</div>
                <div class="loja-toggle-sub">Exibe ou oculta o acesso ao histórico do cliente</div>
              </div>
              <div class="toggle-wrap">
                <input type="hidden" name="minha_conta_botao_index" id="minhaContaHidden" value="<?= $minhaConta ?>">
                <div class="toggle-track" id="toggleMinhaContaTrack"
                     style="background:<?= $minhaConta==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                  <div class="toggle-knob" id="toggleMinhaContaKnob" style="left:<?= $minhaConta==='1' ? '27px' : '3px' ?>"></div>
                </div>
                <span id="toggleMinhaContaLabel" style="font-weight:700;font-size:.88rem;color:<?= $minhaConta==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                  <?= $minhaConta==='1' ? 'Visível' : 'Oculto' ?>
                </span>
              </div>
            </div>

            <div class="loja-toggle-row">
              <div class="loja-toggle-info">
                <div class="loja-toggle-title"><i class="bi bi-calendar-check me-2" style="color:#e94560"></i>Botão "Agendar Horário" na Index</div>
                <div class="loja-toggle-sub">Mostra ou oculta o botão na página inicial (não afeta o agendamento)</div>
              </div>
              <div class="toggle-wrap">
                <input type="hidden" name="agenda_botao_index" id="agendaBotaoHidden" value="<?= $agendaBotao ?>">
                <div class="toggle-track" id="toggleAgendaBotaoTrack"
                     style="background:<?= $agendaBotao==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                  <div class="toggle-knob" id="toggleAgendaBotaoKnob" style="left:<?= $agendaBotao==='1' ? '27px' : '3px' ?>"></div>
                </div>
                <span id="toggleAgendaBotaoLabel" style="font-weight:700;font-size:.88rem;color:<?= $agendaBotao==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                  <?= $agendaBotao==='1' ? 'Visível' : 'Oculto' ?>
                </span>
              </div>
            </div>

            <div class="loja-toggle-row">
              <div class="loja-toggle-info">
                <div class="loja-toggle-title"><i class="bi bi-scissors me-2" style="color:#a78bfa"></i>Serviços & Pacotes na Fila</div>
                <div class="loja-toggle-sub">Exibe cards de serviço/pacote (opcional) ao entrar na fila</div>
              </div>
              <div class="toggle-wrap">
                <input type="hidden" name="servicos_index_ativo" id="servIndexHidden" value="<?= $servIndexAtivo ?>">
                <div class="toggle-track" id="toggleServIndexTrack"
                     style="background:<?= $servIndexAtivo==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                  <div class="toggle-knob" id="toggleServIndexKnob" style="left:<?= $servIndexAtivo==='1' ? '27px' : '3px' ?>"></div>
                </div>
                <span id="toggleServIndexLabel" style="font-weight:700;font-size:.88rem;color:<?= $servIndexAtivo==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                  <?= $servIndexAtivo==='1' ? 'Visível' : 'Oculto' ?>
                </span>
              </div>
            </div>

            <div class="loja-toggle-row">
              <div class="loja-toggle-info">
                <div class="loja-toggle-title"><i class="bi bi-lock me-2" style="color:#f59e0b"></i>Status da Loja</div>
                <div class="loja-toggle-sub">Permite ou bloqueia o acesso à loja online</div>
              </div>
              <div class="toggle-wrap">
                <input type="hidden" name="loja_ativa" id="lojaAtivaHidden" value="<?= $lojaAtiva ?>">
                <div class="toggle-track" id="toggleLojaAtivaTrack"
                     style="background:<?= $lojaAtiva==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                  <div class="toggle-knob" id="toggleLojaAtivaKnob" style="left:<?= $lojaAtiva==='1' ? '27px' : '3px' ?>"></div>
                </div>
                <span id="toggleLojaAtivaLabel" style="font-weight:700;font-size:.88rem;color:<?= $lojaAtiva==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                  <?= $lojaAtiva==='1' ? 'Aberta' : 'Fechada' ?>
                </span>
              </div>
            </div>

            <div class="loja-toggle-row">
              <div class="loja-toggle-info">
                <div class="loja-toggle-title"><i class="bi bi-shop me-2" style="color:#4ade80"></i>Retirada na Barbearia</div>
                <div class="loja-toggle-sub">Sem taxa adicional</div>
              </div>
              <div class="toggle-wrap">
                <input type="hidden" name="loja_retirada_ativa" id="retiradaHidden" value="<?= $retiradaAtiva ?>">
                <div class="toggle-track" id="toggleRetiradaTrack"
                     style="background:<?= $retiradaAtiva==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                  <div class="toggle-knob" id="toggleRetiradaKnob" style="left:<?= $retiradaAtiva==='1' ? '27px' : '3px' ?>"></div>
                </div>
                <span id="toggleRetiradaLabel" style="font-weight:700;font-size:.88rem;color:<?= $retiradaAtiva==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                  <?= $retiradaAtiva==='1' ? 'Ativa' : 'Inativa' ?>
                </span>
              </div>
            </div>

            <div class="loja-toggle-row">
              <div class="loja-toggle-info">
                <div class="loja-toggle-title"><i class="bi bi-bicycle me-2" style="color:#60a5fa"></i>Entrega em Domicílio</div>
                <div class="loja-toggle-sub">Com taxa de entrega</div>
              </div>
              <div class="toggle-wrap">
                <input type="hidden" name="loja_entrega_ativa" id="entregaHidden" value="<?= $entregaAtiva ?>">
                <div class="toggle-track" id="toggleEntregaTrack"
                     style="background:<?= $entregaAtiva==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                  <div class="toggle-knob" id="toggleEntregaKnob" style="left:<?= $entregaAtiva==='1' ? '27px' : '3px' ?>"></div>
                </div>
                <span id="toggleEntregaLabel" style="font-weight:700;font-size:.88rem;color:<?= $entregaAtiva==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                  <?= $entregaAtiva==='1' ? 'Ativa' : 'Inativa' ?>
                </span>
              </div>
            </div>

            <div class="mt-3 mb-3">
              <label class="form-label"><i class="bi bi-currency-dollar me-1"></i>Taxa de Entrega (R$)</label>
              <input type="number" name="loja_taxa_entrega" class="form-control"
                     min="0" step="0.50" value="<?= htmlspecialchars($taxaEntrega) ?>"
                     style="max-width:180px">
              <div class="form-text">Valor cobrado na modalidade entrega em domicílio</div>
            </div>

            <div class="mb-3 p-3"
                 style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);
                        border-radius:12px;text-align:center">
              <div style="font-size:.7rem;color:rgba(255,255,255,.3);margin-bottom:.75rem;
                          text-transform:uppercase;letter-spacing:.5px">Preview na Página Inicial</div>
              <div id="previewBotaoLoja"
                   style="display:<?= $lojaBotaoIndex==='1' ? 'inline-block' : 'none' ?>;margin:.25rem">
                <a href="../loja.php" target="_blank"
                   style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);
                          color:#fff;border-radius:50px;padding:.5rem 1.2rem;font-size:.82rem;
                          font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:.5rem">
                  <span style="width:7px;height:7px;border-radius:50%;background:#e94560;box-shadow:0 0 6px #e94560;flex-shrink:0"></span>
                  <i class="bi bi-shop-window"></i>Vitrine de Produtos à Venda
                  <i class="bi bi-chevron-right" style="font-size:.7rem;opacity:.5"></i>
                </a>
              </div>
              <div id="previewMinhaContaVis"
                   style="display:<?= $minhaConta==='1' ? 'inline-block' : 'none' ?>;margin:.25rem">
                <a href="../cliente/minha-conta.php" target="_blank"
                   style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);
                          color:#fff;border-radius:50px;padding:.5rem 1.2rem;font-size:.82rem;
                          font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:.5rem">
                  <i class="bi bi-person-circle" style="color:rgba(255,255,255,.7)"></i>Minha Conta
                  <i class="bi bi-chevron-right" style="font-size:.7rem;opacity:.5"></i>
                </a>
              </div>
              <div id="previewAgendaVis"
                   style="display:<?= $agendaBotao==='1' ? 'inline-block' : 'none' ?>;margin:.25rem">
                <a href="../agendar.php" target="_blank"
                   style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);
                          color:#fff;border-radius:50px;padding:.5rem 1.2rem;font-size:.82rem;
                          font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:.5rem">
                  <i class="bi bi-calendar-check" style="color:#a78bfa"></i>Agendar Horário
                  <i class="bi bi-chevron-right" style="font-size:.7rem;opacity:.5"></i>
                </a>
              </div>
              <div id="previewTudoOculto"
                   style="display:<?= ($lojaBotaoIndex!=='1' && $minhaConta!=='1' && $agendaBotao!=='1') ? 'block' : 'none' ?>;
                          color:rgba(255,255,255,.2);font-size:.82rem;padding:.5rem 0">
                <i class="bi bi-eye-slash me-1"></i>Todos os botões ocultos na página inicial
              </div>
            </div>

            <button type="submit" class="btn-save w-100">
              <i class="bi bi-shop me-1"></i>Salvar Configurações da Loja
            </button>
          </form>
        </div>

        <!-- ══ WHATSAPP ══ -->
        <div class="section-card">
          <div class="section-title">
            <i class="bi bi-whatsapp" style="color:#25d366"></i>Configurações do WhatsApp
          </div>
          <form method="POST" id="formWa">
            <input type="hidden" name="acao" value="salvar_whatsapp">
            <label class="form-label">Provedor de WhatsApp</label>

            <!-- ── 4 abas em 2 linhas ── -->
            <div class="row g-2 mb-3" id="providerTabs">
              <?php foreach([
                'callmebot' => ['CallMeBot', 'Gratuito',    'bi-gift',             '#25d366'],
                'zapi'      => ['Z-API',     'Pago',        'bi-lightning-charge', '#f59e0b'],
                'uazapi'    => ['UazAPI',    'Pago',        'bi-whatsapp',         '#25d366'],
                'evolution' => ['Evolution', 'Self-hosted', 'bi-server',           '#60a5fa'],
              ] as $v => [$nome, $tipo, $ico, $cor]): ?>
              <div class="col-6 col-sm-3">
                <label class="provider-tab <?= $waProvider===$v ? 'active' : '' ?> w-100">
                  <input type="radio" name="wa_provider" value="<?= $v ?>" <?= $waProvider===$v ? 'checked' : '' ?>>
                  <i class="bi <?= $ico ?> d-block mb-1" style="font-size:1.2rem;color:<?= $cor ?>"></i>
                  <div style="font-weight:700;font-size:.82rem"><?= $nome ?></div>
                  <div style="font-size:.68rem;opacity:.55"><?= $tipo ?></div>
                </label>
              </div>
              <?php endforeach; ?>
            </div>

            <!-- ── CallMeBot ── -->
            <div id="cfg_callmebot" class="wa-cfg" style="display:<?= $waProvider==='callmebot' ? 'block' : 'none' ?>">
              <div class="mb-3 p-3"
                   style="background:rgba(37,211,102,.08);border:1px solid rgba(37,211,102,.2);border-radius:10px;font-size:.8rem;color:rgba(255,255,255,.65)">
                <i class="bi bi-info-circle me-1" style="color:#25d366"></i>
                Envie <strong style="color:#fff">I allow callmebot to send me messages</strong>
                para <strong style="color:#fff">+34 644 95 73 56</strong> no WhatsApp.
              </div>
              <label class="form-label">API Key do CallMeBot</label>
              <input type="text" name="wa_callmebot_apikey" class="form-control"
                placeholder="Ex: 1234567" value="<?= htmlspecialchars($waCallmebotKey) ?>">
            </div>

            <!-- ── Z-API ── -->
            <div id="cfg_zapi" class="wa-cfg" style="display:<?= $waProvider==='zapi' ? 'block' : 'none' ?>">
              <?php $zapiOk = $waZapiInstance && $waZapiToken && $waZapiClientToken; ?>
              <div class="mb-3">
                <span class="zapi-status <?= $zapiOk ? 'ok' : 'missing' ?>">
                  <i class="bi bi-<?= $zapiOk ? 'check-circle-fill' : 'exclamation-triangle-fill' ?>"></i>
                  <?= $zapiOk ? 'Configurado corretamente' : 'Faltam campos obrigatórios' ?>
                </span>
              </div>
              <div class="row g-2">
                <div class="col-12">
                  <label class="form-label">ID da Instância Z-API</label>
                  <input type="text" name="wa_zapi_instance" class="form-control"
                    placeholder="Ex: 3EFEA88C3F4C2051DA41EA4EB1F7AE59"
                    value="<?= htmlspecialchars($waZapiInstance) ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Token Z-API da Instância</label>
                  <input type="text" name="wa_zapi_token" class="form-control"
                    placeholder="Token da instância"
                    value="<?= htmlspecialchars($waZapiToken) ?>">
                  <div class="form-text">app.z-api.io → sua instância → Token</div>
                </div>
                <div class="col-12">
                  <label class="form-label d-flex align-items-center gap-2">
                    Client-Token Z-API
                    <span style="background:rgba(233,69,96,.2);color:#e94560;border-radius:4px;
                                 padding:.1rem .4rem;font-size:.68rem;font-weight:700">OBRIGATÓRIO</span>
                  </label>
                  <input type="text" name="wa_zapi_client_token" class="form-control"
                    placeholder="Client-Token da sua conta"
                    value="<?= htmlspecialchars($waZapiClientToken) ?>">
                  <div class="form-text">
                    <i class="bi bi-info-circle me-1"></i>
                    app.z-api.io → sua conta → <strong style="color:rgba(255,255,255,.6)">Security</strong> → Client-Token
                  </div>
                </div>
              </div>
            </div>

            <!-- ── UazAPI ── -->
            <div id="cfg_uazapi" class="wa-cfg" style="display:<?= $waProvider==='uazapi' ? 'block' : 'none' ?>">
              <?php $uazapiOk = $waUazapiUrl && $waUazapiToken && $waUazapiInstance; ?>
              <div class="mb-3 d-flex align-items-center gap-2 flex-wrap">
                <span class="zapi-status <?= $uazapiOk ? 'ok' : 'missing' ?>">
                  <i class="bi bi-<?= $uazapiOk ? 'check-circle-fill' : 'exclamation-triangle-fill' ?>"></i>
                  <?= $uazapiOk ? 'Configurado corretamente' : 'Faltam campos obrigatórios' ?>
                </span>
              </div>
              <div class="mb-3 p-3"
                   style="background:rgba(37,211,102,.07);border:1px solid rgba(37,211,102,.18);border-radius:10px;font-size:.8rem;color:rgba(255,255,255,.65)">
                <i class="bi bi-info-circle me-1" style="color:#25d366"></i>
                Acesse <a href="https://www.uazapi.com" target="_blank" style="color:#25d366">uazapi.com</a>,
                crie sua instância e copie a <strong style="color:#fff">URL do servidor</strong>,
                o <strong style="color:#fff">Token</strong> e o <strong style="color:#fff">nome da instância</strong>.
              </div>
              <div class="row g-2">
                <div class="col-12">
                  <label class="form-label">URL do Servidor UazAPI</label>
                  <input type="text" name="wa_uazapi_url" class="form-control"
                    placeholder="Ex: https://api.uazapi.com"
                    value="<?= htmlspecialchars($waUazapiUrl) ?>">
                  <div class="form-text">URL base da sua instância uazapi (sem barra no final)</div>
                </div>
                <div class="col-12">
                  <label class="form-label d-flex align-items-center gap-2">
                    Token UazAPI
                    <span style="background:rgba(233,69,96,.2);color:#e94560;border-radius:4px;
                                 padding:.1rem .4rem;font-size:.68rem;font-weight:700">OBRIGATÓRIO</span>
                  </label>
                  <input type="text" name="wa_uazapi_token" class="form-control"
                    placeholder="Token de autenticação"
                    value="<?= htmlspecialchars($waUazapiToken) ?>">
                  <div class="form-text">Encontrado no painel uazapi → sua instância → Token</div>
                </div>
                <div class="col-12">
                  <label class="form-label d-flex align-items-center gap-2">
                    Nome da Instância
                    <span style="background:rgba(233,69,96,.2);color:#e94560;border-radius:4px;
                                 padding:.1rem .4rem;font-size:.68rem;font-weight:700">OBRIGATÓRIO</span>
                  </label>
                  <input type="text" name="wa_uazapi_instance" class="form-control"
                    placeholder="Ex: barbearia"
                    value="<?= htmlspecialchars($waUazapiInstance) ?>">
                  <div class="form-text">Nome exato da instância criada no painel uazapi</div>
                </div>
              </div>
            </div>

            <!-- ── Evolution API ── -->
            <div id="cfg_evolution" class="wa-cfg" style="display:<?= $waProvider==='evolution' ? 'block' : 'none' ?>">
              <div class="row g-2">
                <div class="col-12">
                  <label class="form-label">URL da Evolution API</label>
                  <input type="text" name="wa_evolution_url" class="form-control"
                    placeholder="Ex: http://localhost:8080" value="<?= htmlspecialchars($waEvoUrl) ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">API Key</label>
                  <input type="text" name="wa_evolution_key" class="form-control"
                    placeholder="Sua API Key" value="<?= htmlspecialchars($waEvoKey) ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Nome da Instância</label>
                  <input type="text" name="wa_evolution_instance" class="form-control"
                    placeholder="Ex: barbearia" value="<?= htmlspecialchars($waEvoInstance) ?>">
                </div>
              </div>
            </div>

            <button type="submit" class="btn-save w-100 mt-3"
              style="background:linear-gradient(135deg,#25d366,#128c7e)">
              <i class="bi bi-whatsapp me-1"></i>Salvar Configurações WhatsApp
            </button>
          </form>

          <!-- ── AUTOMAÇÕES WA ── -->
          <hr style="border-color:rgba(255,255,255,.08);margin:1.25rem 0">
          <div style="font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.6rem">
            <i class="bi bi-robot" style="color:#a78bfa"></i>Automações WhatsApp
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_whatsapp">
            <!-- campos ocultos para manter os valores já salvos dos outros provedores -->
            <input type="hidden" name="wa_provider"          value="<?= htmlspecialchars(getConfig('wa_provider') ?? '') ?>">
            <input type="hidden" name="wa_callmebot_apikey"  value="<?= htmlspecialchars(getConfig('wa_callmebot_apikey') ?? '') ?>">
            <input type="hidden" name="wa_zapi_instance"     value="<?= htmlspecialchars(getConfig('wa_zapi_instance') ?? '') ?>">
            <input type="hidden" name="wa_zapi_token"        value="<?= htmlspecialchars(getConfig('wa_zapi_token') ?? '') ?>">
            <input type="hidden" name="wa_zapi_client_token" value="<?= htmlspecialchars(getConfig('wa_zapi_client_token') ?? '') ?>">
            <input type="hidden" name="wa_uazapi_url"        value="<?= htmlspecialchars(getConfig('wa_uazapi_url') ?? '') ?>">
            <input type="hidden" name="wa_uazapi_token"      value="<?= htmlspecialchars(getConfig('wa_uazapi_token') ?? '') ?>">
            <input type="hidden" name="wa_uazapi_instance"   value="<?= htmlspecialchars(getConfig('wa_uazapi_instance') ?? '') ?>">
            <input type="hidden" name="wa_evolution_url"     value="<?= htmlspecialchars(getConfig('wa_evolution_url') ?? '') ?>">
            <input type="hidden" name="wa_evolution_key"     value="<?= htmlspecialchars(getConfig('wa_evolution_key') ?? '') ?>">
            <input type="hidden" name="wa_evolution_instance" value="<?= htmlspecialchars(getConfig('wa_evolution_instance') ?? '') ?>">

            <div class="row g-3">
              <div class="col-12">
                <div class="loja-toggle-row" style="margin-bottom:0">
                  <div class="loja-toggle-info">
                    <div class="loja-toggle-title"><i class="bi bi-star-fill me-2" style="color:#f59e0b"></i>Avaliação Imediata</div>
                    <div class="loja-toggle-sub">Envia avaliação (1-5) logo após concluir o atendimento</div>
                  </div>
                  <div class="toggle-wrap">
                    <input type="hidden" name="avaliacao_imediata" id="avalImediataHidden" value="<?= $avaliacaoImediata ?>">
                    <div class="toggle-track" id="toggleAvalImediataTrack"
                         style="background:<?= $avaliacaoImediata==='1' ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)' ?>">
                      <div class="toggle-knob" id="toggleAvalImediataKnob" style="left:<?= $avaliacaoImediata==='1' ? '27px' : '3px' ?>"></div>
                    </div>
                    <span id="toggleAvalImediataLabel" style="font-weight:700;font-size:.88rem;color:<?= $avaliacaoImediata==='1' ? '#4ade80' : 'rgba(255,255,255,.4)' ?>">
                      <?= $avaliacaoImediata==='1' ? 'Ativa' : 'Inativa' ?>
                    </span>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6">
                <label class="form-label">
                  <i class="bi bi-clock me-1"></i>Confirmação de Presença (min antes)
                </label>
                <input type="number" name="confirmacao_antecedencia_min" class="form-control"
                       min="1" max="30" value="<?= htmlspecialchars($confirmacaoMin) ?>">
                <div class="form-text">Minutos antes da vez para enviar confirmação de presença</div>
              </div>
              <div class="col-12 col-sm-6">
                <label class="form-label">
                  <i class="bi bi-calendar-x me-1"></i>Lembrete de Retorno (dias)
                </label>
                <input type="number" name="lembrete_retorno_dias" class="form-control"
                       min="7" max="365" value="<?= htmlspecialchars($lembreteRetornoDias) ?>">
                <div class="form-text">Dias sem visita para disparar lembrete de retorno (cron)</div>
              </div>
            </div>

            <div class="mt-3 p-3" style="background:rgba(139,92,246,.07);border:1px solid rgba(139,92,246,.2);border-radius:10px;font-size:.78rem;color:rgba(255,255,255,.55)">
              <i class="bi bi-terminal me-1" style="color:#a78bfa"></i>
              <strong style="color:#c4b5fd">Crons necessários:</strong><br>
              <code style="color:#e2d9f3;font-size:.75rem">*/2 * * * * /usr/local/bin/lsphp -q /home/cotpoobz/public_html/barbearia/api/notificar_fila.php</code><br>
              <code style="color:#e2d9f3;font-size:.75rem">0 10 * * * /usr/local/bin/lsphp -q /home/cotpoobz/public_html/barbearia/api/cron_retorno.php</code>
            </div>

            <button type="submit" class="btn-save w-100 mt-3"
              style="background:linear-gradient(135deg,#7c3aed,#5b21b6)">
              <i class="bi bi-robot me-1"></i>Salvar Automações
            </button>
          </form>

          <hr style="border-color:rgba(255,255,255,.08);margin:1rem 0">
          <form method="POST">
            <input type="hidden" name="acao" value="testar_whatsapp">
            <label class="form-label">Testar Envio de Mensagem</label>
            <div class="d-flex gap-2">
              <input type="tel" name="tel_teste" class="form-control"
                placeholder="(00) 00000-0000" id="telTeste">
              <button type="submit" class="btn-test" style="white-space:nowrap">
                <i class="bi bi-send me-1"></i>Testar
              </button>
            </div>
            <div class="form-text">Informe seu número para receber uma mensagem de teste</div>
          </form>
        </div>

        <!-- Info sistema -->
        <div class="section-card">
          <div class="section-title">
            <i class="bi bi-info-circle" style="color:#22c55e"></i>Informações do Sistema
          </div>
          <div class="row g-2 mb-3">
            <div class="col-4"><div class="stat-inf">
              <div class="stat-inf-val"><?= $totalClientes ?></div>
              <div class="stat-inf-lbl">Clientes</div>
            </div></div>
            <div class="col-4"><div class="stat-inf">
              <div class="stat-inf-val" style="color:#4ade80"><?= $totalAtend ?></div>
              <div class="stat-inf-lbl">Atendimentos</div>
            </div></div>
            <div class="col-4"><div class="stat-inf">
              <div class="stat-inf-val" style="color:#60a5fa"><?= $totalBarbeiros ?></div>
              <div class="stat-inf-lbl">Barbeiros</div>
            </div></div>
          </div>
          <div class="info-row"><span class="info-key">Versão</span><span class="info-val">1.0.0</span></div>
          <div class="info-row"><span class="info-key">Banco de Dados</span><span class="info-val">SQLite</span></div>
          <div class="info-row"><span class="info-key">Versão PHP</span><span class="info-val"><?= phpversion() ?></span></div>
          <div class="info-row">
            <span class="info-key">PDO SQLite</span>
            <span class="info-val"><?= extension_loaded('pdo_sqlite')
              ? '<span style="color:#4ade80"><i class="bi bi-check-circle me-1"></i>Ativa</span>'
              : '<span style="color:#f87171"><i class="bi bi-x-circle me-1"></i>Inativa</span>' ?></span>
          </div>
          <div class="info-row">
            <span class="info-key">cURL</span>
            <span class="info-val"><?= extension_loaded('curl')
              ? '<span style="color:#4ade80"><i class="bi bi-check-circle me-1"></i>Ativa</span>'
              : '<span style="color:#f87171"><i class="bi bi-x-circle me-1"></i>Inativa</span>' ?></span>
          </div>
          <div class="info-row">
            <span class="info-key">Uploads</span>
            <span class="info-val"><?= is_writable(__DIR__.'/../uploads/')
              ? '<span style="color:#4ade80"><i class="bi bi-check-circle me-1"></i>Gravável</span>'
              : '<span style="color:#f87171"><i class="bi bi-x-circle me-1"></i>Sem permissão</span>' ?></span>
          </div>
          <div class="info-row">
            <span class="info-key">Banco</span>
            <span class="info-val"><?= is_writable(DB_PATH)
              ? '<span style="color:#4ade80"><i class="bi bi-check-circle me-1"></i>Gravável</span>'
              : '<span style="color:#f87171"><i class="bi bi-x-circle me-1"></i>Sem permissão</span>' ?></span>
          </div>
        </div>

      </div><!-- /col direita -->
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// ── Tabs de provedor (agora com 4 opções) ──
document.querySelectorAll('#providerTabs input[type=radio]').forEach(radio => {
  radio.addEventListener('change', function() {
    document.querySelectorAll('.provider-tab').forEach(t => t.classList.remove('active'));
    this.closest('.provider-tab').classList.add('active');
    document.querySelectorAll('.wa-cfg').forEach(d => d.style.display = 'none');
    const cfg = document.getElementById('cfg_' + this.value);
    if (cfg) cfg.style.display = 'block';
  });
});

function previewImg(input, wrapId, placeholderId, imgId) {
  if (!input.files || !input.files[0]) return;
  const reader = new FileReader();
  reader.onload = e => {
    const wrap = document.getElementById(wrapId);
    const ph   = document.getElementById(placeholderId);
    let img    = document.getElementById(imgId);
    if (!img) {
      img = document.createElement('img');
      img.id = imgId;
      img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:inherit';
      wrap.appendChild(img);
    }
    img.src = e.target.result;
    if (ph) ph.style.display = 'none';
    if (wrapId === 'capaWrap') {
      const prevBg = document.getElementById('prevBg');
      prevBg.style.background = '';
      prevBg.style.backgroundImage = `url('${e.target.result}')`;
    }
    if (wrapId === 'logoWrap') {
      const pl = document.getElementById('prevLogo');
      if (pl && pl.tagName === 'IMG') pl.src = e.target.result;
    }
  };
  reader.readAsDataURL(input.files[0]);
}

function togglePass(id, btn) {
  const inp = document.getElementById(id);
  inp.type  = inp.type === 'password' ? 'text' : 'password';
  btn.querySelector('i').className = inp.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
}

document.getElementById('telTeste')?.addEventListener('input', function() {
  let v = this.value.replace(/\D/g,'');
  if (v.length <= 10) v = v.replace(/(\d{2})(\d{4})(\d{0,4})/,'($1) $2-$3');
  else                v = v.replace(/(\d{2})(\d{5})(\d{0,4})/,'($1) $2-$3');
  this.value = v;
});


// ── Fila Modo — botões de seleção ──
function setFilaModo(val) {
  document.getElementById('filaModoHidden').value = val;
  var cores = {
    auto:    {bg:'rgba(245,158,11,.15)', border:'2px solid rgba(245,158,11,.5)', color:'#fbbf24'},
    aberta:  {bg:'rgba(34,197,94,.15)', border:'2px solid rgba(34,197,94,.5)',  color:'#4ade80'},
    fechada: {bg:'rgba(239,68,68,.1)',  border:'2px solid rgba(239,68,68,.5)',  color:'#f87171'},
  };
  ['auto','aberta','fechada'].forEach(function(v) {
    var btn = document.getElementById('btnModo_' + v);
    if (!btn) return;
    if (v === val) {
      btn.style.background = cores[v].bg;
      btn.style.border     = cores[v].border;
      btn.style.color      = cores[v].color;
    } else {
      btn.style.background = 'rgba(255,255,255,.04)';
      btn.style.border     = '2px solid rgba(255,255,255,.1)';
      btn.style.color      = 'rgba(255,255,255,.45)';
    }
  });
}
function criarToggle(trackId, knobId, labelId, hiddenId, txtOn, txtOff) {
  const track  = document.getElementById(trackId);
  const knob   = document.getElementById(knobId);
  const label  = document.getElementById(labelId);
  const hidden = document.getElementById(hiddenId);
  if (!track) return;
  function atualizar(ativo) {
    track.style.background = ativo ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,.15)';
    knob.style.left   = ativo ? '27px' : '3px';
    label.textContent = ativo ? txtOn  : txtOff;
    label.style.color = ativo ? '#4ade80' : 'rgba(255,255,255,.4)';
    hidden.value      = ativo ? '1' : '0';
  }
  track.addEventListener('click', () => {
    const novoEstado = hidden.value !== '1';
    atualizar(novoEstado);
    if (hiddenId === 'lojaBotaoHidden') {
      document.getElementById('previewBotaoLoja').style.display = novoEstado ? 'inline-block' : 'none';
      atualizarPreviewTudoOculto();
    }
    if (hiddenId === 'minhaContaHidden') {
      document.getElementById('previewMinhaContaVis').style.display = novoEstado ? 'inline-block' : 'none';
      atualizarPreviewTudoOculto();
    }
  });
}

function atualizarPreviewTudoOculto() {
  const lojaVis  = document.getElementById('lojaBotaoHidden').value  === '1';
  const contaVis = document.getElementById('minhaContaHidden').value === '1';
  document.getElementById('previewTudoOculto').style.display = (!lojaVis && !contaVis) ? 'block' : 'none';
}

criarToggle('toggleAvalImediataTrack','toggleAvalImediataKnob','toggleAvalImediataLabel','avalImediataHidden','Ativa','Inativa');
criarToggle('toggleTrack',           'toggleKnob',           'toggleLabel',           'filaAtivaHidden',  'Aberta',  'Fechada');
criarToggle('toggleLojaBotaoTrack',  'toggleLojaBotaoKnob',  'toggleLojaBotaoLabel',  'lojaBotaoHidden',  'Visível', 'Oculto');
criarToggle('toggleMinhaContaTrack', 'toggleMinhaContaKnob', 'toggleMinhaContaLabel', 'minhaContaHidden', 'Visível', 'Oculto');
criarToggle('toggleAgendaBotaoTrack', 'toggleAgendaBotaoKnob', 'toggleAgendaBotaoLabel', 'agendaBotaoHidden',  'Visível', 'Oculto');
criarToggle('toggleServIndexTrack',   'toggleServIndexKnob',   'toggleServIndexLabel',   'servIndexHidden',    'Visível', 'Oculto');

// Sincronizar preview dos botões com os toggles
function syncPreviewBotoes() {
  var loja    = document.getElementById('lojaBotaoHidden');
  var conta   = document.getElementById('minhaContaHidden');
  var agenda  = document.getElementById('agendaBotaoHidden');
  var pLoja   = document.getElementById('previewBotaoLoja');
  var pConta  = document.getElementById('previewMinhaContaVis');
  var pAgenda = document.getElementById('previewAgendaVis');
  var pVazio  = document.getElementById('previewTudoOculto');
  if (pLoja)   pLoja.style.display   = (loja  && loja.value  ==='1') ? 'inline-block' : 'none';
  if (pConta)  pConta.style.display  = (conta && conta.value ==='1') ? 'inline-block' : 'none';
  if (pAgenda) pAgenda.style.display = (agenda&& agenda.value==='1') ? 'inline-block' : 'none';
  if (pVazio)  pVazio.style.display  =
    ((!loja||loja.value!=='1') && (!conta||conta.value!=='1') && (!agenda||agenda.value!=='1'))
    ? 'block' : 'none';
}
// Observar mudanças nos hiddens
['lojaBotaoHidden','minhaContaHidden','agendaAtivoHidden'].forEach(function(id) {
  var el = document.getElementById(id);
  if (el) { var obs = new MutationObserver(syncPreviewBotoes); obs.observe(el,{attributes:true,attributeFilter:['value']}); }
});
// Patch criarToggle para chamar sync após mudar valor
var _criarToggleOrig = criarToggle;
document.querySelectorAll('.toggle-track').forEach(function(track) {
  track.addEventListener('click', function() { setTimeout(syncPreviewBotoes, 50); });
});
criarToggle('toggleLojaAtivaTrack',  'toggleLojaAtivaKnob',  'toggleLojaAtivaLabel',  'lojaAtivaHidden',  'Aberta',  'Fechada');
criarToggle('toggleRetiradaTrack',   'toggleRetiradaKnob',   'toggleRetiradaLabel',   'retiradaHidden',   'Ativa',   'Inativa');
criarToggle('toggleEntregaTrack',    'toggleEntregaKnob',    'toggleEntregaLabel',    'entregaHidden',    'Ativa',   'Inativa');
criarToggle('toggleAvalImediataTrack','toggleAvalImediataKnob','toggleAvalImediataLabel','avalImediataHidden','Ativa', 'Inativa');

function toggleDiaConfig(num) {
  const row  = document.getElementById('diaRow'  + num);
  const body = document.getElementById('diaBody' + num);
  if (!body) return;
  const open = body.style.display === 'none';
  body.style.display = open ? 'block' : 'none';
  row.classList.toggle('open', open);
}

function toggleDiaAtivo(num) {
  const hidden = document.getElementById('diaAtivoHidden' + num);
  const track  = document.getElementById('diaTTrack'      + num);
  const knob   = document.getElementById('diaTKnob'       + num);
  if (!hidden) return;
  const ativo  = hidden.value !== '1';
  hidden.value           = ativo ? '1' : '0';
  track.style.background = ativo
    ? 'linear-gradient(135deg,#22c55e,#16a34a)'
    : 'rgba(255,255,255,.12)';
  knob.style.left = ativo ? '18px' : '2px';
  atualizarDiaLabel(num);
}

function atualizarDiaLabel(num) {
  const hidden = document.getElementById('diaAtivoHidden'          + num);
  const label  = document.getElementById('diaStatusLabel'          + num);
  const abre   = document.querySelector(`[name="horario_abertura_${num}"]`);
  const fecha  = document.querySelector(`[name="horario_fechamento_${num}"]`);
  const motivo = document.querySelector(`[name="motivo_fechamento_${num}"]`);
  if (!label || !hidden) return;
  const ativo = hidden.value === '1';
  if (ativo && abre && fecha) {
    label.style.color = '#4ade80';
    label.textContent = abre.value + ' – ' + fecha.value;
  } else {
    label.style.color = 'rgba(255,255,255,.3)';
    label.textContent = (motivo && motivo.value.trim()) ? motivo.value.trim() : 'Fechado';
  }
}
</script>
<?php if (file_exists(__DIR__ . '/../sw.js')): ?>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope)).catch(e => console.log('SW erro:', e));
  });
}
</script>
<?php endif; ?>
</body>
</html>