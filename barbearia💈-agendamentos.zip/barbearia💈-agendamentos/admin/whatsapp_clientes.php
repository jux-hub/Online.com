<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

$nomeBarbearia = getConfig('nome_barbearia');

// ── Templates de mensagem salvos ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'salvar_template') {
        $titulo   = trim($_POST['titulo']   ?? '');
        $mensagem = trim($_POST['mensagem'] ?? '');
        $emoji    = trim($_POST['emoji']    ?? '');
        if ($titulo && $mensagem) {
            $db->prepare("INSERT INTO wa_templates (titulo, mensagem, emoji) VALUES (?,?,?)")
               ->execute([$titulo, $mensagem, $emoji]);
            flash('success', 'Template salvo!');
        }
        header('Location: whatsapp_clientes.php'); exit;

    } elseif ($acao === 'editar_template') {
        $id       = (int)($_POST['id']       ?? 0);
        $titulo   = trim($_POST['titulo']    ?? '');
        $mensagem = trim($_POST['mensagem']  ?? '');
        $emoji    = trim($_POST['emoji']     ?? '');
        if ($id && $titulo && $mensagem) {
            $db->prepare("UPDATE wa_templates SET titulo=?, mensagem=?, emoji=? WHERE id=?")
               ->execute([$titulo, $mensagem, $emoji, $id]);
            flash('success', 'Template atualizado!');
        }
        header('Location: whatsapp_clientes.php'); exit;

    } elseif ($acao === 'excluir_template') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $db->prepare("DELETE FROM wa_templates WHERE id=?")->execute([$id]);
            flash('warning', 'Template excluído.');
        }
        header('Location: whatsapp_clientes.php'); exit;

    } elseif ($acao === 'registrar_envio') {
        // Registra envio no histórico
        $cliente_id = (int)($_POST['cliente_id'] ?? 0);
        $mensagem   = trim($_POST['mensagem']    ?? '');
        $telefone   = trim($_POST['telefone']    ?? '');
        if ($cliente_id && $mensagem) {
            $db->prepare("INSERT INTO wa_historico (cliente_id, telefone, mensagem, enviado_por)
                          VALUES (?,?,?,?)")
               ->execute([$cliente_id, $telefone, $mensagem, $_SESSION['usuario_nome'] ?? 'Admin']);
        }
        echo json_encode(['ok' => true]); exit;
    }
}

// ── Cria tabelas se não existirem ──
$db->exec("
    CREATE TABLE IF NOT EXISTS wa_templates (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo    TEXT NOT NULL,
        mensagem  TEXT NOT NULL,
        emoji     TEXT DEFAULT '💬',
        usos      INTEGER DEFAULT 0,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
$db->exec("
    CREATE TABLE IF NOT EXISTS wa_historico (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente_id  INTEGER,
        telefone    TEXT,
        mensagem    TEXT,
        enviado_por TEXT,
        enviado_em  DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

// ── Templates padrão se não houver nenhum ──
$totalTpl = $db->query("SELECT COUNT(*) as c FROM wa_templates")->fetch()['c'];
if ($totalTpl == 0) {
    $tplPadroes = [
        ['🎉 Promoção Especial',   "Olá, {nome}! 🎉\n\nTemos uma promoção especial para você!\n\n✂️ *{barbearia}*\n\nNão perca essa oportunidade. Entre na fila online agora:\n{link}", '🎉'],
        ['⏰ Lembrete de Visita',  "Olá, {nome}! Faz um tempo que não te vemos por aqui. 😊\n\n✂️ *{barbearia}* está te esperando!\n\nEntre na fila online: {link}", '⏰'],
        ['🎂 Aniversário',         "Feliz aniversário, {nome}! 🎂🎊\n\nA equipe da *{barbearia}* deseja um dia incrível!\n\nVenha comemorar com a gente. ✂️", '🎂'],
        ['⭐ Agradecimento',       "Olá, {nome}! 😊\n\nObrigado pela sua visita à *{barbearia}*!\n\nSua opinião é muito importante pra nós. Volte sempre! ✂️💈", '⭐'],
        ['📢 Novidade',            "Olá, {nome}! 📢\n\nTemos novidades na *{barbearia}*!\n\nVenha conferir nossos novos serviços. Entre na fila: {link}", '📢'],
    ];
    foreach ($tplPadroes as $t) {
        $db->prepare("INSERT INTO wa_templates (titulo, mensagem, emoji) VALUES (?,?,?)")
           ->execute($t);
    }
}

// ── Busca de clientes (AJAX) ──
if (isset($_GET['ajax_busca'])) {
    $q      = trim($_GET['q'] ?? '');
    $filtro = trim($_GET['filtro'] ?? 'todos');
    $limit  = 20;

    $whereExtra = '';
    if ($filtro === 'vip') {
        $whereExtra = "HAVING total_concluido >= 10";
    } elseif ($filtro === 'freq') {
        $whereExtra = "HAVING total_concluido >= 3 AND total_concluido < 10";
    } elseif ($filtro === 'novos') {
        $whereExtra = "HAVING total_concluido = 0";
    } elseif ($filtro === 'inativos') {
        $whereExtra = "HAVING ultimo_atend < date('now','-60 days') OR ultimo_atend IS NULL";
    }

    $stmt = $db->prepare("
        SELECT c.id, c.nome, c.telefone, c.criado_em,
               COALESCE(SUM(CASE WHEN f.status='concluido' THEN 1 ELSE 0 END),0) AS total_concluido,
               MAX(f.finalizado_em) AS ultimo_atend
        FROM clientes c
        LEFT JOIN fila f ON f.cliente_id = c.id
        WHERE (c.nome LIKE ? OR c.telefone LIKE ?)
        GROUP BY c.id
        $whereExtra
        ORDER BY c.nome ASC
        LIMIT $limit
    ");
    $stmt->execute(["%$q%", "%$q%"]);
    $rows = $stmt->fetchAll();

    header('Content-Type: application/json');
    echo json_encode($rows);
    exit;
}

// ── Busca em MASSA por segmento (AJAX) ──
if (isset($_GET['ajax_segmento'])) {
    $seg   = trim($_GET['seg'] ?? 'todos');
    $limit = 500;

    $having = '';
    switch ($seg) {
        case 'vip':      $having = "HAVING total_concluido >= 10"; break;
        case 'freq':     $having = "HAVING total_concluido >= 3 AND total_concluido < 10"; break;
        case 'novos':    $having = "HAVING total_concluido = 0"; break;
        case 'inativos': $having = "HAVING ultimo_atend < date('now','-60 days') OR ultimo_atend IS NULL"; break;
        case 'sumidos':  $having = "HAVING ultimo_atend < date('now','-30 days') OR ultimo_atend IS NULL"; break;
    }

    $stmt = $db->query("
        SELECT c.id, c.nome, c.telefone,
               COALESCE(SUM(CASE WHEN f.status='concluido' THEN 1 ELSE 0 END),0) AS total_concluido,
               MAX(f.finalizado_em) AS ultimo_atend
        FROM clientes c
        LEFT JOIN fila f ON f.cliente_id = c.id
        WHERE c.telefone IS NOT NULL AND c.telefone != ''
        GROUP BY c.id
        $having
        ORDER BY c.nome ASC
        LIMIT $limit
    ");
    $rows = $stmt->fetchAll();

    header('Content-Type: application/json');
    echo json_encode($rows);
    exit;
}

// ── Histórico recente ──
$historico = $db->query("
    SELECT h.*, c.nome as cliente_nome
    FROM wa_historico h
    LEFT JOIN clientes c ON c.id = h.cliente_id
    ORDER BY h.enviado_em DESC
    LIMIT 30
")->fetchAll();

// ── Templates ──
$templates = $db->query("SELECT * FROM wa_templates ORDER BY usos DESC, criado_em ASC")->fetchAll();

// ── Stats ──
$statsWa = $db->query("
    SELECT
        COUNT(*)                                               AS total_envios,
        COUNT(DISTINCT cliente_id)                             AS clientes_alcancados,
        COUNT(CASE WHEN DATE(enviado_em)=DATE('now') THEN 1 END) AS hoje,
        COUNT(CASE WHEN enviado_em >= DATE('now','-7 days') THEN 1 END) AS semana
    FROM wa_historico
")->fetch();

$proto    = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$linkFila = $proto . '://' . $_SERVER['HTTP_HOST'] . BASE_URL . '/';

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>WhatsApp Clientes – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--wa:#25d366;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  /* ── SIDEBAR ── */
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  /* ── LAYOUT ── */
  .main-content{margin-left:var(--sidebar-w);min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  /* ── STATS ── */
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
    border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.1rem;
    position:relative;overflow:hidden;text-align:center}
  .stat-card::after{content:'';position:absolute;top:-15px;right:-15px;
    width:60px;height:60px;border-radius:50%;opacity:.1}
  .stat-card.c1::after{background:#25d366}
  .stat-card.c2::after{background:#3b82f6}
  .stat-card.c3::after{background:#f59e0b}
  .stat-card.c4::after{background:#e94560}
  .stat-value{font-size:1.7rem;font-weight:800;color:#fff;line-height:1}
  .stat-label{color:rgba(255,255,255,.45);font-size:.78rem;margin-top:.3rem}

  /* ── CARD SEÇÃO ── */
  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);
    border-radius:18px;padding:1.35rem;margin-bottom:1.1rem}
  .card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;
    display:flex;align-items:center;gap:.5rem}

  /* ── BUSCA ── */
  .search-wrap{position:relative}
  .search-wrap .bi-search{position:absolute;left:.85rem;top:50%;transform:translateY(-50%);
    color:rgba(255,255,255,.3);pointer-events:none}
  .search-input{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.65rem 1rem .65rem 2.4rem;width:100%;font-size:.9rem;transition:.2s}
  .search-input:focus{outline:none;border-color:var(--wa);background:rgba(37,211,102,.07);
    box-shadow:0 0 0 3px rgba(37,211,102,.15)}
  .search-input::placeholder{color:rgba(255,255,255,.3)}

  /* Filtros rápidos */
  .filtro-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
    color:rgba(255,255,255,.55);border-radius:20px;padding:.3rem .8rem;
    font-size:.78rem;font-weight:600;cursor:pointer;transition:.2s;white-space:nowrap}
  .filtro-btn:hover,.filtro-btn.active{background:rgba(37,211,102,.15);
    border-color:rgba(37,211,102,.3);color:#4ade80}

  /* ── LISTA DE RESULTADOS ── */
  .resultado-item{
    display:flex;align-items:center;gap:.75rem;
    padding:.65rem .85rem;border-radius:10px;
    background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
    cursor:pointer;transition:all .2s;margin-bottom:.4rem;
  }
  .resultado-item:hover{background:rgba(37,211,102,.08);border-color:rgba(37,211,102,.25)}
  .resultado-item.selecionado{background:rgba(37,211,102,.12);border-color:rgba(37,211,102,.4)}
  .res-avatar{width:36px;height:36px;border-radius:50%;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.9rem;color:#fff}
  .res-nome{font-weight:600;color:#fff;font-size:.88rem;line-height:1.2}
  .res-tel{font-size:.75rem;color:rgba(255,255,255,.4)}
  .badge-vip{background:rgba(245,158,11,.2);color:#fbbf24;border:1px solid rgba(245,158,11,.25);
    border-radius:20px;padding:.1rem .45rem;font-size:.65rem;font-weight:700}
  .badge-freq{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.2);
    border-radius:20px;padding:.1rem .45rem;font-size:.65rem;font-weight:700}
  .badge-novo{background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.2);
    border-radius:20px;padding:.1rem .45rem;font-size:.65rem;font-weight:700}

  /* ── PAINEL DE ENVIO ── */
  .envio-panel{
    background:rgba(37,211,102,.04);
    border:1px solid rgba(37,211,102,.2);
    border-radius:16px;padding:1.35rem;
  }
  .cliente-selecionado-card{
    background:rgba(37,211,102,.08);border:1px solid rgba(37,211,102,.25);
    border-radius:12px;padding:.85rem 1rem;
    display:flex;align-items:center;gap:.85rem;margin-bottom:1rem;
  }
  .sel-avatar{width:46px;height:46px;border-radius:50%;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;
    font-weight:800;font-size:1.1rem;color:#fff}
  .sel-nome{font-weight:700;color:#fff;font-size:.95rem}
  .sel-tel{font-size:.82rem;color:rgba(255,255,255,.5)}

  /* Textarea da mensagem */
  .msg-area{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:12px;padding:.8rem 1rem;width:100%;
    font-size:.9rem;resize:vertical;min-height:120px;transition:.2s;font-family:inherit}
  .msg-area:focus{outline:none;border-color:var(--wa);background:rgba(37,211,102,.06);
    box-shadow:0 0 0 3px rgba(37,211,102,.12)}
  .msg-area::placeholder{color:rgba(255,255,255,.3)}

  /* Variáveis disponíveis */
  .var-chip{background:rgba(37,211,102,.12);border:1px solid rgba(37,211,102,.2);
    color:#4ade80;border-radius:6px;padding:.2rem .55rem;font-size:.73rem;
    font-weight:700;cursor:pointer;transition:.2s;font-family:monospace}
  .var-chip:hover{background:rgba(37,211,102,.22);transform:translateY(-1px)}

  /* Preview WA */
  .wa-preview{
    background:#0d1117;border:1px solid rgba(37,211,102,.15);
    border-radius:14px;padding:1rem;
  }
  .wa-bubble{
    background:#1f2c34;border-radius:0 12px 12px 12px;
    padding:.75rem 1rem;max-width:85%;font-size:.85rem;
    color:#e9edef;line-height:1.5;white-space:pre-wrap;word-break:break-word;
    position:relative;
  }
  .wa-bubble::before{content:'';position:absolute;top:0;left:-8px;
    border:8px solid transparent;border-right-color:#1f2c34;border-top:0}
  .wa-time{font-size:.68rem;color:rgba(255,255,255,.3);text-align:right;margin-top:.3rem}

  /* Botão WA */
  .btn-wa-enviar{
    background:linear-gradient(135deg,#25d366,#1da851);
    border:none;color:#fff;border-radius:12px;padding:.8rem 1.5rem;
    font-weight:800;font-size:1rem;cursor:pointer;transition:all .3s;
    display:flex;align-items:center;gap:.5rem;width:100%;justify-content:center;
    text-decoration:none;
  }
  .btn-wa-enviar:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(37,211,102,.35);color:#fff}
  .btn-wa-enviar:active{transform:translateY(0)}

  /* Templates */
  .tpl-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
    border-radius:12px;padding:.85rem;cursor:pointer;transition:all .2s;
    display:flex;align-items:flex-start;gap:.65rem}
  .tpl-card:hover{background:rgba(37,211,102,.07);border-color:rgba(37,211,102,.25);
    transform:translateY(-1px)}
  .tpl-emoji{font-size:1.4rem;flex-shrink:0;line-height:1}
  .tpl-titulo{font-weight:700;color:#fff;font-size:.85rem;margin-bottom:.2rem}
  .tpl-preview{font-size:.75rem;color:rgba(255,255,255,.4);
    overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}

  /* Histórico */
  .hist-item{display:flex;gap:.75rem;padding:.7rem 0;
    border-bottom:1px solid rgba(255,255,255,.05)}
  .hist-item:last-child{border-bottom:none}
  .hist-avatar{width:32px;height:32px;border-radius:50%;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;
    background:rgba(37,211,102,.15);color:#4ade80;font-size:.8rem;font-weight:800}


  /* ── DISPARO EM MASSA ── */
  .massa-seg-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
    color:rgba(255,255,255,.6);border-radius:12px;padding:.6rem 1rem;cursor:pointer;
    transition:all .2s;text-align:center;flex:1;min-width:80px}
  .massa-seg-btn:hover{background:rgba(37,211,102,.1);border-color:rgba(37,211,102,.3);color:#4ade80}
  .massa-seg-btn.active{background:rgba(37,211,102,.18);border-color:#25d366;color:#25d366;font-weight:700}
  .massa-seg-btn .seg-icon{font-size:1.3rem;display:block;margin-bottom:.25rem}
  .massa-seg-btn .seg-nome{font-size:.75rem;font-weight:600}
  .massa-seg-btn .seg-cnt{font-size:1.1rem;font-weight:800;color:#fff;display:block}
  .massa-cliente-item{display:flex;align-items:center;gap:.6rem;padding:.4rem .6rem;
    border-radius:8px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);
    margin-bottom:.3rem;font-size:.82rem}
  .massa-cliente-item .mc-avatar{width:28px;height:28px;border-radius:50%;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.75rem}
  .massa-prog-bar{height:6px;background:rgba(255,255,255,.1);border-radius:10px;overflow:hidden;margin:.5rem 0}
  .massa-prog-fill{height:100%;background:linear-gradient(90deg,#25d366,#1da851);
    border-radius:10px;transition:width .3s}

  h4,h5,h6{color:#fff;margin:0}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<!-- ══ SIDEBAR ══ -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<!-- ══ CONTEÚDO ══ -->
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">
          <i class="bi bi-whatsapp me-2" style="color:#25d366"></i>WhatsApp para Clientes
        </h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
          Envie mensagens personalizadas diretamente no WhatsApp
        </div>
      </div>
    </div>
    <a href="dashboard.php"
       style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
              color:rgba(255,255,255,.6);border-radius:10px;padding:.4rem .9rem;
              font-size:.82rem;font-weight:600;text-decoration:none;
              display:flex;align-items:center;gap:.4rem">
      <i class="bi bi-arrow-left"></i> Dashboard
    </a>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- ── STATS ── -->
    <div class="row g-2 mb-3">
      <div class="col-6 col-md-3">
        <div class="stat-card c1">
          <div class="stat-value"><?= number_format($statsWa['total_envios']) ?></div>
          <div class="stat-label"><i class="bi bi-send-fill me-1" style="color:#25d366"></i>Total Enviados</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card c2">
          <div class="stat-value"><?= number_format($statsWa['clientes_alcancados']) ?></div>
          <div class="stat-label"><i class="bi bi-people-fill me-1" style="color:#60a5fa"></i>Clientes Contactados</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card c3">
          <div class="stat-value"><?= $statsWa['hoje'] ?></div>
          <div class="stat-label"><i class="bi bi-calendar-day me-1" style="color:#fbbf24"></i>Enviados Hoje</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card c4">
          <div class="stat-value"><?= $statsWa['semana'] ?></div>
          <div class="stat-label"><i class="bi bi-calendar-week me-1" style="color:#e94560"></i>Últimos 7 dias</div>
        </div>
      </div>
    </div>

    <div class="row g-3">

      <!-- ══ COLUNA ESQUERDA: Busca + Templates ══ -->
      <div class="col-12 col-xl-4">

        <!-- Busca de clientes -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-search" style="color:#25d366"></i>
            Buscar Cliente
          </div>

          <!-- Filtros rápidos -->
          <div style="display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:.85rem">
            <button class="filtro-btn active" data-filtro="todos">Todos</button>
            <button class="filtro-btn" data-filtro="vip">⭐ VIP</button>
            <button class="filtro-btn" data-filtro="freq">✓ Frequentes</button>
            <button class="filtro-btn" data-filtro="novos">✦ Novos</button>
            <button class="filtro-btn" data-filtro="inativos">💤 Inativos</button>
          </div>

          <div class="search-wrap mb-2">
            <i class="bi bi-search"></i>
            <input type="text" id="buscaCliente" class="search-input"
                   placeholder="Nome ou telefone…" autocomplete="off">
          </div>

          <div id="loadingBusca" style="display:none;text-align:center;padding:.75rem 0;
               color:rgba(255,255,255,.3);font-size:.82rem">
            <span class="spinner-border spinner-border-sm me-1"></span>Buscando...
          </div>

          <div id="resultadosBusca" style="max-height:320px;overflow-y:auto">
            <!-- Resultados via JS -->
          </div>

          <div id="semResultados" style="display:none;text-align:center;padding:1.5rem 0;
               color:rgba(255,255,255,.3);font-size:.85rem">
            <i class="bi bi-emoji-frown" style="font-size:2rem;display:block;margin-bottom:.4rem"></i>
            Nenhum cliente encontrado
          </div>
        </div>

        <!-- Templates -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-collection-fill" style="color:#f59e0b"></i>
            Templates de Mensagem
            <button onclick="abrirModalTemplate()"
              style="background:rgba(233,69,96,.12);border:1px solid rgba(233,69,96,.25);
                     color:#e94560;border-radius:7px;padding:.2rem .6rem;
                     font-size:.75rem;font-weight:700;cursor:pointer;margin-left:auto;
                     display:flex;align-items:center;gap:.25rem">
              <i class="bi bi-plus-lg"></i> Novo
            </button>
          </div>

          <div style="max-height:380px;overflow-y:auto;display:flex;flex-direction:column;gap:.4rem">
            <?php foreach ($templates as $tpl): ?>
            <div class="tpl-card" onclick="usarTemplate(<?= htmlspecialchars(json_encode($tpl['mensagem'])) ?>)">
              <div class="tpl-emoji"><?= htmlspecialchars($tpl['emoji'] ?: '💬') ?></div>
              <div style="flex:1;min-width:0">
                <div class="tpl-titulo"><?= htmlspecialchars($tpl['titulo']) ?></div>
                <div class="tpl-preview"><?= htmlspecialchars($tpl['mensagem']) ?></div>
              </div>
              <div style="display:flex;flex-direction:column;gap:.25rem;flex-shrink:0">
                <button onclick="event.stopPropagation();editarTemplate(<?= $tpl['id'] ?>,<?= htmlspecialchars(json_encode($tpl)) ?>)"
                  style="background:rgba(59,130,246,.12);border:1px solid rgba(59,130,246,.2);
                         color:#60a5fa;border-radius:6px;padding:.2rem .45rem;font-size:.72rem;cursor:pointer">
                  <i class="bi bi-pencil-fill"></i>
                </button>
                <form method="POST" class="d-inline"
                      onsubmit="return confirm('Excluir este template?')">
                  <input type="hidden" name="acao" value="excluir_template">
                  <input type="hidden" name="id"   value="<?= $tpl['id'] ?>">
                  <button type="submit" onclick="event.stopPropagation()"
                    style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);
                           color:#f87171;border-radius:6px;padding:.2rem .45rem;font-size:.72rem;cursor:pointer;width:100%">
                    <i class="bi bi-trash3-fill"></i>
                  </button>
                </form>
              </div>
            </div>
            <?php endforeach; ?>
          </div>

          <!-- Variáveis disponíveis -->
          <div style="margin-top:.85rem;padding-top:.85rem;border-top:1px solid rgba(255,255,255,.07)">
            <div style="font-size:.72rem;color:rgba(255,255,255,.35);font-weight:600;
                        text-transform:uppercase;letter-spacing:.5px;margin-bottom:.5rem">
              Variáveis disponíveis (clique para inserir)
            </div>
            <div style="display:flex;gap:.3rem;flex-wrap:wrap">
              <span class="var-chip" onclick="inserirVar('{nome}')">{nome}</span>
              <span class="var-chip" onclick="inserirVar('{telefone}')">{telefone}</span>
              <span class="var-chip" onclick="inserirVar('{barbearia}')">{barbearia}</span>
              <span class="var-chip" onclick="inserirVar('{link}')">{link}</span>
              <span class="var-chip" onclick="inserirVar('{data}')">{data}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- ══ COLUNA CENTRAL: Compor mensagem ══ -->
      <div class="col-12 col-xl-5">
        <div class="card-sec" style="border-color:rgba(37,211,102,.2)">
          <div class="card-title">
            <i class="bi bi-pencil-square" style="color:#25d366"></i>
            Compor Mensagem
          </div>

          <!-- Cliente selecionado -->
          <div id="placeholderCliente"
               style="background:rgba(255,255,255,.03);border:2px dashed rgba(255,255,255,.12);
                      border-radius:12px;padding:1.5rem;text-align:center;margin-bottom:1rem">
            <i class="bi bi-person-circle" style="font-size:2rem;color:rgba(255,255,255,.2);display:block;margin-bottom:.5rem"></i>
            <div style="color:rgba(255,255,255,.3);font-size:.85rem">
              Selecione um cliente na busca ao lado
            </div>
          </div>

          <div id="clienteSelecionadoCard" style="display:none" class="cliente-selecionado-card">
            <div id="selAvatarEl" class="sel-avatar">?</div>
            <div style="flex:1;min-width:0">
              <div id="selNomeEl" class="sel-nome">—</div>
              <div id="selTelEl"  class="sel-tel">—</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:.3rem;align-items:flex-end">
              <span id="selBadgeEl" style="font-size:.72rem"></span>
              <button onclick="limparSelecao()"
                style="background:rgba(255,255,255,.08);border:none;color:rgba(255,255,255,.4);
                       border-radius:6px;padding:.2rem .5rem;cursor:pointer;font-size:.75rem">
                <i class="bi bi-x"></i> Trocar
              </button>
            </div>
          </div>

          <!-- Textarea -->
          <div style="margin-bottom:.5rem">
            <label style="font-size:.82rem;color:rgba(255,255,255,.55);font-weight:600;
                          margin-bottom:.35rem;display:flex;justify-content:space-between">
              <span><i class="bi bi-chat-text me-1"></i>Mensagem</span>
              <span id="charCount" style="color:rgba(255,255,255,.3)">0 caracteres</span>
            </label>
            <textarea id="msgTexto" class="msg-area"
                      placeholder="Digite a mensagem ou escolha um template…"
                      oninput="atualizarPreview();atualizarCount()"></textarea>
          </div>

          <!-- Botão enviar -->
          <a id="btnEnviar" href="#" target="_blank"
             class="btn-wa-enviar"
             style="opacity:.4;pointer-events:none;margin-bottom:.85rem"
             onclick="registrarEnvio()">
            <i class="bi bi-whatsapp" style="font-size:1.2rem"></i>
            Abrir WhatsApp e Enviar
          </a>

          <!-- Avisos -->
          <div style="background:rgba(37,211,102,.05);border:1px solid rgba(37,211,102,.12);
                      border-radius:10px;padding:.75rem 1rem">
            <div style="font-size:.75rem;color:rgba(255,255,255,.4);line-height:1.55">
              <i class="bi bi-info-circle me-1" style="color:#25d366"></i>
              Ao clicar, o WhatsApp abrirá com a mensagem pré-preenchida para o cliente selecionado.
              O envio precisa ser confirmado manualmente no WhatsApp.
            </div>
          </div>
        </div>
      </div>

      <!-- ══ COLUNA DIREITA: Preview + Histórico ══ -->
      <div class="col-12 col-xl-3">

        <!-- Preview WA -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-phone" style="color:#25d366"></i>
            Preview
          </div>
          <div class="wa-preview">
            <!-- Header fake WA -->
            <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.85rem;
                        padding-bottom:.75rem;border-bottom:1px solid rgba(255,255,255,.06)">
              <div style="width:32px;height:32px;border-radius:50%;
                          background:rgba(37,211,102,.2);display:flex;align-items:center;
                          justify-content:center;font-size:.8rem;color:#25d366;font-weight:700"
                   id="prevAvatarWa">?</div>
              <div>
                <div style="font-size:.82rem;font-weight:700;color:#fff" id="prevNomeWa">Cliente</div>
                <div style="font-size:.68rem;color:rgba(255,255,255,.3)">WhatsApp</div>
              </div>
              <i class="bi bi-whatsapp ms-auto" style="color:#25d366;font-size:1.1rem"></i>
            </div>
            <!-- Bolha -->
            <div class="wa-bubble" id="prevBubble">
              A mensagem aparecerá aqui conforme você digita…
            </div>
            <div class="wa-time"><?= date('H:i') ?> ✓✓</div>
          </div>
        </div>

        <!-- Histórico -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-clock-history" style="color:#8b5cf6"></i>
            Histórico Recente
            <span style="background:rgba(139,92,246,.15);color:#a78bfa;border-radius:20px;
              padding:.1rem .5rem;font-size:.72rem;margin-left:auto">
              <?= count($historico) ?>
            </span>
          </div>
          <div style="max-height:420px;overflow-y:auto">
            <?php if (empty($historico)): ?>
            <div style="text-align:center;padding:1.5rem 0;color:rgba(255,255,255,.25);font-size:.85rem">
              <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.4rem"></i>
              Nenhum envio registrado
            </div>
            <?php else: ?>
            <?php foreach ($historico as $h): ?>
            <div class="hist-item">
              <div class="hist-avatar">
                <?= mb_strtoupper(mb_substr($h['cliente_nome'] ?? '?', 0, 1)) ?>
              </div>
              <div style="flex:1;min-width:0">
                <div style="font-size:.82rem;font-weight:600;color:#fff;
                            white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                  <?= htmlspecialchars($h['cliente_nome'] ?? $h['telefone']) ?>
                </div>
                <div style="font-size:.73rem;color:rgba(255,255,255,.35);
                            white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                  <?= htmlspecialchars(mb_substr($h['mensagem'], 0, 50)) ?>…
                </div>
                <div style="font-size:.68rem;color:rgba(255,255,255,.2);margin-top:.1rem">
                  <?= date('d/m H:i', strtotime($h['enviado_em'])) ?>
                  · <?= htmlspecialchars($h['enviado_por']) ?>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>


      <!-- ══ DISPARO EM MASSA ══ -->
      <div class="col-12 mt-2">
        <div class="card-sec" style="border-color:rgba(233,69,96,.2)">
          <div class="card-title">
            <i class="bi bi-broadcast" style="color:#e94560"></i>
            Disparo em Massa por Segmento
            <span style="background:rgba(233,69,96,.12);color:#e94560;border-radius:20px;
              padding:.1rem .55rem;font-size:.7rem;font-weight:700;margin-left:.25rem">NOVO</span>
          </div>

          <div class="row g-3">

            <!-- Coluna esq: segmentos + lista -->
            <div class="col-12 col-lg-5">
              <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.65rem;font-weight:600;
                          text-transform:uppercase;letter-spacing:.5px">1. Escolha o segmento</div>
              <div style="display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:.85rem" id="massaSegmentos">
                <button class="massa-seg-btn active" data-seg="todos">
                  <span class="seg-icon">👥</span>
                  <span class="seg-cnt" id="cnt_todos">–</span>
                  <span class="seg-nome">Todos</span>
                </button>
                <button class="massa-seg-btn" data-seg="vip">
                  <span class="seg-icon">⭐</span>
                  <span class="seg-cnt" id="cnt_vip">–</span>
                  <span class="seg-nome">VIP</span>
                </button>
                <button class="massa-seg-btn" data-seg="freq">
                  <span class="seg-icon">✓</span>
                  <span class="seg-cnt" id="cnt_freq">–</span>
                  <span class="seg-nome">Frequentes</span>
                </button>
                <button class="massa-seg-btn" data-seg="sumidos">
                  <span class="seg-icon">💤</span>
                  <span class="seg-cnt" id="cnt_sumidos">–</span>
                  <span class="seg-nome">Sumidos 30d</span>
                </button>
                <button class="massa-seg-btn" data-seg="inativos">
                  <span class="seg-icon">🚫</span>
                  <span class="seg-cnt" id="cnt_inativos">–</span>
                  <span class="seg-nome">Inativos 60d</span>
                </button>
                <button class="massa-seg-btn" data-seg="novos">
                  <span class="seg-icon">✦</span>
                  <span class="seg-cnt" id="cnt_novos">–</span>
                  <span class="seg-nome">Novos</span>
                </button>
              </div>

              <!-- Lista prévia de clientes -->
              <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.5rem;font-weight:600;
                          display:flex;align-items:center;justify-content:space-between">
                <span id="massaListaLabel">Carregando clientes…</span>
                <span id="massaSelecionados" style="color:#25d366;font-weight:700"></span>
              </div>
              <div id="massaListaClientes"
                   style="max-height:220px;overflow-y:auto;display:flex;flex-direction:column;gap:.3rem">
                <div style="text-align:center;padding:1rem;color:rgba(255,255,255,.2);font-size:.82rem">
                  <span class="spinner-border spinner-border-sm me-1"></span> Carregando…
                </div>
              </div>
            </div>

            <!-- Coluna dir: mensagem + disparo -->
            <div class="col-12 col-lg-7">
              <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.65rem;font-weight:600;
                          text-transform:uppercase;letter-spacing:.5px">2. Escreva a mensagem</div>

              <!-- Atalho de templates -->
              <div style="display:flex;gap:.35rem;flex-wrap:wrap;margin-bottom:.65rem">
                <?php foreach (array_slice($templates, 0, 4) as $t): ?>
                <button onclick="usarTemplateMassa(<?= htmlspecialchars(json_encode($t['mensagem'])) ?>)"
                  style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
                         color:rgba(255,255,255,.6);border-radius:8px;padding:.25rem .6rem;
                         font-size:.73rem;cursor:pointer;transition:.2s"
                  onmouseover="this.style.borderColor='rgba(37,211,102,.4)';this.style.color='#4ade80'"
                  onmouseout="this.style.borderColor='rgba(255,255,255,.1)';this.style.color='rgba(255,255,255,.6)'">
                  <?= htmlspecialchars($t['emoji'] ?: '💬') ?> <?= htmlspecialchars($t['titulo']) ?>
                </button>
                <?php endforeach; ?>
              </div>

              <textarea id="massaMsgTexto" class="msg-area" style="min-height:100px"
                        placeholder="Digite a mensagem para o grupo selecionado…&#10;Use {nome}, {barbearia}, {link}"
                        oninput="atualizarMassaPreview();atualizarMassaCount()"></textarea>
              <div style="font-size:.72rem;color:rgba(255,255,255,.3);text-align:right;margin-top:.2rem">
                <span id="massaCharCount">0 caracteres</span>
              </div>

              <!-- Preview massa -->
              <div id="massaPreviewWrap" style="display:none;margin:.65rem 0">
                <div style="font-size:.75rem;color:rgba(255,255,255,.35);margin-bottom:.3rem">Prévia da mensagem:</div>
                <div style="background:#1f2c34;border-radius:0 10px 10px 10px;
                            padding:.6rem .85rem;font-size:.82rem;color:#e9edef;
                            white-space:pre-wrap;word-break:break-word;max-height:80px;overflow-y:auto"
                     id="massaBubble"></div>
              </div>

              <!-- Barra de progresso (aparece durante disparo) -->
              <div id="massaProgWrap" style="display:none;margin:.65rem 0">
                <div style="display:flex;justify-content:space-between;font-size:.75rem;
                            color:rgba(255,255,255,.4);margin-bottom:.25rem">
                  <span>Enviando…</span>
                  <span id="massaProgTexto">0 / 0</span>
                </div>
                <div class="massa-prog-bar">
                  <div class="massa-prog-fill" id="massaProgFill" style="width:0%"></div>
                </div>
              </div>

              <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.75rem">
                <button id="btnDispararMassa"
                  onclick="iniciarDisparo()"
                  style="flex:1;background:linear-gradient(135deg,#e94560,#c41230);
                         border:none;color:#fff;border-radius:12px;padding:.75rem 1.2rem;
                         font-weight:800;font-size:.95rem;cursor:pointer;transition:all .3s;
                         display:flex;align-items:center;justify-content:center;gap:.5rem;
                         opacity:.5;pointer-events:none">
                  <i class="bi bi-broadcast"></i>
                  <span id="btnDisparoTxt">Disparar para <span id="btnDisparoQtd">0</span> clientes</span>
                </button>
                <button id="btnPausarMassa" onclick="pausarDisparo()"
                  style="display:none;background:rgba(245,158,11,.15);border:1px solid rgba(245,158,11,.3);
                         color:#fbbf24;border-radius:12px;padding:.75rem 1rem;
                         font-weight:700;cursor:pointer;font-size:.88rem">
                  <i class="bi bi-pause-fill"></i> Pausar
                </button>
              </div>

              <div style="margin-top:.6rem;font-size:.72rem;color:rgba(255,255,255,.3);
                          padding:.5rem .75rem;background:rgba(245,158,11,.05);
                          border:1px solid rgba(245,158,11,.12);border-radius:8px;line-height:1.5">
                <i class="bi bi-info-circle me-1" style="color:#f59e0b"></i>
                Cada cliente abrirá no <strong style="color:rgba(255,255,255,.5)">WhatsApp Web</strong>
                com a mensagem pronta. Confirme o envio em cada janela.
                Intervalo de <strong style="color:rgba(255,255,255,.5)">1,2s</strong> entre clientes para evitar bloqueio.
              </div>
            </div>
          </div>
        </div>
      </div>

    </div><!-- /row -->
  </div>
</div>

<!-- ══ MODAL TEMPLATE ══ -->
<div class="modal fade" id="modalTemplate" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px">
      <div class="modal-header" style="border-bottom:1px solid rgba(255,255,255,.08);padding:1.25rem 1.5rem">
        <h6 class="modal-title" id="tplModalTitle" style="color:#fff;font-weight:700">
          <i class="bi bi-collection me-2" style="color:#f59e0b"></i>Novo Template
        </h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" style="filter:invert(1) opacity(.5)"></button>
      </div>
      <form method="POST" id="formTemplate">
        <input type="hidden" name="acao" id="tplAcao" value="salvar_template">
        <input type="hidden" name="id"   id="tplId"   value="">
        <div style="padding:1.25rem 1.5rem">
          <div class="mb-3">
            <label style="color:rgba(255,255,255,.65);font-size:.83rem;font-weight:600;margin-bottom:.35rem;display:block">
              Emoji
            </label>
            <input type="text" name="emoji" id="tplEmoji"
                   style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
                          color:#fff;border-radius:10px;padding:.55rem .85rem;width:80px;
                          font-size:1.3rem;text-align:center"
                   maxlength="4" placeholder="💬">
          </div>
          <div class="mb-3">
            <label style="color:rgba(255,255,255,.65);font-size:.83rem;font-weight:600;margin-bottom:.35rem;display:block">
              Título do template *
            </label>
            <input type="text" name="titulo" id="tplTitulo" required maxlength="60"
                   style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
                          color:#fff;border-radius:10px;padding:.6rem 1rem;width:100%;font-size:.9rem"
                   placeholder="Ex: Promoção de Segunda">
          </div>
          <div>
            <label style="color:rgba(255,255,255,.65);font-size:.83rem;font-weight:600;margin-bottom:.35rem;display:block">
              Mensagem *
            </label>
            <textarea name="mensagem" id="tplMensagem" required
                      style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
                             color:#fff;border-radius:10px;padding:.7rem 1rem;width:100%;
                             font-size:.88rem;resize:vertical;min-height:110px;font-family:inherit"
                      placeholder="Use {nome}, {barbearia}, {link}, {data}…"></textarea>
          </div>
        </div>
        <div style="padding:1rem 1.5rem;border-top:1px solid rgba(255,255,255,.07);
                    display:flex;gap:.6rem;justify-content:flex-end">
          <button type="button" data-bs-dismiss="modal"
            style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                   color:rgba(255,255,255,.6);border-radius:9px;padding:.5rem 1rem;
                   font-weight:600;cursor:pointer">Cancelar</button>
          <button type="submit"
            style="background:linear-gradient(135deg,#f59e0b,#d97706);border:none;color:#fff;
                   border-radius:9px;padding:.5rem 1.2rem;font-weight:700;cursor:pointer">
            <i class="bi bi-floppy-fill me-1"></i>Salvar Template
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const BARBEARIA = <?= json_encode($nomeBarbearia) ?>;
const LINK_FILA = <?= json_encode($linkFila) ?>;
const CORES     = ['#e94560','#3b82f6','#22c55e','#f59e0b','#8b5cf6','#06b6d4','#f97316','#ec4899'];

let clienteAtual  = null;
let filtroAtual   = 'todos';
let timerBusca    = null;

// ── BUSCA ──
const inputBusca = document.getElementById('buscaCliente');
inputBusca.addEventListener('input', () => {
  clearTimeout(timerBusca);
  timerBusca = setTimeout(buscarClientes, 350);
});

function buscarClientes() {
  const q = inputBusca.value.trim();
  document.getElementById('loadingBusca').style.display    = 'block';
  document.getElementById('resultadosBusca').innerHTML     = '';
  document.getElementById('semResultados').style.display   = 'none';

  fetch(`whatsapp_clientes.php?ajax_busca=1&q=${encodeURIComponent(q)}&filtro=${filtroAtual}`)
    .then(r => r.json())
    .then(data => {
      document.getElementById('loadingBusca').style.display = 'none';
      if (!data.length) {
        document.getElementById('semResultados').style.display = 'block';
        return;
      }
      const frag = document.createDocumentFragment();
      data.forEach(c => {
        const div   = document.createElement('div');
        const cor   = CORES[Math.abs(hashCode(c.nome)) % CORES.length];
        const inic  = c.nome.charAt(0).toUpperCase();
        const isVip = parseInt(c.total_concluido) >= 10;
        const isFreq= parseInt(c.total_concluido) >= 3 && !isVip;
        const badge = isVip
          ? `<span class="badge-vip">⭐ VIP</span>`
          : isFreq ? `<span class="badge-freq">✓ Freq</span>`
          : `<span class="badge-novo">✦ Novo</span>`;
        div.className = 'resultado-item';
        div.innerHTML = `
          <div class="res-avatar" style="background:${cor}22;border:2px solid ${cor}44;color:${cor}">${inic}</div>
          <div style="flex:1;min-width:0">
            <div class="res-nome">${escHtml(c.nome)}</div>
            <div class="res-tel">${escHtml(c.telefone)}</div>
          </div>
          <div>${badge}</div>`;
        div.addEventListener('click', () => selecionarCliente(c, cor, badge));
        frag.appendChild(div);
      });
      document.getElementById('resultadosBusca').appendChild(frag);
    })
    .catch(() => {
      document.getElementById('loadingBusca').style.display = 'none';
    });
}

// ── FILTROS RÁPIDOS ──
document.querySelectorAll('.filtro-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    filtroAtual = btn.dataset.filtro;
    buscarClientes();
  });
});

// ── SELECIONAR CLIENTE ──
function selecionarCliente(c, cor, badge) {
  clienteAtual = c;

  // Marca selecionado na lista
  document.querySelectorAll('.resultado-item').forEach(el => el.classList.remove('selecionado'));
  event.currentTarget.classList.add('selecionado');

  const inic = c.nome.charAt(0).toUpperCase();

  // Atualiza card
  document.getElementById('placeholderCliente').style.display        = 'none';
  document.getElementById('clienteSelecionadoCard').style.display    = 'flex';
  document.getElementById('selAvatarEl').textContent                  = inic;
  document.getElementById('selAvatarEl').style.background             = cor + '22';
  document.getElementById('selAvatarEl').style.border                 = '2px solid ' + cor + '55';
  document.getElementById('selAvatarEl').style.color                  = cor;
  document.getElementById('selNomeEl').textContent                    = c.nome;
  document.getElementById('selTelEl').textContent                     = c.telefone;
  document.getElementById('selBadgeEl').innerHTML                     = badge;

  // Preview WA
  document.getElementById('prevAvatarWa').textContent = inic;
  document.getElementById('prevNomeWa').textContent   = c.nome;

  atualizarBotaoEnviar();
  atualizarPreview();

  // Scroll para o painel de envio no mobile
  if (window.innerWidth < 1200) {
    document.getElementById('msgTexto').scrollIntoView({behavior:'smooth', block:'start'});
  }
}

function limparSelecao() {
  clienteAtual = null;
  document.getElementById('placeholderCliente').style.display     = 'block';
  document.getElementById('clienteSelecionadoCard').style.display = 'none';
  document.getElementById('prevNomeWa').textContent               = 'Cliente';
  document.getElementById('prevAvatarWa').textContent             = '?';
  atualizarBotaoEnviar();
}

// ── TEMPLATES ──
function usarTemplate(msg) {
  document.getElementById('msgTexto').value = msg;
  atualizarPreview();
  atualizarCount();
  atualizarBotaoEnviar();
}

function inserirVar(variavel) {
  const ta  = document.getElementById('msgTexto');
  const ini = ta.selectionStart;
  const fim = ta.selectionEnd;
  ta.value  = ta.value.substring(0, ini) + variavel + ta.value.substring(fim);
  ta.selectionStart = ta.selectionEnd = ini + variavel.length;
  ta.focus();
  atualizarPreview();
  atualizarCount();
}

// ── PREVIEW ──
function resolverVariaveis(texto) {
  if (!texto) return '';
  const nome = clienteAtual ? clienteAtual.nome     : '{nome}';
  const tel  = clienteAtual ? clienteAtual.telefone : '{telefone}';
  const hoje = new Date().toLocaleDateString('pt-BR');
  return texto
    .replace(/{nome}/g,      nome)
    .replace(/{telefone}/g,  tel)
    .replace(/{barbearia}/g, BARBEARIA)
    .replace(/{link}/g,      LINK_FILA)
    .replace(/{data}/g,      hoje);
}

function atualizarPreview() {
  const raw      = document.getElementById('msgTexto').value;
  const resolvido = resolverVariaveis(raw);
  document.getElementById('prevBubble').textContent =
    resolvido || 'A mensagem aparecerá aqui conforme você digita…';
  atualizarBotaoEnviar();
}

function atualizarCount() {
  const n = document.getElementById('msgTexto').value.length;
  document.getElementById('charCount').textContent = n + ' caractere' + (n !== 1 ? 's' : '');
}

function atualizarBotaoEnviar() {
  const btn  = document.getElementById('btnEnviar');
  const msg  = document.getElementById('msgTexto').value.trim();
  const pronto = clienteAtual && msg;

  if (pronto) {
    const tel       = clienteAtual.telefone.replace(/\D/g,'');
    const numBr     = tel.startsWith('55') ? tel : '55' + tel;
    const msgFinal  = resolverVariaveis(msg);
    btn.href        = `https://wa.me/${numBr}?text=${encodeURIComponent(msgFinal)}`;
    btn.style.opacity         = '1';
    btn.style.pointerEvents   = 'auto';
  } else {
    btn.href                  = '#';
    btn.style.opacity         = '.4';
    btn.style.pointerEvents   = 'none';
  }
}

// ── REGISTRAR ENVIO ──
function registrarEnvio() {
  if (!clienteAtual) return;
  const msg = resolverVariaveis(document.getElementById('msgTexto').value.trim());
  if (!msg) return;
  fetch('whatsapp_clientes.php', {
    method: 'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: new URLSearchParams({
      acao:       'registrar_envio',
      cliente_id: clienteAtual.id,
      telefone:   clienteAtual.telefone,
      mensagem:   msg,
    })
  });
  // Incrementa visualmente no histórico
  setTimeout(() => location.reload(), 2500);
}

// ── MODAL TEMPLATE ──
function abrirModalTemplate() {
  document.getElementById('tplAcao').value    = 'salvar_template';
  document.getElementById('tplId').value      = '';
  document.getElementById('tplModalTitle').innerHTML =
    '<i class="bi bi-collection me-2" style="color:#f59e0b"></i>Novo Template';
  document.getElementById('tplEmoji').value   = '💬';
  document.getElementById('tplTitulo').value  = '';
  document.getElementById('tplMensagem').value= '';
  new bootstrap.Modal(document.getElementById('modalTemplate')).show();
}

function editarTemplate(id, tpl) {
  document.getElementById('tplAcao').value    = 'editar_template';
  document.getElementById('tplId').value      = id;
  document.getElementById('tplModalTitle').innerHTML =
    '<i class="bi bi-pencil-fill me-2" style="color:#f59e0b"></i>Editar Template';
  document.getElementById('tplEmoji').value   = tpl.emoji   || '💬';
  document.getElementById('tplTitulo').value  = tpl.titulo  || '';
  document.getElementById('tplMensagem').value= tpl.mensagem|| '';
  new bootstrap.Modal(document.getElementById('modalTemplate')).show();
}

// ── UTILS ──
function escHtml(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function hashCode(s) {
  let h=0; for(let i=0;i<s.length;i++) h=Math.imul(31,h)+s.charCodeAt(i)|0; return h;
}

// Sidebar mobile

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// Carrega lista inicial
buscarClientes();

// ══════════════════════════════════════════════
// ── DISPARO EM MASSA ──
// ══════════════════════════════════════════════
const SEGMENTOS   = ['todos','vip','freq','sumidos','inativos','novos'];
let massaClientes = [];
let massaSeg      = 'todos';
let massaDisparo  = false;
let massaPausado  = false;
let massaIdx      = 0;
const CONTADORES  = {};

// Carregar contadores de todos os segmentos ao iniciar
async function carregarContadores() {
  for (const seg of SEGMENTOS) {
    try {
      const r = await fetch(`whatsapp_clientes.php?ajax_segmento=1&seg=${seg}`);
      const d = await r.json();
      CONTADORES[seg] = d;
      const el = document.getElementById('cnt_' + seg);
      if (el) el.textContent = d.length;
    } catch(e) {}
  }
  // Carregar lista inicial (todos)
  renderizarListaMassa(CONTADORES['todos'] || []);
}

function renderizarListaMassa(lista) {
  massaClientes = lista;
  const box = document.getElementById('massaListaClientes');
  const label = document.getElementById('massaListaLabel');
  label.textContent = lista.length
    ? `${lista.length} cliente${lista.length !== 1 ? 's' : ''} neste segmento`
    : 'Nenhum cliente neste segmento';

  if (!lista.length) {
    box.innerHTML = `<div style="text-align:center;padding:1rem;color:rgba(255,255,255,.2);font-size:.82rem">
      <i class="bi bi-emoji-frown" style="font-size:1.5rem;display:block;margin-bottom:.3rem"></i>
      Nenhum cliente encontrado
    </div>`;
    atualizarBotaoDisparo();
    return;
  }

  const frag = document.createDocumentFragment();
  lista.slice(0, 50).forEach(c => {
    const cor  = CORES[Math.abs(hashCode(c.nome)) % CORES.length];
    const inic = c.nome.charAt(0).toUpperCase();
    const isVip = parseInt(c.total_concluido) >= 10;
    const isFreq = parseInt(c.total_concluido) >= 3 && !isVip;
    const badge = isVip ? '⭐' : isFreq ? '✓' : '✦';
    const div = document.createElement('div');
    div.className = 'massa-cliente-item';
    div.innerHTML = `
      <div class="mc-avatar" style="background:${cor}22;color:${cor}">${inic}</div>
      <div style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#fff;font-size:.82rem">${escHtml(c.nome)}</div>
      <div style="font-size:.72rem;color:rgba(255,255,255,.35);flex-shrink:0">${escHtml(c.telefone)}</div>
      <span style="font-size:.7rem;flex-shrink:0">${badge}</span>`;
    frag.appendChild(div);
  });

  if (lista.length > 50) {
    const more = document.createElement('div');
    more.style.cssText = 'text-align:center;padding:.4rem;font-size:.75rem;color:rgba(255,255,255,.3)';
    more.textContent = `+ ${lista.length - 50} outros clientes`;
    frag.appendChild(more);
  }

  box.innerHTML = '';
  box.appendChild(frag);
  atualizarBotaoDisparo();
}

// Troca de segmento
document.querySelectorAll('.massa-seg-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.massa-seg-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    massaSeg = btn.dataset.seg;
    if (CONTADORES[massaSeg] !== undefined) {
      renderizarListaMassa(CONTADORES[massaSeg]);
    } else {
      document.getElementById('massaListaClientes').innerHTML =
        '<div style="text-align:center;padding:1rem;color:rgba(255,255,255,.2);font-size:.82rem"><span class="spinner-border spinner-border-sm me-1"></span> Carregando…</div>';
      fetch(`whatsapp_clientes.php?ajax_segmento=1&seg=${massaSeg}`)
        .then(r => r.json()).then(d => { CONTADORES[massaSeg] = d; renderizarListaMassa(d); });
    }
  });
});

function usarTemplateMassa(msg) {
  document.getElementById('massaMsgTexto').value = msg;
  atualizarMassaPreview();
  atualizarMassaCount();
}

function atualizarMassaCount() {
  const n = document.getElementById('massaMsgTexto').value.length;
  document.getElementById('massaCharCount').textContent = n + ' caractere' + (n !== 1 ? 's' : '');
  atualizarBotaoDisparo();
}

function atualizarMassaPreview() {
  const raw = document.getElementById('massaMsgTexto').value;
  const wrap = document.getElementById('massaPreviewWrap');
  const bubble = document.getElementById('massaBubble');
  if (!raw.trim()) { wrap.style.display = 'none'; return; }
  wrap.style.display = 'block';
  const hoje = new Date().toLocaleDateString('pt-BR');
  bubble.textContent = raw
    .replace(/{nome}/g, 'Cliente Exemplo')
    .replace(/{telefone}/g, '(11) 99999-9999')
    .replace(/{barbearia}/g, BARBEARIA)
    .replace(/{link}/g, LINK_FILA)
    .replace(/{data}/g, hoje);
}

function atualizarBotaoDisparo() {
  const btn = document.getElementById('btnDispararMassa');
  const msg = (document.getElementById('massaMsgTexto')?.value || '').trim();
  const qtd = massaClientes.length;
  document.getElementById('btnDisparoQtd').textContent = qtd;
  if (qtd > 0 && msg) {
    btn.style.opacity = '1';
    btn.style.pointerEvents = 'auto';
  } else {
    btn.style.opacity = '.5';
    btn.style.pointerEvents = 'none';
  }
}

async function iniciarDisparo() {
  if (!massaClientes.length) return;
  const msg = document.getElementById('massaMsgTexto').value.trim();
  if (!msg) return;

  if (!confirm(`Disparar mensagem para ${massaClientes.length} clientes?\nCada um abrirá no WhatsApp — confirme cada envio.`)) return;

  massaDisparo = true;
  massaPausado = false;
  massaIdx     = 0;

  document.getElementById('btnDispararMassa').style.display = 'none';
  document.getElementById('btnPausarMassa').style.display   = 'inline-flex';
  document.getElementById('massaProgWrap').style.display    = 'block';

  const hoje = new Date().toLocaleDateString('pt-BR');

  for (let i = 0; i < massaClientes.length; i++) {
    // Aguarda despausar
    while (massaPausado) { await sleep(500); }
    if (!massaDisparo) break;

    const cli = massaClientes[i];
    massaIdx  = i + 1;

    // Atualizar progresso
    const pct = Math.round((massaIdx / massaClientes.length) * 100);
    document.getElementById('massaProgFill').style.width  = pct + '%';
    document.getElementById('massaProgTexto').textContent = `${massaIdx} / ${massaClientes.length}`;

    // Resolver variáveis
    const msgFinal = msg
      .replace(/{nome}/g, cli.nome)
      .replace(/{telefone}/g, cli.telefone)
      .replace(/{barbearia}/g, BARBEARIA)
      .replace(/{link}/g, LINK_FILA)
      .replace(/{data}/g, hoje);

    // Abrir WhatsApp
    const tel    = cli.telefone.replace(/\D/g, '');
    const numBr  = tel.startsWith('55') ? tel : '55' + tel;
    window.open(`https://wa.me/${numBr}?text=${encodeURIComponent(msgFinal)}`, '_blank');

    // Registrar no histórico
    fetch('whatsapp_clientes.php', {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body: new URLSearchParams({
        acao: 'registrar_envio', cliente_id: cli.id,
        telefone: cli.telefone, mensagem: msgFinal,
      })
    });

    // Intervalo entre envios
    await sleep(1200);
  }

  // Finalizado
  massaDisparo = false;
  document.getElementById('btnDispararMassa').style.display = 'flex';
  document.getElementById('btnPausarMassa').style.display   = 'none';
  document.getElementById('btnDisparoTxt').innerHTML =
    `<i class="bi bi-check2-circle me-1"></i> Concluído! ${massaIdx} mensagens`;
  setTimeout(() => {
    document.getElementById('btnDisparoTxt').innerHTML =
      `Disparar para <span id="btnDisparoQtd">${massaClientes.length}</span> clientes`;
    document.getElementById('massaProgWrap').style.display = 'none';
  }, 4000);
}

function pausarDisparo() {
  massaPausado = !massaPausado;
  const btn = document.getElementById('btnPausarMassa');
  btn.innerHTML = massaPausado
    ? '<i class="bi bi-play-fill"></i> Retomar'
    : '<i class="bi bi-pause-fill"></i> Pausar';
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// Carregar ao iniciar
carregarContadores();

</script>
</body>
</html>