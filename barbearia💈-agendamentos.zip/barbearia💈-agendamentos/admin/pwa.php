<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

$nomeBarbearia = getConfig('nome_barbearia');

// ── Verifica GD ──
$gdOk = extension_loaded('gd') && function_exists('imagecreatefromstring');

// ── Tamanhos gerenciados ──
$tamanhos = [72, 96, 128, 144, 152, 192, 384, 512];
$iconsDir = __DIR__ . '/../icons/';

// ── Garante que a pasta existe ──
if (!is_dir($iconsDir)) {
    mkdir($iconsDir, 0755, true);
}

// ── AÇÕES POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    // ── Upload e redimensionamento ──
    if ($acao === 'upload_icone' && $gdOk) {
        $file = $_FILES['icone'] ?? null;

        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            flash('danger', 'Erro no upload. Tente novamente.');
        } else {
            $mime = mime_content_type($file['tmp_name']);
            if (!in_array($mime, ['image/png','image/jpeg','image/jpg','image/webp','image/gif'])) {
                flash('danger', 'Formato inválido. Use PNG, JPG ou WebP.');
            } else {
                $src = imagecreatefromstring(file_get_contents($file['tmp_name']));
                if (!$src) {
                    flash('danger', 'Não foi possível processar a imagem.');
                } else {
                    $ok    = 0;
                    $falha = 0;
                    foreach ($tamanhos as $tam) {
                        $dst = imagecreatetruecolor($tam, $tam);
                        imagealphablending($dst, false);
                        imagesavealpha($dst, true);
                        $transp = imagecolorallocatealpha($dst, 0, 0, 0, 127);
                        imagefilledrectangle($dst, 0, 0, $tam, $tam, $transp);
                        imagealphablending($dst, true);
                        $srcW = imagesx($src);
                        $srcH = imagesy($src);
                        $razao = min($srcW, $srcH);
                        $srcX  = (int)(($srcW - $razao) / 2);
                        $srcY  = (int)(($srcH - $razao) / 2);
                        imagecopyresampled($dst, $src, 0, 0, $srcX, $srcY, $tam, $tam, $razao, $razao);
                        $destFile = $iconsDir . "icon-{$tam}.png";
                        if (imagepng($dst, $destFile, 9)) {
                            $ok++;
                        } else {
                            $falha++;
                        }
                        imagedestroy($dst);
                    }
                    imagedestroy($src);

                    $faviconSrc = imagecreatefromstring(file_get_contents($file['tmp_name']));
                    $faviconDst = imagecreatetruecolor(32, 32);
                    imagealphablending($faviconDst, false);
                    imagesavealpha($faviconDst, true);
                    $t = imagecolorallocatealpha($faviconDst, 0, 0, 0, 127);
                    imagefilledrectangle($faviconDst, 0, 0, 32, 32, $t);
                    imagealphablending($faviconDst, true);
                    $sW = imagesx($faviconSrc); $sH = imagesy($faviconSrc);
                    $rz = min($sW,$sH); $sX = (int)(($sW-$rz)/2); $sY = (int)(($sH-$rz)/2);
                    imagecopyresampled($faviconDst, $faviconSrc, 0,0,$sX,$sY,32,32,$rz,$rz);
                    imagepng($faviconDst, __DIR__ . '/../favicon.png');
                    imagedestroy($faviconDst);
                    imagedestroy($faviconSrc);

                    atualizarManifest($iconsDir, $tamanhos, $nomeBarbearia, $db);
                    setConfig('pwa_icone_atualizado', date('Y-m-d H:i:s'));

                    if ($falha === 0) {
                        flash('success', "✅ {$ok} ícones gerados com sucesso! O PWA foi atualizado.");
                    } else {
                        flash('warning', "{$ok} ícones gerados, {$falha} falharam. Verifique permissões da pasta.");
                    }
                }
            }
        }
        header('Location: pwa.php'); exit;
    }

    // ── Atualiza apenas o manifest ──
    if ($acao === 'salvar_manifest') {
        $nomeApp    = trim($_POST['nome_app']    ?? $nomeBarbearia);
        $nomeShort  = trim($_POST['nome_short']  ?? $nomeBarbearia);
        $corTema    = trim($_POST['cor_tema']    ?? '#e94560');
        $corFundo   = trim($_POST['cor_fundo']   ?? '#1a1a2e');
        $startUrl   = trim($_POST['start_url']   ?? BASE_URL . '/');
        $display    = trim($_POST['display']     ?? 'standalone');

        setConfig('pwa_nome_app',   $nomeApp);
        setConfig('pwa_nome_short', $nomeShort);
        setConfig('pwa_cor_tema',   $corTema);
        setConfig('pwa_cor_fundo',  $corFundo);
        setConfig('pwa_start_url',  $startUrl);
        setConfig('pwa_display',    $display);

        atualizarManifest($iconsDir, $tamanhos, $nomeApp, $db);
        flash('success', 'Manifest atualizado! Reinstale o PWA para ver as mudanças.');
        header('Location: pwa.php'); exit;
    }

    // ── Restaurar ícone padrão ──
    if ($acao === 'restaurar_padrao') {
        foreach ($tamanhos as $tam) {
            $f = $iconsDir . "icon-{$tam}.png";
            if (file_exists($f)) unlink($f);
        }
        setConfig('pwa_icone_atualizado', '');
        atualizarManifest($iconsDir, $tamanhos, $nomeBarbearia, $db);
        flash('warning', 'Ícones removidos. O PWA usará os ícones padrão.');
        header('Location: pwa.php'); exit;
    }
}

// ── Gera/atualiza manifest.php ──
function atualizarManifest(string $iconsDir, array $tamanhos, string $nomeApp, $db): void {
    $nomeShort = getConfig('pwa_nome_short') ?: $nomeApp;
    $corTema   = getConfig('pwa_cor_tema')   ?: '#e94560';
    $corFundo  = getConfig('pwa_cor_fundo')  ?: '#1a1a2e';
    $startUrl  = getConfig('pwa_start_url')  ?: BASE_URL . '/';
    $display   = getConfig('pwa_display')    ?: 'standalone';

    $icons = [];
    foreach ($tamanhos as $tam) {
        $file = $iconsDir . "icon-{$tam}.png";
        if (file_exists($file)) {
            $icons[] = [
                'src'     => BASE_URL . "/icons/icon-{$tam}.png?v=" . filemtime($file),
                'sizes'   => "{$tam}x{$tam}",
                'type'    => 'image/png',
                'purpose' => $tam >= 192 ? 'any maskable' : 'any',
            ];
        }
    }

    if (empty($icons)) {
        foreach ($tamanhos as $tam) {
            $icons[] = [
                'src'     => BASE_URL . "/icons/icon-{$tam}.png",
                'sizes'   => "{$tam}x{$tam}",
                'type'    => 'image/png',
                'purpose' => $tam >= 192 ? 'any maskable' : 'any',
            ];
        }
    }

    $manifest = [
        'name'             => $nomeApp,
        'short_name'       => $nomeShort,
        'description'      => "Sistema de fila online – {$nomeApp}",
        'start_url'        => $startUrl,
        'display'          => $display,
        'background_color' => $corFundo,
        'theme_color'      => $corTema,
        'orientation'      => 'portrait-primary',
        'icons'            => $icons,
    ];

    file_put_contents(
        __DIR__ . '/../manifest.php',
        json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );
}

// ── Lê configs atuais ──
$pwaConfig = [
    'nome_app'   => getConfig('pwa_nome_app')   ?: $nomeBarbearia,
    'nome_short' => getConfig('pwa_nome_short') ?: $nomeBarbearia,
    'cor_tema'   => getConfig('pwa_cor_tema')   ?: '#e94560',
    'cor_fundo'  => getConfig('pwa_cor_fundo')  ?: '#1a1a2e',
    'start_url'  => getConfig('pwa_start_url')  ?: BASE_URL . '/',
    'display'    => getConfig('pwa_display')    ?: 'standalone',
];
$ultimoUpdate = getConfig('pwa_icone_atualizado') ?: null;

// ── Status dos ícones ──
$iconsStatus = [];
foreach ($tamanhos as $tam) {
    $file = $iconsDir . "icon-{$tam}.png";
    $iconsStatus[$tam] = [
        'existe'  => file_exists($file),
        'tamanho' => file_exists($file) ? round(filesize($file) / 1024, 1) . ' KB' : '—',
        'mtime'   => file_exists($file) ? date('d/m/y H:i', filemtime($file)) : null,
    ];
}
$totalIcones   = count(array_filter($iconsStatus, fn($i) => $i['existe']));
$manifestExist = file_exists(__DIR__ . '/../manifest.php');

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PWA – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}
  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);
    border-radius:18px;padding:1.5rem;margin-bottom:1.25rem}
  .card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1.25rem;
    display:flex;align-items:center;gap:.5rem}
  .upload-zone{border:2px dashed rgba(233,69,96,.35);border-radius:16px;
    padding:2.5rem 1.5rem;text-align:center;cursor:pointer;
    transition:all .3s;position:relative;background:rgba(233,69,96,.04)}
  .upload-zone:hover,.upload-zone.drag{border-color:var(--primary);background:rgba(233,69,96,.09)}
  .upload-zone input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%}
  .upload-icon{font-size:3rem;color:rgba(233,69,96,.5);margin-bottom:.75rem;display:block}
  .upload-title{font-weight:700;color:#fff;font-size:1rem;margin-bottom:.3rem}
  .upload-sub{font-size:.83rem;color:rgba(255,255,255,.4)}
  .icon-preview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:.75rem}
  .icon-preview-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
    border-radius:12px;padding:.75rem;text-align:center;transition:.2s}
  .icon-preview-item:hover{background:rgba(255,255,255,.07)}
  .icon-preview-item.ok{border-color:rgba(34,197,94,.25)}
  .icon-preview-item.missing{border-color:rgba(239,68,68,.2);opacity:.6}
  .icon-img{border-radius:8px;object-fit:cover;display:block;margin:0 auto .5rem}
  .icon-size-label{font-size:.78rem;font-weight:700;color:#fff}
  .icon-meta{font-size:.68rem;color:rgba(255,255,255,.35);margin-top:.15rem}
  .icon-badge-ok{background:rgba(34,197,94,.15);color:#4ade80;border-radius:20px;
    padding:.1rem .5rem;font-size:.68rem;font-weight:700}
  .icon-badge-miss{background:rgba(239,68,68,.12);color:#f87171;border-radius:20px;
    padding:.1rem .5rem;font-size:.68rem;font-weight:700}
  .status-row{display:flex;align-items:center;gap:.75rem;padding:.75rem 1rem;
    background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);
    border-radius:11px;margin-bottom:.5rem}
  .status-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
  .status-label{font-size:.85rem;color:rgba(255,255,255,.7);flex:1}
  .status-val{font-size:.8rem;color:rgba(255,255,255,.4)}
  .form-control-pwa{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.6rem 1rem;width:100%;font-size:.9rem;transition:.2s}
  .form-control-pwa:focus{outline:none;border-color:var(--primary);background:rgba(255,255,255,.1);
    box-shadow:0 0 0 3px rgba(233,69,96,.15)}
  .form-control-pwa::placeholder{color:rgba(255,255,255,.3)}
  .form-select-pwa{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.6rem 1rem;width:100%;font-size:.9rem;
    appearance:none;cursor:pointer}
  .form-select-pwa option{background:#1a1a2e;color:#fff}
  .form-label-pwa{color:rgba(255,255,255,.65);font-size:.83rem;font-weight:600;margin-bottom:.35rem;display:block}
  .cor-preview{width:36px;height:36px;border-radius:8px;border:2px solid rgba(255,255,255,.2);
    cursor:pointer;flex-shrink:0}
  .gd-alert{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);
    border-radius:12px;padding:1rem 1.25rem;margin-bottom:1.25rem;
    display:flex;align-items:flex-start;gap:.75rem}
  .btn-pwa-primary{background:linear-gradient(135deg,var(--primary),#c41230);
    border:none;color:#fff;border-radius:10px;padding:.65rem 1.25rem;
    font-weight:700;cursor:pointer;font-size:.9rem;transition:.2s;
    display:inline-flex;align-items:center;gap:.4rem}
  .btn-pwa-primary:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(233,69,96,.3)}
  .btn-pwa-sec{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:rgba(255,255,255,.7);border-radius:10px;padding:.65rem 1.25rem;
    font-weight:600;cursor:pointer;font-size:.9rem;transition:.2s;
    display:inline-flex;align-items:center;gap:.4rem;text-decoration:none}
  .btn-pwa-sec:hover{background:rgba(255,255,255,.12);color:#fff}
  .btn-danger-pwa{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);
    color:#f87171;border-radius:10px;padding:.65rem 1.25rem;
    font-weight:600;cursor:pointer;font-size:.9rem;transition:.2s;
    display:inline-flex;align-items:center;gap:.4rem}
  .btn-danger-pwa:hover{background:rgba(239,68,68,.22)}
  h4,h5,h6{color:#fff;margin:0}
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
    .icon-preview-grid{grid-template-columns:repeat(auto-fill,minmax(90px,1fr))}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">PWA & Ícones</h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
          Gerencie os ícones e configurações do app instalável
        </div>
      </div>
    </div>
    <a href="dashboard.php" class="btn-pwa-sec" style="font-size:.82rem;padding:.4rem .9rem">
      <i class="bi bi-arrow-left"></i> Dashboard
    </a>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <?php if (!$gdOk): ?>
    <div class="gd-alert">
      <i class="bi bi-exclamation-triangle-fill" style="color:#f87171;font-size:1.3rem;flex-shrink:0;margin-top:.1rem"></i>
      <div>
        <div style="font-weight:700;color:#fff;margin-bottom:.25rem">Extensão GD não encontrada</div>
        <div style="font-size:.85rem;color:rgba(255,255,255,.6)">
          O redimensionamento automático de imagens requer a extensão <strong>GD</strong> do PHP.
          Entre em contato com o suporte da hospedagem e solicite a ativação do <code>php_gd2</code>.
          Enquanto isso, você pode subir os ícones manualmente na pasta <code><?= BASE_URL ?>/icons/</code>.
        </div>
      </div>
    </div>
    <?php endif; ?>

    <div class="row g-3">

      <!-- ══ COLUNA ESQUERDA ══ -->
      <div class="col-12 col-lg-6">

        <!-- Status geral -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-info-circle-fill" style="color:#3b82f6"></i>Status do PWA
          </div>
          <div class="status-row">
            <div class="status-dot" style="background:<?= $gdOk ? '#4ade80' : '#f87171' ?>"></div>
            <div class="status-label">Extensão GD (redimensionamento)</div>
            <div class="status-val" style="color:<?= $gdOk ? '#4ade80' : '#f87171' ?>"><?= $gdOk ? 'Ativa' : 'Inativa' ?></div>
          </div>
          <div class="status-row">
            <div class="status-dot" style="background:<?= $manifestExist ? '#4ade80' : '#f87171' ?>"></div>
            <div class="status-label">manifest.php</div>
            <div class="status-val" style="color:<?= $manifestExist ? '#4ade80' : '#f87171' ?>"><?= $manifestExist ? 'Presente' : 'Ausente' ?></div>
          </div>
          <div class="status-row">
            <div class="status-dot" style="background:<?= $totalIcones === count($tamanhos) ? '#4ade80' : ($totalIcones > 0 ? '#fbbf24' : '#f87171') ?>"></div>
            <div class="status-label">Ícones gerados</div>
            <div class="status-val"><?= $totalIcones ?>/<?= count($tamanhos) ?></div>
          </div>
          <?php if (is_writable($iconsDir)): ?>
          <div class="status-row">
            <div class="status-dot" style="background:#4ade80"></div>
            <div class="status-label">Pasta <code style="font-size:.75rem">icons/</code> com permissão de escrita</div>
            <div class="status-val" style="color:#4ade80">Ok</div>
          </div>
          <?php else: ?>
          <div class="status-row">
            <div class="status-dot" style="background:#f87171"></div>
            <div class="status-label">Pasta <code style="font-size:.75rem">icons/</code> sem permissão de escrita</div>
            <div class="status-val" style="color:#f87171">Erro</div>
          </div>
          <?php endif; ?>
          <?php if ($ultimoUpdate): ?>
          <div class="status-row">
            <div class="status-dot" style="background:#a78bfa"></div>
            <div class="status-label">Último upload de ícone</div>
            <div class="status-val"><?= date('d/m/y H:i', strtotime($ultimoUpdate)) ?></div>
          </div>
          <?php endif; ?>
        </div>

        <!-- Upload -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-upload" style="color:var(--primary)"></i>Novo Ícone
          </div>
          <?php if ($gdOk): ?>
          <form method="POST" enctype="multipart/form-data" id="formUpload">
            <input type="hidden" name="acao" value="upload_icone">
            <div class="upload-zone" id="uploadZone">
              <input type="file" name="icone" id="inputIcone" accept="image/*" required>
              <i class="bi bi-image upload-icon" id="uploadIconeEl"></i>
              <div class="upload-title" id="uploadTitle">Clique ou arraste a imagem aqui</div>
              <div class="upload-sub">PNG, JPG ou WebP · Recomendado: 512×512px ou maior · Quadrada</div>
              <div id="uploadPreviewWrap" style="display:none;margin-top:1rem">
                <img id="uploadPreview" src="" alt=""
                     style="width:80px;height:80px;border-radius:12px;object-fit:cover;
                            border:2px solid rgba(233,69,96,.4);margin:0 auto;display:block">
                <div id="uploadFileName" style="font-size:.78rem;color:rgba(255,255,255,.4);margin-top:.4rem;text-align:center"></div>
              </div>
            </div>
            <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);
                        border-radius:10px;padding:.75rem 1rem;margin-top:.85rem;margin-bottom:1rem">
              <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.4rem;font-weight:600">
                Serão gerados automaticamente:
              </div>
              <div style="display:flex;gap:.3rem;flex-wrap:wrap">
                <?php foreach ($tamanhos as $tam): ?>
                <span style="background:rgba(233,69,96,.12);border:1px solid rgba(233,69,96,.2);
                             color:#e94560;border-radius:6px;padding:.15rem .5rem;font-size:.72rem;font-weight:700">
                  <?= $tam ?>px
                </span>
                <?php endforeach; ?>
                <span style="background:rgba(59,130,246,.12);border:1px solid rgba(59,130,246,.2);
                             color:#60a5fa;border-radius:6px;padding:.15rem .5rem;font-size:.72rem;font-weight:700">
                  32px favicon
                </span>
              </div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
              <button type="submit" class="btn-pwa-primary flex-grow-1" id="btnUpload">
                <i class="bi bi-upload"></i> Gerar e Aplicar Ícones
              </button>
              <?php if ($totalIcones > 0): ?>
              <form method="POST" class="d-inline"
                    onsubmit="return confirm('Remover todos os ícones personalizados?')">
                <input type="hidden" name="acao" value="restaurar_padrao">
                <button type="submit" class="btn-danger-pwa">
                  <i class="bi bi-arrow-counterclockwise"></i> Restaurar Padrão
                </button>
              </form>
              <?php endif; ?>
            </div>
          </form>
          <?php else: ?>
          <div style="text-align:center;padding:2rem 0;color:rgba(255,255,255,.3)">
            <i class="bi bi-exclamation-circle" style="font-size:2.5rem;display:block;margin-bottom:.5rem"></i>
            Upload indisponível — GD não está ativo.<br>
            <span style="font-size:.82rem">Ative a extensão GD na hospedagem.</span>
          </div>
          <?php endif; ?>
        </div>

        <!-- Configurações do Manifest -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-file-code-fill" style="color:#f59e0b"></i>Configurações do App (manifest.php)
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_manifest">
            <div class="row g-3">
              <div class="col-12">
                <label class="form-label-pwa">Nome completo do app</label>
                <input type="text" name="nome_app" class="form-control-pwa" maxlength="60"
                       value="<?= htmlspecialchars($pwaConfig['nome_app']) ?>"
                       placeholder="Ex: Barbearia Renato Barber">
              </div>
              <div class="col-12">
                <label class="form-label-pwa">Nome curto (aparece embaixo do ícone)</label>
                <input type="text" name="nome_short" class="form-control-pwa" maxlength="12"
                       value="<?= htmlspecialchars($pwaConfig['nome_short']) ?>"
                       placeholder="Ex: Barbearia">
                <div style="font-size:.72rem;color:rgba(255,255,255,.3);margin-top:.25rem">Máximo 12 caracteres</div>
              </div>
              <div class="col-6">
                <label class="form-label-pwa">Cor do tema (barra superior)</label>
                <div class="d-flex gap-2 align-items-center">
                  <div class="cor-preview" id="prevTema"
                       style="background:<?= htmlspecialchars($pwaConfig['cor_tema']) ?>"
                       onclick="document.getElementById('inpCorTema').click()"></div>
                  <input type="color" name="cor_tema" id="inpCorTema"
                         value="<?= htmlspecialchars($pwaConfig['cor_tema']) ?>"
                         style="opacity:0;width:0;height:0;position:absolute"
                         oninput="document.getElementById('prevTema').style.background=this.value;
                                  document.getElementById('lblCorTema').textContent=this.value">
                  <span id="lblCorTema" style="font-size:.85rem;color:rgba(255,255,255,.6)">
                    <?= htmlspecialchars($pwaConfig['cor_tema']) ?>
                  </span>
                </div>
              </div>
              <div class="col-6">
                <label class="form-label-pwa">Cor de fundo (splash)</label>
                <div class="d-flex gap-2 align-items-center">
                  <div class="cor-preview" id="prevFundo"
                       style="background:<?= htmlspecialchars($pwaConfig['cor_fundo']) ?>"
                       onclick="document.getElementById('inpCorFundo').click()"></div>
                  <input type="color" name="cor_fundo" id="inpCorFundo"
                         value="<?= htmlspecialchars($pwaConfig['cor_fundo']) ?>"
                         style="opacity:0;width:0;height:0;position:absolute"
                         oninput="document.getElementById('prevFundo').style.background=this.value;
                                  document.getElementById('lblCorFundo').textContent=this.value">
                  <span id="lblCorFundo" style="font-size:.85rem;color:rgba(255,255,255,.6)">
                    <?= htmlspecialchars($pwaConfig['cor_fundo']) ?>
                  </span>
                </div>
              </div>
              <div class="col-12">
                <label class="form-label-pwa">URL de início</label>
                <input type="text" name="start_url" class="form-control-pwa"
                       value="<?= htmlspecialchars($pwaConfig['start_url']) ?>"
                       placeholder="<?= BASE_URL ?>/">
              </div>
              <div class="col-12">
                <label class="form-label-pwa">Modo de exibição</label>
                <select name="display" class="form-select-pwa">
                  <?php foreach(['standalone'=>'Standalone (app nativo)','fullscreen'=>'Fullscreen','minimal-ui'=>'Minimal UI','browser'=>'Navegador'] as $v=>$l): ?>
                  <option value="<?= $v ?>" <?= $pwaConfig['display']===$v?'selected':'' ?>><?= $l ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div style="margin-top:1.1rem">
              <button type="submit" class="btn-pwa-primary">
                <i class="bi bi-floppy-fill"></i> Salvar e Atualizar Manifest
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- ══ COLUNA DIREITA ══ -->
      <div class="col-12 col-lg-6">

        <!-- Grid de ícones -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-grid-3x3-gap-fill" style="color:#22c55e"></i>
            Ícones Atuais
            <span style="background:rgba(34,197,94,.15);color:#4ade80;border-radius:20px;
              padding:.1rem .55rem;font-size:.75rem;margin-left:.25rem">
              <?= $totalIcones ?>/<?= count($tamanhos) ?>
            </span>
          </div>
          <div class="icon-preview-grid">
            <?php foreach ($tamanhos as $tam):
              $st      = $iconsStatus[$tam];
              $imgFile = $iconsDir . "icon-{$tam}.png";
              $imgSrc  = $st['existe']
                ? BASE_URL . "/icons/icon-{$tam}.png?v=" . filemtime($imgFile)
                : null;
              $dispPx  = min($tam, 64);
            ?>
            <div class="icon-preview-item <?= $st['existe'] ? 'ok' : 'missing' ?>">
              <?php if ($imgSrc): ?>
                <img src="<?= $imgSrc ?>" width="<?= $dispPx ?>" height="<?= $dispPx ?>"
                     class="icon-img" alt="<?= $tam ?>px">
              <?php else: ?>
                <div class="icon-img"
                     style="width:<?= $dispPx ?>px;height:<?= $dispPx ?>px;
                            background:rgba(255,255,255,.05);border-radius:8px;
                            display:flex;align-items:center;justify-content:center;
                            margin:0 auto .5rem">
                  <i class="bi bi-image" style="color:rgba(255,255,255,.2);font-size:1.3rem"></i>
                </div>
              <?php endif; ?>
              <div class="icon-size-label"><?= $tam ?>×<?= $tam ?></div>
              <div class="icon-meta"><?= $st['tamanho'] ?></div>
              <div style="margin-top:.3rem">
                <?php if ($st['existe']): ?>
                  <span class="icon-badge-ok"><i class="bi bi-check2"></i> OK</span>
                <?php else: ?>
                  <span class="icon-badge-miss"><i class="bi bi-x"></i> Faltando</span>
                <?php endif; ?>
              </div>
              <?php if ($st['mtime']): ?>
              <div class="icon-meta" style="margin-top:.2rem"><?= $st['mtime'] ?></div>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
          <?php if ($totalIcones > 0): ?>
          <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid rgba(255,255,255,.06)">
            <div style="font-size:.78rem;color:rgba(255,255,255,.3);margin-bottom:.5rem">
              <i class="bi bi-info-circle me-1"></i>
              Após trocar os ícones, usuários que já instalaram o PWA precisam
              desinstalar e reinstalar para ver o novo ícone.
            </div>
            <a href="<?= BASE_URL ?>/icons/icon-192.png" target="_blank" class="btn-pwa-sec"
               style="font-size:.8rem;padding:.4rem .8rem">
              <i class="bi bi-eye"></i> Ver ícone 192px
            </a>
          </div>
          <?php endif; ?>
        </div>

        <!-- manifest.php atual -->
        <?php if ($manifestExist): ?>
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-braces" style="color:#8b5cf6"></i>manifest.php atual
          </div>
          <pre style="background:rgba(0,0,0,.3);border:1px solid rgba(255,255,255,.08);
                      border-radius:10px;padding:.85rem;font-size:.73rem;
                      color:rgba(255,255,255,.65);overflow-x:auto;max-height:280px;
                      white-space:pre-wrap;word-break:break-all;margin:0"><?= htmlspecialchars(
              file_get_contents(__DIR__ . '/../manifest.php')
          ) ?></pre>
        </div>
        <?php endif; ?>

        <!-- Dicas -->
        <div class="card-sec" style="border-color:rgba(245,158,11,.2)">
          <div class="card-title">
            <i class="bi bi-lightbulb-fill" style="color:#fbbf24"></i>Dicas para o melhor resultado
          </div>
          <?php
          $dicas = [
            ['bi-image',            '#60a5fa', 'Use uma imagem quadrada de pelo menos 512×512px para melhor qualidade em todos os tamanhos.'],
            ['bi-file-earmark-image','#4ade80', 'Prefira PNG com fundo transparente para ficar melhor no Android.'],
            ['bi-phone',            '#a78bfa', 'No iOS o ícone é sempre cortado em quadrado, então evite elementos nas bordas.'],
            ['bi-arrow-repeat',     '#fbbf24', 'Após atualizar, limpe o cache do navegador (Ctrl+Shift+R) para ver o novo ícone.'],
            ['bi-app-indicator',    '#e94560', 'O "Nome curto" aparece embaixo do ícone na tela inicial — mantenha curto e legível.'],
          ];
          foreach ($dicas as $d): ?>
          <div style="display:flex;gap:.65rem;align-items:flex-start;
                      padding:.5rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <i class="bi <?= $d[0] ?>" style="color:<?= $d[1] ?>;font-size:1rem;flex-shrink:0;margin-top:.1rem"></i>
            <div style="font-size:.83rem;color:rgba(255,255,255,.55);line-height:1.45"><?= $d[2] ?></div>
          </div>
          <?php endforeach; ?>
        </div>

      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

document.getElementById('inputIcone')?.addEventListener('change', function() {
  const file = this.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('uploadPreview').src           = e.target.result;
    document.getElementById('uploadFileName').textContent  = file.name + ' (' + (file.size/1024).toFixed(1) + ' KB)';
    document.getElementById('uploadPreviewWrap').style.display = 'block';
    document.getElementById('uploadIconeEl').style.display     = 'none';
    document.getElementById('uploadTitle').textContent         = 'Imagem selecionada ✓';
  };
  reader.readAsDataURL(file);
});

const zone = document.getElementById('uploadZone');
if (zone) {
  zone.addEventListener('dragover',  e => { e.preventDefault(); zone.classList.add('drag'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('drag');
    const dt = e.dataTransfer;
    if (dt.files.length) {
      document.getElementById('inputIcone').files = dt.files;
      document.getElementById('inputIcone').dispatchEvent(new Event('change'));
    }
  });
}

document.getElementById('formUpload')?.addEventListener('submit', function() {
  const btn = document.getElementById('btnUpload');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Gerando ícones...';
});
</script>
</body>
</html>