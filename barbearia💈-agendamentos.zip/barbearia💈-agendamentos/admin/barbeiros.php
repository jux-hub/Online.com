<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);
// Criar pasta de uploads
$uploadDir = __DIR__ . '/../uploads/barbeiros/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    if ($acao === 'salvar') {
        $id    = (int)($_POST['id'] ?? 0);
        $nome  = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $tel   = trim($_POST['telefone'] ?? '');
        $com   = (float)($_POST['comissao_percent'] ?? 50);
        $senha = $_POST['senha'] ?? '';
        $foto  = null;

        if (!$nome || !$email) {
            flash('danger', 'Nome e e-mail são obrigatórios.');
        } else {
            if (!empty($_FILES['foto']['name'])) {
                $ext   = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
                $allow = ['jpg','jpeg','png','webp'];
                if (!in_array($ext, $allow)) {
                    flash('danger', 'Foto inválida. Use JPG, PNG ou WEBP.');
                    header('Location: barbeiros.php'); exit;
                }
                $nomeArq = 'barb_' . time() . '_' . rand(100,999) . '.' . $ext;
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $uploadDir . $nomeArq)) {
                    $foto = $nomeArq;
                    if ($id) {
                        $old = $db->prepare('SELECT foto FROM usuarios WHERE id=?');
                        $old->execute([$id]);
                        $oldFoto = $old->fetch()['foto'] ?? '';
                        if ($oldFoto && file_exists($uploadDir . $oldFoto)) unlink($uploadDir . $oldFoto);
                    }
                }
            }

            if ($id) {
                if ($foto) {
                    $sql    = 'UPDATE usuarios SET nome=?,email=?,telefone=?,comissao_percent=?,foto=? WHERE id=?';
                    $params = [$nome,$email,$tel,$com,$foto,$id];
                } else {
                    $sql    = 'UPDATE usuarios SET nome=?,email=?,telefone=?,comissao_percent=? WHERE id=?';
                    $params = [$nome,$email,$tel,$com,$id];
                }
                if ($senha) {
                    $sql    = str_replace(' WHERE id=?', ',senha=? WHERE id=?', $sql);
                    array_splice($params, -1, 0, [password_hash($senha, PASSWORD_DEFAULT)]);
                }
                $db->prepare($sql)->execute($params);
                flash('success', 'Barbeiro atualizado!');
            } else {
                if (!$senha) {
                    flash('danger', 'Senha obrigatória para novo barbeiro.');
                } else {
                    try {
                        $db->prepare("INSERT INTO usuarios (nome,email,senha,tipo,telefone,comissao_percent,foto) VALUES (?,?,?,?,?,?,?)")
                           ->execute([$nome,$email,password_hash($senha,PASSWORD_DEFAULT),'barbeiro',$tel,$com,$foto]);
                        flash('success', 'Barbeiro cadastrado!');
                    } catch(Exception $e) { flash('danger', 'E-mail já cadastrado.'); }
                }
            }
        }
    } elseif ($acao === 'toggle') {
        $db->prepare('UPDATE usuarios SET ativo = CASE WHEN ativo=1 THEN 0 ELSE 1 END WHERE id=?')
           ->execute([(int)$_POST['id']]);
        flash('success', 'Status atualizado!');
    } elseif ($acao === 'excluir') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            // Remove foto do disco
            $row = $db->prepare('SELECT foto FROM usuarios WHERE id=?');
            $row->execute([$id]);
            $fotoAntiga = $row->fetch()['foto'] ?? '';
            if ($fotoAntiga && file_exists($uploadDir . $fotoAntiga)) {
                unlink($uploadDir . $fotoAntiga);
            }

            // Desativa foreign keys, remove vínculos e exclui
            try { $db->exec("PRAGMA foreign_keys = OFF"); } catch(Exception $e) {}
            try { $db->prepare('DELETE FROM fila_itens WHERE fila_id IN (SELECT id FROM fila WHERE barbeiro_id=?)')->execute([$id]); } catch(Exception $e) {}
            try { $db->prepare('DELETE FROM fila WHERE barbeiro_id=?')->execute([$id]); } catch(Exception $e) {}
            try { $db->prepare('DELETE FROM usuarios WHERE id=? AND tipo=?')->execute([$id, 'barbeiro']); } catch(Exception $e) {}
            try { $db->exec("PRAGMA foreign_keys = ON"); } catch(Exception $e) {}

            flash('success', 'Barbeiro excluído!');
        }
    }
    header('Location: barbeiros.php'); exit;
}

$barbeiros     = $db->query("SELECT * FROM usuarios WHERE tipo='barbeiro' ORDER BY nome")->fetchAll();
$nomeBarbearia = getConfig('nome_barbearia');

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Barbeiros – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif}
  .sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;background:linear-gradient(180deg,#1a1a2e,#16213e);border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08)}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:260px;padding:2rem;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center}

  .barb-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem;display:flex;align-items:center;gap:1rem;transition:.2s}
  .barb-card:hover{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.2)}
  .barb-avatar{width:60px;height:60px;border-radius:50%;object-fit:cover;border:2px solid rgba(233,69,96,.5);flex-shrink:0}
  .barb-avatar-placeholder{width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:flex;align-items:center;justify-content:center;flex-shrink:0;border:2px solid rgba(233,69,96,.5)}
  .barb-nome{font-weight:700;color:#fff;font-size:1rem;margin-bottom:.15rem}
  .barb-email{color:rgba(255,255,255,.5);font-size:.85rem}
  .barb-tel{color:rgba(255,255,255,.4);font-size:.8rem}
  .barb-com{color:#4ade80;font-weight:700;font-size:.9rem}
  .badge-ativo{background:rgba(34,197,94,.2);color:#4ade80;border-radius:6px;padding:.25rem .65rem;font-size:.78rem;font-weight:600}
  .badge-inativo{background:rgba(239,68,68,.2);color:#f87171;border-radius:6px;padding:.25rem .65rem;font-size:.78rem;font-weight:600}
  .btn-editar-card{background:rgba(59,130,246,.2);color:#60a5fa;border:none;border-radius:8px;padding:.4rem .75rem;transition:.2s;cursor:pointer}
  .btn-editar-card:hover{background:rgba(59,130,246,.35);color:#93c5fd}
  .btn-toggle-card{background:rgba(245,158,11,.2);color:#fbbf24;border:none;border-radius:8px;padding:.4rem .75rem;transition:.2s;cursor:pointer;width:100%}
  .btn-toggle-card:hover{background:rgba(245,158,11,.35)}
  .btn-excluir-card{background:rgba(239,68,68,.2);color:#f87171;border:none;border-radius:8px;padding:.4rem .75rem;transition:.2s;cursor:pointer;width:100%}
  .btn-excluir-card:hover{background:rgba(239,68,68,.35)}

  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12)}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08)}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08)}
  .modal-title{color:#fff}
  .form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.12);border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.4)}
  .form-control[type=file]{color:rgba(255,255,255,.7)}
  label{color:rgba(255,255,255,.8)}
  h5,h4{color:#fff}
  .btn-save{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;font-weight:600}
  .btn-save:hover{opacity:.9;color:#fff}
  .btn-danger-confirm{background:linear-gradient(135deg,#ef4444,#b91c1c);border:none;color:#fff;border-radius:10px;font-weight:600}
  .btn-danger-confirm:hover{opacity:.9;color:#fff}
  .preview-foto{width:80px;height:80px;border-radius:50%;object-fit:cover;border:2px solid rgba(233,69,96,.5);display:none}
  .excluir-nome{color:#f87171;font-weight:700}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .barb-card{flex-wrap:wrap}
  }
</style>
</head>
<body>
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-sm d-md-none" style="background:rgba(255,255,255,.1);color:#fff" id="btnMenuMobile">
        <i class="bi bi-list fs-5"></i>
      </button>
      <h5 class="mb-0 fw-bold"><i class="bi bi-people-fill me-2" style="color:#e94560"></i>Gerenciar Barbeiros</h5>
    </div>
    <button class="btn btn-save px-3" data-bs-toggle="modal" data-bs-target="#modalBarbeiro" id="btnNovo">
      <i class="bi bi-plus-lg me-1"></i>Novo Barbeiro
    </button>
  </div>

  <?= renderFlash() ?>

  <div class="row g-3">
    <?php if(empty($barbeiros)): ?>
    <div class="col-12">
      <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:3rem;text-align:center;color:rgba(255,255,255,.3)">
        <i class="bi bi-people fs-1 d-block mb-2"></i>
        Nenhum barbeiro cadastrado ainda
      </div>
    </div>
    <?php endif; ?>

    <?php foreach($barbeiros as $b): ?>
    <div class="col-12 col-md-6 col-xl-4">
      <div class="barb-card">
        <?php if(!empty($b['foto']) && file_exists(__DIR__.'/../uploads/barbeiros/'.$b['foto'])): ?>
          <img src="<?= BASE_URL ?>/uploads/barbeiros/<?= htmlspecialchars($b['foto']) ?>"
               alt="<?= htmlspecialchars($b['nome']) ?>" class="barb-avatar">
        <?php else: ?>
          <div class="barb-avatar-placeholder">
            <i class="bi bi-person-fill text-white fs-4"></i>
          </div>
        <?php endif; ?>

        <div class="flex-grow-1 min-width-0">
          <div class="barb-nome"><?= htmlspecialchars($b['nome']) ?></div>
          <div class="barb-email text-truncate"><?= htmlspecialchars($b['email']) ?></div>
          <?php if($b['telefone']): ?>
          <div class="barb-tel"><i class="bi bi-phone me-1"></i><?= htmlspecialchars($b['telefone']) ?></div>
          <?php endif; ?>
          <div class="d-flex align-items-center gap-2 mt-1">
            <span class="barb-com"><i class="bi bi-percent me-1"></i><?= $b['comissao_percent'] ?>%</span>
            <?php if($b['ativo']): ?>
              <span class="badge-ativo">Ativo</span>
            <?php else: ?>
              <span class="badge-inativo">Inativo</span>
            <?php endif; ?>
          </div>
        </div>

        <div class="d-flex flex-column gap-2">
          <button class="btn-editar-card btn-editar"
            data-id="<?= $b['id'] ?>"
            data-nome="<?= htmlspecialchars($b['nome']) ?>"
            data-email="<?= htmlspecialchars($b['email']) ?>"
            data-telefone="<?= htmlspecialchars($b['telefone'] ?? '') ?>"
            data-comissao="<?= $b['comissao_percent'] ?>"
            data-foto="<?= !empty($b['foto']) ? BASE_URL . '/uploads/barbeiros/'.htmlspecialchars($b['foto']) : '' ?>"
            data-bs-toggle="modal" data-bs-target="#modalBarbeiro"
            title="Editar">
            <i class="bi bi-pencil"></i>
          </button>
          <form method="POST" class="d-inline">
            <input type="hidden" name="acao" value="toggle">
            <input type="hidden" name="id" value="<?= $b['id'] ?>">
            <button type="submit" class="btn-toggle-card" title="<?= $b['ativo'] ? 'Desativar' : 'Ativar' ?>">
              <i class="bi bi-<?= $b['ativo'] ? 'toggle-on' : 'toggle-off' ?>"></i>
            </button>
          </form>
          <button class="btn-excluir-card btn-excluir"
            data-id="<?= $b['id'] ?>"
            data-nome="<?= htmlspecialchars($b['nome']) ?>"
            data-bs-toggle="modal" data-bs-target="#modalExcluir"
            title="Excluir">
            <i class="bi bi-trash"></i>
          </button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Modal Cadastro/Edição -->
<div class="modal fade" id="modalBarbeiro" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitulo">Novo Barbeiro</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" id="formBarbeiro" enctype="multipart/form-data">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="fId" value="0">
        <div class="modal-body">
          <div class="text-center mb-3">
            <div id="fotoAtual" style="display:flex;flex-direction:column;align-items:center;gap:.5rem">
              <div id="fotoPlaceholder" style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:flex;align-items:center;justify-content:center;font-size:2rem;margin:0 auto">
                <i class="bi bi-person-fill text-white"></i>
              </div>
              <img id="fotoPreview" src="" class="preview-foto" alt="Preview">
              <small style="color:rgba(255,255,255,.45)">Foto do barbeiro</small>
            </div>
          </div>
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Nome *</label>
              <input type="text" name="nome" id="fNome" class="form-control" required>
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label">E-mail *</label>
              <input type="email" name="email" id="fEmail" class="form-control" required>
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label">Telefone</label>
              <input type="tel" name="telefone" id="fTelefone" class="form-control">
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label">Comissão (%)</label>
              <input type="number" name="comissao_percent" id="fComissao" class="form-control" min="0" max="100" step="0.5" value="50">
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label" id="lblSenha">Senha *</label>
              <input type="password" name="senha" id="fSenha" class="form-control" placeholder="••••••••">
            </div>
            <div class="col-12">
              <label class="form-label">
                <i class="bi bi-camera me-1"></i>Foto do Barbeiro
                <small style="color:rgba(255,255,255,.4)">(JPG, PNG, WEBP – máx. 2MB)</small>
              </label>
              <input type="file" name="foto" id="fFoto" class="form-control" accept="image/jpeg,image/png,image/webp">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-save px-4">
            <i class="bi bi-check2 me-1"></i>Salvar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Confirmar Exclusão -->
<div class="modal fade" id="modalExcluir" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-exclamation-triangle-fill me-2" style="color:#f87171"></i>Confirmar Exclusão</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="color:rgba(255,255,255,.8)">
        Tem certeza que deseja excluir o barbeiro <span id="excluirNome" class="excluir-nome"></span>?
        <div class="mt-2" style="color:rgba(255,255,255,.45);font-size:.85rem">
          <i class="bi bi-info-circle me-1"></i>Esta ação não poderá ser desfeita. Todo o histórico de fila e a foto também serão removidos.
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
        <form method="POST" class="d-inline">
          <input type="hidden" name="acao" value="excluir">
          <input type="hidden" name="id" id="excluirId" value="0">
          <button type="submit" class="btn btn-danger-confirm px-4">
            <i class="bi bi-trash me-1"></i>Excluir
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

document.getElementById('btnNovo').addEventListener('click', () => {
  document.getElementById('modalTitulo').textContent = 'Novo Barbeiro';
  document.getElementById('fId').value = 0;
  document.getElementById('fNome').value = '';
  document.getElementById('fEmail').value = '';
  document.getElementById('fTelefone').value = '';
  document.getElementById('fComissao').value = 50;
  document.getElementById('fSenha').value = '';
  document.getElementById('fFoto').value = '';
  document.getElementById('lblSenha').textContent = 'Senha *';
  document.getElementById('fSenha').required = true;
  document.getElementById('fotoPlaceholder').style.display = 'flex';
  document.getElementById('fotoPreview').style.display = 'none';
  document.getElementById('fotoPreview').src = '';
});

document.querySelectorAll('.btn-editar').forEach(btn => {
  btn.addEventListener('click', function() {
    document.getElementById('modalTitulo').textContent = 'Editar Barbeiro';
    document.getElementById('fId').value = this.dataset.id;
    document.getElementById('fNome').value = this.dataset.nome;
    document.getElementById('fEmail').value = this.dataset.email;
    document.getElementById('fTelefone').value = this.dataset.telefone;
    document.getElementById('fComissao').value = this.dataset.comissao;
    document.getElementById('fSenha').value = '';
    document.getElementById('fFoto').value = '';
    document.getElementById('lblSenha').textContent = 'Nova Senha (deixe em branco para manter)';
    document.getElementById('fSenha').required = false;
    const fotoUrl = this.dataset.foto;
    if (fotoUrl) {
      document.getElementById('fotoPlaceholder').style.display = 'none';
      document.getElementById('fotoPreview').src = fotoUrl;
      document.getElementById('fotoPreview').style.display = 'block';
    } else {
      document.getElementById('fotoPlaceholder').style.display = 'flex';
      document.getElementById('fotoPreview').style.display = 'none';
    }
  });
});

document.getElementById('fFoto').addEventListener('change', function() {
  const file = this.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) {
    alert('Foto muito grande! Máximo 2MB.');
    this.value = '';
    return;
  }
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('fotoPlaceholder').style.display = 'none';
    document.getElementById('fotoPreview').src = e.target.result;
    document.getElementById('fotoPreview').style.display = 'block';
  };
  reader.readAsDataURL(file);
});

document.querySelectorAll('.btn-excluir').forEach(btn => {
  btn.addEventListener('click', function() {
    document.getElementById('excluirId').value = this.dataset.id;
    document.getElementById('excluirNome').textContent = this.dataset.nome;
  });
});
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</body>
</html>