<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'salvar') {
        $id    = (int)($_POST['id'] ?? 0);
        $nome  = trim($_POST['nome']  ?? '');
        $email = trim($_POST['email'] ?? '');
        $tel   = trim($_POST['telefone'] ?? '');
        $senha = $_POST['senha'] ?? '';

        if (!$nome || !$email) {
            flash('danger', 'Nome e e-mail são obrigatórios.');
        } else {
            if ($id) {
                if ($senha) {
                    $db->prepare("UPDATE usuarios SET nome=?,email=?,telefone=?,senha=? WHERE id=? AND tipo='assistente'")
                       ->execute([$nome, $email, $tel, password_hash($senha, PASSWORD_DEFAULT), $id]);
                } else {
                    $db->prepare("UPDATE usuarios SET nome=?,email=?,telefone=? WHERE id=? AND tipo='assistente'")
                       ->execute([$nome, $email, $tel, $id]);
                }
                flash('success', 'Assistente atualizado!');
            } else {
                if (!$senha) {
                    flash('danger', 'Senha obrigatória para novo assistente.');
                } else {
                    try {
                        $db->prepare("INSERT INTO usuarios (nome,email,senha,tipo,telefone,ativo) VALUES (?,?,?,'assistente',?,1)")
                           ->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT), $tel]);
                        flash('success', 'Assistente cadastrado com sucesso!');
                    } catch (Exception $e) {
                        flash('danger', 'E-mail já cadastrado.');
                    }
                }
            }
        }
    }

    if ($acao === 'toggle') {
        $db->prepare("UPDATE usuarios SET ativo = CASE WHEN ativo=1 THEN 0 ELSE 1 END WHERE id=? AND tipo='assistente'")
           ->execute([(int)$_POST['id']]);
        flash('success', 'Status atualizado!');
    }

    if ($acao === 'excluir') {
        $db->prepare("DELETE FROM usuarios WHERE id=? AND tipo='assistente'")
           ->execute([(int)$_POST['id']]);
        flash('success', 'Assistente removido.');
    }

    header('Location: assistentes.php'); exit;
}

$assistentes   = $db->query("SELECT * FROM usuarios WHERE tipo='assistente' ORDER BY nome")->fetchAll();
$nomeBarbearia = getConfig('nome_barbearia');

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Assistentes – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<style>
  :root{--primary:#e94560}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif}
  .sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;background:linear-gradient(180deg,#1a1a2e,#16213e);border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:.25s;display:flex;align-items:center;gap:.75rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:260px;padding:2rem;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center}

  .assist-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem;display:flex;align-items:center;gap:1rem;transition:.2s}
  .assist-card:hover{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.2)}
  .assist-avatar{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#3b82f6,#1d4ed8);display:flex;align-items:center;justify-content:center;flex-shrink:0;border:2px solid rgba(59,130,246,.5);font-size:1.4rem}
  .assist-nome{font-weight:700;color:#fff;font-size:.98rem}
  .assist-email{color:rgba(255,255,255,.5);font-size:.84rem}
  .assist-tel{color:rgba(255,255,255,.4);font-size:.78rem}
  .badge-ativo{background:rgba(34,197,94,.2);color:#4ade80;border-radius:6px;padding:.25rem .65rem;font-size:.78rem;font-weight:600}
  .badge-inativo{background:rgba(239,68,68,.2);color:#f87171;border-radius:6px;padding:.25rem .65rem;font-size:.78rem;font-weight:600}
  .badge-assistente{background:rgba(59,130,246,.2);color:#60a5fa;border-radius:6px;padding:.25rem .65rem;font-size:.78rem;font-weight:600}
  .btn-ac{border:none;border-radius:8px;padding:.4rem .75rem;transition:.2s;cursor:pointer;font-size:.82rem}
  .btn-editar-ac{background:rgba(59,130,246,.2);color:#60a5fa;}
  .btn-editar-ac:hover{background:rgba(59,130,246,.35);color:#93c5fd}
  .btn-toggle-ac{background:rgba(245,158,11,.2);color:#fbbf24;}
  .btn-toggle-ac:hover{background:rgba(245,158,11,.35)}
  .btn-excluir-ac{background:rgba(239,68,68,.15);color:#f87171;}
  .btn-excluir-ac:hover{background:rgba(239,68,68,.3)}

  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12)}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08)}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08)}
  .modal-title{color:#fff}
  .form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.12);border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.4)}
  label{color:rgba(255,255,255,.8)}
  .btn-save{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;font-weight:600}
  .btn-save:hover{opacity:.9;color:#fff}

  .info-box{background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);border-radius:12px;padding:1rem 1.2rem;margin-bottom:1.5rem;font-size:.88rem;color:rgba(255,255,255,.7)}
  .info-box i{color:#60a5fa}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0;padding:1rem}
    .topbar{margin:-1rem -1rem 1rem;padding:.85rem 1rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-sm d-md-none" style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px" id="btnMenuMobile">
        <i class="bi bi-list fs-5"></i>
      </button>
      <h5 class="mb-0 fw-bold">
        <i class="bi bi-person-badge me-2" style="color:#60a5fa"></i>Assistentes de Fila
      </h5>
    </div>
    <button class="btn btn-save px-3" data-bs-toggle="modal" data-bs-target="#modalAssistente" id="btnNovo">
      <i class="bi bi-plus-lg me-1"></i>Novo Assistente
    </button>
  </div>

  <?= renderFlash() ?>

  <div class="info-box">
    <i class="bi bi-info-circle me-2"></i>
    Assistentes podem visualizar a fila de <strong style="color:#fff">todos os barbeiros</strong> em tempo real,
    mas <strong style="color:#fff">não</strong> têm acesso a relatórios, financeiro ou configurações.
    Ideal para recepcionistas ou monitores de fila.
  </div>

  <div class="row g-3">
    <?php if (empty($assistentes)): ?>
    <div class="col-12">
      <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:3rem;text-align:center;color:rgba(255,255,255,.3)">
        <i class="bi bi-person-badge fs-1 d-block mb-2"></i>
        Nenhum assistente cadastrado ainda
      </div>
    </div>
    <?php endif; ?>

    <?php foreach ($assistentes as $a): ?>
    <div class="col-12 col-md-6 col-xl-4">
      <div class="assist-card">
        <div class="assist-avatar">
          <i class="bi bi-person-badge text-white"></i>
        </div>
        <div class="flex-grow-1" style="min-width:0">
          <div class="assist-nome"><?= htmlspecialchars($a['nome']) ?></div>
          <div class="assist-email text-truncate"><?= htmlspecialchars($a['email']) ?></div>
          <?php if ($a['telefone']): ?>
            <div class="assist-tel"><i class="bi bi-phone me-1"></i><?= htmlspecialchars($a['telefone']) ?></div>
          <?php endif; ?>
          <div class="d-flex align-items-center gap-2 mt-1 flex-wrap">
            <span class="badge-assistente"><i class="bi bi-eye me-1"></i>Assistente</span>
            <?php if ($a['ativo']): ?>
              <span class="badge-ativo">Ativo</span>
            <?php else: ?>
              <span class="badge-inativo">Inativo</span>
            <?php endif; ?>
          </div>
        </div>
        <div class="d-flex flex-column gap-2">
          <button class="btn-ac btn-editar-ac btn-editar"
            data-id="<?= $a['id'] ?>"
            data-nome="<?= htmlspecialchars($a['nome']) ?>"
            data-email="<?= htmlspecialchars($a['email']) ?>"
            data-telefone="<?= htmlspecialchars($a['telefone'] ?? '') ?>"
            data-bs-toggle="modal" data-bs-target="#modalAssistente"
            title="Editar">
            <i class="bi bi-pencil"></i>
          </button>
          <form method="POST" class="d-inline">
            <input type="hidden" name="acao" value="toggle">
            <input type="hidden" name="id" value="<?= $a['id'] ?>">
            <button type="submit" class="btn-ac btn-toggle-ac w-100"
                    title="<?= $a['ativo'] ? 'Desativar' : 'Ativar' ?>">
              <i class="bi bi-<?= $a['ativo'] ? 'toggle-on' : 'toggle-off' ?>"></i>
            </button>
          </form>
          <form method="POST" class="d-inline"
                onsubmit="return confirm('Remover este assistente?')">
            <input type="hidden" name="acao" value="excluir">
            <input type="hidden" name="id" value="<?= $a['id'] ?>">
            <button type="submit" class="btn-ac btn-excluir-ac w-100" title="Excluir">
              <i class="bi bi-trash"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalAssistente" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitulo">Novo Assistente</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="fId" value="0">
        <div class="modal-body">

          <!-- Avatar decorativo -->
          <div class="text-center mb-4">
            <div style="width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,#3b82f6,#1d4ed8);display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:2rem;border:2px solid rgba(59,130,246,.4)">
              <i class="bi bi-person-badge text-white"></i>
            </div>
            <div style="color:rgba(255,255,255,.4);font-size:.78rem;margin-top:.5rem">Assistente de Fila</div>
          </div>

          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Nome completo *</label>
              <input type="text" name="nome" id="fNome" class="form-control"
                     placeholder="Ex: Maria Silva" required>
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label">E-mail *</label>
              <input type="email" name="email" id="fEmail" class="form-control"
                     placeholder="email@exemplo.com" required>
            </div>
            <div class="col-12 col-md-6">
              <label class="form-label">Telefone</label>
              <input type="tel" name="telefone" id="fTelefone" class="form-control"
                     placeholder="(00) 00000-0000">
            </div>
            <div class="col-12">
              <label class="form-label" id="lblSenha">Senha *</label>
              <div class="input-group">
                <input type="password" name="senha" id="fSenha" class="form-control"
                       placeholder="Mínimo 6 caracteres">
                <button type="button" class="btn"
                        style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#aaa"
                        onclick="togglePass('fSenha',this)">
                  <i class="bi bi-eye"></i>
                </button>
              </div>
              <div class="form-text" style="color:rgba(255,255,255,.35);font-size:.76rem"
                   id="senhaHint">Obrigatório para novo assistente</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-save px-4">
            <i class="bi bi-check2 me-1"></i>Salvar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

document.getElementById('btnNovo').addEventListener('click', () => {
  document.getElementById('modalTitulo').textContent = 'Novo Assistente';
  document.getElementById('fId').value = 0;
  document.getElementById('fNome').value = '';
  document.getElementById('fEmail').value = '';
  document.getElementById('fTelefone').value = '';
  document.getElementById('fSenha').value = '';
  document.getElementById('fSenha').required = true;
  document.getElementById('lblSenha').textContent = 'Senha *';
  document.getElementById('senhaHint').textContent = 'Obrigatório para novo assistente';
});

document.querySelectorAll('.btn-editar').forEach(btn => {
  btn.addEventListener('click', function() {
    document.getElementById('modalTitulo').textContent = 'Editar Assistente';
    document.getElementById('fId').value        = this.dataset.id;
    document.getElementById('fNome').value      = this.dataset.nome;
    document.getElementById('fEmail').value     = this.dataset.email;
    document.getElementById('fTelefone').value  = this.dataset.telefone;
    document.getElementById('fSenha').value     = '';
    document.getElementById('fSenha').required  = false;
    document.getElementById('lblSenha').textContent  = 'Nova Senha';
    document.getElementById('senhaHint').textContent = 'Deixe em branco para manter a senha atual';
  });
});

function togglePass(id, btn) {
  const inp = document.getElementById(id);
  inp.type  = inp.type === 'password' ? 'text' : 'password';
  btn.querySelector('i').className = inp.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
}

// Máscara telefone
document.getElementById('fTelefone').addEventListener('input', function() {
  let v = this.value.replace(/\D/g,'');
  if (v.length <= 10) v = v.replace(/(\d{2})(\d{4})(\d{0,4})/,'($1) $2-$3');
  else                v = v.replace(/(\d{2})(\d{5})(\d{0,4})/,'($1) $2-$3');
  this.value = v;
});
</script>
<?php if (file_exists(__DIR__ . '/../sw.js')): ?>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope)).catch(e => console.log('SW erro:', e));
  });
}
</script>
<?php endif; ?>
</body>
</html>