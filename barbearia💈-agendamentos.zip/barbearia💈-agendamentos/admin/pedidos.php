<?php
require_once '../config.php';
require_once '../whatsapp/config.php'; // ← CORREÇÃO: inclui a função enviarWhatsApp()
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// ── AÇÕES POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    $id   = (int)($_POST['id'] ?? 0);

    if (in_array($acao, ['confirmar','pronto','entregar','cancelar']) && $id) {
        $novoStatus = match($acao) {
            'confirmar' => 'confirmado',
            'pronto'    => 'pronto',
            'entregar'  => 'entregue',
            'cancelar'  => 'cancelado',
        };

        $pedido = $db->query("SELECT * FROM pedidos WHERE id=$id")->fetch();

        $db->prepare("UPDATE pedidos SET status=?, atualizado_em=CURRENT_TIMESTAMP WHERE id=?")
           ->execute([$novoStatus, $id]);

        // ── Notificação WhatsApp ao confirmar ──
        if ($acao === 'confirmar' && $pedido && !$pedido['notificado']) {
            $nomeBarbearia = getConfig('nome_barbearia') ?? 'Barbearia';
            if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbearia);

            $tel = preg_replace('/\D/', '', $pedido['cliente_tel']);
            // Garante DDI 55
            if (strlen($tel) <= 11) $tel = '55' . $tel;

            $tipoEnt = $pedido['tipo_entrega'] === 'entrega' ? 'entrega' : 'retirada';
            $msg = "✂️ *{$nomeBarbearia}*\n\n"
                 . "Olá, *{$pedido['cliente_nome']}*! 🎉\n\n"
                 . "Seu pedido *#{$id}* foi *confirmado*!\n\n"
                 . ($tipoEnt === 'entrega'
                     ? "🚴 Entregaremos no endereço informado em breve.\n"
                     : "🏪 Pode retirar na barbearia quando quiser.\n")
                 . "\n💰 O pagamento é feito na "
                 . ($tipoEnt === 'entrega' ? "entrega" : "retirada") . "."
                 . "\n\nObrigado pela preferência! 💈";

            try {
                enviarWhatsApp($tel, $msg);
                $db->prepare("UPDATE pedidos SET notificado=1 WHERE id=?")->execute([$id]);
            } catch (Exception $e) {
                // Falha no WhatsApp não impede o fluxo
            }
        }

        // ── Ao cancelar, repõe estoque de produtos ──
        if ($acao === 'cancelar' && $pedido) {
            $itens = $db->query("SELECT * FROM pedidos_itens WHERE pedido_id=$id")->fetchAll();
            foreach ($itens as $item) {
                if ($item['tipo'] === 'produto' && $item['produto_id']) {
                    $db->prepare("UPDATE produtos SET estoque = estoque + ? WHERE id=?")
                       ->execute([$item['quantidade'], $item['produto_id']]);
                }
            }
        }

        flash('success', 'Pedido atualizado com sucesso!');
    }

    header('Location: pedidos.php'); exit;
}

// ── FILTROS ──
$filtroStatus = $_GET['status'] ?? '';
$filtroBusca  = trim($_GET['busca'] ?? '');
$porPag       = 15;
$pagina       = max(1, (int)($_GET['pag'] ?? 1));
$offset       = ($pagina - 1) * $porPag;

$where  = [];
$params = [];
if ($filtroStatus) {
    $where[]  = "p.status=?";
    $params[] = $filtroStatus;
}
if ($filtroBusca) {
    $where[]  = "(p.cliente_nome LIKE ? OR p.cliente_tel LIKE ?)";
    $params[] = "%$filtroBusca%";
    $params[] = "%$filtroBusca%";
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$totalStmt = $db->prepare("SELECT COUNT(*) FROM pedidos p $whereSql");
$totalStmt->execute($params);
$total     = (int)$totalStmt->fetchColumn();
$totalPags = max(1, ceil($total / $porPag));
$pagina    = min($pagina, $totalPags);
$offset    = ($pagina - 1) * $porPag;

$stmt = $db->prepare("
    SELECT p.* FROM pedidos p
    $whereSql
    ORDER BY
        CASE p.status
            WHEN 'pendente'   THEN 1
            WHEN 'confirmado' THEN 2
            WHEN 'pronto'     THEN 3
            WHEN 'entregue'   THEN 4
            WHEN 'cancelado'  THEN 5
        END,
        p.criado_em DESC
    LIMIT $porPag OFFSET $offset
");
$stmt->execute($params);
$pedidos = $stmt->fetchAll();

// ── Stats ──
$stats = $db->query("
    SELECT
        COUNT(*)                                                                    AS total,
        SUM(CASE WHEN status='pendente'   THEN 1 ELSE 0 END)                       AS pendentes,
        SUM(CASE WHEN status='confirmado' THEN 1 ELSE 0 END)                       AS confirmados,
        SUM(CASE WHEN status='pronto'     THEN 1 ELSE 0 END)                       AS prontos,
        SUM(CASE WHEN status='entregue'   THEN 1 ELSE 0 END)                       AS entregues,
        COALESCE(SUM(CASE WHEN status IN ('confirmado','pronto','entregue')
                          THEN total ELSE 0 END), 0)                               AS receita
    FROM pedidos
")->fetch();

$nomeBarbearia = getConfig('nome_barbearia') ?? 'Barbearia';

$statusCores = [
    'pendente'   => ['cor'=>'#fbbf24','bg'=>'rgba(245,158,11,.15)','border'=>'rgba(245,158,11,.25)','label'=>'Pendente'],
    'confirmado' => ['cor'=>'#60a5fa','bg'=>'rgba(59,130,246,.12)','border'=>'rgba(59,130,246,.22)','label'=>'Confirmado'],
    'pronto'     => ['cor'=>'#a78bfa','bg'=>'rgba(139,92,246,.12)','border'=>'rgba(139,92,246,.22)','label'=>'Pronto p/ Retirar'],
    'entregue'   => ['cor'=>'#4ade80','bg'=>'rgba(34,197,94,.12)', 'border'=>'rgba(34,197,94,.22)', 'label'=>'Entregue/Retirado'],
    'cancelado'  => ['cor'=>'#f87171','bg'=>'rgba(239,68,68,.1)',  'border'=>'rgba(239,68,68,.2)',  'label'=>'Cancelado'],
];

function urlP(array $extra = []): string {
    $p = array_merge([
        'status' => $_GET['status'] ?? '',
        'busca'  => $_GET['busca']  ?? '',
        'pag'    => 1,
    ], $extra);
    return 'pedidos.php?' . http_build_query(array_filter($p, fn($v) => $v !== ''));
}

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pedidos Online – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);
    display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;
    background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  .main-content{margin-left:var(--sidebar-w);min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;
    align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  /* Stats */
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
    border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.1rem;
    position:relative;overflow:hidden}
  .stat-card::after{content:'';position:absolute;top:-15px;right:-15px;
    width:60px;height:60px;border-radius:50%;opacity:.12}
  .stat-card.c1::after{background:#fbbf24}
  .stat-card.c2::after{background:#60a5fa}
  .stat-card.c3::after{background:#a78bfa}
  .stat-card.c4::after{background:#4ade80}
  .stat-icon{width:40px;height:40px;border-radius:10px;display:flex;
    align-items:center;justify-content:center;font-size:1.1rem;margin-bottom:.7rem}
  .stat-value{font-size:1.5rem;font-weight:800;color:#fff;line-height:1}
  .stat-label{color:rgba(255,255,255,.5);font-size:.78rem;margin-top:.25rem}

  /* Pills de status */
  .status-pills{display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:1.25rem}
  .pill{border-radius:20px;padding:.35rem .85rem;font-size:.78rem;font-weight:700;
    cursor:pointer;text-decoration:none;transition:.2s;border:1px solid transparent;
    display:inline-flex;align-items:center;gap:.3rem}

  /* Cards de pedido */
  .pedido-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
    border-radius:16px;padding:1.1rem;margin-bottom:.85rem;transition:.2s}
  .pedido-card:hover{border-color:rgba(255,255,255,.15)}
  .pedido-card.status-pendente  {border-left:3px solid #fbbf24}
  .pedido-card.status-confirmado{border-left:3px solid #60a5fa}
  .pedido-card.status-pronto    {border-left:3px solid #a78bfa}
  .pedido-card.status-entregue  {border-left:3px solid #4ade80}
  .pedido-card.status-cancelado {border-left:3px solid #f87171;opacity:.6}

  .pedido-header{display:flex;align-items:flex-start;justify-content:space-between;
    gap:1rem;margin-bottom:.85rem;flex-wrap:wrap}
  .pedido-num{font-size:1rem;font-weight:800;color:#fff}
  .pedido-cliente{font-size:.88rem;color:rgba(255,255,255,.7);margin-top:.15rem}
  .pedido-tel{font-size:.78rem;color:rgba(255,255,255,.35)}
  .status-badge{border-radius:20px;padding:.2rem .7rem;font-size:.75rem;
    font-weight:700;white-space:nowrap}

  .pedido-itens{background:rgba(255,255,255,.03);border-radius:10px;
    padding:.7rem .9rem;margin-bottom:.85rem}
  .pedido-item-linha{display:flex;justify-content:space-between;align-items:center;
    font-size:.83rem;padding:.25rem 0;border-bottom:1px solid rgba(255,255,255,.04)}
  .pedido-item-linha:last-child{border-bottom:none}

  .pedido-footer{display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.5rem}
  .pedido-total{font-size:1.05rem;font-weight:800;color:#4ade80}
  .pedido-meta{font-size:.75rem;color:rgba(255,255,255,.3)}

  /* Botões de ação */
  .btn-acao{border:none;border-radius:9px;padding:.4rem .85rem;font-size:.8rem;
    font-weight:700;cursor:pointer;transition:.2s;
    display:inline-flex;align-items:center;gap:.35rem}
  .btn-confirmar{background:rgba(59,130,246,.2);color:#60a5fa;border:1px solid rgba(59,130,246,.3)}
  .btn-confirmar:hover{background:rgba(59,130,246,.35)}
  .btn-pronto{background:rgba(139,92,246,.2);color:#a78bfa;border:1px solid rgba(139,92,246,.3)}
  .btn-pronto:hover{background:rgba(139,92,246,.35)}
  .btn-entregar{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.25)}
  .btn-entregar:hover{background:rgba(34,197,94,.28)}
  .btn-cancelar{background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2)}
  .btn-cancelar:hover{background:rgba(239,68,68,.22)}
  .btn-wa{background:rgba(37,211,102,.12);color:#25d366;border:1px solid rgba(37,211,102,.2)}
  .btn-wa:hover{background:rgba(37,211,102,.25)}

  /* Filtro bar */
  .filtro-bar{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);
    border-radius:14px;padding:.8rem 1rem;margin-bottom:1rem}
  .search-input{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.55rem 1rem;font-size:.88rem;transition:.2s}
  .search-input:focus{outline:none;border-color:var(--primary);background:rgba(255,255,255,.1)}
  .search-input::placeholder{color:rgba(255,255,255,.3)}

  /* Badges entrega/retirada */
  .badge-entrega {background:rgba(59,130,246,.12);color:#60a5fa;
    border:1px solid rgba(59,130,246,.2);border-radius:20px;
    padding:.12rem .5rem;font-size:.7rem;font-weight:700}
  .badge-retirada{background:rgba(34,197,94,.1);color:#4ade80;
    border:1px solid rgba(34,197,94,.18);border-radius:20px;
    padding:.12rem .5rem;font-size:.7rem;font-weight:700}
  .badge-notif{background:rgba(245,158,11,.15);color:#fbbf24;
    border:1px solid rgba(245,158,11,.2);border-radius:20px;
    padding:.1rem .45rem;font-size:.68rem;font-weight:700}

  /* Paginação */
  .pag-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
    color:rgba(255,255,255,.6);border-radius:8px;padding:.3rem .65rem;font-size:.82rem;
    text-decoration:none;transition:.2s;display:inline-flex;align-items:center}
  .pag-btn:hover,.pag-btn.active{background:rgba(233,69,96,.2);
    border-color:rgba(233,69,96,.4);color:#fff}
  .pag-btn.disabled{opacity:.3;pointer-events:none}

  h4,h5,h6{color:#fff;margin:0}
  .empty{text-align:center;padding:3rem 0;color:rgba(255,255,255,.25)}
  .empty i{font-size:3rem;display:block;margin-bottom:.75rem}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<!-- CONTEÚDO -->
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;
               border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">Pedidos Online</h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
          <?= (int)($stats['pendentes'] ?? 0) ?> pendente<?= ($stats['pendentes'] ?? 0) != 1 ? 's' : '' ?>
          aguardando confirmação
        </div>
      </div>
    </div>
    <a href="../loja.php" target="_blank"
       style="background:rgba(233,69,96,.12);border:1px solid rgba(233,69,96,.25);
              color:#e94560;border-radius:10px;padding:.45rem .9rem;
              font-size:.82rem;font-weight:700;text-decoration:none;
              display:flex;align-items:center;gap:.4rem">
      <i class="bi bi-shop"></i> Ver Loja
    </a>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- STATS -->
    <div class="row g-2 mb-3">
      <div class="col-6 col-xl-3">
        <div class="stat-card c1">
          <div class="stat-icon" style="background:rgba(245,158,11,.2)">
            <i class="bi bi-hourglass-split" style="color:#fbbf24"></i>
          </div>
          <div class="stat-value"><?= (int)($stats['pendentes'] ?? 0) ?></div>
          <div class="stat-label">Pendentes</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c2">
          <div class="stat-icon" style="background:rgba(59,130,246,.2)">
            <i class="bi bi-check-circle-fill" style="color:#60a5fa"></i>
          </div>
          <div class="stat-value"><?= (int)($stats['confirmados'] ?? 0) ?></div>
          <div class="stat-label">Confirmados</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c3">
          <div class="stat-icon" style="background:rgba(139,92,246,.2)">
            <i class="bi bi-bag-check-fill" style="color:#a78bfa"></i>
          </div>
          <div class="stat-value">
            <?= (int)($stats['entregues'] ?? 0) + (int)($stats['prontos'] ?? 0) ?>
          </div>
          <div class="stat-label">Finalizados</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c4">
          <div class="stat-icon" style="background:rgba(34,197,94,.2)">
            <i class="bi bi-cash-stack" style="color:#4ade80"></i>
          </div>
          <div class="stat-value" style="font-size:1.1rem">
            <?= formatMoney($stats['receita'] ?? 0) ?>
          </div>
          <div class="stat-label">Receita</div>
        </div>
      </div>
    </div>

    <!-- PILLS DE STATUS -->
    <div class="status-pills">
      <?php
      $statusOpts = [
          ''           => 'Todos',
          'pendente'   => '⏳ Pendentes',
          'confirmado' => '✅ Confirmados',
          'pronto'     => '📦 Prontos',
          'entregue'   => '🚴 Entregues',
          'cancelado'  => '❌ Cancelados',
      ];
      foreach ($statusOpts as $v => $l):
          $ativo = ($filtroStatus === $v);
          $bg    = $ativo ? 'rgba(233,69,96,.2)'        : 'rgba(255,255,255,.05)';
          $bord  = $ativo ? 'rgba(233,69,96,.4)'        : 'rgba(255,255,255,.1)';
          $cor   = $ativo ? '#fff'                      : 'rgba(255,255,255,.5)';
      ?>
      <a href="<?= urlP(['status' => $v]) ?>" class="pill"
         style="background:<?= $bg ?>;border-color:<?= $bord ?>;color:<?= $cor ?>">
        <?= $l ?>
      </a>
      <?php endforeach; ?>
    </div>

    <!-- BUSCA -->
    <div class="filtro-bar">
      <form method="GET" class="d-flex gap-2 flex-wrap align-items-center">
        <input type="hidden" name="status" value="<?= htmlspecialchars($filtroStatus) ?>">
        <input type="text" name="busca" class="search-input flex-grow-1"
               style="max-width:320px"
               placeholder="Buscar cliente ou telefone…"
               value="<?= htmlspecialchars($filtroBusca) ?>">
        <button type="submit"
          style="background:var(--primary);border:none;color:#fff;border-radius:9px;
                 padding:.5rem 1rem;font-weight:700;font-size:.85rem;cursor:pointer">
          <i class="bi bi-search me-1"></i>Buscar
        </button>
        <?php if ($filtroBusca): ?>
        <a href="<?= urlP(['busca' => '']) ?>"
           style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                  color:rgba(255,255,255,.6);border-radius:9px;padding:.5rem .85rem;
                  font-size:.85rem;text-decoration:none">
          <i class="bi bi-x-lg"></i>
        </a>
        <?php endif; ?>
        <span style="font-size:.78rem;color:rgba(255,255,255,.3);margin-left:auto">
          <?= $total ?> pedido<?= $total !== 1 ? 's' : '' ?>
        </span>
      </form>
    </div>

    <!-- LISTA DE PEDIDOS -->
    <?php if (empty($pedidos)): ?>
      <div class="empty">
        <i class="bi bi-bag-x"></i>
        Nenhum pedido encontrado.
      </div>
    <?php else: ?>
      <?php foreach ($pedidos as $ped):
        $sc      = $statusCores[$ped['status']] ?? $statusCores['pendente'];
        $itens   = $db->query("SELECT * FROM pedidos_itens WHERE pedido_id={$ped['id']}")->fetchAll();
        $waNum   = preg_replace('/\D/', '', $ped['cliente_tel']);
        $dataFmt = date('d/m/y H:i', strtotime($ped['criado_em']));
      ?>
      <div class="pedido-card status-<?= $ped['status'] ?>">

        <!-- Header do pedido -->
        <div class="pedido-header">
          <div>
            <div class="pedido-num" style="display:flex;align-items:center;gap:.5rem;flex-wrap:wrap">
              Pedido #<?= $ped['id'] ?>
              <?= $ped['tipo_entrega'] === 'entrega'
                  ? '<span class="badge-entrega"><i class="bi bi-bicycle me-1"></i>Entrega</span>'
                  : '<span class="badge-retirada"><i class="bi bi-shop me-1"></i>Retirada</span>' ?>
              <?php if ($ped['notificado']): ?>
                <span class="badge-notif"><i class="bi bi-whatsapp me-1"></i>Notificado</span>
              <?php endif; ?>
            </div>
            <div class="pedido-cliente"><?= htmlspecialchars($ped['cliente_nome']) ?></div>
            <div class="pedido-tel"><?= htmlspecialchars($ped['cliente_tel']) ?></div>
            <?php if ($ped['cliente_end']): ?>
              <div style="font-size:.77rem;color:rgba(255,255,255,.4);margin-top:.25rem">
                <i class="bi bi-geo-alt me-1"></i>
                <?= htmlspecialchars($ped['cliente_end']) ?>
                <?= $ped['cliente_bairro'] ? ' — ' . htmlspecialchars($ped['cliente_bairro']) : '' ?>
                <?= $ped['cliente_ref']    ? ' (' . htmlspecialchars($ped['cliente_ref']) . ')' : '' ?>
              </div>
            <?php endif; ?>
            <?php if ($ped['observacoes']): ?>
              <div style="font-size:.77rem;color:rgba(255,255,255,.35);margin-top:.2rem">
                <i class="bi bi-chat-left-text me-1"></i>
                <?= htmlspecialchars($ped['observacoes']) ?>
              </div>
            <?php endif; ?>
          </div>
          <span class="status-badge"
                style="background:<?= $sc['bg'] ?>;color:<?= $sc['cor'] ?>;
                       border:1px solid <?= $sc['border'] ?>">
            <?= $sc['label'] ?>
          </span>
        </div>

        <!-- Itens do pedido -->
        <div class="pedido-itens">
          <?php foreach ($itens as $item): ?>
          <div class="pedido-item-linha">
            <span style="color:rgba(255,255,255,.75)">
              <?= $item['tipo'] === 'pacote' ? '📋' : '📦' ?>
              <?= htmlspecialchars($item['nome']) ?>
              <span style="color:rgba(255,255,255,.3)"> ×<?= $item['quantidade'] ?></span>
            </span>
            <span style="color:#4ade80;font-weight:700">
              <?= formatMoney($item['valor_total']) ?>
            </span>
          </div>
          <?php endforeach; ?>
          <?php if ($ped['taxa_entrega'] > 0): ?>
          <div class="pedido-item-linha">
            <span style="color:rgba(255,255,255,.45)">
              <i class="bi bi-bicycle me-1"></i>Taxa de entrega
            </span>
            <span style="color:rgba(255,255,255,.55)">
              <?= formatMoney($ped['taxa_entrega']) ?>
            </span>
          </div>
          <?php endif; ?>
        </div>

        <!-- Footer do pedido -->
        <div class="pedido-footer">
          <div>
            <div class="pedido-total"><?= formatMoney($ped['total']) ?></div>
            <div class="pedido-meta"><?= $dataFmt ?></div>
          </div>
          <div class="d-flex gap-1 flex-wrap">

            <!-- WhatsApp direto -->
            <a href="https://wa.me/55<?= $waNum ?>" target="_blank"
               class="btn-acao btn-wa" title="Abrir WhatsApp">
              <i class="bi bi-whatsapp"></i>
            </a>

            <!-- Ações por status -->
            <?php if ($ped['status'] === 'pendente'): ?>
              <form method="POST" class="d-inline">
                <input type="hidden" name="acao" value="confirmar">
                <input type="hidden" name="id"   value="<?= $ped['id'] ?>">
                <button type="submit" class="btn-acao btn-confirmar">
                  <i class="bi bi-check-lg"></i> Confirmar
                </button>
              </form>
              <form method="POST" class="d-inline"
                    onsubmit="return confirm('Cancelar pedido #<?= $ped['id'] ?>?')">
                <input type="hidden" name="acao" value="cancelar">
                <input type="hidden" name="id"   value="<?= $ped['id'] ?>">
                <button type="submit" class="btn-acao btn-cancelar">
                  <i class="bi bi-x-lg"></i> Cancelar
                </button>
              </form>

            <?php elseif ($ped['status'] === 'confirmado'): ?>
              <form method="POST" class="d-inline">
                <input type="hidden" name="acao" value="pronto">
                <input type="hidden" name="id"   value="<?= $ped['id'] ?>">
                <button type="submit" class="btn-acao btn-pronto">
                  <i class="bi bi-bag-check"></i> Marcar Pronto
                </button>
              </form>

            <?php elseif ($ped['status'] === 'pronto'): ?>
              <form method="POST" class="d-inline">
                <input type="hidden" name="acao" value="entregar">
                <input type="hidden" name="id"   value="<?= $ped['id'] ?>">
                <button type="submit" class="btn-acao btn-entregar">
                  <i class="bi bi-check2-all"></i>
                  <?= $ped['tipo_entrega'] === 'entrega' ? 'Marcar Entregue' : 'Marcar Retirado' ?>
                </button>
              </form>
            <?php endif; ?>

          </div>
        </div>
      </div>
      <?php endforeach; ?>

      <!-- Paginação -->
      <?php if ($totalPags > 1): ?>
      <div class="d-flex align-items-center gap-1 flex-wrap mt-3">
        <a href="<?= urlP(['pag' => $pagina - 1]) ?>"
           class="pag-btn <?= $pagina <= 1 ? 'disabled' : '' ?>">
          <i class="bi bi-chevron-left"></i>
        </a>
        <?php for ($i = max(1,$pagina-2); $i <= min($totalPags,$pagina+2); $i++): ?>
          <a href="<?= urlP(['pag' => $i]) ?>"
             class="pag-btn <?= $i === $pagina ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <a href="<?= urlP(['pag' => $pagina + 1]) ?>"
           class="pag-btn <?= $pagina >= $totalPags ? 'disabled' : '' ?>">
          <i class="bi bi-chevron-right"></i>
        </a>
        <span style="font-size:.78rem;color:rgba(255,255,255,.3);margin-left:.5rem">
          Página <?= $pagina ?>/<?= $totalPags ?>
        </span>
      </div>
      <?php endif; ?>

    <?php endif; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// Auto-refresh a cada 60s para captar novos pedidos
setTimeout(() => location.reload(), 60000);
</script>
</body>
</html>