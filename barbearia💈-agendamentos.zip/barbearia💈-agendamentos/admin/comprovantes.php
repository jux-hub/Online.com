<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}

// ── Garante estrutura correta da fila_itens ANTES de qualquer query ──
$db->exec("
    CREATE TABLE IF NOT EXISTS fila_itens (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        fila_id    INTEGER NOT NULL,
        produto_id INTEGER,
        nome       TEXT,
        preco      REAL DEFAULT 0,
        criado_em  DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
foreach ([
    "ALTER TABLE fila_itens ADD COLUMN quantidade INTEGER DEFAULT 1",
    "ALTER TABLE fila_itens ADD COLUMN subtotal   REAL    DEFAULT 0",
    "ALTER TABLE fila_itens ADD COLUMN pacote_id  INTEGER",
] as $m) {
    try { $db->exec($m); } catch (Exception $e) {}
}
$db->exec("UPDATE fila_itens SET quantidade = 1     WHERE quantidade IS NULL OR quantidade = 0");
$db->exec("UPDATE fila_itens SET subtotal   = preco WHERE subtotal   IS NULL OR subtotal   = 0");

// ── Filtros ──
$filtroCliente  = trim($_GET['cliente']  ?? '');
$filtroBarbeiro = (int)($_GET['barbeiro'] ?? 0);
$filtroDataIni  = $_GET['data_ini'] ?? '';
$filtroDataFim  = $_GET['data_fim'] ?? '';
$filtroValMin   = $_GET['val_min']  ?? '';
$filtroValMax   = $_GET['val_max']  ?? '';
$pagina         = max(1, (int)($_GET['pag'] ?? 1));
$porPagina      = 20;

$barbeiros = $db->query("SELECT id, nome FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();

// ── WHERE ──
$where  = ["f.status = 'concluido'"];
$params = [];

if ($filtroCliente !== '') {
    $where[]  = "(f.nome LIKE ? OR c.nome LIKE ? OR f.telefone LIKE ? OR c.telefone LIKE ?)";
    $like     = "%$filtroCliente%";
    $params[] = $like; $params[] = $like; $params[] = $like; $params[] = $like;
}
if ($filtroBarbeiro > 0) {
    $where[]  = "f.barbeiro_id = ?";
    $params[] = $filtroBarbeiro;
}
if ($filtroDataIni !== '') {
    $where[]  = "DATE(f.finalizado_em) >= ?";
    $params[] = $filtroDataIni;
}
if ($filtroDataFim !== '') {
    $where[]  = "DATE(f.finalizado_em) <= ?";
    $params[] = $filtroDataFim;
}
if ($filtroValMin !== '') {
    $where[]  = "f.valor >= ?";
    $params[] = (float)$filtroValMin;
}
if ($filtroValMax !== '') {
    $where[]  = "f.valor <= ?";
    $params[] = (float)$filtroValMax;
}

$whereSQL = implode(' AND ', $where);

// Total de registros
$totalStmt = $db->prepare("
    SELECT COUNT(*) FROM fila f
    LEFT JOIN clientes c ON c.id = f.cliente_id
    WHERE $whereSQL
");
$totalStmt->execute($params);
$totalRegistros = (int)$totalStmt->fetchColumn();
$totalPaginas   = max(1, ceil($totalRegistros / $porPagina));
$pagina         = min($pagina, $totalPaginas);
$offset         = ($pagina - 1) * $porPagina;

// Atendimentos
$stmt = $db->prepare("
    SELECT
        f.id,
        COALESCE(c.nome,     f.nome)     AS cliente_nome,
        COALESCE(c.telefone, f.telefone) AS cliente_telefone,
        s.nome                           AS servico,
        f.valor                          AS total_pago,
        f.forma_pagamento,
        f.finalizado_em,
        f.criado_em                      AS entrou_em,
        f.iniciado_em                    AS atendimento_iniciado_em,
        f.observacoes,
        u.nome AS barbeiro_nome,
        u.foto AS barbeiro_foto,
        c.id   AS cliente_id
    FROM fila f
    LEFT JOIN usuarios u ON u.id = f.barbeiro_id
    LEFT JOIN clientes c ON c.id = f.cliente_id
    LEFT JOIN servicos s ON s.id = f.servico_id
    WHERE $whereSQL
    ORDER BY f.finalizado_em DESC
    LIMIT $porPagina OFFSET $offset
");
$stmt->execute($params);
$atendimentos = $stmt->fetchAll();

// Itens dos atendimentos
$ids = array_column($atendimentos, 'id');
$itensMap = [];
if ($ids) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $itensStmt = $db->prepare("
        SELECT
            fi.fila_id,
            COALESCE(fi.quantidade, 1)         AS quantidade,
            COALESCE(fi.subtotal,   fi.preco)  AS subtotal,
            fi.produto_id,
            fi.pacote_id,
            COALESCE(fi.nome, p.nome, pk.nome) AS nome_item,
            p.nome  AS produto_nome,
            pk.nome AS pacote_nome
        FROM fila_itens fi
        LEFT JOIN produtos p  ON p.id  = fi.produto_id
        LEFT JOIN pacotes  pk ON pk.id = fi.pacote_id
        WHERE fi.fila_id IN ($placeholders)
    ");
    $itensStmt->execute($ids);
    foreach ($itensStmt->fetchAll() as $item) {
        $itensMap[$item['fila_id']][] = $item;
    }
}

// Totalizadores
$totStmt = $db->prepare("
    SELECT
        COUNT(*)                  AS total_atend,
        COALESCE(SUM(f.valor), 0) AS total_receita
    FROM fila f
    LEFT JOIN clientes c ON c.id = f.cliente_id
    WHERE $whereSQL
");
$totStmt->execute($params);
$totais = $totStmt->fetch();

// URL com filtros
function filtroUrl(array $override = []): string {
    $base = array_filter([
        'cliente'  => $_GET['cliente']  ?? '',
        'barbeiro' => $_GET['barbeiro'] ?? '',
        'data_ini' => $_GET['data_ini'] ?? '',
        'data_fim' => $_GET['data_fim'] ?? '',
        'val_min'  => $_GET['val_min']  ?? '',
        'val_max'  => $_GET['val_max']  ?? '',
        'pag'      => $_GET['pag']      ?? '',
    ]);
    $merged = array_merge($base, $override);
    return 'comprovantes.php?' . http_build_query(array_filter($merged, fn($v) => $v !== ''));
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Comprovantes – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
:root{--primary:#e94560}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

/* ── Sidebar ── */
.sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;background:linear-gradient(180deg,#1a1a2e,#16213e);border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:transform .3s}
.sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
.sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
.nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;text-decoration:none;font-size:.9rem}
.nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
.nav-link-side.active{border-left:3px solid var(--primary)}
.nav-link-side i{font-size:1rem;flex-shrink:0}
.nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

/* ── Layout ── */
.main-content{margin-left:260px;padding:2rem;min-height:100vh}
.topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
.topbar h5{color:#fff;font-size:1rem}

/* ── Stat cards ── */
.stat-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:1.1rem 1.4rem;display:flex;align-items:center;gap:1rem;height:100%}
.stat-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0}
.stat-label{color:rgba(255,255,255,.5);font-size:.78rem;margin-bottom:.15rem}
.stat-value{color:#fff;font-size:1.25rem;font-weight:700;line-height:1.2}

/* ── Filtros ── */
.filtros-box{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:14px;padding:1.25rem;margin-bottom:1.5rem}
.form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px;font-size:.88rem}
.form-control:focus,.form-select:focus{background:rgba(255,255,255,.12);border-color:var(--primary);color:#fff;box-shadow:0 0 0 .2rem rgba(233,69,96,.2)}
.form-control::placeholder{color:rgba(255,255,255,.4)}
.form-select option{background:#1a1a2e;color:#fff}
label{color:rgba(255,255,255,.75);font-size:.82rem;margin-bottom:.3rem;display:block}

/* ── Tabela ── */
.table-box{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:14px;overflow:hidden}
.table{--bs-table-bg:transparent;--bs-table-hover-bg:rgba(255,255,255,.04);color:#e0e0e0;margin:0}
.table thead th{background:rgba(255,255,255,.07);color:rgba(255,255,255,.7);font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid rgba(255,255,255,.1);padding:.85rem 1rem;white-space:nowrap}
.table tbody td{border-color:rgba(255,255,255,.06);padding:.85rem 1rem;vertical-align:middle;font-size:.88rem;color:#e0e0e0}
.table tbody tr:hover td{background:rgba(255,255,255,.03)}

/* ── Badges pagamento ── */
.badge-pag{padding:.3rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700;display:inline-block}
.pag-dinheiro{background:rgba(34,197,94,.2);color:#4ade80}
.pag-pix{background:rgba(96,165,250,.2);color:#93c5fd}
.pag-debito{background:rgba(167,139,250,.2);color:#c4b5fd}
.pag-credito{background:rgba(251,191,36,.2);color:#fde68a}
.pag-outro{background:rgba(255,255,255,.1);color:rgba(255,255,255,.7)}

/* ── Avatar barbeiro ── */
.barb-mini{width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid rgba(233,69,96,.4);flex-shrink:0}
.barb-mini-ph{width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:inline-flex;align-items:center;justify-content:center;font-size:.75rem;color:#fff;font-weight:700;flex-shrink:0}

/* ── Botão ver comprovante ── */
.btn-comp{background:rgba(233,69,96,.15);color:#ff8099;border:1px solid rgba(233,69,96,.4);border-radius:8px;padding:.4rem .8rem;font-size:.8rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.35rem;white-space:nowrap}
.btn-comp:hover{background:rgba(233,69,96,.35);color:#fff;border-color:#e94560}

/* ── Paginação ── */
.pag-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.8);border-radius:8px;padding:.4rem .9rem;font-size:.85rem;transition:.2s;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}
.pag-btn:hover{background:rgba(255,255,255,.13);color:#fff}
.pag-btn.active{background:var(--primary);border-color:var(--primary);color:#fff;font-weight:700}
.pag-btn.disabled{opacity:.3;pointer-events:none}

/* ── Modal comprovante ── */
.modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12);color:#e0e0e0}
.modal-header{border-bottom:1px solid rgba(255,255,255,.08)}
.modal-footer{border-top:1px solid rgba(255,255,255,.08)}
.modal-title{color:#fff !important}
.comp-header{background:linear-gradient(135deg,#e94560,#c41230);border-radius:12px;padding:1.25rem;text-align:center;color:#fff;margin-bottom:1rem}
.comp-section{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:.9rem 1rem;margin-bottom:.75rem}
.comp-label{color:rgba(255,255,255,.5);font-size:.72rem;text-transform:uppercase;letter-spacing:.6px;margin-bottom:.25rem;display:block}
.comp-value{color:#fff;font-weight:600;font-size:.95rem}
.comp-total{font-size:1.5rem;font-weight:800;color:#4ade80}
.btn-print{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;font-weight:600;padding:.55rem 1.2rem}
.btn-print:hover{opacity:.88;color:#fff}
.btn-pdf{background:rgba(96,165,250,.2);border:1px solid rgba(96,165,250,.45);color:#93c5fd;border-radius:10px;font-weight:600;padding:.55rem 1.2rem}
.btn-pdf:hover{background:rgba(96,165,250,.35);color:#fff}

/* ── Texto da tabela ── */
.text-white-soft{color:rgba(255,255,255,.85) !important}
.text-muted-custom{color:rgba(255,255,255,.45) !important}
.text-green{color:#4ade80 !important;font-weight:700}
.text-id{color:rgba(255,255,255,.3);font-size:.8rem}

/* ── Print ── */
@media print{
  body{background:#fff !important;color:#000 !important}
  .sidebar,.topbar,.filtros-box,.table-box,.pag-btn,
  .modal-footer,.modal-header .btn-close,#btnMenu{display:none !important}
  .main-content{margin:0 !important;padding:0 !important}
  .modal{position:static !important;display:block !important}
  .modal-dialog{margin:0 !important;max-width:100% !important}
  .modal-content{background:#fff !important;border:none !important;box-shadow:none !important;color:#000 !important}
  .comp-header{background:#e94560 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .comp-section{background:#f8f8f8 !important;border:1px solid #eee !important}
  .comp-label{color:#666 !important}
  .comp-value{color:#000 !important}
  .comp-total{color:#16a34a !important}
}

/* ── Responsivo ── */
@media(max-width:991px){
  .sidebar{transform:translateX(-100%)}
  .sidebar.open{transform:translateX(0);box-shadow:4px 0 24px rgba(0,0,0,.5)}
  .main-content{margin-left:0}
  .topbar{padding:.75rem 1rem}
  .stat-value{font-size:1.05rem}
}
@media(max-width:576px){
  .main-content{padding:1rem}
  .topbar{margin:-1rem -1rem 1.25rem}
  .filtros-box{padding:.9rem}
  .table thead th{font-size:.72rem;padding:.6rem .75rem}
  .table tbody td{font-size:.82rem;padding:.65rem .75rem}
  .stat-card{padding:.85rem 1rem;gap:.75rem}
  .stat-icon{width:40px;height:40px;font-size:1.1rem}
  .stat-value{font-size:.95rem}
  .stat-label{font-size:.72rem}
}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-sm d-md-none" style="background:rgba(255,255,255,.1);color:#fff" id="btnMenuMobile">
        <i class="bi bi-list fs-5"></i>
      </button>
      <h5 class="mb-0 fw-bold"><i class="bi bi-receipt me-2" style="color:#e94560"></i>Comprovantes de Atendimento</h5>
    </div>
    <div style="color:rgba(255,255,255,.45);font-size:.85rem">
      <i class="bi bi-calendar3 me-1"></i><?= date('d/m/Y') ?>
    </div>
  </div>

  <?= renderFlash() ?>

  <!-- Totais -->
  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(233,69,96,.15)"><i class="bi bi-receipt" style="color:#e94560"></i></div>
        <div>
          <div class="stat-label">Atendimentos</div>
          <div class="stat-value"><?= number_format($totais['total_atend']) ?></div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(34,197,94,.15)"><i class="bi bi-cash-stack" style="color:#4ade80"></i></div>
        <div>
          <div class="stat-label">Receita Total</div>
          <div class="stat-value" style="font-size:1.1rem">R$ <?= number_format($totais['total_receita'], 2, ',', '.') ?></div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(96,165,250,.15)"><i class="bi bi-graph-up" style="color:#60a5fa"></i></div>
        <div>
          <div class="stat-label">Ticket Médio</div>
          <div class="stat-value" style="font-size:1.1rem">R$ <?= $totais['total_atend'] > 0 ? number_format($totais['total_receita'] / $totais['total_atend'], 2, ',', '.') : '0,00' ?></div>
        </div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(167,139,250,.15)"><i class="bi bi-layers" style="color:#a78bfa"></i></div>
        <div>
          <div class="stat-label">Pág. <?= $pagina ?> / <?= $totalPaginas ?></div>
          <div class="stat-value" style="font-size:1rem"><?= $totalRegistros ?> registros</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Filtros -->
  <div class="filtros-box">
    <form method="GET" action="comprovantes.php">
      <div class="row g-3 align-items-end">
        <div class="col-12 col-md-3">
          <label><i class="bi bi-search me-1"></i>Buscar cliente</label>
          <input type="text" name="cliente" class="form-control" placeholder="Nome ou telefone..."
                 value="<?= htmlspecialchars($filtroCliente) ?>">
        </div>
        <div class="col-12 col-md-2">
          <label><i class="bi bi-person-fill me-1"></i>Barbeiro</label>
          <select name="barbeiro" class="form-select">
            <option value="">Todos</option>
            <?php foreach($barbeiros as $b): ?>
            <option value="<?= $b['id'] ?>" <?= $filtroBarbeiro == $b['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($b['nome']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-2">
          <label><i class="bi bi-calendar-event me-1"></i>Data início</label>
          <input type="date" name="data_ini" class="form-control" value="<?= htmlspecialchars($filtroDataIni) ?>">
        </div>
        <div class="col-6 col-md-2">
          <label><i class="bi bi-calendar-event me-1"></i>Data fim</label>
          <input type="date" name="data_fim" class="form-control" value="<?= htmlspecialchars($filtroDataFim) ?>">
        </div>
        <div class="col-6 col-md-1">
          <label>Val. mín R$</label>
          <input type="number" name="val_min" class="form-control" placeholder="0" step="0.01" min="0"
                 value="<?= htmlspecialchars($filtroValMin) ?>">
        </div>
        <div class="col-6 col-md-1">
          <label>Val. máx R$</label>
          <input type="number" name="val_max" class="form-control" placeholder="999" step="0.01" min="0"
                 value="<?= htmlspecialchars($filtroValMax) ?>">
        </div>
        <div class="col-12 col-md-1 d-flex gap-2">
          <button type="submit" class="btn w-100"
            style="background:var(--primary);color:#fff;border:none;border-radius:10px;font-size:.85rem">
            <i class="bi bi-search"></i>
          </button>
          <a href="comprovantes.php" class="btn w-100"
            style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.7);border:none;border-radius:10px;font-size:.85rem"
            title="Limpar filtros">
            <i class="bi bi-x-lg"></i>
          </a>
        </div>
      </div>
    </form>
  </div>

  <!-- Tabela -->
  <?php if(empty($atendimentos)): ?>
  <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:3rem;text-align:center;color:rgba(255,255,255,.3)">
    <i class="bi bi-receipt fs-1 d-block mb-2"></i>
    Nenhum comprovante encontrado.
  </div>
  <?php else: ?>
  <div class="table-box">
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            <th>Cliente</th>
            <th>Barbeiro</th>
            <th>Serviço</th>
            <th>Extras</th>
            <th>Duração</th>
            <th>Pagamento</th>
            <th>Total</th>
            <th>Data</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
  <?php foreach($atendimentos as $a):
    $nomeCli = $a['cliente_nome'] ?: '—';
    $telCli  = $a['cliente_telefone'] ?: '';
    $itens   = $itensMap[$a['id']] ?? [];

    $duracao = '';
    if ($a['atendimento_iniciado_em'] && $a['finalizado_em']) {
        $ini  = new DateTime($a['atendimento_iniciado_em']);
        $fim  = new DateTime($a['finalizado_em']);
        $diff = $ini->diff($fim);
        $duracao = $diff->h > 0 ? $diff->h.'h '.$diff->i.'min' : $diff->i.'min';
    }

    $fp  = strtolower($a['forma_pagamento'] ?? '');
    $cls = str_contains($fp,'dinheiro') ? 'pag-dinheiro'
         : (str_contains($fp,'pix')     ? 'pag-pix'
         : (str_contains($fp,'deb')     ? 'pag-debito'
         : (str_contains($fp,'cred')    ? 'pag-credito'
         : 'pag-outro')));
  ?>
  <tr>
    <td><span class="text-id">#<?= $a['id'] ?></span></td>
    <td>
      <div class="text-white-soft fw-600"><?= htmlspecialchars($nomeCli) ?></div>
      <?php if($telCli): ?>
      <div class="text-muted-custom" style="font-size:.78rem">
        <i class="bi bi-phone me-1"></i><?= htmlspecialchars($telCli) ?>
      </div>
      <?php endif; ?>
    </td>
    <td>
      <div class="d-flex align-items-center gap-2">
        <?php if(!empty($a['barbeiro_foto']) && file_exists(__DIR__.'/../uploads/barbeiros/'.$a['barbeiro_foto'])): ?>
          <img src="<?= BASE_URL ?>/uploads/barbeiros/<?= htmlspecialchars($a['barbeiro_foto']) ?>" class="barb-mini" alt="">
        <?php else: ?>
          <span class="barb-mini-ph"><?= mb_strtoupper(mb_substr($a['barbeiro_nome'] ?? 'B', 0, 1)) ?></span>
        <?php endif; ?>
        <span class="text-white-soft"><?= htmlspecialchars($a['barbeiro_nome'] ?? '—') ?></span>
      </div>
    </td>
    <td><span class="text-white-soft"><?= htmlspecialchars($a['servico'] ?? '—') ?></span></td>
    <td>
      <?php if($itens): ?>
        <span style="background:rgba(59,130,246,.15);color:#93c5fd;border-radius:6px;padding:.2rem .55rem;font-size:.78rem;font-weight:600">
          <i class="bi bi-bag me-1"></i><?= count($itens) ?> item(s)
        </span>
      <?php else: ?>
        <span class="text-muted-custom">—</span>
      <?php endif; ?>
    </td>
    <td>
      <?php if($duracao): ?>
        <span style="color:#fde68a;font-size:.82rem">
          <i class="bi bi-clock me-1"></i><?= $duracao ?>
        </span>
      <?php else: ?>
        <span class="text-muted-custom">—</span>
      <?php endif; ?>
    </td>
    <td><span class="badge-pag <?= $cls ?>"><?= htmlspecialchars(ucfirst($a['forma_pagamento'] ?? '—')) ?></span></td>
    <td><span class="text-green">R$ <?= number_format($a['total_pago'] ?? 0, 2, ',', '.') ?></span></td>
    <td>
      <span style="color:rgba(255,255,255,.7);font-size:.82rem">
        <?= $a['finalizado_em'] ? date('d/m/y H:i', strtotime($a['finalizado_em'])) : '—' ?>
      </span>
    </td>
    <td>
      <button class="btn-comp btn-ver-comp"
        data-id="<?= $a['id'] ?>"
        data-cliente="<?= htmlspecialchars($nomeCli) ?>"
        data-tel="<?= htmlspecialchars($telCli) ?>"
        data-barbeiro="<?= htmlspecialchars($a['barbeiro_nome'] ?? '—') ?>"
        data-servico="<?= htmlspecialchars($a['servico'] ?? '—') ?>"
        data-pagamento="<?= htmlspecialchars(ucfirst($a['forma_pagamento'] ?? '—')) ?>"
        data-total="<?= number_format($a['total_pago'] ?? 0, 2, ',', '.') ?>"
        data-data="<?= $a['finalizado_em'] ? date('d/m/Y \à\s H:i', strtotime($a['finalizado_em'])) : '—' ?>"
        data-duracao="<?= htmlspecialchars($duracao ?: '—') ?>"
        data-entrou="<?= $a['entrou_em'] ? date('H:i', strtotime($a['entrou_em'])) : '—' ?>"
        data-obs="<?= htmlspecialchars($a['observacoes'] ?? '') ?>"
        data-itens='<?= htmlspecialchars(json_encode(array_map(fn($i) => [
          'nome'     => $i['nome_item'] ?? $i['produto_nome'] ?? $i['pacote_nome'] ?? '?',
          'tipo'     => $i['produto_id'] ? 'produto' : 'pacote',
          'qtd'      => $i['quantidade'] ?? 1,
          'subtotal' => $i['subtotal']   ?? 0,
        ], $itens)), ENT_QUOTES) ?>'>
        <i class="bi bi-receipt"></i> Ver
      </button>
    </td>
  </tr>
  <?php endforeach; ?>
</tbody>
      </table>
    </div>
  </div>

  <!-- Paginação -->
  <?php if($totalPaginas > 1): ?>
  <div class="d-flex justify-content-center align-items-center gap-2 mt-4 flex-wrap">
    <a href="<?= filtroUrl(['pag' => $pagina - 1]) ?>" class="pag-btn <?= $pagina <= 1 ? 'disabled' : '' ?>">
      <i class="bi bi-chevron-left"></i>
    </a>
    <?php
      $ini = max(1, $pagina - 2);
      $fim = min($totalPaginas, $pagina + 2);
      if($ini > 1): ?>
        <a href="<?= filtroUrl(['pag' => 1]) ?>" class="pag-btn">1</a>
        <?php if($ini > 2): ?><span style="color:rgba(255,255,255,.3)">…</span><?php endif;
      endif;
      for($p = $ini; $p <= $fim; $p++): ?>
        <a href="<?= filtroUrl(['pag' => $p]) ?>" class="pag-btn <?= $p == $pagina ? 'active' : '' ?>"><?= $p ?></a>
      <?php endfor;
      if($fim < $totalPaginas): ?>
        <?php if($fim < $totalPaginas - 1): ?><span style="color:rgba(255,255,255,.3)">…</span><?php endif; ?>
        <a href="<?= filtroUrl(['pag' => $totalPaginas]) ?>" class="pag-btn"><?= $totalPaginas ?></a>
      <?php endif; ?>
    <a href="<?= filtroUrl(['pag' => $pagina + 1]) ?>" class="pag-btn <?= $pagina >= $totalPaginas ? 'disabled' : '' ?>">
      <i class="bi bi-chevron-right"></i>
    </a>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>

<!-- Modal Comprovante -->
<div class="modal fade" id="modalComp" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" style="color:#fff">
          <i class="bi bi-receipt me-2" style="color:#e94560"></i>Comprovante
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="corpoComprovante"></div>
      <div class="modal-footer gap-2">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Fechar</button>
        <button type="button" class="btn btn-pdf" id="btnSalvarPDF">
          <i class="bi bi-file-earmark-pdf me-1"></i>PDF
        </button>
        <button type="button" class="btn btn-print" id="btnImprimir">
          <i class="bi bi-printer me-1"></i>Imprimir
        </button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

const nomeBarbearia = <?= json_encode($nomeBarbearia) ?>;
let dadosAtivos = {};

function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function gerarHTML(d) {
  const itensHTML = d.itens && d.itens.length ? `
    <div class="comp-section">
      <div class="comp-label mb-2"><i class="bi bi-bag me-1"></i>Produtos & Pacotes</div>
      <table style="width:100%;border-collapse:collapse;font-size:.85rem;color:#e0e0e0">
        <thead>
          <tr style="border-bottom:1px solid rgba(255,255,255,.1)">
            <th style="text-align:left;padding:.3rem .5rem;color:rgba(255,255,255,.5);font-size:.72rem">Item</th>
            <th style="text-align:center;padding:.3rem .5rem;color:rgba(255,255,255,.5);font-size:.72rem">Qtd</th>
            <th style="text-align:right;padding:.3rem .5rem;color:rgba(255,255,255,.5);font-size:.72rem">Subtotal</th>
          </tr>
        </thead>
        <tbody>
          ${d.itens.map(i=>`
            <tr style="border-bottom:1px solid rgba(255,255,255,.05)">
              <td style="padding:.35rem .5rem">
                <span style="font-size:.68rem;padding:.1rem .35rem;border-radius:4px;margin-right:.3rem;
                  background:${i.tipo==='produto'?'rgba(96,165,250,.15)':'rgba(167,139,250,.15)'};
                  color:${i.tipo==='produto'?'#60a5fa':'#a78bfa'}">${i.tipo}</span>
                ${esc(i.nome)}
              </td>
              <td style="text-align:center;padding:.35rem .5rem">${i.qtd}</td>
              <td style="text-align:right;padding:.35rem .5rem;color:#4ade80;font-weight:600">
                R$ ${parseFloat(i.subtotal||0).toFixed(2).replace('.',',')}
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>` : '';

  const obsHTML = d.obs ? `
    <div class="comp-section">
      <div class="comp-label"><i class="bi bi-chat-text me-1"></i>Observações</div>
      <div class="comp-value" style="font-weight:400;font-size:.88rem">${esc(d.obs)}</div>
    </div>` : '';

  return `<div id="printArea">
    <div class="comp-header">
      <div style="font-size:1.4rem;margin-bottom:.2rem">✂️</div>
      <div style="font-size:1.05rem;font-weight:800">${esc(nomeBarbearia)}</div>
      <div style="font-size:.78rem;opacity:.85;margin-top:.2rem">Comprovante de Atendimento #${d.id}</div>
    </div>

    <div class="comp-section">
      <div class="row g-2">
        <div class="col-7">
          <div class="comp-label"><i class="bi bi-person me-1"></i>Cliente</div>
          <div class="comp-value">${esc(d.cliente)}</div>
          ${d.tel?`<div style="color:rgba(255,255,255,.5);font-size:.78rem"><i class="bi bi-phone me-1"></i>${esc(d.tel)}</div>`:''}
        </div>
        <div class="col-5 text-end">
          <div class="comp-label">Data</div>
          <div class="comp-value" style="font-size:.85rem">${esc(d.data)}</div>
        </div>
      </div>
    </div>

    <div class="comp-section">
      <div class="row g-2">
        <div class="col-7">
          <div class="comp-label"><i class="bi bi-scissors me-1"></i>Serviço</div>
          <div class="comp-value">${esc(d.servico)}</div>
        </div>
        <div class="col-5 text-end">
          <div class="comp-label">Barbeiro</div>
          <div class="comp-value" style="font-size:.9rem">${esc(d.barbeiro)}</div>
        </div>
      </div>
    </div>

    <div class="comp-section">
      <div class="row g-2">
        <div class="col-6">
          <div class="comp-label"><i class="bi bi-clock me-1"></i>Duração</div>
          <div class="comp-value">${esc(d.duracao)}</div>
        </div>
        <div class="col-6 text-end">
          <div class="comp-label">Entrada na fila</div>
          <div class="comp-value">${esc(d.entrou)}</div>
        </div>
      </div>
    </div>

    ${itensHTML}
    ${obsHTML}

    <hr style="border-color:rgba(255,255,255,.1);margin:.75rem 0">

    <div class="d-flex justify-content-between align-items-center px-1">
      <div>
        <div class="comp-label">Forma de pagamento</div>
        <div class="comp-value">${esc(d.pagamento)}</div>
      </div>
      <div class="text-end">
        <div class="comp-label">Total</div>
        <div class="comp-total">R$ ${esc(d.total)}</div>
      </div>
    </div>

    <div style="text-align:center;margin-top:1.2rem;color:rgba(255,255,255,.2);font-size:.7rem">
      Gerado em ${new Date().toLocaleString('pt-BR')} · ${esc(nomeBarbearia)}
    </div>
  </div>`;
}

document.querySelectorAll('.btn-ver-comp').forEach(btn => {
  btn.addEventListener('click', function() {
    let itens = [];
    try { itens = JSON.parse(this.dataset.itens); } catch(e) {}
    dadosAtivos = {
      id: this.dataset.id, cliente: this.dataset.cliente,
      tel: this.dataset.tel, barbeiro: this.dataset.barbeiro,
      servico: this.dataset.servico, pagamento: this.dataset.pagamento,
      total: this.dataset.total, data: this.dataset.data,
      duracao: this.dataset.duracao, entrou: this.dataset.entrou,
      obs: this.dataset.obs, itens,
    };
    document.getElementById('corpoComprovante').innerHTML = gerarHTML(dadosAtivos);
    new bootstrap.Modal(document.getElementById('modalComp')).show();
  });
});

document.getElementById('btnImprimir').addEventListener('click', () => {
  const area = document.getElementById('printArea');
  if (!area) return;
  const w = window.open('', '_blank', 'width=440,height=720');
  w.document.write(`<!DOCTYPE html><html><head>
    <meta charset="UTF-8">
    <title>Comprovante #${dadosAtivos.id}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
      body{background:#fff;color:#000;font-family:'Segoe UI',sans-serif;padding:1.5rem}
      .comp-header{background:#e94560;color:#fff;border-radius:10px;padding:1rem;text-align:center;margin-bottom:1rem}
      .comp-section{background:#f5f5f5;border-radius:8px;padding:.85rem 1rem;margin-bottom:.65rem}
      .comp-label{color:#888;font-size:.72rem;text-transform:uppercase;letter-spacing:.5px}
      .comp-value{font-weight:700;font-size:.95rem;color:#111}
      .comp-total{font-size:1.4rem;font-weight:800;color:#16a34a}
      hr{border-color:#ddd;margin:.75rem 0}
      table{width:100%;border-collapse:collapse;font-size:.85rem}
      th{color:#888;font-size:.72rem;padding:.3rem .5rem;text-align:left;border-bottom:1px solid #eee}
      td{padding:.35rem .5rem;border-bottom:1px solid #f0f0f0;color:#111}
    </style></head><body>
    ${area.innerHTML}
    <script>window.onload=()=>{window.print();window.close()}<\/script>
    </body></html>`);
  w.document.close();
});

document.getElementById('btnSalvarPDF').addEventListener('click', () => {
  const el = document.getElementById('printArea');
  if (!el) return;
  const clone = el.cloneNode(true);
  clone.style.cssText = 'background:#fff;color:#000;padding:1.2rem;font-family:Segoe UI,sans-serif;width:390px';
  clone.querySelectorAll('.comp-section').forEach(s => s.style.cssText = 'background:#f5f5f5;border-radius:8px;padding:.85rem;margin-bottom:.65rem');
  clone.querySelectorAll('.comp-label').forEach(l => l.style.color = '#888');
  clone.querySelectorAll('.comp-value').forEach(v => v.style.color = '#111');
  clone.querySelectorAll('.comp-total').forEach(t => t.style.color = '#16a34a');
  clone.querySelectorAll('.comp-header').forEach(h => {
    h.style.background = '#e94560';
    h.style.color = '#fff';
  });
  document.body.appendChild(clone);
  html2pdf().set({
    margin: [8,8,8,8],
    filename: `comprovante_${dadosAtivos.id}_${(dadosAtivos.cliente||'cliente').replace(/\s+/g,'_')}.pdf`,
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2, useCORS: true },
    jsPDF: { unit: 'mm', format: 'a5', orientation: 'portrait' },
  }).from(clone).save().then(() => document.body.removeChild(clone));
});
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope)).catch(e => console.log('SW erro:', e));
  });
}
</script>
</body>
</html>