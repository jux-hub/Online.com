<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// ── Excluir registro ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'excluir') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id) {
        $db->prepare('DELETE FROM fila WHERE id=?')->execute([$id]);
        flash('success', 'Registro excluído do histórico.');
    }
    $redir = $_POST['redirect'] ?? 'historico.php';
    header('Location: ' . $redir); exit;
}

// ── Filtros ──────────────────────────────────────
$busca    = trim($_GET['busca'] ?? '');
$barb_id  = (int)($_GET['barbeiro'] ?? 0);
$status   = $_GET['status'] ?? 'todos';
$dataIni  = $_GET['data_ini'] ?? date('Y-m-01');
$dataFim  = $_GET['data_fim'] ?? date('Y-m-d');
$pagina   = max(1, (int)($_GET['pagina'] ?? 1));
$porPagina = 20;
$offset    = ($pagina - 1) * $porPagina;

// ── Exportar CSV ─────────────────────────────────
if (isset($_GET['exportar'])) {
    $sqlExp = "SELECT f.id, DATE(f.finalizado_em) as data,
                   TIME(f.finalizado_em) as hora,
                   c.nome as cliente, c.telefone,
                   u.nome as barbeiro,
                   s.nome as servico,
                   f.valor, f.forma_pagamento, f.status,
                   ROUND(f.valor * u.comissao_percent / 100, 2) as comissao,
                   ROUND(f.valor - (f.valor * u.comissao_percent / 100), 2) as lucro
               FROM fila f
               JOIN clientes c ON c.id=f.cliente_id
               JOIN usuarios u ON u.id=f.barbeiro_id
               LEFT JOIN servicos s ON s.id=f.servico_id
               WHERE 1=1";
    $paramsExp = [];
    if ($busca) {
        $sqlExp .= " AND (c.nome LIKE ? OR c.telefone LIKE ?)";
        $paramsExp[] = "%{$busca}%";
        $paramsExp[] = "%{$busca}%";
    }
    if ($barb_id) { $sqlExp .= " AND f.barbeiro_id=?"; $paramsExp[] = $barb_id; }
    if ($status !== 'todos') { $sqlExp .= " AND f.status=?"; $paramsExp[] = $status; }
    $sqlExp .= " AND DATE(f.criado_em) BETWEEN ? AND ? ORDER BY f.criado_em DESC";
    $paramsExp[] = $dataIni;
    $paramsExp[] = $dataFim;

    $rows = $db->prepare($sqlExp);
    $rows->execute($paramsExp);
    $rows = $rows->fetchAll();

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="historico_' . date('Y-m-d') . '.csv"');
    header('Pragma: no-cache');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    fputcsv($out, ['#','Data','Hora','Cliente','Telefone','Barbeiro','Serviço','Valor','Pagamento','Status','Comissão','Lucro'], ';');
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['id'], $r['data'], $r['hora'],
            $r['cliente'], $r['telefone'],
            $r['barbeiro'], $r['servico'] ?? '–',
            number_format($r['valor'] ?? 0, 2, ',', '.'),
            $r['forma_pagamento'] ?? '–',
            $r['status'],
            number_format($r['comissao'] ?? 0, 2, ',', '.'),
            number_format($r['lucro'] ?? 0, 2, ',', '.'),
        ], ';');
    }
    fclose($out);
    exit;
}

// ── Query principal ──────────────────────────────
$where  = "WHERE 1=1";
$params = [];

if ($busca) {
    $where   .= " AND (c.nome LIKE ? OR c.telefone LIKE ?)";
    $params[] = "%{$busca}%";
    $params[] = "%{$busca}%";
}
if ($barb_id) { $where .= " AND f.barbeiro_id=?"; $params[] = $barb_id; }
if ($status !== 'todos') { $where .= " AND f.status=?"; $params[] = $status; }
$where   .= " AND DATE(f.criado_em) BETWEEN ? AND ?";
$params[] = $dataIni;
$params[] = $dataFim;

$sqlBase = "FROM fila f
            JOIN clientes c ON c.id=f.cliente_id
            JOIN usuarios u ON u.id=f.barbeiro_id
            LEFT JOIN servicos s ON s.id=f.servico_id
            {$where}";

// Total de registros
$totalQ = $db->prepare("SELECT COUNT(*) as c {$sqlBase}");
$totalQ->execute($params);
$total = (int)$totalQ->fetch()['c'];
$totalPaginas = max(1, ceil($total / $porPagina));

// KPIs do período filtrado (sem paginação)
$kpiQ = $db->prepare("SELECT
    SUM(f.valor) as fat,
    SUM(f.valor * u.comissao_percent / 100) as com,
    COUNT(*) as cortes
    {$sqlBase} AND f.status='concluido'");
$kpiQ->execute($params);
$kpi = $kpiQ->fetch();
$kpiFat     = (float)($kpi['fat']    ?? 0);
$kpiCom     = (float)($kpi['com']    ?? 0);
$kpiCortes  = (int)  ($kpi['cortes'] ?? 0);
$kpiLucro   = $kpiFat - $kpiCom;
$kpiTicket  = $kpiCortes > 0 ? $kpiFat / $kpiCortes : 0;

// Registros da página
$sql = "SELECT f.id, f.status, f.valor, f.forma_pagamento,
               f.criado_em, f.iniciado_em, f.finalizado_em,
               c.nome as cliente_nome, c.telefone,
               u.nome as barbeiro_nome, u.comissao_percent, u.foto as barbeiro_foto,
               s.nome as servico_nome, s.preco as servico_preco
        {$sqlBase}
        ORDER BY f.criado_em DESC
        LIMIT {$porPagina} OFFSET {$offset}";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$registros = $stmt->fetchAll();

$barbeiros     = $db->query("SELECT * FROM usuarios WHERE tipo='barbeiro' ORDER BY nome")->fetchAll();
$nomeBarbearia = getConfig('nome_barbearia');

$statusConfig = [
    'concluido' => ['Concluído',  '#4ade80', 'rgba(34,197,94,.2)'],
    'cancelado' => ['Cancelado',  '#f87171', 'rgba(239,68,68,.2)'],
    'aguardando'=> ['Aguardando', '#fbbf24', 'rgba(245,158,11,.2)'],
    'atendendo' => ['Atendendo',  '#60a5fa', 'rgba(59,130,246,.2)'],
];
$pgIcons = ['pix'=>'bi-qr-code','dinheiro'=>'bi-cash','debito'=>'bi-credit-card','credito'=>'bi-credit-card-2-front'];

function urlPag($pagina) {
    $p = $_GET; $p['pagina'] = $pagina;
    return '?' . http_build_query($p);
}

function diffMinutos($ini, $fim) {
    if (!$ini || !$fim) return null;
    $mins = (int)round((strtotime($fim) - strtotime($ini)) / 60);
    if ($mins < 0) return null;
    if ($mins < 60) return "{$mins} min";
    $h = intdiv($mins, 60); $m = $mins % 60;
    return $m > 0 ? "{$h}h {$m}min" : "{$h}h";
}

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Histórico – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  .sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:.25s;display:flex;align-items:center;gap:.75rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  .main-content{margin-left:260px;padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  .kpi-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
    border-radius:14px;padding:.9rem 1.1rem;display:flex;align-items:center;gap:.85rem}
  .kpi-icon{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;
    justify-content:center;font-size:1.1rem;flex-shrink:0}
  .kpi-val{font-size:1.1rem;font-weight:800;color:#fff;line-height:1.1}
  .kpi-lbl{font-size:.72rem;color:rgba(255,255,255,.4);margin-top:.15rem}

  .filtros-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);
    border-radius:16px;padding:1.1rem;margin-bottom:1.25rem}
  .form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:10px;padding:.5rem .85rem;font-size:.875rem}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.12);
    border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.35)}
  .form-select option{background:#1a1a2e;color:#fff}
  .form-control[type=date]{color-scheme:dark}
  label.form-label{color:rgba(255,255,255,.7);font-size:.8rem;margin-bottom:.3rem}

  .btn-filtrar{background:linear-gradient(135deg,#e94560,#c41230);border:none;
    color:#fff;border-radius:10px;padding:.5rem 1.2rem;font-weight:600;
    font-size:.875rem;cursor:pointer;transition:.2s}
  .btn-filtrar:hover{opacity:.9;color:#fff}
  .btn-exportar{background:linear-gradient(135deg,#22c55e,#16a34a);border:none;
    color:#fff;border-radius:10px;padding:.5rem 1.2rem;font-weight:600;
    font-size:.875rem;cursor:pointer;transition:.2s;text-decoration:none;
    display:inline-flex;align-items:center;gap:.4rem}
  .btn-exportar:hover{opacity:.9;color:#fff}
  .btn-limpar{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);
    color:rgba(255,255,255,.6);border-radius:10px;padding:.5rem 1rem;
    font-size:.875rem;text-decoration:none;transition:.2s}
  .btn-limpar:hover{background:rgba(255,255,255,.15);color:#fff}

  .reg-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
    border-radius:12px;padding:.9rem 1rem;margin-bottom:.5rem;transition:.2s}
  .reg-card:hover{background:rgba(255,255,255,.065)}
  .reg-card.concluido{border-left:3px solid rgba(34,197,94,.5)}
  .reg-card.cancelado{border-left:3px solid rgba(239,68,68,.4)}
  .reg-card.aguardando{border-left:3px solid rgba(245,158,11,.4)}
  .reg-card.atendendo{border-left:3px solid rgba(59,130,246,.4)}

  .reg-header{cursor:pointer;display:flex;align-items:start;gap:.75rem;flex-wrap:wrap}

  .reg-detail{display:none;margin-top:.85rem;padding-top:.85rem;
    border-top:1px solid rgba(255,255,255,.07)}
  .reg-detail.open{display:block}
  .detail-item{background:rgba(255,255,255,.04);border-radius:9px;padding:.65rem .85rem;text-align:center}
  .detail-val{font-size:.9rem;font-weight:700;color:#fff;margin-bottom:.15rem}
  .detail-lbl{font-size:.68rem;color:rgba(255,255,255,.4)}

  .barb-mini-foto{width:32px;height:32px;border-radius:50%;object-fit:cover;
    border:1px solid rgba(233,69,96,.4);flex-shrink:0}
  .barb-mini-ph{width:32px;height:32px;border-radius:50%;
    background:linear-gradient(135deg,#e94560,#c41230);
    display:flex;align-items:center;justify-content:center;flex-shrink:0}

  .reg-data{font-size:.75rem;color:rgba(255,255,255,.4);min-width:65px;flex-shrink:0}
  .reg-cliente{font-weight:700;color:#fff;font-size:.9rem}
  .reg-tel{font-size:.75rem;color:rgba(255,255,255,.4)}
  .reg-valor{font-weight:800;color:#4ade80;font-size:.95rem;flex-shrink:0}
  .reg-com{font-size:.75rem;color:#fbbf24;flex-shrink:0}
  .reg-lucro{font-size:.75rem;color:#60a5fa;flex-shrink:0}

  .status-badge{border-radius:6px;padding:.2rem .6rem;font-size:.74rem;font-weight:600;flex-shrink:0}

  .btn-del{background:rgba(239,68,68,.15);color:#f87171;border:none;
    border-radius:7px;padding:.3rem .55rem;font-size:.75rem;cursor:pointer;
    transition:.2s;display:inline-flex;align-items:center;gap:.25rem}
  .btn-del:hover{background:rgba(239,68,68,.3)}

  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12)}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08)}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08)}
  .modal-title{color:#fff}
  .btn-danger-confirm{background:linear-gradient(135deg,#ef4444,#b91c1c);
    border:none;color:#fff;border-radius:10px;font-weight:600}
  .btn-danger-confirm:hover{opacity:.9;color:#fff}
  .excluir-info{color:#f87171;font-weight:700}

  .pag-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
    color:rgba(255,255,255,.65);border-radius:8px;padding:.4rem .85rem;
    text-decoration:none;font-size:.85rem;transition:.2s}
  .pag-btn:hover,.pag-btn.active{background:var(--primary);border-color:var(--primary);color:#fff}
  .pag-btn.disabled{opacity:.3;pointer-events:none}

  .vazio{text-align:center;padding:3rem 0;color:rgba(255,255,255,.3)}

  .btn-comp{background:rgba(255,255,255,.07);color:rgba(255,255,255,.5);
    border:none;border-radius:7px;padding:.3rem .55rem;font-size:.75rem;
    text-decoration:none;transition:.2s;display:inline-flex;align-items:center;gap:.25rem}
  .btn-comp:hover{background:rgba(233,69,96,.2);color:#e94560}

  .chevron{font-size:.75rem;color:rgba(255,255,255,.3);transition:.25s;flex-shrink:0;margin-top:.2rem}
  .chevron.open{transform:rotate(180deg)}

  h4,h5,h6{color:#fff;margin:0}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">
          <i class="bi bi-clock-history me-2" style="color:#e94560"></i>Histórico Completo
        </h5>
        <div style="font-size:.72rem;color:rgba(255,255,255,.4)">
          <?= $total ?> registro(s) encontrado(s)
        </div>
      </div>
    </div>
    <?php
      $exportParams = $_GET;
      $exportParams['exportar'] = '1';
      unset($exportParams['pagina']);
    ?>
    <a href="?<?= http_build_query($exportParams) ?>" class="btn-exportar">
      <i class="bi bi-file-earmark-spreadsheet"></i>
      <span class="d-none d-sm-inline">Exportar CSV</span>
    </a>
  </div>

  <div class="page-body">

    <?= renderFlash() ?>

    <!-- ── Mini KPIs ── -->
    <div class="row g-2 mb-4">
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(233,69,96,.15)">
            <i class="bi bi-scissors" style="color:#e94560"></i>
          </div>
          <div>
            <div class="kpi-val"><?= $kpiCortes ?></div>
            <div class="kpi-lbl">Cortes concluídos</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(34,197,94,.15)">
            <i class="bi bi-cash-stack" style="color:#4ade80"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#4ade80;font-size:.95rem"><?= formatMoney($kpiFat) ?></div>
            <div class="kpi-lbl">Faturamento</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(245,158,11,.15)">
            <i class="bi bi-percent" style="color:#fbbf24"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#fbbf24;font-size:.95rem"><?= formatMoney($kpiCom) ?></div>
            <div class="kpi-lbl">Total comissões</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(59,130,246,.15)">
            <i class="bi bi-graph-up-arrow" style="color:#60a5fa"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#60a5fa;font-size:.95rem"><?= formatMoney($kpiLucro) ?></div>
            <div class="kpi-lbl">Lucro líquido</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(168,85,247,.15)">
            <i class="bi bi-receipt" style="color:#a78bfa"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#a78bfa;font-size:.95rem">
              <?= $kpiCortes > 0 ? formatMoney($kpiTicket) : 'R$ 0,00' ?>
            </div>
            <div class="kpi-lbl">Ticket médio</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(236,72,153,.15)">
            <i class="bi bi-arrow-up-right-circle" style="color:#f472b6"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#f472b6;font-size:.95rem">
              <?= $kpiFat > 0 ? number_format($kpiLucro / $kpiFat * 100, 1) : 0 ?>%
            </div>
            <div class="kpi-lbl">Margem de lucro</div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Filtros ── -->
    <div class="filtros-card">
      <form method="GET" id="formFiltro">
        <div class="row g-2 align-items-end">
          <div class="col-12 col-md-3">
            <label class="form-label"><i class="bi bi-search me-1"></i>Buscar cliente</label>
            <input type="text" name="busca" class="form-control"
              placeholder="Nome ou telefone..."
              value="<?= htmlspecialchars($busca) ?>">
          </div>
          <div class="col-6 col-md-2">
            <label class="form-label"><i class="bi bi-calendar me-1"></i>De</label>
            <input type="date" name="data_ini" class="form-control"
              value="<?= htmlspecialchars($dataIni) ?>">
          </div>
          <div class="col-6 col-md-2">
            <label class="form-label"><i class="bi bi-calendar me-1"></i>Até</label>
            <input type="date" name="data_fim" class="form-control"
              value="<?= htmlspecialchars($dataFim) ?>">
          </div>
          <div class="col-6 col-md-2">
            <label class="form-label"><i class="bi bi-person me-1"></i>Barbeiro</label>
            <select name="barbeiro" class="form-select">
              <option value="0">Todos</option>
              <?php foreach($barbeiros as $b): ?>
              <option value="<?= $b['id'] ?>" <?= $barb_id==$b['id']?'selected':'' ?>>
                <?= htmlspecialchars($b['nome']) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-6 col-md-2">
            <label class="form-label"><i class="bi bi-circle me-1"></i>Status</label>
            <select name="status" class="form-select">
              <option value="todos"      <?= $status==='todos'     ?'selected':'' ?>>Todos</option>
              <option value="concluido"  <?= $status==='concluido' ?'selected':'' ?>>Concluídos</option>
              <option value="cancelado"  <?= $status==='cancelado' ?'selected':'' ?>>Cancelados</option>
              <option value="aguardando" <?= $status==='aguardando'?'selected':'' ?>>Aguardando</option>
              <option value="atendendo"  <?= $status==='atendendo' ?'selected':'' ?>>Atendendo</option>
            </select>
          </div>
          <div class="col-12 col-md-1 d-flex gap-2">
            <button type="submit" class="btn-filtrar flex-grow-1">
              <i class="bi bi-search"></i>
            </button>
            <a href="historico.php" class="btn-limpar">
              <i class="bi bi-x-lg"></i>
            </a>
          </div>
        </div>
      </form>
    </div>

    <!-- ── Lista de registros ── -->
    <?php if(empty($registros)): ?>
      <div class="vazio">
        <i class="bi bi-inbox" style="font-size:2.5rem;display:block;margin-bottom:.75rem"></i>
        Nenhum registro encontrado para os filtros selecionados
      </div>
    <?php else: ?>

      <?php foreach($registros as $idx => $r):
        [$stLabel, $stCor, $stBg] = $statusConfig[$r['status']] ?? ['–','#fff','rgba(255,255,255,.1)'];
        $comissao = ($r['valor'] ?? 0) * ($r['comissao_percent'] / 100);
        $lucro    = ($r['valor'] ?? 0) - $comissao;
        $icon     = $pgIcons[$r['forma_pagamento'] ?? ''] ?? 'bi-dash';
        $keyComp  = substr(md5($r['id'] . 'barbearia_renato'), 0, 8);
        $temFoto  = !empty($r['barbeiro_foto'])
            && file_exists(__DIR__.'/../uploads/barbeiros/'.$r['barbeiro_foto']);
        $fotoUrl  = $temFoto
            ? BASE_URL . '/uploads/barbeiros/'.htmlspecialchars($r['barbeiro_foto'])
            : null;

        $tempoEspera = diffMinutos($r['criado_em'],   $r['iniciado_em']);
        $tempoAtend  = diffMinutos($r['iniciado_em'], $r['finalizado_em']);
        $tempoTotal  = diffMinutos($r['criado_em'],   $r['finalizado_em']);
        $detailId = 'det' . $r['id'];
      ?>
      <div class="reg-card <?= $r['status'] ?>">

        <div class="reg-header" onclick="toggleDetail('<?= $detailId ?>', this)">

          <div class="reg-data">
            <div style="font-weight:600;color:rgba(255,255,255,.55)">
              <?= $r['criado_em'] ? date('d/m/y', strtotime($r['criado_em'])) : '–' ?>
            </div>
            <div style="font-size:.7rem;color:rgba(255,255,255,.3)">
              <?= $r['criado_em'] ? date('H:i', strtotime($r['criado_em'])) : '' ?>
            </div>
          </div>

          <div class="flex-grow-1 min-width-0">
            <div class="reg-cliente"><?= htmlspecialchars($r['cliente_nome']) ?></div>
            <div class="reg-tel"><?= htmlspecialchars($r['telefone']) ?></div>
            <div class="d-flex align-items-center gap-1 flex-wrap mt-1">
              <?php if($fotoUrl): ?>
                <img src="<?= $fotoUrl ?>" class="barb-mini-foto" alt="">
              <?php else: ?>
                <div class="barb-mini-ph">
                  <i class="bi bi-person-fill text-white" style="font-size:.65rem"></i>
                </div>
              <?php endif; ?>
              <span style="font-size:.78rem;color:rgba(255,255,255,.5)">
                <?= htmlspecialchars($r['barbeiro_nome']) ?>
              </span>
              <?php if($r['servico_nome']): ?>
                <span style="background:rgba(59,130,246,.15);color:#60a5fa;
                  border-radius:5px;padding:.15rem .5rem;font-size:.72rem">
                  <?= htmlspecialchars($r['servico_nome']) ?>
                </span>
              <?php endif; ?>
              <?php if($r['forma_pagamento']): ?>
                <span style="font-size:.75rem;color:rgba(255,255,255,.4)">
                  <i class="bi <?= $icon ?> me-1"></i><?= ucfirst($r['forma_pagamento']) ?>
                </span>
              <?php endif; ?>
            </div>
          </div>

          <div class="d-flex flex-column align-items-end gap-1">
            <span class="status-badge" style="background:<?= $stBg ?>;color:<?= $stCor ?>">
              <?= $stLabel ?>
            </span>
            <?php if($r['valor']): ?>
              <div class="reg-valor"><?= formatMoney($r['valor']) ?></div>
              <div class="reg-com"><i class="bi bi-percent me-1"></i><?= formatMoney($comissao) ?></div>
              <div class="reg-lucro"><i class="bi bi-arrow-up-right me-1"></i><?= formatMoney($lucro) ?></div>
            <?php endif; ?>
          </div>

          <i class="bi bi-chevron-down chevron" id="chv<?= $r['id'] ?>"></i>
        </div>

        <div class="reg-detail" id="<?= $detailId ?>">
          <div class="row g-2 mb-3">
            <div class="col-6 col-md-3">
              <div class="detail-item">
                <div class="detail-val" style="color:#fb923c"><?= $tempoEspera ?? '–' ?></div>
                <div class="detail-lbl"><i class="bi bi-hourglass-split me-1"></i>Tempo de espera</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div class="detail-item">
                <div class="detail-val" style="color:#2dd4bf"><?= $tempoAtend ?? '–' ?></div>
                <div class="detail-lbl"><i class="bi bi-scissors me-1"></i>Duração atendimento</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div class="detail-item">
                <div class="detail-val" style="color:#a78bfa"><?= $tempoTotal ?? '–' ?></div>
                <div class="detail-lbl"><i class="bi bi-clock me-1"></i>Tempo total</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div class="detail-item">
                <div class="detail-val" style="color:#60a5fa">
                  <?= $r['valor'] ? formatMoney($lucro) : '–' ?>
                </div>
                <div class="detail-lbl"><i class="bi bi-graph-up-arrow me-1"></i>Lucro líquido</div>
              </div>
            </div>
          </div>

          <div class="d-flex gap-3 flex-wrap mb-3" style="font-size:.75rem;color:rgba(255,255,255,.4)">
            <?php if($r['criado_em']): ?>
            <span>
              <i class="bi bi-plus-circle me-1" style="color:#fbbf24"></i>
              Entrada: <?= date('d/m/Y H:i', strtotime($r['criado_em'])) ?>
            </span>
            <?php endif; ?>
            <?php if($r['iniciado_em']): ?>
            <span>
              <i class="bi bi-play-circle me-1" style="color:#4ade80"></i>
              Início: <?= date('d/m/Y H:i', strtotime($r['iniciado_em'])) ?>
            </span>
            <?php endif; ?>
            <?php if($r['finalizado_em']): ?>
            <span>
              <i class="bi bi-check-circle me-1" style="color:#60a5fa"></i>
              Fim: <?= date('d/m/Y H:i', strtotime($r['finalizado_em'])) ?>
            </span>
            <?php endif; ?>
            <span><i class="bi bi-hash me-1"></i>ID #<?= $r['id'] ?></span>
          </div>

          <div class="d-flex align-items-center gap-2 flex-wrap">
            <?php if($keyComp && $r['status']==='concluido' && $r['valor']): ?>
              <a href="../comprovante.php?id=<?= $r['id'] ?>&key=<?= $keyComp ?>"
                 target="_blank" class="btn-comp">
                <i class="bi bi-receipt"></i>Ver comprovante
              </a>
            <?php endif; ?>
            <button class="btn-del"
              data-id="<?= $r['id'] ?>"
              data-cliente="<?= htmlspecialchars($r['cliente_nome']) ?>"
              data-bs-toggle="modal" data-bs-target="#modalExcluir">
              <i class="bi bi-trash"></i>Excluir
            </button>
          </div>
        </div>

      </div>
      <?php endforeach; ?>

      <?php if($totalPaginas > 1): ?>
      <div class="d-flex align-items-center justify-content-center gap-1 mt-4 flex-wrap">
        <a href="<?= urlPag($pagina - 1) ?>"
           class="pag-btn <?= $pagina<=1?'disabled':'' ?>">
          <i class="bi bi-chevron-left"></i>
        </a>
        <?php
          $ini2 = max(1, $pagina - 2);
          $fim2 = min($totalPaginas, $pagina + 2);
          if($ini2 > 1): ?>
            <a href="<?= urlPag(1) ?>" class="pag-btn">1</a>
            <?php if($ini2 > 2): ?>
              <span style="color:rgba(255,255,255,.3);padding:0 .25rem">…</span>
            <?php endif; ?>
        <?php endif; ?>
        <?php for($i = $ini2; $i <= $fim2; $i++): ?>
          <a href="<?= urlPag($i) ?>"
             class="pag-btn <?= $i===$pagina?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <?php if($fim2 < $totalPaginas): ?>
          <?php if($fim2 < $totalPaginas - 1): ?>
            <span style="color:rgba(255,255,255,.3);padding:0 .25rem">…</span>
          <?php endif; ?>
          <a href="<?= urlPag($totalPaginas) ?>" class="pag-btn"><?= $totalPaginas ?></a>
        <?php endif; ?>
        <a href="<?= urlPag($pagina + 1) ?>"
           class="pag-btn <?= $pagina>=$totalPaginas?'disabled':'' ?>">
          <i class="bi bi-chevron-right"></i>
        </a>
        <span style="color:rgba(255,255,255,.3);font-size:.8rem;margin-left:.5rem">
          Página <?= $pagina ?> de <?= $totalPaginas ?> · <?= $total ?> registros
        </span>
      </div>
      <?php endif; ?>

    <?php endif; ?>

  </div>
</div>

<!-- Modal Confirmar Exclusão -->
<div class="modal fade" id="modalExcluir" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          <i class="bi bi-exclamation-triangle-fill me-2" style="color:#f87171"></i>
          Confirmar Exclusão
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="color:rgba(255,255,255,.8)">
        Deseja excluir o atendimento de
        <span id="excluirCliente" class="excluir-info"></span>?
        <div class="mt-2" style="color:rgba(255,255,255,.4);font-size:.85rem">
          <i class="bi bi-info-circle me-1"></i>
          Esta ação remove permanentemente o registro e não pode ser desfeita.
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
        <form method="POST" class="d-inline">
          <input type="hidden" name="acao" value="excluir">
          <input type="hidden" name="id" id="excluirId" value="">
          <input type="hidden" name="redirect" value="<?= htmlspecialchars('?' . http_build_query($_GET)) ?>">
          <button type="submit" class="btn btn-danger-confirm px-4">
            <i class="bi bi-trash me-1"></i>Excluir
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

function toggleDetail(id, header) {
  const det  = document.getElementById(id);
  const regId = id.replace('det','');
  const chv  = document.getElementById('chv' + regId);
  if (!det) return;
  det.classList.toggle('open');
  chv?.classList.toggle('open');
}

document.querySelectorAll('.btn-del').forEach(btn => {
  btn.addEventListener('click', function(e) {
    e.stopPropagation();
    document.getElementById('excluirId').value            = this.dataset.id;
    document.getElementById('excluirCliente').textContent = this.dataset.cliente;
  });
});
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</body>
</html>