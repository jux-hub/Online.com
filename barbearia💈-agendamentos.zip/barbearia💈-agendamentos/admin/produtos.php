<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// ── Migrações automáticas ──
try { $db->exec("CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    descricao TEXT,
    tipo TEXT NOT NULL DEFAULT 'produto',
    preco REAL NOT NULL DEFAULT 0,
    ativo INTEGER NOT NULL DEFAULT 1,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
)"); } catch(Exception $e) {}

try { $db->exec("CREATE TABLE IF NOT EXISTS fila_itens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fila_id INTEGER NOT NULL,
    produto_id INTEGER,
    nome TEXT NOT NULL,
    preco REAL DEFAULT 0,
    qty INTEGER DEFAULT 1,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
)"); } catch(Exception $e) {}

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'salvar') {
        $id        = (int)($_POST['id'] ?? 0);
        $nome      = trim($_POST['nome'] ?? '');
        $descricao = trim($_POST['descricao'] ?? '');
        $tipo      = in_array($_POST['tipo'] ?? '', ['produto','pacote']) ? $_POST['tipo'] : 'produto';
        $preco     = (float)str_replace(',', '.', $_POST['preco'] ?? 0);
        $ativo     = isset($_POST['ativo']) ? 1 : 0;

        if ($nome === '') { flash('danger','Nome obrigatório.'); header('Location: produtos.php'); exit; }

        if ($id > 0) {
            $db->prepare("UPDATE produtos SET nome=?, descricao=?, tipo=?, preco=?, ativo=? WHERE id=?")
               ->execute([$nome, $descricao, $tipo, $preco, $ativo, $id]);
            flash('success','Produto/pacote atualizado!');
        } else {
            $db->prepare("INSERT INTO produtos (nome, descricao, tipo, preco, ativo) VALUES (?,?,?,?,?)")
               ->execute([$nome, $descricao, $tipo, $preco, $ativo]);
            flash('success','Produto/pacote cadastrado!');
        }
    }

    if ($acao === 'toggle') {
        $id = (int)$_POST['id'];
        $db->prepare("UPDATE produtos SET ativo = 1 - ativo WHERE id=?")->execute([$id]);
    }

    if ($acao === 'excluir') {
        $id  = (int)$_POST['id'];
        $uso = $db->prepare("SELECT COUNT(*) FROM fila_itens WHERE produto_id=?");
        $uso->execute([$id]);
        if ($uso->fetchColumn() > 0) {
            flash('danger','Não é possível excluir: produto já foi vendido em atendimentos.');
        } else {
            $db->prepare("DELETE FROM produtos WHERE id=?")->execute([$id]);
            flash('success','Excluído com sucesso.');
        }
    }

    header('Location: produtos.php'); exit;
}

// ── GET ──
$tipo_filtro = $_GET['tipo'] ?? 'todos';
$busca       = trim($_GET['q'] ?? '');

$where  = '1=1';
$params = [];
if ($tipo_filtro !== 'todos') { $where .= ' AND tipo=?';                           $params[] = $tipo_filtro; }
if ($busca !== '')             { $where .= ' AND (nome LIKE ? OR descricao LIKE ?)'; $params[] = "%$busca%"; $params[] = "%$busca%"; }

$stmt = $db->prepare("SELECT * FROM produtos WHERE $where ORDER BY tipo, nome");
$stmt->execute($params);
$lista = $stmt->fetchAll();

// Stats
$stats = $db->query("SELECT
    COUNT(*) as total,
    SUM(ativo) as ativos,
    SUM(tipo='produto') as produtos,
    SUM(tipo='pacote') as pacotes
FROM produtos")->fetch();

// Mais vendidos
$maisVendidos = $db->query("
    SELECT fi.nome, fi.produto_id, SUM(fi.qty) as qtd, SUM(fi.preco * fi.qty) as receita
    FROM fila_itens fi GROUP BY fi.nome ORDER BY qtd DESC LIMIT 5
")->fetchAll();

$nomeBarbearia = getConfig('nome_barbearia');

$editando = null;
if (isset($_GET['editar'])) {
    $s = $db->prepare("SELECT * FROM produtos WHERE id=?");
    $s->execute([(int)$_GET['editar']]);
    $editando = $s->fetch();
}

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Produtos p/ Venda – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0;min-height:100vh}

  /* ── Sidebar ── */
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);
    display:flex;align-items:center;gap:.75rem}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:.25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-link-side i{font-size:1rem;width:18px;text-align:center}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  /* ── Layout ── */
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%);transition:.3s}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}

  /* ── Topbar ── */
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;
    flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:100;
    backdrop-filter:blur(10px)}

  /* ── Page body ── */
  .page-body{padding:1.5rem}

  /* ── Stats ── */
  .stat-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);
    border-radius:14px;padding:1.1rem 1.25rem}
  .stat-val{font-size:1.9rem;font-weight:900;color:#fff;line-height:1}
  .stat-lbl{font-size:.78rem;color:rgba(255,255,255,.45);margin-top:.2rem}

  /* ── Formulário ── */
  .form-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);
    border-radius:16px;padding:1.5rem}
  .form-control,.form-select{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:10px}
  .form-control:focus,.form-select:focus{background:rgba(255,255,255,.12);
    border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.35)}
  .form-select option{background:#1a1a2e}
  .form-label{color:rgba(255,255,255,.75);font-size:.87rem;margin-bottom:.35rem}
  .form-check-input{background-color:rgba(255,255,255,.1);border-color:rgba(255,255,255,.2)}
  .form-check-input:checked{background-color:#e94560;border-color:#e94560}
  .form-check-label{color:rgba(255,255,255,.7);font-size:.9rem}

  /* ── Tipo toggle ── */
  .tipo-toggle{display:flex;gap:.5rem;margin-bottom:.25rem}
  .tipo-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);
    color:rgba(255,255,255,.55);border-radius:8px;padding:.45rem 1rem;font-size:.88rem;
    cursor:pointer;transition:.2s;flex:1;text-align:center}
  .tipo-btn:hover{background:rgba(255,255,255,.1)}
  .tipo-btn.sel-produto{background:rgba(99,102,241,.2);border-color:rgba(99,102,241,.5);color:#a5b4fc;font-weight:700}
  .tipo-btn.sel-pacote{background:rgba(234,179,8,.15);border-color:rgba(234,179,8,.4);color:#fde047;font-weight:700}
  .tipo-btn input{display:none}

  /* ── Tabela ── */
  .table-dark-custom{width:100%;border-collapse:separate;border-spacing:0 .4rem}
  .table-dark-custom thead th{color:rgba(255,255,255,.4);font-size:.75rem;font-weight:700;
    text-transform:uppercase;letter-spacing:.06em;padding:.5rem .9rem;border:none}
  .table-dark-custom tbody tr{background:rgba(255,255,255,.04);border-radius:10px;transition:.15s}
  .table-dark-custom tbody tr:hover{background:rgba(255,255,255,.07)}
  .table-dark-custom tbody td{padding:.75rem .9rem;border:none;vertical-align:middle}
  .table-dark-custom tbody td:first-child{border-radius:10px 0 0 10px}
  .table-dark-custom tbody td:last-child{border-radius:0 10px 10px 0}

  .badge-produto{background:rgba(99,102,241,.2);color:#a5b4fc;border-radius:6px;padding:.25rem .6rem;font-size:.78rem;font-weight:700}
  .badge-pacote{background:rgba(234,179,8,.15);color:#fde047;border-radius:6px;padding:.25rem .6rem;font-size:.78rem;font-weight:700}
  .badge-ativo{background:rgba(34,197,94,.15);color:#4ade80;border-radius:6px;padding:.2rem .55rem;font-size:.75rem}
  .badge-inativo{background:rgba(239,68,68,.12);color:#f87171;border-radius:6px;padding:.2rem .55rem;font-size:.75rem}

  /* ── Filtros ── */
  .filtro-bar{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center;margin-bottom:1.25rem}
  .filtro-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
    color:rgba(255,255,255,.55);border-radius:8px;padding:.4rem .9rem;font-size:.85rem;
    cursor:pointer;transition:.2s;text-decoration:none}
  .filtro-btn:hover,.filtro-btn.active{background:rgba(233,69,96,.18);border-color:rgba(233,69,96,.4);color:#e94560}

  /* ── Mais vendidos ── */
  .rank-item{display:flex;align-items:center;gap:.75rem;padding:.6rem .85rem;
    background:rgba(255,255,255,.04);border-radius:10px;margin-bottom:.35rem}
  .rank-num{width:24px;height:24px;background:rgba(233,69,96,.18);color:#e94560;
    border-radius:50%;display:flex;align-items:center;justify-content:center;
    font-size:.78rem;font-weight:800;flex-shrink:0}
  .rank-num.gold{background:rgba(234,179,8,.2);color:#fde047}
  .rank-num.silver{background:rgba(148,163,184,.15);color:#94a3b8}
  .rank-num.bronze{background:rgba(180,83,9,.2);color:#fb923c}

  h4,h5,h6{color:#fff;margin:0}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<!-- ════════════════════════════════════
     SIDEBAR
════════════════════════════════════ -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<!-- ════════════════════════════════════
     CONTEÚDO PRINCIPAL
════════════════════════════════════ -->
<div class="main-content">

  <!-- ── Topbar ── -->
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <!-- Botão menu mobile -->
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">
          <i class="bi bi-bag-fill me-2" style="color:#e94560"></i>Produtos p/ Venda
        </h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)"><?= date('d/m/Y H:i') ?></div>
      </div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <div class="d-none d-sm-block" style="text-align:right">
        <div style="color:#fff;font-weight:600;font-size:.88rem"><?= htmlspecialchars($_SESSION['usuario_nome']) ?></div>
        <div style="font-size:.72rem;color:rgba(255,255,255,.4)">Administrador</div>
      </div>
      <div style="width:36px;height:36px;background:linear-gradient(135deg,#e94560,#c41230);
        border-radius:50%;display:flex;align-items:center;justify-content:center">
        <i class="bi bi-person-fill text-white"></i>
      </div>
    </div>
  </div>

  <!-- ── Page Body ── -->
  <div class="page-body">
    <?= renderFlash() ?>

    <!-- Título da seção -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
      <div>
        <h4 class="mb-0 fw-bold"><i class="bi bi-bag-fill me-2" style="color:#e94560"></i>Produtos & Pacotes p/ Venda</h4>
        <div style="font-size:.82rem;color:rgba(255,255,255,.4);margin-top:.2rem">
          Itens disponíveis para venda nos atendimentos da fila
        </div>
      </div>
    </div>

    <!-- ── Stats ── -->
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-val"><?= $stats['total'] ?? 0 ?></div>
          <div class="stat-lbl">Total cadastrados</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-val" style="color:#4ade80"><?= $stats['ativos'] ?? 0 ?></div>
          <div class="stat-lbl">Ativos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-val" style="color:#a5b4fc"><?= $stats['produtos'] ?? 0 ?></div>
          <div class="stat-lbl">Produtos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-val" style="color:#fde047"><?= $stats['pacotes'] ?? 0 ?></div>
          <div class="stat-lbl">Pacotes</div>
        </div>
      </div>
    </div>

    <div class="row g-4">

      <!-- ════════════════════════════════════
           FORMULÁRIO CADASTRO / EDIÇÃO
      ════════════════════════════════════ -->
      <div class="col-12 col-lg-4">
        <div class="form-card">
          <h6 class="fw-bold mb-3" style="color:#fff">
            <i class="bi bi-<?= $editando ? 'pencil-fill' : 'plus-circle-fill' ?> me-2" style="color:#e94560"></i>
            <?= $editando ? 'Editar' : 'Novo' ?> Produto / Pacote
          </h6>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar">
            <?php if($editando): ?>
            <input type="hidden" name="id" value="<?= $editando['id'] ?>">
            <?php endif; ?>

            <!-- Tipo -->
            <div class="mb-3">
              <label class="form-label">Tipo</label>
              <div class="tipo-toggle">
                <?php foreach(['produto'=>'🧴 Produto','pacote'=>'📦 Pacote'] as $v=>$l): ?>
                <label class="tipo-btn <?= ($editando && $editando['tipo']===$v) || (!$editando && $v==='produto') ? 'sel-'.$v : '' ?>"
                       id="tipoBtn_<?= $v ?>">
                  <input type="radio" name="tipo" value="<?= $v ?>"
                    <?= ($editando && $editando['tipo']===$v) || (!$editando && $v==='produto') ? 'checked' : '' ?>>
                  <?= $l ?>
                </label>
                <?php endforeach; ?>
              </div>
            </div>

            <!-- Nome -->
            <div class="mb-3">
              <label class="form-label">Nome *</label>
              <input type="text" name="nome" class="form-control"
                placeholder="Ex: Pomada Modeladora"
                value="<?= htmlspecialchars($editando['nome'] ?? '') ?>" required>
            </div>

            <!-- Descrição -->
            <div class="mb-3">
              <label class="form-label">
                Descrição <span style="color:rgba(255,255,255,.35)">(opcional)</span>
              </label>
              <textarea name="descricao" class="form-control" rows="2"
                placeholder="Breve descrição do item..."><?= htmlspecialchars($editando['descricao'] ?? '') ?></textarea>
            </div>

            <!-- Preço -->
            <div class="mb-3">
              <label class="form-label">Preço (R$) *</label>
              <input type="text" name="preco" class="form-control mascara-preco"
                placeholder="0,00"
                value="<?= $editando ? number_format($editando['preco'],2,',','.') : '' ?>" required>
            </div>

            <!-- Ativo -->
            <div class="mb-4">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" name="ativo" id="chkAtivo"
                  <?= (!$editando || $editando['ativo']) ? 'checked' : '' ?>>
                <label class="form-check-label" for="chkAtivo">Disponível para venda</label>
              </div>
            </div>

            <div class="d-flex gap-2">
              <button type="submit"
                style="background:linear-gradient(135deg,#e94560,#c41230);color:#fff;border:none;
                  border-radius:10px;padding:.65rem;font-weight:700;width:100%;cursor:pointer">
                <i class="bi bi-<?= $editando ? 'check-lg' : 'plus-lg' ?> me-1"></i>
                <?= $editando ? 'Salvar Alterações' : 'Cadastrar' ?>
              </button>
              <?php if($editando): ?>
              <a href="produtos.php"
                style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.6);border:none;
                  border-radius:10px;padding:.65rem 1rem;text-decoration:none;display:flex;
                  align-items:center;justify-content:center">
                <i class="bi bi-x-lg"></i>
              </a>
              <?php endif; ?>
            </div>
          </form>
        </div>

        <!-- ── Mais vendidos ── -->
        <?php if(!empty($maisVendidos)): ?>
        <div class="form-card mt-3">
          <h6 class="fw-bold mb-3" style="color:#fff">
            <i class="bi bi-trophy-fill me-2" style="color:#fde047"></i>Mais Vendidos
          </h6>
          <?php foreach($maisVendidos as $idx => $mv): ?>
          <div class="rank-item">
            <div class="rank-num <?= $idx===0?'gold':($idx===1?'silver':($idx===2?'bronze':'')) ?>">
              <?= $idx+1 ?>
            </div>
            <div class="flex-grow-1">
              <div style="font-weight:600;color:#fff;font-size:.88rem"><?= htmlspecialchars($mv['nome']) ?></div>
              <div style="font-size:.76rem;color:rgba(255,255,255,.4)">
                <?= $mv['qtd'] ?> vendido<?= $mv['qtd']>1?'s':'' ?>
              </div>
            </div>
            <div style="color:#4ade80;font-weight:700;font-size:.85rem"><?= formatMoney($mv['receita']) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- ════════════════════════════════════
           LISTA DE PRODUTOS
      ════════════════════════════════════ -->
      <div class="col-12 col-lg-8">

        <!-- Filtros -->
        <div class="filtro-bar">
          <form method="GET" class="d-flex gap-2 flex-wrap w-100">
            <input type="text" name="q" class="form-control form-control-sm" style="max-width:220px"
              placeholder="Buscar..." value="<?= htmlspecialchars($busca) ?>">
            <?php foreach(['todos'=>'Todos','produto'=>'🧴 Produtos','pacote'=>'📦 Pacotes'] as $v=>$l): ?>
            <button type="submit" name="tipo" value="<?= $v ?>"
              class="filtro-btn <?= $tipo_filtro===$v?'active':'' ?>"><?= $l ?></button>
            <?php endforeach; ?>
          </form>
        </div>

        <?php if(empty($lista)): ?>
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);
          border-radius:16px;padding:3rem;text-align:center;color:rgba(255,255,255,.3)">
          <i class="bi bi-bag-x" style="font-size:3rem;display:block;margin-bottom:1rem"></i>
          Nenhum item encontrado.
        </div>
        <?php else: ?>
        <table class="table-dark-custom">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Tipo</th>
              <th>Preço</th>
              <th>Status</th>
              <th style="text-align:right">Ações</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($lista as $p): ?>
            <tr>
              <td>
                <div style="font-weight:600;color:#fff"><?= htmlspecialchars($p['nome']) ?></div>
                <?php if($p['descricao']): ?>
                <div style="font-size:.77rem;color:rgba(255,255,255,.4);margin-top:.15rem">
                  <?= htmlspecialchars($p['descricao']) ?>
                </div>
                <?php endif; ?>
              </td>
              <td>
                <?php if($p['tipo']==='produto'): ?>
                  <span class="badge-produto">🧴 Produto</span>
                <?php else: ?>
                  <span class="badge-pacote">📦 Pacote</span>
                <?php endif; ?>
              </td>
              <td style="font-weight:700;color:#4ade80"><?= formatMoney($p['preco']) ?></td>
              <td>
                <?php if($p['ativo']): ?>
                  <span class="badge-ativo"><i class="bi bi-check-circle-fill me-1"></i>Ativo</span>
                <?php else: ?>
                  <span class="badge-inativo"><i class="bi bi-dash-circle me-1"></i>Inativo</span>
                <?php endif; ?>
              </td>
              <td>
                <div class="d-flex gap-1 justify-content-end">
                  <!-- Editar -->
                  <a href="?editar=<?= $p['id'] ?>" class="btn btn-sm"
                    style="background:rgba(59,130,246,.15);color:#60a5fa;border:none;border-radius:7px"
                    title="Editar">
                    <i class="bi bi-pencil-fill"></i>
                  </a>
                  <!-- Ativar/Desativar -->
                  <form method="POST" class="d-inline">
                    <input type="hidden" name="acao" value="toggle">
                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                    <button type="submit" class="btn btn-sm"
                      style="background:rgba(<?= $p['ativo']?'239,68,68':'34,197,94' ?>,.15);
                        color:<?= $p['ativo']?'#f87171':'#4ade80' ?>;border:none;border-radius:7px"
                      title="<?= $p['ativo']?'Desativar':'Ativar' ?>">
                      <i class="bi bi-<?= $p['ativo']?'eye-slash-fill':'eye-fill' ?>"></i>
                    </button>
                  </form>
                  <!-- Excluir -->
                  <form method="POST" class="d-inline"
                    onsubmit="return confirm('Excluir \'<?= addslashes(htmlspecialchars($p['nome'])) ?>\'?')">
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="<?= $p['id'] ?>">
                    <button type="submit" class="btn btn-sm"
                      style="background:rgba(239,68,68,.12);color:#f87171;border:none;border-radius:7px"
                      title="Excluir">
                      <i class="bi bi-trash3-fill"></i>
                    </button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php endif; ?>

      </div>
    </div>
  </div><!-- /page-body -->
</div><!-- /main-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ── Menu mobile ──

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// ── Tipo toggle visual ──
document.querySelectorAll('.tipo-btn input').forEach(r => {
  r.addEventListener('change', function() {
    document.querySelectorAll('.tipo-btn').forEach(b => b.className = 'tipo-btn');
    this.closest('.tipo-btn').classList.add('sel-' + this.value);
  });
});

// ── Máscara preço ──
document.querySelectorAll('.mascara-preco').forEach(i => {
  i.addEventListener('input', function() {
    let v = this.value.replace(/\D/g,'');
    v = (parseInt(v||0)/100).toFixed(2).replace('.',',');
    this.value = v;
  });
});
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(r => console.log('SW:', r.scope)).catch(e => console.log('SW erro:', e));
  });
}
</script>
</body>
</html>