<?php
require_once '../config.php';
requireAdmin();
$db = getDB();
$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia') ?: 'Barbearia';

function navActive(string $p, string $a): string { return $p===$a?'nav-link-side active':'nav-link-side'; }

// ── Criar tabela se não existir ──
$db->exec("CREATE TABLE IF NOT EXISTS feriados (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  data       TEXT NOT NULL,
  descricao  TEXT NOT NULL,
  recorrente INTEGER NOT NULL DEFAULT 0,
  criado_em  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)");

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'add') {
        $data  = $_POST['data']      ?? '';
        $desc  = trim($_POST['descricao'] ?? '');
        $rec   = isset($_POST['recorrente']) ? 1 : 0;
        if ($data && $desc) {
            // Checar duplicata
            $dup = $db->prepare("SELECT id FROM feriados WHERE data=?");
            $dup->execute([$data]);
            if ($dup->fetch()) {
                flash('warning', 'Já existe um feriado nessa data.');
            } else {
                $db->prepare("INSERT INTO feriados (data,descricao,recorrente) VALUES (?,?,?)")
                   ->execute([$data, $desc, $rec]);
                flash('success', 'Feriado adicionado!');
            }
        } else {
            flash('danger', 'Preencha data e descrição.');
        }
    }

    if ($acao === 'del') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $db->prepare("DELETE FROM feriados WHERE id=?")->execute([$id]);
            flash('success', 'Feriado removido.');
        }
    }

    if ($acao === 'add_folga') {
        $barb = (int)($_POST['barbeiro_id'] ?? 0);
        $data = $_POST['data'] ?? '';
        $obs  = trim($_POST['obs'] ?? '');
        if ($barb && $data) {
            // Usar tabela barbeiro_pausas com data inteira (inicio=00:00, fim=23:59)
            $ini = $data . ' 00:00:00';
            $fim = $data . ' 23:59:59';
            $db->prepare("INSERT INTO barbeiro_pausas (barbeiro_id,motivo,inicio,fim) VALUES (?,?,?,?)")
               ->execute([$barb, $obs ?: 'Folga', $ini, $fim]);
            flash('success', 'Folga registrada!');
        } else {
            flash('danger', 'Selecione barbeiro e data.');
        }
    }

    if ($acao === 'del_folga') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $db->prepare("DELETE FROM barbeiro_pausas WHERE id=?")->execute([$id]);
            flash('success', 'Folga removida.');
        }
    }

    header('Location: feriados.php'); exit;
}

// ── Leitura ──
$ano      = (int)($_GET['ano'] ?? date('Y'));
$feriados = $db->prepare("SELECT * FROM feriados ORDER BY data ASC");
$feriados->execute();
$feriados = $feriados->fetchAll();

$barbeiros = $db->query("SELECT id, nome FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();

// Folgas do ano selecionado
$folgas = $db->prepare("
    SELECT bp.*, u.nome as barbeiro_nome
    FROM barbeiro_pausas bp
    JOIN usuarios u ON u.id = bp.barbeiro_id
    WHERE DATE(bp.inicio) = DATE(bp.fim, 'start of day')
      AND strftime('%Y', bp.inicio) = ?
      AND (julianday(bp.fim) - julianday(bp.inicio)) >= 0.9
    ORDER BY bp.inicio ASC
");
$folgas->execute([(string)$ano]);
$folgas = $folgas->fetchAll();

// Próximos feriados (próximos 90 dias)
$hoje     = date('Y-m-d');
$limite   = date('Y-m-d', strtotime('+90 days'));
$proximos = array_filter($feriados, function($f) use ($hoje, $limite, $ano) {
    $dataReal = $f['recorrente'] ? ($ano . '-' . substr($f['data'], 5)) : $f['data'];
    return $dataReal >= $hoje && $dataReal <= $limite;
});
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Feriados – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%);transition:.3s}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  /* componente */
  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.25rem}
  .card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
  .form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:10px;padding:.55rem .85rem;font-size:.88rem;width:100%}
  .form-control-dark:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
  .form-control-dark::placeholder{color:rgba(255,255,255,.3)}
  select.form-control-dark option{background:#1a1a2e}
  .btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;border-radius:10px;padding:.6rem 1.25rem;font-weight:700;cursor:pointer;font-size:.9rem;transition:.2s;white-space:nowrap}
  .btn-primary-custom:hover{opacity:.88;transform:translateY(-1px)}
  .feriado-row{display:flex;align-items:center;gap:.75rem;padding:.65rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
  .feriado-row:last-child{border-bottom:none}
  .feriado-data{background:rgba(233,69,96,.15);color:#e94560;border-radius:10px;padding:.3rem .7rem;font-size:.82rem;font-weight:700;white-space:nowrap;min-width:88px;text-align:center}
  .feriado-desc{flex:1;font-size:.9rem;color:#e0e0e0}
  .tag-rec{background:rgba(59,130,246,.15);color:#60a5fa;border-radius:20px;padding:.1rem .5rem;font-size:.7rem;font-weight:700;margin-left:.4rem}
  .prox-card{background:rgba(233,69,96,.07);border:1px solid rgba(233,69,96,.2);border-radius:12px;padding:.75rem 1rem;margin-bottom:.5rem;display:flex;align-items:center;gap:.75rem}
  .btn-del{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#f87171;border-radius:8px;padding:.25rem .55rem;font-size:.78rem;cursor:pointer;transition:.15s}
  .btn-del:hover{background:rgba(239,68,68,.25)}
  .folga-row{display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
  .folga-row:last-child{border-bottom:none}
  .folga-avatar{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#e94560,#c41230);display:flex;align-items:center;justify-content:center;font-size:.82rem;font-weight:800;color:#fff;flex-shrink:0}
  h4,h5,h6{color:#fff;margin:0}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"            class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"          class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"             class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"     class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"             class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"               class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"         class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"              class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"           class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"            class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"            class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"    class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"                class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"                class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700"><i class="bi bi-calendar-x-fill me-2" style="color:var(--primary)"></i>Feriados & Folgas</h6>
  </div>
  <div class="d-flex align-items-center gap-2">
    <form method="GET" style="display:flex;gap:.4rem;align-items:center">
      <select name="ano" class="form-control-dark" style="width:auto" onchange="this.form.submit()">
        <?php for($y=date('Y')-1;$y<=date('Y')+2;$y++): ?>
        <option value="<?= $y ?>" <?= $y===$ano?'selected':'' ?>><?= $y ?></option>
        <?php endfor; ?>
      </select>
    </form>
  </div>
</div>
<div class="page-body">
  <?= renderFlash() ?>

  <div class="row g-3">

    <!-- ── Coluna esquerda: adicionar + lista ── -->
    <div class="col-lg-8">

      <!-- Adicionar Feriado -->
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-calendar-plus" style="color:var(--primary)"></i>Adicionar Feriado / Dia Fechado</div>
        <form method="POST">
          <input type="hidden" name="acao" value="add">
          <div class="row g-2">
            <div class="col-sm-4">
              <label style="color:rgba(255,255,255,.5);font-size:.78rem;display:block;margin-bottom:.3rem">Data</label>
              <input type="date" name="data" class="form-control-dark" required>
            </div>
            <div class="col-sm-5">
              <label style="color:rgba(255,255,255,.5);font-size:.78rem;display:block;margin-bottom:.3rem">Descrição</label>
              <input type="text" name="descricao" class="form-control-dark" placeholder="Ex: Natal, Aniversário cidade…" required>
            </div>
            <div class="col-sm-3 d-flex align-items-end flex-column gap-2">
              <div class="form-check" style="margin-top:1.6rem">
                <input class="form-check-input" type="checkbox" name="recorrente" id="chkRec" value="1">
                <label class="form-check-label" for="chkRec" style="font-size:.82rem;color:rgba(255,255,255,.6)">Anual (repete todo ano)</label>
              </div>
              <button type="submit" class="btn-primary-custom w-100"><i class="bi bi-plus-lg me-1"></i>Adicionar</button>
            </div>
          </div>
        </form>
      </div>

      <!-- Lista de Feriados -->
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-calendar-x" style="color:var(--primary)"></i>Feriados Cadastrados
          <span style="background:rgba(255,255,255,.08);border-radius:20px;padding:.1rem .55rem;font-size:.72rem;color:rgba(255,255,255,.5);margin-left:auto"><?= count($feriados) ?></span>
        </div>
        <?php if (empty($feriados)): ?>
        <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25)">
          <i class="bi bi-calendar-check" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
          Nenhum feriado cadastrado
        </div>
        <?php else: ?>
        <?php foreach ($feriados as $f): ?>
        <div class="feriado-row">
          <div class="feriado-data">
            <?php
              $partes = explode('-', $f['data']);
              // recorrente: mostrar dd/mm, senão dd/mm/aaaa
              echo $f['recorrente']
                ? (count($partes) >= 3 ? $partes[2].'/'.$partes[1] : $f['data'])
                : (count($partes) === 3 ? $partes[2].'/'.$partes[1].'/'.$partes[0] : $f['data']);
            ?>
          </div>
          <div class="feriado-desc">
            <?= htmlspecialchars($f['descricao']) ?>
            <?php if ($f['recorrente']): ?><span class="tag-rec"><i class="bi bi-arrow-repeat me-1"></i>Anual</span><?php endif; ?>
          </div>
          <form method="POST" onsubmit="return confirm('Remover este feriado?')">
            <input type="hidden" name="acao" value="del">
            <input type="hidden" name="id" value="<?= $f['id'] ?>">
            <button type="submit" class="btn-del"><i class="bi bi-trash"></i></button>
          </form>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <!-- Folgas de Barbeiros -->
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-person-x-fill" style="color:#f59e0b"></i>Folgas de Barbeiros — <?= $ano ?>
          <span style="background:rgba(255,255,255,.08);border-radius:20px;padding:.1rem .55rem;font-size:.72rem;color:rgba(255,255,255,.5);margin-left:auto"><?= count($folgas) ?></span>
        </div>

        <!-- Adicionar folga inline -->
        <form method="POST" style="background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.2);border-radius:12px;padding:.85rem;margin-bottom:1rem">
          <input type="hidden" name="acao" value="add_folga">
          <div class="row g-2">
            <div class="col-sm-4">
              <select name="barbeiro_id" class="form-control-dark" required>
                <option value="">Barbeiro…</option>
                <?php foreach ($barbeiros as $b): ?>
                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['nome']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-sm-3">
              <input type="date" name="data" class="form-control-dark" required>
            </div>
            <div class="col-sm-3">
              <input type="text" name="obs" class="form-control-dark" placeholder="Motivo (opcional)">
            </div>
            <div class="col-sm-2">
              <button type="submit" class="btn-primary-custom w-100" style="background:linear-gradient(135deg,#f59e0b,#d97706)"><i class="bi bi-plus-lg"></i></button>
            </div>
          </div>
        </form>

        <?php if (empty($folgas)): ?>
        <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.85rem">Nenhuma folga em <?= $ano ?></div>
        <?php else: ?>
        <?php foreach ($folgas as $fg): ?>
        <div class="folga-row">
          <div class="folga-avatar"><?= mb_strtoupper(mb_substr($fg['barbeiro_nome'],0,1)) ?></div>
          <div style="flex:1">
            <div style="font-weight:700;color:#fff;font-size:.88rem"><?= htmlspecialchars($fg['barbeiro_nome']) ?></div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
              <?= date('d/m/Y', strtotime($fg['inicio'])) ?>
              <?php if ($fg['motivo']): ?> · <?= htmlspecialchars($fg['motivo']) ?><?php endif; ?>
            </div>
          </div>
          <form method="POST" onsubmit="return confirm('Remover folga?')">
            <input type="hidden" name="acao" value="del_folga">
            <input type="hidden" name="id" value="<?= $fg['id'] ?>">
            <button type="submit" class="btn-del"><i class="bi bi-trash"></i></button>
          </form>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- ── Coluna direita: próximos ── -->
    <div class="col-lg-4">
      <div class="card-sec">
        <div class="card-title"><i class="bi bi-calendar-event" style="color:#f59e0b"></i>Próximos 90 Dias</div>
        <?php if (empty($proximos)): ?>
        <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.85rem">Nenhum feriado nos próximos 90 dias</div>
        <?php else: ?>
        <?php foreach ($proximos as $p): ?>
        <?php
          $dataReal = $p['recorrente'] ? ($ano.'-'.substr($p['data'],5)) : $p['data'];
          $diff = (strtotime($dataReal) - strtotime($hoje)) / 86400;
        ?>
        <div class="prox-card">
          <div style="text-align:center;min-width:44px">
            <div style="font-size:1.4rem;font-weight:900;color:#e94560;line-height:1"><?= date('d', strtotime($dataReal)) ?></div>
            <div style="font-size:.65rem;color:rgba(255,255,255,.4);text-transform:uppercase"><?= strftime('%b', strtotime($dataReal)) ?></div>
          </div>
          <div style="flex:1">
            <div style="font-weight:700;color:#fff;font-size:.85rem"><?= htmlspecialchars($p['descricao']) ?></div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.35)">
              <?= $diff <= 0 ? 'Hoje' : 'em '.round($diff).' dias' ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <!-- Info -->
      <div class="card-sec" style="background:rgba(59,130,246,.06);border-color:rgba(59,130,246,.2)">
        <div class="card-title" style="color:#60a5fa"><i class="bi bi-info-circle"></i>Como funciona</div>
        <p style="font-size:.82rem;color:rgba(255,255,255,.5);line-height:1.6;margin:0">
          Feriados cadastrados aqui fazem a barbearia aparecer como <strong style="color:#f87171">fechada</strong> na página principal.<br><br>
          Feriados <span style="color:#60a5fa">Anuais</span> se repetem todo ano automaticamente (útil para Natal, Ano Novo, etc.).<br><br>
          <strong style="color:#fbbf24">Folgas</strong> bloqueiam o barbeiro específico pelo dia inteiro, sem afetar os demais.
        </p>
      </div>
    </div>

  </div>
</div><!-- /page-body -->
</div><!-- /main-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
</body>
</html>
