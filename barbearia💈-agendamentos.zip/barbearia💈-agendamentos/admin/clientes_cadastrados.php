<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// ── AÇÕES POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'excluir') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id) {
        // Verifica quais tabelas existem antes de deletar
        $tabelas = $db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);

        $db->prepare("DELETE FROM fila WHERE cliente_id=?")->execute([$id]);

        if (in_array('vendas', $tabelas))
            $db->prepare("DELETE FROM vendas WHERE cliente_id=?")->execute([$id]);

        if (in_array('pacotes_clientes', $tabelas))
            $db->prepare("DELETE FROM pacotes_clientes WHERE cliente_id=?")->execute([$id]);

        $db->prepare("DELETE FROM clientes WHERE id=?")->execute([$id]);
        flash('warning', 'Cliente excluído.');
    }
    header('Location: clientes_cadastrados.php'); exit;
    }
}

// ── FILTROS ──
$busca    = trim($_GET['busca'] ?? '');
$orderBy  = in_array($_GET['order'] ?? '', ['nome','telefone','total_atend','ultimo_atend','criado_em'])
            ? $_GET['order'] : 'criado_em';
$orderDir = ($_GET['dir'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';
$porPag   = 20;
$pagina   = max(1, (int)($_GET['pag'] ?? 1));
$offset   = ($pagina - 1) * $porPag;

// ── QUERY PRINCIPAL ──
$where  = '';
$params = [];
if ($busca) {
    $where  = "WHERE c.nome LIKE ? OR c.telefone LIKE ?";
    $params = ["%$busca%", "%$busca%"];
}

$orderSql = match($orderBy) {
    'nome'        => 'c.nome',
    'telefone'    => 'c.telefone',
    'total_atend' => 'total_atend',
    'ultimo_atend'=> 'ultimo_atend',
    default       => 'c.criado_em',
};

$sqlBase = "
    FROM clientes c
    LEFT JOIN (
        SELECT cliente_id,
               COUNT(*)                                          AS total_atend,
               SUM(CASE WHEN status='concluido' THEN 1 ELSE 0 END) AS total_concluido,
               SUM(CASE WHEN status='cancelado' THEN 1 ELSE 0 END) AS total_cancelado,
               COALESCE(SUM(CASE WHEN status='concluido' THEN valor ELSE 0 END),0) AS total_gasto,
               MAX(finalizado_em)                               AS ultimo_atend,
               MIN(criado_em)                                   AS primeiro_atend
        FROM fila
        GROUP BY cliente_id
    ) f ON f.cliente_id = c.id
    $where
";

$totalStmt = $db->prepare("SELECT COUNT(*) as c $sqlBase");
$totalStmt->execute($params);
$total     = (int)$totalStmt->fetch()['c'];
$totalPags = max(1, ceil($total / $porPag));
$pagina    = min($pagina, $totalPags);
$offset    = ($pagina - 1) * $porPag;

$stmt = $db->prepare("
    SELECT c.*,
           COALESCE(f.total_atend,     0) AS total_atend,
           COALESCE(f.total_concluido, 0) AS total_concluido,
           COALESCE(f.total_cancelado, 0) AS total_cancelado,
           COALESCE(f.total_gasto,     0) AS total_gasto,
           f.ultimo_atend,
           f.primeiro_atend
    $sqlBase
    ORDER BY $orderSql $orderDir
    LIMIT $porPag OFFSET $offset
");
$stmt->execute($params);
$clientes = $stmt->fetchAll();

// ── STATS GLOBAIS ──
$statsGerais = $db->query("
    SELECT
        COUNT(DISTINCT c.id)                                          AS total_clientes,
        COUNT(DISTINCT CASE WHEN f.status='concluido' THEN c.id END)  AS clientes_atendidos,
        COALESCE(SUM(CASE WHEN f.status='concluido' THEN f.valor END),0) AS receita_total,
        COUNT(DISTINCT CASE
            WHEN DATE(f.criado_em) >= DATE('now','-30 days') THEN c.id
        END)                                                           AS novos_mes
    FROM clientes c
    LEFT JOIN fila f ON f.cliente_id = c.id
")->fetch();

$nomeBarbearia = getConfig('nome_barbearia');

// Helper URL
function urlC(array $extra = []): string {
    $p = array_merge([
        'busca'  => $_GET['busca']  ?? '',
        'order'  => $_GET['order']  ?? 'criado_em',
        'dir'    => $_GET['dir']    ?? 'desc',
        'pag'    => $_GET['pag']    ?? 1,
    ], $extra);
    return 'clientes.php?' . http_build_query(array_filter($p, fn($v) => $v !== ''));
}
function sortUrl(string $col): string {
    $atualDir = ($_GET['dir'] ?? 'desc');
    $novoDir  = ($_GET['order'] ?? '') === $col && $atualDir === 'asc' ? 'desc' : 'asc';
    return urlC(['order' => $col, 'dir' => $novoDir, 'pag' => 1]);
}

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Clientes – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  /* ── SIDEBAR ── */
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  /* ── LAYOUT ── */
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%);transition:.3s}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  /* ── STAT CARDS ── */
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
    border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem;
    position:relative;overflow:hidden}
  .stat-card::after{content:'';position:absolute;top:-15px;right:-15px;
    width:70px;height:70px;border-radius:50%;opacity:.12}
  .stat-card.c1::after{background:#e94560}
  .stat-card.c2::after{background:#22c55e}
  .stat-card.c3::after{background:#3b82f6}
  .stat-card.c4::after{background:#f59e0b}
  .stat-icon{width:46px;height:46px;border-radius:12px;display:flex;
    align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:.85rem}
  .stat-value{font-size:1.6rem;font-weight:800;color:#fff;line-height:1}
  .stat-label{color:rgba(255,255,255,.5);font-size:.82rem;margin-top:.3rem}

  /* ── FILTROS ── */
  .filtros-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09);
    border-radius:16px;padding:1rem 1.25rem;margin-bottom:1.25rem}
  .search-wrap{position:relative}
  .search-wrap .bi{position:absolute;left:.85rem;top:50%;transform:translateY(-50%);
    color:rgba(255,255,255,.3);font-size:1rem;pointer-events:none}
  .search-input{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.6rem 1rem .6rem 2.4rem;width:100%;
    font-size:.9rem;transition:.2s}
  .search-input:focus{outline:none;border-color:var(--primary);background:rgba(255,255,255,.1);
    box-shadow:0 0 0 3px rgba(233,69,96,.15)}
  .search-input::placeholder{color:rgba(255,255,255,.3)}

  /* ── TABELA ── */
  .table-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09);
    border-radius:16px;overflow:hidden}
  .table-head{background:rgba(255,255,255,.05);padding:.65rem 1rem;
    display:grid;gap:.5rem;align-items:center;
    border-bottom:1px solid rgba(255,255,255,.08);font-size:.75rem;
    color:rgba(255,255,255,.4);font-weight:700;text-transform:uppercase;letter-spacing:.5px}
  .table-head a{color:rgba(255,255,255,.4);text-decoration:none;display:flex;align-items:center;gap:.25rem}
  .table-head a:hover{color:#fff}
  .table-head a.asc::after{content:'↑';color:var(--primary)}
  .table-head a.desc::after{content:'↓';color:var(--primary)}

  /* Grid colunas: avatar+nome | telefone | atendimentos | gasto | último | ações */
  .row-grid{grid-template-columns: 2.2fr 1.4fr 1fr 1fr 1.2fr 100px}

  .cli-row{padding:.75rem 1rem;display:grid;gap:.5rem;align-items:center;
    border-bottom:1px solid rgba(255,255,255,.05);transition:.2s;cursor:pointer}
  .cli-row:last-child{border-bottom:none}
  .cli-row:hover{background:rgba(255,255,255,.04)}

  /* Avatar */
  .cli-avatar{width:38px;height:38px;border-radius:50%;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;
    font-weight:800;font-size:.95rem;color:#fff;border:2px solid transparent}
  .cli-nome{font-weight:600;color:#fff;font-size:.9rem;line-height:1.2}
  .cli-sub{font-size:.74rem;color:rgba(255,255,255,.35);margin-top:.1rem}

  /* Badges */
  .badge-vip{background:rgba(245,158,11,.2);color:#fbbf24;border:1px solid rgba(245,158,11,.25);
    border-radius:20px;padding:.1rem .5rem;font-size:.68rem;font-weight:700}
  .badge-novo{background:rgba(59,130,246,.2);color:#60a5fa;border:1px solid rgba(59,130,246,.25);
    border-radius:20px;padding:.1rem .5rem;font-size:.68rem;font-weight:700}
  .badge-freq{background:rgba(34,197,94,.2);color:#4ade80;border:1px solid rgba(34,197,94,.25);
    border-radius:20px;padding:.1rem .5rem;font-size:.68rem;font-weight:700}

  /* Botões ação */
  .btn-sm-act{border:none;border-radius:7px;padding:.3rem .55rem;font-size:.78rem;
    cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.25rem}
  .btn-info-act{background:rgba(59,130,246,.15);color:#60a5fa}
  .btn-info-act:hover{background:rgba(59,130,246,.28)}
  .btn-edit-act{background:rgba(233,69,96,.12);color:#e94560}
  .btn-edit-act:hover{background:rgba(233,69,96,.25)}
  .btn-del-act{background:rgba(239,68,68,.1);color:#f87171}
  .btn-del-act:hover{background:rgba(239,68,68,.22)}
  .btn-wa-act{background:rgba(37,211,102,.12);color:#25d366}
  .btn-wa-act:hover{background:rgba(37,211,102,.25)}

  /* Paginação */
  .pag-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
    color:rgba(255,255,255,.6);border-radius:8px;padding:.3rem .65rem;font-size:.82rem;
    text-decoration:none;transition:.2s;display:inline-flex;align-items:center}
  .pag-btn:hover,.pag-btn.active{background:rgba(233,69,96,.2);border-color:rgba(233,69,96,.4);color:#fff}
  .pag-btn.disabled{opacity:.3;pointer-events:none}

  /* ── MODAL ── */
  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08);padding:1.25rem 1.5rem}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08);padding:1rem 1.5rem}
  .modal-title{color:#fff;font-weight:700}
  .btn-close{filter:invert(1) opacity(.5)}
  .form-control-modal{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.6rem 1rem;width:100%;font-size:.9rem;transition:.2s}
  .form-control-modal:focus{outline:none;border-color:var(--primary);
    box-shadow:0 0 0 3px rgba(233,69,96,.15);background:rgba(255,255,255,.1)}
  .form-control-modal::placeholder{color:rgba(255,255,255,.3)}
  .modal-label{color:rgba(255,255,255,.7);font-size:.85rem;font-weight:600;margin-bottom:.4rem}

  /* Detalhes do cliente */
  .detalhe-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
    border-radius:12px;padding:.85rem 1rem;display:flex;align-items:center;gap:.75rem}
  .detalhe-icon{width:36px;height:36px;border-radius:9px;flex-shrink:0;
    display:flex;align-items:center;justify-content:center;font-size:.95rem}
  .detalhe-label{font-size:.72rem;color:rgba(255,255,255,.4);text-transform:uppercase;
    letter-spacing:.5px;margin-bottom:.15rem}
  .detalhe-valor{color:#fff;font-weight:600;font-size:.92rem}

  /* Timeline de atendimentos */
  .timeline-item{display:flex;gap:.75rem;padding:.6rem 0;
    border-bottom:1px solid rgba(255,255,255,.05)}
  .timeline-item:last-child{border-bottom:none}
  .timeline-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;margin-top:.3rem}

  h4,h5,h6{color:#fff;margin:0}
  .text-vazio{color:rgba(255,255,255,.3);text-align:center;padding:2.5rem 0}

  @media(max-width:992px){
    .row-grid{grid-template-columns: 2fr 1.2fr 80px}
    .col-hide-md{display:none}
  }
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
    .row-grid{grid-template-columns: 1fr 80px}
    .col-hide-sm{display:none}
  }
</style>
</head>
<body>

<!-- ══ SIDEBAR ══ -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<!-- ══ CONTEÚDO ══ -->
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">Clientes</h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
          <?= number_format($total) ?> cliente<?= $total !== 1 ? 's' : '' ?> encontrado<?= $total !== 1 ? 's' : '' ?>
        </div>
      </div>
    </div>
    <!-- Exportar CSV -->
    <a href="clientes.php?export=csv&busca=<?= urlencode($busca) ?>"
       style="background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);
              color:#4ade80;border-radius:10px;padding:.45rem .9rem;
              font-size:.82rem;font-weight:700;text-decoration:none;
              display:flex;align-items:center;gap:.4rem">
      <i class="bi bi-download"></i> Exportar CSV
    </a>
  </div>

  <?php
  // ── EXPORTAÇÃO CSV ──
  if (($_GET['export'] ?? '') === 'csv') {
      $stmtExp = $db->prepare("
          SELECT c.id, c.nome, c.telefone, c.criado_em,
                 COALESCE(f.total_atend,0)     AS total_atend,
                 COALESCE(f.total_concluido,0) AS concluidos,
                 COALESCE(f.total_cancelado,0) AS cancelados,
                 COALESCE(f.total_gasto,0)     AS total_gasto,
                 f.ultimo_atend, f.primeiro_atend
          FROM clientes c
          LEFT JOIN (
              SELECT cliente_id,
                     COUNT(*) AS total_atend,
                     SUM(CASE WHEN status='concluido' THEN 1 ELSE 0 END) AS total_concluido,
                     SUM(CASE WHEN status='cancelado' THEN 1 ELSE 0 END) AS total_cancelado,
                     COALESCE(SUM(CASE WHEN status='concluido' THEN valor ELSE 0 END),0) AS total_gasto,
                     MAX(finalizado_em) AS ultimo_atend,
                     MIN(criado_em)     AS primeiro_atend
              FROM fila GROUP BY cliente_id
          ) f ON f.cliente_id = c.id
          " . ($busca ? "WHERE c.nome LIKE ? OR c.telefone LIKE ?" : "") . "
          ORDER BY c.nome ASC
      ");
      $busca ? $stmtExp->execute(["%$busca%","%$busca%"]) : $stmtExp->execute();
      $rows = $stmtExp->fetchAll();
      header('Content-Type: text/csv; charset=UTF-8');
      header('Content-Disposition: attachment; filename="clientes_' . date('Ymd_Hi') . '.csv"');
      echo "\xEF\xBB\xBF"; // BOM UTF-8
      echo "ID;Nome;Telefone;Cadastrado em;Atendimentos;Concluídos;Cancelados;Total Gasto;Último Atend.;Primeiro Atend.\n";
      foreach ($rows as $r) {
          echo implode(';', [
              $r['id'],
              '"'.$r['nome'].'"',
              $r['telefone'],
              $r['criado_em'],
              $r['total_atend'],
              $r['concluidos'],
              $r['cancelados'],
              number_format($r['total_gasto'],2,',','.'),
              $r['ultimo_atend'] ?? '-',
              $r['primeiro_atend'] ?? '-',
          ]) . "\n";
      }
      exit;
  }
  ?>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- ── STATS ── -->
    <div class="row g-2 mb-3">
      <div class="col-6 col-xl-3">
        <div class="stat-card c1">
          <div class="stat-icon" style="background:rgba(233,69,96,.2)">
            <i class="bi bi-people-fill" style="color:#e94560"></i>
          </div>
          <div class="stat-value"><?= number_format($statsGerais['total_clientes']) ?></div>
          <div class="stat-label">Total de Clientes</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c2">
          <div class="stat-icon" style="background:rgba(34,197,94,.2)">
            <i class="bi bi-person-check-fill" style="color:#22c55e"></i>
          </div>
          <div class="stat-value"><?= number_format($statsGerais['clientes_atendidos']) ?></div>
          <div class="stat-label">Já Atendidos</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c3">
          <div class="stat-icon" style="background:rgba(59,130,246,.2)">
            <i class="bi bi-person-plus-fill" style="color:#3b82f6"></i>
          </div>
          <div class="stat-value"><?= number_format($statsGerais['novos_mes']) ?></div>
          <div class="stat-label">Novos (30 dias)</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c4">
          <div class="stat-icon" style="background:rgba(245,158,11,.2)">
            <i class="bi bi-cash-coin" style="color:#f59e0b"></i>
          </div>
          <div class="stat-value" style="font-size:1.1rem">
            <?= formatMoney($statsGerais['receita_total']) ?>
          </div>
          <div class="stat-label">Receita Total</div>
        </div>
      </div>
    </div>

    <!-- ── FILTROS ── -->
    <div class="filtros-card">
      <form method="GET" class="d-flex gap-2 flex-wrap align-items-center">
        <input type="hidden" name="order" value="<?= htmlspecialchars($orderBy) ?>">
        <input type="hidden" name="dir"   value="<?= htmlspecialchars($orderDir === 'ASC' ? 'asc' : 'desc') ?>">
        <div class="search-wrap flex-grow-1" style="min-width:200px;max-width:400px">
          <i class="bi bi-search"></i>
          <input type="text" name="busca" class="search-input"
                 placeholder="Buscar por nome ou telefone…"
                 value="<?= htmlspecialchars($busca) ?>" autocomplete="off">
        </div>
        <button type="submit"
          style="background:var(--primary);border:none;color:#fff;border-radius:9px;
                 padding:.55rem 1.1rem;font-weight:700;font-size:.88rem;cursor:pointer">
          <i class="bi bi-search me-1"></i>Buscar
        </button>
        <?php if ($busca): ?>
        <a href="clientes.php"
           style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                  color:rgba(255,255,255,.6);border-radius:9px;padding:.55rem .9rem;
                  font-size:.88rem;text-decoration:none">
          <i class="bi bi-x-lg"></i> Limpar
        </a>
        <?php endif; ?>
        <span style="font-size:.78rem;color:rgba(255,255,255,.3);margin-left:auto">
          <?= $total ?> resultado<?= $total !== 1 ? 's' : '' ?>
        </span>
      </form>
    </div>

    <!-- ── TABELA ── -->
    <div class="table-card">
      <!-- Cabeçalho -->
      <div class="table-head row-grid">
        <div>
          <a href="<?= sortUrl('nome') ?>"
             class="<?= $orderBy==='nome' ? strtolower($orderDir) : '' ?>">
            Cliente
          </a>
        </div>
        <div class="col-hide-sm">
          <a href="<?= sortUrl('telefone') ?>"
             class="<?= $orderBy==='telefone' ? strtolower($orderDir) : '' ?>">
            Telefone
          </a>
        </div>
        <div class="col-hide-md">
          <a href="<?= sortUrl('total_atend') ?>"
             class="<?= $orderBy==='total_atend' ? strtolower($orderDir) : '' ?>">
            Visitas
          </a>
        </div>
        <div class="col-hide-md">
          <a href="<?= sortUrl('total_atend') ?>"
             class="<?= $orderBy==='total_atend' ? strtolower($orderDir) : '' ?>">
            Gasto Total
          </a>
        </div>
        <div class="col-hide-sm">
          <a href="<?= sortUrl('ultimo_atend') ?>"
             class="<?= $orderBy==='ultimo_atend' ? strtolower($orderDir) : '' ?>">
            Último Atend.
          </a>
        </div>
        <div style="text-align:center">Ações</div>
      </div>

      <!-- Linhas -->
      <?php if (empty($clientes)): ?>
        <div class="text-vazio">
          <i class="bi bi-people" style="font-size:3rem;display:block;margin-bottom:.75rem;opacity:.25"></i>
          <?= $busca ? 'Nenhum cliente encontrado para "'.$busca.'"' : 'Nenhum cliente cadastrado ainda.' ?>
        </div>
      <?php else: ?>
        <?php
        // Paleta de cores para avatares
        $cores = ['#e94560','#3b82f6','#22c55e','#f59e0b','#8b5cf6','#06b6d4','#f97316','#ec4899'];
        foreach ($clientes as $cli):
          $inicial  = mb_strtoupper(mb_substr($cli['nome'], 0, 1));
          $corIdx   = crc32($cli['nome']) % count($cores);
          $cor      = $cores[abs($corIdx)];
          $isVip    = $cli['total_concluido'] >= 10;
          $isFreq   = $cli['total_concluido'] >= 3 && !$isVip;
          $isNovo   = $cli['total_concluido'] == 0;
          $waNum    = preg_replace('/\D/','',$cli['telefone']);
          $waLink   = 'https://wa.me/55'.$waNum;
          $ultimoFmt = $cli['ultimo_atend']
              ? date('d/m/y', strtotime($cli['ultimo_atend']))
              : '—';
        ?>
        <div class="cli-row row-grid"
             onclick="abrirDetalhe(<?= $cli['id'] ?>)"
             title="Ver detalhes de <?= htmlspecialchars($cli['nome']) ?>">

          <!-- Nome + Avatar -->
          <div class="d-flex align-items-center gap-2" style="min-width:0">
            <div class="cli-avatar"
                 style="background:<?= $cor ?>22;border-color:<?= $cor ?>55;color:<?= $cor ?>">
              <?= $inicial ?>
            </div>
            <div style="min-width:0">
              <div class="cli-nome text-truncate"><?= htmlspecialchars($cli['nome']) ?></div>
              <div class="cli-sub">
                <?php if ($isVip): ?>
                  <span class="badge-vip">⭐ VIP</span>
                <?php elseif ($isFreq): ?>
                  <span class="badge-freq">✓ Frequente</span>
                <?php elseif ($isNovo): ?>
                  <span class="badge-novo">✦ Novo</span>
                <?php endif; ?>
                <span style="margin-left:.25rem">desde <?= date('m/Y', strtotime($cli['criado_em'])) ?></span>
              </div>
            </div>
          </div>

          <!-- Telefone -->
          <div class="col-hide-sm" style="font-size:.85rem;color:rgba(255,255,255,.65)">
            <?= htmlspecialchars($cli['telefone']) ?>
          </div>

          <!-- Visitas -->
          <div class="col-hide-md">
            <div style="font-weight:700;color:#fff;font-size:.95rem"><?= $cli['total_concluido'] ?></div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.35)">
              <?= $cli['total_cancelado'] ?> cancel.
            </div>
          </div>

          <!-- Gasto Total -->
          <div class="col-hide-md">
            <div style="font-weight:700;color:#4ade80;font-size:.9rem">
              <?= formatMoney($cli['total_gasto']) ?>
            </div>
          </div>

          <!-- Último Atend. -->
          <div class="col-hide-sm" style="font-size:.83rem;color:rgba(255,255,255,.5)">
            <?= $ultimoFmt ?>
          </div>

          <!-- Ações -->
          <div class="d-flex gap-1 justify-content-center" onclick="event.stopPropagation()">
            <button class="btn-sm-act btn-info-act" onclick="abrirDetalhe(<?= $cli['id'] ?>)" title="Ver detalhes">
              <i class="bi bi-eye-fill"></i>
            </button>
            <a href="<?= $waLink ?>" target="_blank" class="btn-sm-act btn-wa-act" title="WhatsApp">
              <i class="bi bi-whatsapp"></i>
            </a>
            <button class="btn-sm-act btn-edit-act"
                    onclick="abrirEdicao(<?= $cli['id'] ?>, '<?= addslashes(htmlspecialchars($cli['nome'])) ?>', '<?= htmlspecialchars($cli['telefone']) ?>')"
                    title="Editar">
              <i class="bi bi-pencil-fill"></i>
            </button>
            <form method="POST" class="d-inline"
                  onsubmit="return confirm('Excluir <?= addslashes(htmlspecialchars($cli['nome'])) ?>? Esta ação não pode ser desfeita.')">
              <input type="hidden" name="acao" value="excluir">
              <input type="hidden" name="id"   value="<?= $cli['id'] ?>">
              <button type="submit" class="btn-sm-act btn-del-act" title="Excluir">
                <i class="bi bi-trash3-fill"></i>
              </button>
            </form>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- ── PAGINAÇÃO ── -->
    <?php if ($totalPags > 1): ?>
    <div class="d-flex align-items-center gap-1 flex-wrap mt-3">
      <a href="<?= urlC(['pag'=>$pagina-1]) ?>"
         class="pag-btn <?= $pagina<=1?'disabled':'' ?>">
        <i class="bi bi-chevron-left"></i>
      </a>

      <?php
      $ini = max(1, $pagina-2);
      $fim = min($totalPags, $pagina+2);
      if ($ini > 1): ?>
        <a href="<?= urlC(['pag'=>1]) ?>" class="pag-btn">1</a>
        <?php if ($ini > 2): ?><span style="color:rgba(255,255,255,.3);padding:0 .2rem">…</span><?php endif; ?>
      <?php endif; ?>

      <?php for ($i = $ini; $i <= $fim; $i++): ?>
        <a href="<?= urlC(['pag'=>$i]) ?>"
           class="pag-btn <?= $i===$pagina?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>

      <?php if ($fim < $totalPags): ?>
        <?php if ($fim < $totalPags-1): ?><span style="color:rgba(255,255,255,.3);padding:0 .2rem">…</span><?php endif; ?>
        <a href="<?= urlC(['pag'=>$totalPags]) ?>" class="pag-btn"><?= $totalPags ?></a>
      <?php endif; ?>

      <a href="<?= urlC(['pag'=>$pagina+1]) ?>"
         class="pag-btn <?= $pagina>=$totalPags?'disabled':'' ?>">
        <i class="bi bi-chevron-right"></i>
      </a>

      <span style="font-size:.78rem;color:rgba(255,255,255,.3);margin-left:.5rem">
        Página <?= $pagina ?>/<?= $totalPags ?> · <?= $total ?> clientes
      </span>
    </div>
    <?php endif; ?>

  </div>
</div>

<!-- ══ MODAL EDITAR ══ -->
<div class="modal fade" id="modalEditar" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"><i class="bi bi-pencil-fill me-2" style="color:var(--primary)"></i>Editar Cliente</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="acao" value="editar">
        <input type="hidden" name="id"   id="editId">
        <div class="modal-body" style="padding:1.25rem 1.5rem">
          <div class="mb-3">
            <label class="modal-label">Nome completo</label>
            <input type="text" name="nome" id="editNome" class="form-control-modal" required>
          </div>
          <div>
            <label class="modal-label">WhatsApp / Telefone</label>
            <input type="text" name="telefone" id="editTel" class="form-control-modal" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm"
            style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                   color:rgba(255,255,255,.6);border-radius:8px;padding:.45rem .9rem"
            data-bs-dismiss="modal">Cancelar</button>
          <button type="submit"
            style="background:var(--primary);border:none;color:#fff;border-radius:8px;
                   padding:.45rem 1.1rem;font-weight:700;cursor:pointer">
            <i class="bi bi-check2 me-1"></i>Salvar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- ══ MODAL DETALHE ══ -->
<div class="modal fade" id="modalDetalhe" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="detalheTitle">
          <i class="bi bi-person-circle me-2" style="color:var(--primary)"></i>Perfil do Cliente
        </h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="padding:1.25rem 1.5rem" id="detalheBody">
        <div class="text-center py-4" style="color:rgba(255,255,255,.4)">
          <div class="spinner-border spinner-border-sm me-2"></div>Carregando...
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ── Sidebar mobile ──

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// ── Modal Editar ──
function abrirEdicao(id, nome, tel) {
  document.getElementById('editId').value   = id;
  document.getElementById('editNome').value = nome;
  document.getElementById('editTel').value  = tel;
  new bootstrap.Modal(document.getElementById('modalEditar')).show();
}

// ── Modal Detalhe ──
// Dados embutidos no PHP para evitar segunda requisição
const clientesData = <?= json_encode(array_map(function($c) use ($db) {
    // Últimos 8 atendimentos
    $hist = $db->prepare("
        SELECT f.criado_em, f.finalizado_em, f.status, f.valor, f.forma_pagamento,
               u.nome as barbeiro, s.nome as servico
        FROM fila f
        JOIN usuarios u ON u.id = f.barbeiro_id
        LEFT JOIN servicos s ON s.id = f.servico_id
        WHERE f.cliente_id = ?
        ORDER BY f.criado_em DESC
        LIMIT 8
    ");
    $hist->execute([$c['id']]);
    $c['historico'] = $hist->fetchAll(PDO::FETCH_ASSOC);
    return $c;
}, $clientes)) ?>;

function abrirDetalhe(id) {
  const c = clientesData.find(x => x.id == id);
  if (!c) return;

  const modal = new bootstrap.Modal(document.getElementById('modalDetalhe'));
  document.getElementById('detalheTitle').innerHTML =
    '<i class="bi bi-person-circle me-2" style="color:#e94560"></i>' +
    escHtml(c.nome);

  const cores = ['#e94560','#3b82f6','#22c55e','#f59e0b','#8b5cf6','#06b6d4','#f97316','#ec4899'];
  const cor   = cores[Math.abs(hashCode(c.nome)) % cores.length];
  const inic  = c.nome.charAt(0).toUpperCase();
  const isVip = parseInt(c.total_concluido) >= 10;
  const isFreq= parseInt(c.total_concluido) >= 3 && !isVip;
  const waNum = c.telefone.replace(/\D/g,'');

  let badgeHtml = '';
  if (isVip)        badgeHtml = '<span style="background:rgba(245,158,11,.2);color:#fbbf24;border:1px solid rgba(245,158,11,.25);border-radius:20px;padding:.15rem .6rem;font-size:.75rem;font-weight:700">⭐ Cliente VIP</span>';
  else if (isFreq)  badgeHtml = '<span style="background:rgba(34,197,94,.2);color:#4ade80;border:1px solid rgba(34,197,94,.25);border-radius:20px;padding:.15rem .6rem;font-size:.75rem;font-weight:700">✓ Frequente</span>';
  else              badgeHtml = '<span style="background:rgba(59,130,246,.2);color:#60a5fa;border:1px solid rgba(59,130,246,.25);border-radius:20px;padding:.15rem .6rem;font-size:.75rem;font-weight:700">✦ Novo</span>';

  // Stats rápidos
  const detalhes = [
    { icon:'bi-scissors',       bg:'rgba(233,69,96,.15)',   cor:'#e94560', label:'Atendimentos',   val: c.total_concluido + ' concluídos' },
    { icon:'bi-x-circle',       bg:'rgba(239,68,68,.12)',   cor:'#f87171', label:'Cancelamentos',  val: c.total_cancelado },
    { icon:'bi-cash-coin',      bg:'rgba(34,197,94,.12)',   cor:'#4ade80', label:'Total Gasto',     val: 'R$ ' + parseFloat(c.total_gasto).toFixed(2).replace('.',',') },
    { icon:'bi-calendar-check', bg:'rgba(59,130,246,.12)',  cor:'#60a5fa', label:'Cadastrado em',   val: fmtData(c.criado_em) },
    { icon:'bi-clock-history',  bg:'rgba(245,158,11,.12)',  cor:'#fbbf24', label:'Último Atend.',   val: c.ultimo_atend ? fmtData(c.ultimo_atend) : '—' },
    { icon:'bi-calendar2-plus', bg:'rgba(139,92,246,.12)',  cor:'#a78bfa', label:'Primeiro Atend.', val: c.primeiro_atend ? fmtData(c.primeiro_atend) : '—' },
  ];

  let detHtml = detalhes.map(d => `
    <div class="detalhe-item">
      <div class="detalhe-icon" style="background:${d.bg}">
        <i class="bi ${d.icon}" style="color:${d.cor}"></i>
      </div>
      <div>
        <div class="detalhe-label">${d.label}</div>
        <div class="detalhe-valor">${d.val}</div>
      </div>
    </div>`).join('');

  // Histórico
  let histHtml = '';
  if (c.historico && c.historico.length) {
    histHtml = c.historico.map(h => {
      const statusCor = h.status==='concluido' ? '#4ade80' : h.status==='cancelado' ? '#f87171' : '#fbbf24';
      const statusLabel = {concluido:'Concluído', cancelado:'Cancelado', aguardando:'Aguardando', atendendo:'Atendendo'}[h.status] || h.status;
      const pgto = h.forma_pagamento ? ' · ' + h.forma_pagamento : '';
      const val  = h.valor ? ' · <strong style="color:#4ade80">R$ '+parseFloat(h.valor).toFixed(2).replace('.',',')+'</strong>' : '';
      return `
        <div class="timeline-item">
          <div class="timeline-dot" style="background:${statusCor}"></div>
          <div style="flex:1;min-width:0">
            <div style="font-size:.85rem;color:#fff;font-weight:600">
              ${escHtml(h.barbeiro)}${h.servico ? ' · '+escHtml(h.servico) : ''}
            </div>
            <div style="font-size:.76rem;color:rgba(255,255,255,.4);margin-top:.1rem">
              ${fmtData(h.criado_em)}${pgto}${val}
            </div>
          </div>
          <span style="font-size:.73rem;font-weight:700;color:${statusCor};white-space:nowrap">${statusLabel}</span>
        </div>`;
    }).join('');
  } else {
    histHtml = '<div style="color:rgba(255,255,255,.3);font-size:.85rem;text-align:center;padding:1rem 0">Nenhum atendimento registrado</div>';
  }

  document.getElementById('detalheBody').innerHTML = `
    <!-- Cabeçalho do perfil -->
    <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.25rem;
                padding-bottom:1.25rem;border-bottom:1px solid rgba(255,255,255,.08)">
      <div style="width:60px;height:60px;border-radius:50%;flex-shrink:0;
                  background:${cor}22;border:2px solid ${cor}55;
                  display:flex;align-items:center;justify-content:center;
                  font-size:1.5rem;font-weight:800;color:${cor}">
        ${inic}
      </div>
      <div>
        <div style="font-size:1.1rem;font-weight:800;color:#fff">${escHtml(c.nome)}</div>
        <div style="font-size:.85rem;color:rgba(255,255,255,.5);margin:.2rem 0">${escHtml(c.telefone)}</div>
        <div style="display:flex;gap:.4rem;flex-wrap:wrap;margin-top:.3rem">
          ${badgeHtml}
        </div>
      </div>
      <div class="ms-auto d-flex gap-2 flex-wrap">
        <a href="https://wa.me/55${waNum}" target="_blank"
           style="background:rgba(37,211,102,.15);border:1px solid rgba(37,211,102,.25);
                  color:#25d366;border-radius:9px;padding:.4rem .85rem;
                  font-size:.82rem;font-weight:700;text-decoration:none;
                  display:flex;align-items:center;gap:.35rem">
          <i class="bi bi-whatsapp"></i> WhatsApp
        </a>
      </div>
    </div>

    <!-- Stats em grid -->
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(175px,1fr));gap:.6rem;margin-bottom:1.25rem">
      ${detHtml}
    </div>

    <!-- Histórico -->
    <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);
                border-radius:12px;padding:1rem">
      <div style="font-size:.78rem;font-weight:700;color:rgba(255,255,255,.4);
                  text-transform:uppercase;letter-spacing:.5px;margin-bottom:.75rem">
        <i class="bi bi-clock-history me-1"></i>Últimos Atendimentos
      </div>
      ${histHtml}
    </div>`;

  modal.show();
}

// Utils
function escHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fmtData(str) {
  if (!str) return '—';
  const d = new Date(str.replace(' ','T'));
  return isNaN(d) ? str : d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
}
function hashCode(s) {
  let h=0; for(let i=0;i<s.length;i++) h=Math.imul(31,h)+s.charCodeAt(i)|0; return h;
}
</script>
</body>
</html>