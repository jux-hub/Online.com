<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    if ($acao === 'salvar') {
        $id    = (int)($_POST['id'] ?? 0);
        $nome  = trim($_POST['nome'] ?? '');
        $preco = (float)str_replace(',','.',$_POST['preco'] ?? 0);
        $tempo = (int)($_POST['tempo_minutos'] ?? 30);
        if (!$nome || $preco <= 0) { flash('danger','Nome e preço são obrigatórios.'); }
        else {
            if ($id) {
                $db->prepare('UPDATE servicos SET nome=?,preco=?,tempo_minutos=? WHERE id=?')
                   ->execute([$nome,$preco,$tempo,$id]);
            } else {
                $db->prepare('INSERT INTO servicos (nome,preco,tempo_minutos) VALUES (?,?,?)')
                   ->execute([$nome,$preco,$tempo]);
            }
            flash('success','Serviço salvo!');
        }
    } elseif ($acao === 'toggle') {
        $db->prepare('UPDATE servicos SET ativo = CASE WHEN ativo=1 THEN 0 ELSE 1 END WHERE id=?')
           ->execute([(int)$_POST['id']]);
        flash('success','Status atualizado!');
    } elseif ($acao === 'excluir') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $db->prepare('DELETE FROM servicos WHERE id=?')->execute([$id]);
            flash('success','Serviço excluído!');
        }
    }
    header('Location: servicos.php'); exit;
}

$servicos      = $db->query('SELECT * FROM servicos ORDER BY nome')->fetchAll();
$nomeBarbearia = getConfig('nome_barbearia');

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Serviços – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<!-- PWA -->
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif}
  .sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;background:linear-gradient(180deg,#1a1a2e,#16213e);border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08)}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:260px;padding:2rem;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);padding:.85rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center}

  /* CARDS DE SERVIÇO */
  .serv-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem;display:flex;align-items:center;gap:1rem;transition:.2s}
  .serv-card:hover{background:rgba(255,255,255,.08)}
  .serv-icon{width:52px;height:52px;border-radius:14px;background:linear-gradient(135deg,rgba(233,69,96,.25),rgba(196,18,48,.2));display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#e94560;flex-shrink:0;border:1px solid rgba(233,69,96,.3)}
  .serv-nome{font-weight:700;color:#fff;font-size:1rem;margin-bottom:.2rem}
  .serv-preco{color:#4ade80;font-weight:800;font-size:1.1rem}
  .serv-tempo{color:rgba(255,255,255,.45);font-size:.82rem}
  .badge-ativo{background:rgba(34,197,94,.2);color:#4ade80;border-radius:6px;padding:.25rem .65rem;font-size:.78rem;font-weight:600}
  .badge-inativo{background:rgba(239,68,68,.2);color:#f87171;border-radius:6px;padding:.25rem .65rem;font-size:.78rem;font-weight:600}
  .btn-editar-card{background:rgba(59,130,246,.2);color:#60a5fa;border:none;border-radius:8px;padding:.4rem .75rem;cursor:pointer;transition:.2s}
  .btn-editar-card:hover{background:rgba(59,130,246,.35)}
  .btn-toggle-card{background:rgba(245,158,11,.2);color:#fbbf24;border:none;border-radius:8px;padding:.4rem .75rem;cursor:pointer;transition:.2s;width:100%}
  .btn-toggle-card:hover{background:rgba(245,158,11,.35)}
  .btn-excluir-card{background:rgba(239,68,68,.2);color:#f87171;border:none;border-radius:8px;padding:.4rem .75rem;cursor:pointer;transition:.2s;width:100%}
  .btn-excluir-card:hover{background:rgba(239,68,68,.35)}

  /* Modal */
  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12)}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08)}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08)}
  .modal-title,.modal-body label{color:#fff}
  .form-control{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:#fff;border-radius:10px}
  .form-control:focus{background:rgba(255,255,255,.12);border-color:var(--primary);color:#fff;box-shadow:0 0 0 .25rem rgba(233,69,96,.2)}
  .form-control::placeholder{color:rgba(255,255,255,.4)}
  h5,h4{color:#fff}
  .btn-save{background:linear-gradient(135deg,#e94560,#c41230);border:none;color:#fff;border-radius:10px;font-weight:600}
  .btn-save:hover{opacity:.9;color:#fff}
  .btn-danger-confirm{background:linear-gradient(135deg,#ef4444,#b91c1c);border:none;color:#fff;border-radius:10px;font-weight:600}
  .btn-danger-confirm:hover{opacity:.9;color:#fff}
  /* Texto de aviso no modal de exclusão */
  .excluir-nome{color:#f87171;font-weight:700}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
  }
</style>
</head>
<body>
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-sm d-md-none" style="background:rgba(255,255,255,.1);color:#fff" id="btnMenuMobile">
        <i class="bi bi-list fs-5"></i>
      </button>
      <h5 class="mb-0 fw-bold"><i class="bi bi-scissors me-2" style="color:#e94560"></i>Gerenciar Serviços</h5>
    </div>
    <button class="btn btn-save px-3" data-bs-toggle="modal" data-bs-target="#modalServico" id="btnNovo">
      <i class="bi bi-plus-lg me-1"></i>Novo Serviço
    </button>
  </div>

  <?= renderFlash() ?>

  <div class="row g-3">
    <?php if(empty($servicos)): ?>
    <div class="col-12">
      <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:3rem;text-align:center;color:rgba(255,255,255,.3)">
        <i class="bi bi-scissors fs-1 d-block mb-2"></i>Nenhum serviço cadastrado
      </div>
    </div>
    <?php endif; ?>

    <?php foreach($servicos as $s): ?>
    <div class="col-12 col-md-6 col-xl-4">
      <div class="serv-card">
        <div class="serv-icon"><i class="bi bi-scissors"></i></div>
        <div class="flex-grow-1">
          <div class="serv-nome"><?= htmlspecialchars($s['nome']) ?></div>
          <div class="d-flex align-items-center gap-2 flex-wrap">
            <span class="serv-preco"><?= formatMoney($s['preco']) ?></span>
            <span class="serv-tempo"><i class="bi bi-clock me-1"></i><?= $s['tempo_minutos'] ?> min</span>
            <?php if($s['ativo']): ?>
              <span class="badge-ativo">Ativo</span>
            <?php else: ?>
              <span class="badge-inativo">Inativo</span>
            <?php endif; ?>
          </div>
        </div>
        <div class="d-flex flex-column gap-2">
          <!-- Editar -->
          <button class="btn-editar-card"
            data-id="<?= $s['id'] ?>"
            data-nome="<?= htmlspecialchars($s['nome']) ?>"
            data-preco="<?= $s['preco'] ?>"
            data-tempo="<?= $s['tempo_minutos'] ?>"
            data-bs-toggle="modal" data-bs-target="#modalServico"
            title="Editar">
            <i class="bi bi-pencil"></i>
          </button>
          <!-- Ativar/Desativar -->
          <form method="POST" class="d-inline">
            <input type="hidden" name="acao" value="toggle">
            <input type="hidden" name="id" value="<?= $s['id'] ?>">
            <button type="submit" class="btn-toggle-card" title="<?= $s['ativo'] ? 'Desativar' : 'Ativar' ?>">
              <i class="bi bi-<?= $s['ativo'] ? 'toggle-on' : 'toggle-off' ?>"></i>
            </button>
          </form>
          <!-- Excluir -->
          <button class="btn-excluir-card"
            data-id="<?= $s['id'] ?>"
            data-nome="<?= htmlspecialchars($s['nome']) ?>"
            data-bs-toggle="modal" data-bs-target="#modalExcluir"
            title="Excluir">
            <i class="bi bi-trash"></i>
          </button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Modal Salvar/Editar -->
<div class="modal fade" id="modalServico" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitulo">Novo Serviço</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="fId" value="0">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Nome do Serviço *</label>
              <input type="text" name="nome" id="fNome" class="form-control" required>
            </div>
            <div class="col-6">
              <label class="form-label">Preço (R$) *</label>
              <input type="number" name="preco" id="fPreco" class="form-control" step="0.50" min="0" required>
            </div>
            <div class="col-6">
              <label class="form-label">Tempo (minutos)</label>
              <input type="number" name="tempo_minutos" id="fTempo" class="form-control" min="5" value="30">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-save px-4"><i class="bi bi-check2 me-1"></i>Salvar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Confirmar Exclusão -->
<div class="modal fade" id="modalExcluir" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-exclamation-triangle-fill me-2" style="color:#f87171"></i>Confirmar Exclusão</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" style="color:rgba(255,255,255,.8)">
        Tem certeza que deseja excluir o serviço <span id="excluirNome" class="excluir-nome"></span>?
        <div class="mt-2" style="color:rgba(255,255,255,.45);font-size:.85rem">
          <i class="bi bi-info-circle me-1"></i>Esta ação não poderá ser desfeita.
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
        <form method="POST" class="d-inline">
          <input type="hidden" name="acao" value="excluir">
          <input type="hidden" name="id" id="excluirId" value="0">
          <button type="submit" class="btn btn-danger-confirm px-4">
            <i class="bi bi-trash me-1"></i>Excluir
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// Modal Novo
document.getElementById('btnNovo').addEventListener('click', () => {
  document.getElementById('modalTitulo').textContent = 'Novo Serviço';
  document.getElementById('fId').value = 0;
  document.getElementById('fNome').value = '';
  document.getElementById('fPreco').value = '';
  document.getElementById('fTempo').value = 30;
});

// Modal Editar
document.querySelectorAll('.btn-editar-card').forEach(btn => {
  btn.addEventListener('click', function() {
    document.getElementById('modalTitulo').textContent = 'Editar Serviço';
    document.getElementById('fId').value = this.dataset.id;
    document.getElementById('fNome').value = this.dataset.nome;
    document.getElementById('fPreco').value = this.dataset.preco;
    document.getElementById('fTempo').value = this.dataset.tempo;
  });
});

// Modal Excluir
document.querySelectorAll('.btn-excluir-card').forEach(btn => {
  btn.addEventListener('click', function() {
    document.getElementById('excluirId').value = this.dataset.id;
    document.getElementById('excluirNome').textContent = this.dataset.nome;
  });
});
</script>
<!-- Service Worker -->
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</body>
</html>