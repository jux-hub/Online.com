<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// ── AÇÕES POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    // ════ PACOTES ════
    if ($acao === 'salvar_pacote') {
        $id       = (int)($_POST['id'] ?? 0);
        $nome     = trim($_POST['nome'] ?? '');
        $desc     = trim($_POST['descricao'] ?? '');
        $creditos = max(1, (int)($_POST['creditos'] ?? 1));
        $preco    = (float)str_replace(',', '.', $_POST['preco'] ?? 0);
        $servico  = (int)($_POST['servico_id'] ?? 0) ?: null;
        $validade = max(0, (int)($_POST['validade_dias'] ?? 0));
        if (!$nome || $preco <= 0) { flash('danger', 'Nome e preço são obrigatórios.'); }
        else {
            if ($id) {
                $db->prepare("UPDATE pacotes SET nome=?,descricao=?,creditos=?,preco=?,servico_id=?,validade_dias=? WHERE id=?")
                   ->execute([$nome,$desc,$creditos,$preco,$servico,$validade,$id]);
            } else {
                $db->prepare("INSERT INTO pacotes (nome,descricao,creditos,preco,servico_id,validade_dias) VALUES (?,?,?,?,?,?)")
                   ->execute([$nome,$desc,$creditos,$preco,$servico,$validade]);
            }
            flash('success', 'Pacote salvo!');
        }
        header('Location: pacotes_produtos.php#pacotes'); exit;

    } elseif ($acao === 'toggle_pacote') {
        $db->prepare("UPDATE pacotes SET ativo = CASE WHEN ativo=1 THEN 0 ELSE 1 END WHERE id=?")
           ->execute([(int)$_POST['id']]);
        flash('success', 'Status atualizado!');
        header('Location: pacotes_produtos.php#pacotes'); exit;

    } elseif ($acao === 'excluir_pacote') {
        $id = (int)($_POST['id'] ?? 0);
        // Verifica se há vendas associadas
        $uso = $db->prepare("SELECT COUNT(*) FROM vendas WHERE pacote_id=?");
        $uso->execute([$id]);
        if ($uso->fetchColumn() > 0) {
            flash('danger', 'Não é possível excluir: pacote possui vendas registradas. Desative-o.');
        } else {
            $db->prepare("DELETE FROM pacotes WHERE id=?")->execute([$id]);
            flash('success', 'Pacote excluído!');
        }
        header('Location: pacotes_produtos.php#pacotes'); exit;

    // ════ PRODUTOS ════
    } elseif ($acao === 'salvar_produto') {
        $id       = (int)($_POST['id'] ?? 0);
        $nome     = trim($_POST['nome'] ?? '');
        $desc     = trim($_POST['descricao'] ?? '');
        $preco    = (float)str_replace(',', '.', $_POST['preco'] ?? 0);
        $estoque  = max(0, (int)($_POST['estoque'] ?? 0));
        $estqMin  = max(0, (int)($_POST['estoque_min'] ?? 0));
        $categ    = trim($_POST['categoria'] ?? 'outros');
        if (!$nome || $preco <= 0) { flash('danger', 'Nome e preço são obrigatórios.'); }
        else {
            if ($id) {
                $db->prepare("UPDATE produtos SET nome=?,descricao=?,preco=?,estoque=?,estoque_min=?,categoria=? WHERE id=?")
                   ->execute([$nome,$desc,$preco,$estoque,$estqMin,$categ,$id]);
            } else {
                $db->prepare("INSERT INTO produtos (nome,descricao,preco,estoque,estoque_min,categoria) VALUES (?,?,?,?,?,?)")
                   ->execute([$nome,$desc,$preco,$estoque,$estqMin,$categ]);
            }
            flash('success', 'Produto salvo!');
        }
        header('Location: pacotes_produtos.php#produtos'); exit;

    } elseif ($acao === 'toggle_produto') {
        $db->prepare("UPDATE produtos SET ativo = CASE WHEN ativo=1 THEN 0 ELSE 1 END WHERE id=?")
           ->execute([(int)$_POST['id']]);
        flash('success', 'Status atualizado!');
        header('Location: pacotes_produtos.php#produtos'); exit;

    } elseif ($acao === 'excluir_produto') {
        $id = (int)($_POST['id'] ?? 0);
        $uso = $db->prepare("SELECT COUNT(*) FROM vendas WHERE produto_id=?");
        $uso->execute([$id]);
        if ($uso->fetchColumn() > 0) {
            flash('danger', 'Não é possível excluir: produto possui vendas registradas. Desative-o.');
        } else {
            $db->prepare("DELETE FROM produtos WHERE id=?")->execute([$id]);
            flash('success', 'Produto excluído!');
        }
        header('Location: pacotes_produtos.php#produtos'); exit;
    }
}

$pacotes  = $db->query("SELECT p.*, s.nome AS servico_nome FROM pacotes p LEFT JOIN servicos s ON s.id=p.servico_id ORDER BY p.ativo DESC, p.nome")->fetchAll();
$produtos = $db->query("SELECT * FROM produtos ORDER BY ativo DESC, categoria, nome")->fetchAll();
$servicos = $db->query("SELECT id, nome FROM servicos WHERE ativo=1 ORDER BY nome")->fetchAll();

// Stats
$totalVendasPacotes  = $db->query("SELECT COALESCE(SUM(valor_total),0) FROM vendas WHERE tipo='pacote'")->fetchColumn();
$totalVendasProdutos = $db->query("SELECT COALESCE(SUM(valor_total),0) FROM vendas WHERE tipo='produto'")->fetchColumn();
$totalCreditosAtivos = $db->query("SELECT COALESCE(SUM(creditos_restantes),0) FROM clientes_pacotes WHERE ativo=1")->fetchColumn();
$produtosEstoqueBaixo = $db->query("SELECT COUNT(*) FROM produtos WHERE estoque <= estoque_min AND estoque_min > 0 AND ativo=1")->fetchColumn();

$nomeBarbearia = getConfig('nome_barbearia');

$categoriasDisponiveis = ['pomada','shampoo','condicionador','balm','oleo','perfume','navalha','outros'];

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pacotes & Produtos – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  .main-content{margin-left:var(--sidebar-w);min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  /* Stats */
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
    border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem;position:relative;overflow:hidden}
  .stat-card::after{content:'';position:absolute;top:-15px;right:-15px;width:70px;height:70px;border-radius:50%;opacity:.12}
  .stat-card.c1::after{background:#e94560}
  .stat-card.c2::after{background:#22c55e}
  .stat-card.c3::after{background:#3b82f6}
  .stat-card.c4::after{background:#f59e0b}
  .stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:.85rem}
  .stat-value{font-size:1.5rem;font-weight:800;color:#fff;line-height:1}
  .stat-label{color:rgba(255,255,255,.5);font-size:.82rem;margin-top:.3rem}

  /* Tabs */
  .tabs-bar{display:flex;gap:.5rem;border-bottom:1px solid rgba(255,255,255,.08);margin-bottom:1.5rem}
  .tab-btn{background:none;border:none;color:rgba(255,255,255,.45);padding:.75rem 1.25rem;
    font-size:.95rem;font-weight:600;cursor:pointer;border-bottom:3px solid transparent;
    transition:.2s;display:flex;align-items:center;gap:.5rem}
  .tab-btn:hover{color:#fff}
  .tab-btn.active{color:#fff;border-bottom-color:var(--primary)}

  /* Cards de pacote/produto */
  .item-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);
    border-radius:16px;padding:1.25rem;transition:.2s;position:relative}
  .item-card:hover{border-color:rgba(233,69,96,.3);background:rgba(255,255,255,.06)}
  .item-card.inativo{opacity:.5}
  .item-tag{position:absolute;top:.85rem;right:.85rem;border-radius:20px;
    padding:.15rem .6rem;font-size:.7rem;font-weight:700}
  .tag-ativo{background:rgba(34,197,94,.2);color:#4ade80;border:1px solid rgba(34,197,94,.25)}
  .tag-inativo{background:rgba(239,68,68,.15);color:#f87171;border:1px solid rgba(239,68,68,.2)}
  .tag-baixo{background:rgba(245,158,11,.2);color:#fbbf24;border:1px solid rgba(245,158,11,.25)}

  .item-preco{font-size:1.4rem;font-weight:800;color:var(--primary)}
  .item-nome{font-size:1rem;font-weight:700;color:#fff;margin-bottom:.25rem}
  .item-desc{font-size:.8rem;color:rgba(255,255,255,.45);margin-bottom:.75rem;min-height:1.2rem}

  .badge-credito{background:rgba(233,69,96,.15);color:#e94560;border:1px solid rgba(233,69,96,.25);
    border-radius:20px;padding:.2rem .65rem;font-size:.75rem;font-weight:700;display:inline-flex;align-items:center;gap:.3rem}
  .badge-estoque{border-radius:20px;padding:.2rem .65rem;font-size:.75rem;font-weight:700;display:inline-flex;align-items:center;gap:.3rem}
  .badge-estq-ok{background:rgba(34,197,94,.12);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
  .badge-estq-baixo{background:rgba(245,158,11,.15);color:#fbbf24;border:1px solid rgba(245,158,11,.25)}
  .badge-estq-zero{background:rgba(239,68,68,.12);color:#f87171;border:1px solid rgba(239,68,68,.2)}

  .badge-categ{background:rgba(139,92,246,.12);color:#a78bfa;border:1px solid rgba(139,92,246,.2);
    border-radius:20px;padding:.15rem .55rem;font-size:.7rem;font-weight:700}

  /* Ações rápidas */
  .btn-card-act{border:none;border-radius:8px;padding:.35rem .65rem;font-size:.8rem;
    cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.3rem}
  .btn-edit-c{background:rgba(59,130,246,.12);color:#60a5fa}
  .btn-edit-c:hover{background:rgba(59,130,246,.25)}
  .btn-toggle-c{background:rgba(245,158,11,.12);color:#fbbf24}
  .btn-toggle-c:hover{background:rgba(245,158,11,.25)}
  .btn-del-c{background:rgba(239,68,68,.1);color:#f87171}
  .btn-del-c:hover{background:rgba(239,68,68,.22)}

  /* Btn add */
  .btn-add{background:linear-gradient(135deg,var(--primary),#c41230);border:none;
    color:#fff;border-radius:12px;padding:.6rem 1.25rem;font-weight:700;
    font-size:.9rem;cursor:pointer;display:flex;align-items:center;gap:.5rem;
    transition:opacity .2s}
  .btn-add:hover{opacity:.88}

  /* Modals */
  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08);padding:1.25rem 1.5rem}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08);padding:1rem 1.5rem}
  .modal-title{color:#fff;font-weight:700}
  .btn-close{filter:invert(1) opacity(.5)}
  .form-ctrl{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.6rem 1rem;width:100%;font-size:.9rem;transition:.2s}
  .form-ctrl:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15);background:rgba(255,255,255,.1)}
  .form-ctrl::placeholder{color:rgba(255,255,255,.3)}
  select.form-ctrl option{background:#1a1a2e;color:#fff}
  .form-lbl{color:rgba(255,255,255,.7);font-size:.85rem;font-weight:600;margin-bottom:.4rem;display:block}
  .form-hint{color:rgba(255,255,255,.3);font-size:.75rem;margin-top:.25rem}
  .section-divider{border:none;border-top:1px solid rgba(255,255,255,.07);margin:1rem 0}

  /* Alerta estoque */
  .alerta-estoque{background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);
    border-radius:12px;padding:.85rem 1.1rem;display:flex;align-items:center;gap:.75rem;margin-bottom:1rem}

  h4,h5,h6{color:#fff;margin:0}
  .empty-state{text-align:center;padding:3rem 0;color:rgba(255,255,255,.25)}
  .empty-state i{font-size:3rem;display:block;margin-bottom:.75rem}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<!-- CONTEÚDO -->
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">Pacotes & Produtos</h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
          <?= count($pacotes) ?> pacote<?= count($pacotes)!==1?'s':'' ?> ·
          <?= count($produtos) ?> produto<?= count($produtos)!==1?'s':'' ?>
        </div>
      </div>
    </div>
    <a href="vendas.php"
       style="background:linear-gradient(135deg,var(--primary),#c41230);border:none;
              color:#fff;border-radius:10px;padding:.5rem 1.1rem;
              font-size:.85rem;font-weight:700;text-decoration:none;
              display:flex;align-items:center;gap:.4rem">
      <i class="bi bi-cart-plus-fill"></i> Nova Venda
    </a>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- STATS -->
    <div class="row g-2 mb-3">
      <div class="col-6 col-xl-3">
        <div class="stat-card c1">
          <div class="stat-icon" style="background:rgba(233,69,96,.2)"><i class="bi bi-ticket-perforated-fill" style="color:#e94560"></i></div>
          <div class="stat-value" style="font-size:1.2rem"><?= formatMoney($totalVendasPacotes) ?></div>
          <div class="stat-label">Vendas de Pacotes</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c2">
          <div class="stat-icon" style="background:rgba(34,197,94,.2)"><i class="bi bi-bag-fill" style="color:#22c55e"></i></div>
          <div class="stat-value" style="font-size:1.2rem"><?= formatMoney($totalVendasProdutos) ?></div>
          <div class="stat-label">Vendas de Produtos</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c3">
          <div class="stat-icon" style="background:rgba(59,130,246,.2)"><i class="bi bi-credit-card-2-front-fill" style="color:#3b82f6"></i></div>
          <div class="stat-value"><?= number_format($totalCreditosAtivos) ?></div>
          <div class="stat-label">Créditos Ativos</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c4">
          <div class="stat-icon" style="background:rgba(245,158,11,.2)"><i class="bi bi-exclamation-triangle-fill" style="color:#f59e0b"></i></div>
          <div class="stat-value"><?= $produtosEstoqueBaixo ?></div>
          <div class="stat-label">Estoque Baixo</div>
        </div>
      </div>
    </div>

    <?php if ($produtosEstoqueBaixo > 0): ?>
    <div class="alerta-estoque">
      <i class="bi bi-exclamation-triangle-fill" style="color:#fbbf24;font-size:1.2rem;flex-shrink:0"></i>
      <div>
        <strong style="color:#fbbf24"><?= $produtosEstoqueBaixo ?> produto<?= $produtosEstoqueBaixo!==1?'s':'' ?> com estoque baixo.</strong>
        <span style="color:rgba(255,255,255,.5);font-size:.85rem"> Verifique a aba Produtos.</span>
      </div>
    </div>
    <?php endif; ?>

    <!-- TABS -->
    <div class="tabs-bar">
      <button class="tab-btn active" id="tabBtnPacotes" onclick="switchTab('pacotes')">
        <i class="bi bi-ticket-perforated-fill"></i> Pacotes
        <span style="background:rgba(255,255,255,.1);border-radius:20px;padding:.05rem .5rem;font-size:.75rem"><?= count($pacotes) ?></span>
      </button>
      <button class="tab-btn" id="tabBtnProdutos" onclick="switchTab('produtos')">
        <i class="bi bi-bag-fill"></i> Produtos
        <span style="background:rgba(255,255,255,.1);border-radius:20px;padding:.05rem .5rem;font-size:.75rem"><?= count($produtos) ?></span>
        <?php if ($produtosEstoqueBaixo > 0): ?>
          <span style="background:rgba(245,158,11,.25);color:#fbbf24;border-radius:20px;padding:.05rem .4rem;font-size:.7rem">
            ⚠ <?= $produtosEstoqueBaixo ?>
          </span>
        <?php endif; ?>
      </button>
    </div>

    <!-- ═══════════ TAB PACOTES ═══════════ -->
    <div id="tabPacotes">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 style="color:rgba(255,255,255,.6);font-size:.85rem;font-weight:600">
          PACOTES CADASTRADOS
        </h6>
        <button class="btn-add" onclick="abrirModalPacote()">
          <i class="bi bi-plus-lg"></i> Novo Pacote
        </button>
      </div>

      <?php if (empty($pacotes)): ?>
        <div class="empty-state">
          <i class="bi bi-ticket-perforated"></i>
          Nenhum pacote cadastrado ainda.<br>
          <small>Clique em "Novo Pacote" para começar.</small>
        </div>
      <?php else: ?>
        <div class="row g-3">
          <?php foreach ($pacotes as $pac):
            $ecoDesconto = $pac['creditos'] > 0 && $pac['preco'] > 0
                ? round(100 - (($pac['preco'] / ($pac['creditos'] * ($pac['servico_id']
                    ? ($db->query("SELECT preco FROM servicos WHERE id=".(int)$pac['servico_id'])->fetchColumn() ?: $pac['preco'])
                    : $pac['preco'] / $pac['creditos']))) * 100))
                : 0;
          ?>
          <div class="col-12 col-md-6 col-xl-4">
            <div class="item-card <?= !$pac['ativo'] ? 'inativo' : '' ?>">
              <span class="item-tag <?= $pac['ativo'] ? 'tag-ativo' : 'tag-inativo' ?>">
                <?= $pac['ativo'] ? '● Ativo' : '○ Inativo' ?>
              </span>

              <div style="margin-right:4rem">
                <div class="item-nome"><?= htmlspecialchars($pac['nome']) ?></div>
                <div class="item-desc"><?= htmlspecialchars($pac['descricao'] ?: '—') ?></div>
              </div>

              <div class="d-flex align-items-center gap-2 flex-wrap mb-2">
                <div class="item-preco"><?= formatMoney($pac['preco']) ?></div>
                <span class="badge-credito">
                  <i class="bi bi-scissors"></i>
                  <?= $pac['creditos'] ?> corte<?= $pac['creditos']!==1?'s':'' ?>
                </span>
                <?php if ($pac['servico_nome']): ?>
                  <span style="background:rgba(99,102,241,.12);color:#818cf8;border:1px solid rgba(99,102,241,.2);
                               border-radius:20px;padding:.15rem .55rem;font-size:.7rem;font-weight:600">
                    <?= htmlspecialchars($pac['servico_nome']) ?>
                  </span>
                <?php endif; ?>
              </div>

              <div style="font-size:.78rem;color:rgba(255,255,255,.35);margin-bottom:.85rem;display:flex;gap:.75rem;flex-wrap:wrap">
                <?php if ($pac['validade_dias'] > 0): ?>
                  <span><i class="bi bi-calendar3 me-1"></i><?= $pac['validade_dias'] ?> dias de validade</span>
                <?php else: ?>
                  <span><i class="bi bi-infinity me-1"></i>Sem validade</span>
                <?php endif; ?>
                <?php
                  $precoUni = $pac['creditos'] > 0 ? $pac['preco'] / $pac['creditos'] : $pac['preco'];
                ?>
                <span><i class="bi bi-tag me-1"></i><?= formatMoney($precoUni) ?>/corte</span>
              </div>

              <hr class="section-divider" style="margin:.6rem 0">
              <div class="d-flex gap-1 flex-wrap">
                <button class="btn-card-act btn-edit-c"
                        onclick="editarPacote(<?= htmlspecialchars(json_encode($pac)) ?>)">
                  <i class="bi bi-pencil-fill"></i> Editar
                </button>
                <form method="POST" class="d-inline">
                  <input type="hidden" name="acao" value="toggle_pacote">
                  <input type="hidden" name="id" value="<?= $pac['id'] ?>">
                  <button type="submit" class="btn-card-act btn-toggle-c">
                    <i class="bi bi-<?= $pac['ativo'] ? 'eye-slash' : 'eye' ?>-fill"></i>
                    <?= $pac['ativo'] ? 'Desativar' : 'Ativar' ?>
                  </button>
                </form>
                <form method="POST" class="d-inline"
                      onsubmit="return confirm('Excluir o pacote \'<?= addslashes(htmlspecialchars($pac['nome'])) ?>\'?')">
                  <input type="hidden" name="acao" value="excluir_pacote">
                  <input type="hidden" name="id" value="<?= $pac['id'] ?>">
                  <button type="submit" class="btn-card-act btn-del-c">
                    <i class="bi bi-trash3-fill"></i>
                  </button>
                </form>
                <a href="vendas.php?tipo=pacote&pacote_id=<?= $pac['id'] ?>"
                   style="background:linear-gradient(135deg,rgba(233,69,96,.2),rgba(233,69,96,.1));
                          border:1px solid rgba(233,69,96,.25);color:#e94560;border-radius:8px;
                          padding:.35rem .65rem;font-size:.8rem;font-weight:700;text-decoration:none;
                          display:inline-flex;align-items:center;gap:.3rem;margin-left:auto">
                  <i class="bi bi-cart-plus"></i> Vender
                </a>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- ═══════════ TAB PRODUTOS ═══════════ -->
    <div id="tabProdutos" style="display:none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 style="color:rgba(255,255,255,.6);font-size:.85rem;font-weight:600">
          PRODUTOS CADASTRADOS
        </h6>
        <button class="btn-add" onclick="abrirModalProduto()">
          <i class="bi bi-plus-lg"></i> Novo Produto
        </button>
      </div>

      <?php if (empty($produtos)): ?>
        <div class="empty-state">
          <i class="bi bi-bag"></i>
          Nenhum produto cadastrado ainda.
        </div>
      <?php else: ?>
        <div class="row g-3">
          <?php foreach ($produtos as $prod):
            $estoqClass = $prod['estoque'] == 0 ? 'badge-estq-zero' :
                         ($prod['estoque'] <= $prod['estoque_min'] && $prod['estoque_min'] > 0 ? 'badge-estq-baixo' : 'badge-estq-ok');
            $estoqIcon  = $prod['estoque'] == 0 ? 'bi-x-circle-fill' :
                         ($prod['estoque'] <= $prod['estoque_min'] && $prod['estoque_min'] > 0 ? 'bi-exclamation-triangle-fill' : 'bi-check-circle-fill');
          ?>
          <div class="col-12 col-md-6 col-xl-4">
            <div class="item-card <?= !$prod['ativo'] ? 'inativo' : '' ?>">
              <span class="item-tag <?= $prod['ativo'] ? 'tag-ativo' : 'tag-inativo' ?>">
                <?= $prod['ativo'] ? '● Ativo' : '○ Inativo' ?>
              </span>

              <div style="margin-right:4rem">
                <div class="item-nome"><?= htmlspecialchars($prod['nome']) ?></div>
                <div class="item-desc"><?= htmlspecialchars($prod['descricao'] ?: '—') ?></div>
              </div>

              <div class="d-flex align-items-center gap-2 flex-wrap mb-2">
                <div class="item-preco"><?= formatMoney($prod['preco']) ?></div>
                <span class="badge-estoque <?= $estoqClass ?>">
                  <i class="bi <?= $estoqIcon ?>"></i>
                  <?= $prod['estoque'] ?> em estoque
                </span>
                <span class="badge-categ"><?= htmlspecialchars(ucfirst($prod['categoria'])) ?></span>
              </div>

              <?php if ($prod['estoque_min'] > 0): ?>
              <div style="font-size:.76rem;color:rgba(255,255,255,.3);margin-bottom:.75rem">
                <i class="bi bi-bell me-1"></i>Alerta quando < <?= $prod['estoque_min'] ?> unidades
              </div>
              <?php endif; ?>

              <hr class="section-divider" style="margin:.6rem 0">
              <div class="d-flex gap-1 flex-wrap">
                <button class="btn-card-act btn-edit-c"
                        onclick="editarProduto(<?= htmlspecialchars(json_encode($prod)) ?>)">
                  <i class="bi bi-pencil-fill"></i> Editar
                </button>
                <form method="POST" class="d-inline">
                  <input type="hidden" name="acao" value="toggle_produto">
                  <input type="hidden" name="id" value="<?= $prod['id'] ?>">
                  <button type="submit" class="btn-card-act btn-toggle-c">
                    <i class="bi bi-<?= $prod['ativo'] ? 'eye-slash' : 'eye' ?>-fill"></i>
                    <?= $prod['ativo'] ? 'Desativar' : 'Ativar' ?>
                  </button>
                </form>
                <form method="POST" class="d-inline"
                      onsubmit="return confirm('Excluir \'<?= addslashes(htmlspecialchars($prod['nome'])) ?>\'?')">
                  <input type="hidden" name="acao" value="excluir_produto">
                  <input type="hidden" name="id" value="<?= $prod['id'] ?>">
                  <button type="submit" class="btn-card-act btn-del-c">
                    <i class="bi bi-trash3-fill"></i>
                  </button>
                </form>
                <a href="vendas.php?tipo=produto&produto_id=<?= $prod['id'] ?>"
                   style="background:linear-gradient(135deg,rgba(34,197,94,.15),rgba(34,197,94,.08));
                          border:1px solid rgba(34,197,94,.25);color:#4ade80;border-radius:8px;
                          padding:.35rem .65rem;font-size:.8rem;font-weight:700;text-decoration:none;
                          display:inline-flex;align-items:center;gap:.3rem;margin-left:auto">
                  <i class="bi bi-cart-plus"></i> Vender
                </a>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

  </div><!-- /page-body -->
</div>

<!-- ═══ MODAL PACOTE ═══ -->
<div class="modal fade" id="modalPacote" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="titleModalPacote">
          <i class="bi bi-ticket-perforated-fill me-2" style="color:var(--primary)"></i>Novo Pacote
        </h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="acao" value="salvar_pacote">
        <input type="hidden" name="id"   id="pacoteId">
        <div class="modal-body" style="padding:1.25rem 1.5rem">
          <div class="mb-3">
            <label class="form-lbl">Nome do Pacote *</label>
            <input type="text" name="nome" id="pacoteNome" class="form-ctrl"
                   placeholder="Ex: Pacote 4 Cortes" required>
          </div>
          <div class="mb-3">
            <label class="form-lbl">Descrição</label>
            <input type="text" name="descricao" id="pacoteDesc" class="form-ctrl"
                   placeholder="Ex: 4 cortes pelo preço de 3">
          </div>
          <div class="row g-2 mb-3">
            <div class="col-6">
              <label class="form-lbl">Quantidade de Créditos *</label>
              <input type="number" name="creditos" id="pacoteCreditos" class="form-ctrl"
                     min="1" value="4" required>
              <div class="form-hint">Quantos cortes o pacote inclui</div>
            </div>
            <div class="col-6">
              <label class="form-lbl">Preço Total (R$) *</label>
              <input type="text" name="preco" id="pacotePreco" class="form-ctrl"
                     placeholder="0,00" required>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-lbl">Serviço vinculado</label>
            <select name="servico_id" id="pacoteServico" class="form-ctrl">
              <option value="">— Qualquer serviço —</option>
              <?php foreach ($servicos as $s): ?>
                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['nome']) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="form-hint">Opcional: restringir a um tipo de serviço específico</div>
          </div>
          <div class="mb-1">
            <label class="form-lbl">Validade (dias)</label>
            <input type="number" name="validade_dias" id="pacoteValidade" class="form-ctrl"
                   min="0" value="90">
            <div class="form-hint">0 = sem validade</div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm"
            style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                   color:rgba(255,255,255,.6);border-radius:8px;padding:.45rem .9rem"
            data-bs-dismiss="modal">Cancelar</button>
          <button type="submit"
            style="background:var(--primary);border:none;color:#fff;border-radius:8px;
                   padding:.45rem 1.1rem;font-weight:700;cursor:pointer">
            <i class="bi bi-check2 me-1"></i>Salvar Pacote
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- ═══ MODAL PRODUTO ═══ -->
<div class="modal fade" id="modalProduto" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="titleModalProduto">
          <i class="bi bi-bag-fill me-2" style="color:#22c55e"></i>Novo Produto
        </h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="acao" value="salvar_produto">
        <input type="hidden" name="id"   id="produtoId">
        <div class="modal-body" style="padding:1.25rem 1.5rem">
          <div class="mb-3">
            <label class="form-lbl">Nome do Produto *</label>
            <input type="text" name="nome" id="produtoNome" class="form-ctrl"
                   placeholder="Ex: Pomada Modeladora" required>
          </div>
          <div class="mb-3">
            <label class="form-lbl">Descrição</label>
            <input type="text" name="descricao" id="produtoDesc" class="form-ctrl"
                   placeholder="Ex: 120g, fixação forte">
          </div>
          <div class="row g-2 mb-3">
            <div class="col-6">
              <label class="form-lbl">Preço de Venda (R$) *</label>
              <input type="text" name="preco" id="produtoPreco" class="form-ctrl"
                     placeholder="0,00" required>
            </div>
            <div class="col-6">
              <label class="form-lbl">Categoria</label>
              <select name="categoria" id="produtoCategoria" class="form-ctrl">
                <?php foreach ($categoriasDisponiveis as $cat): ?>
                  <option value="<?= $cat ?>"><?= ucfirst($cat) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="row g-2 mb-1">
            <div class="col-6">
              <label class="form-lbl">Estoque Atual</label>
              <input type="number" name="estoque" id="produtoEstoque" class="form-ctrl"
                     min="0" value="0">
            </div>
            <div class="col-6">
              <label class="form-lbl">Alerta Mínimo</label>
              <input type="number" name="estoque_min" id="produtoEstoqueMin" class="form-ctrl"
                     min="0" value="0">
              <div class="form-hint">0 = sem alerta</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm"
            style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                   color:rgba(255,255,255,.6);border-radius:8px;padding:.45rem .9rem"
            data-bs-dismiss="modal">Cancelar</button>
          <button type="submit"
            style="background:rgba(34,197,94,.2);border:1px solid rgba(34,197,94,.3);
                   color:#4ade80;border-radius:8px;padding:.45rem 1.1rem;font-weight:700;cursor:pointer">
            <i class="bi bi-check2 me-1"></i>Salvar Produto
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Sidebar mobile

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// Tabs
function switchTab(tab) {
  document.getElementById('tabPacotes').style.display  = tab==='pacotes'  ? '' : 'none';
  document.getElementById('tabProdutos').style.display = tab==='produtos' ? '' : 'none';
  document.getElementById('tabBtnPacotes').classList.toggle('active',  tab==='pacotes');
  document.getElementById('tabBtnProdutos').classList.toggle('active', tab==='produtos');
  history.replaceState(null,'','#'+tab);
}
// Restaura tab via hash
if (location.hash === '#produtos') switchTab('produtos');

// Modal Pacote — novo
function abrirModalPacote() {
  document.getElementById('titleModalPacote').innerHTML =
    '<i class="bi bi-ticket-perforated-fill me-2" style="color:var(--primary)"></i>Novo Pacote';
  document.getElementById('pacoteId').value       = '';
  document.getElementById('pacoteNome').value     = '';
  document.getElementById('pacoteDesc').value     = '';
  document.getElementById('pacoteCreditos').value = '4';
  document.getElementById('pacotePreco').value    = '';
  document.getElementById('pacoteServico').value  = '';
  document.getElementById('pacoteValidade').value = '90';
  new bootstrap.Modal(document.getElementById('modalPacote')).show();
}

// Modal Pacote — editar
function editarPacote(p) {
  document.getElementById('titleModalPacote').innerHTML =
    '<i class="bi bi-pencil-fill me-2" style="color:var(--primary)"></i>Editar Pacote';
  document.getElementById('pacoteId').value       = p.id;
  document.getElementById('pacoteNome').value     = p.nome;
  document.getElementById('pacoteDesc').value     = p.descricao || '';
  document.getElementById('pacoteCreditos').value = p.creditos;
  document.getElementById('pacotePreco').value    = parseFloat(p.preco).toFixed(2).replace('.',',');
  document.getElementById('pacoteServico').value  = p.servico_id || '';
  document.getElementById('pacoteValidade').value = p.validade_dias || 0;
  new bootstrap.Modal(document.getElementById('modalPacote')).show();
}

// Modal Produto — novo
function abrirModalProduto() {
  document.getElementById('titleModalProduto').innerHTML =
    '<i class="bi bi-bag-fill me-2" style="color:#22c55e"></i>Novo Produto';
  document.getElementById('produtoId').value          = '';
  document.getElementById('produtoNome').value        = '';
  document.getElementById('produtoDesc').value        = '';
  document.getElementById('produtoPreco').value       = '';
  document.getElementById('produtoCategoria').value   = 'outros';
  document.getElementById('produtoEstoque').value     = '0';
  document.getElementById('produtoEstoqueMin').value  = '0';
  new bootstrap.Modal(document.getElementById('modalProduto')).show();
}

// Modal Produto — editar
function editarProduto(p) {
  document.getElementById('titleModalProduto').innerHTML =
    '<i class="bi bi-pencil-fill me-2" style="color:#22c55e"></i>Editar Produto';
  document.getElementById('produtoId').value          = p.id;
  document.getElementById('produtoNome').value        = p.nome;
  document.getElementById('produtoDesc').value        = p.descricao || '';
  document.getElementById('produtoPreco').value       = parseFloat(p.preco).toFixed(2).replace('.',',');
  document.getElementById('produtoCategoria').value   = p.categoria || 'outros';
  document.getElementById('produtoEstoque').value     = p.estoque || 0;
  document.getElementById('produtoEstoqueMin').value  = p.estoque_min || 0;
  new bootstrap.Modal(document.getElementById('modalProduto')).show();
}
</script>
</body>
</html>