<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');
$mesAtual      = date('Y-m');
$mesLabel      = strftime('%B de %Y') ?: date('m/Y');

// ── Criar tabela de metas ──
$db->exec("
    CREATE TABLE IF NOT EXISTS metas_barbeiros (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        barbeiro_id  INTEGER NOT NULL,
        mes          TEXT NOT NULL,
        meta_valor   REAL DEFAULT 0,
        meta_atend   INTEGER DEFAULT 0,
        bonus        REAL DEFAULT 0,
        UNIQUE(barbeiro_id, mes)
    )
");

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'salvar_metas') {
        $mes = $_POST['mes'] ?? $mesAtual;
        foreach (($_POST['meta_valor'] ?? []) as $barId => $val) {
            $barId    = (int)$barId;
            $metaVal  = (float)$val;
            $metaAt   = (int)($_POST['meta_atend'][$barId] ?? 0);
            $bonus    = (float)($_POST['bonus'][$barId] ?? 0);
            $db->prepare("
                INSERT INTO metas_barbeiros (barbeiro_id, mes, meta_valor, meta_atend, bonus)
                VALUES (?,?,?,?,?)
                ON CONFLICT(barbeiro_id, mes) DO UPDATE
                SET meta_valor=excluded.meta_valor, meta_atend=excluded.meta_atend, bonus=excluded.bonus
            ")->execute([$barId, $mes, $metaVal, $metaAt, $bonus]);
        }
        flash('success', 'Metas salvas!');
        header('Location: metas.php?mes=' . urlencode($mes)); exit;
    }
}

$mesFiltro = $_GET['mes'] ?? $mesAtual;
list($ano, $mes) = explode('-', $mesFiltro . '-01');

// ── Barbeiros com metas e realizado ──
$barbeiros = $db->prepare("
    SELECT b.id, b.nome, NULL,
           COALESCE(m.meta_valor,0)  AS meta_valor,
           COALESCE(m.meta_atend,0)  AS meta_atend,
           COALESCE(m.bonus,0)       AS bonus,
           COALESCE(SUM(f.valor + 0),0) AS realizado_valor,
           COUNT(CASE WHEN f.status='concluido' THEN 1 END)                AS realizado_atend
    FROM usuarios b
    LEFT JOIN metas_barbeiros m ON m.barbeiro_id = b.id AND m.mes = ?
    LEFT JOIN fila f ON f.barbeiro_id = b.id
        AND f.status = 'concluido'
        AND strftime('%Y-%m', f.finalizado_em) = ?
    WHERE b.ativo = 1 AND b.tipo = 'barbeiro'
    GROUP BY b.id
    ORDER BY b.nome ASC
");
$barbeiros->execute([$mesFiltro, $mesFiltro]);
$barbeiros = $barbeiros->fetchAll();

// ── Histórico meses anteriores ──
$historico = $db->query("
    SELECT m.mes, b.nome, NULL, m.meta_valor, m.meta_atend, m.bonus,
           COALESCE(SUM(f.valor + 0),0) AS realizado
    FROM metas_barbeiros m
    JOIN usuarios b ON b.id = m.barbeiro_id
    LEFT JOIN fila f ON f.barbeiro_id = m.barbeiro_id
        AND f.status = 'concluido'
        AND strftime('%Y-%m', f.finalizado_em) = m.mes
    GROUP BY m.id
    ORDER BY m.mes DESC, b.nome ASC
    LIMIT 30
")->fetchAll();

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
function pct(float $real, float $meta): float { return $meta > 0 ? min(100, round($real / $meta * 100)) : 0; }
function pctColor(float $p): string {
    if ($p >= 100) return '#4ade80';
    if ($p >= 70)  return '#f59e0b';
    return '#f87171';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Metas – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--primary:#e94560;--sidebar-w:260px}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
  background:linear-gradient(180deg,#1a1a2e,#16213e);
  border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto}
.sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
.sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
  border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
.nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
  margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.95rem;text-decoration:none}
.nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
.nav-link-side.active{border-left:3px solid var(--primary)}
.nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
.main-content{margin-left:var(--sidebar-w);min-height:100vh}
.topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
  padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
.page-body{padding:1.5rem}
.card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.1rem}
.card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
.meta-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem}
.progress-track{height:10px;background:rgba(255,255,255,.08);border-radius:10px;overflow:hidden;margin:.5rem 0}
.progress-fill{height:100%;border-radius:10px;transition:width .6s cubic-bezier(.4,0,.2,1)}
.form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
  color:#fff;border-radius:10px;padding:.55rem .85rem;width:100%;font-size:.88rem}
.form-control-dark:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
.form-control-dark::placeholder{color:rgba(255,255,255,.3)}
.btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;
  border-radius:10px;padding:.7rem 1.4rem;font-weight:700;cursor:pointer;transition:all .3s;font-size:.9rem}
.btn-primary-custom:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(233,69,96,.4)}
h4,h5,h6{color:#fff;margin:0}
@media(max-width:768px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.page-body{padding:1rem}}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div style="display:flex;align-items:center;gap:.75rem">
      <button id="btnMenuMobile" style="background:none;border:none;color:#fff;font-size:1.3rem;cursor:pointer" class="d-md-none">
        <i class="bi bi-list"></i>
      </button>
      <div>
        <div style="font-weight:700;color:#fff;font-size:1.05rem"><i class="bi bi-bullseye me-2" style="color:var(--primary)"></i>Metas dos Barbeiros</div>
        <div style="font-size:.78rem;color:rgba(255,255,255,.4)">Defina e acompanhe as metas mensais</div>
      </div>
    </div>
    <!-- Seletor de mês -->
    <form method="GET" style="display:flex;gap:.5rem;align-items:center">
      <input type="month" name="mes" value="<?= htmlspecialchars($mesFiltro) ?>"
             style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
                    color:#fff;border-radius:10px;padding:.45rem .85rem;font-size:.88rem;cursor:pointer">
      <button type="submit" class="btn-primary-custom" style="padding:.45rem 1rem">Ver</button>
    </form>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- Cards de progresso -->
    <div class="row g-3 mb-3">
      <?php foreach ($barbeiros as $b):
        $pVal  = pct($b['realizado_valor'], $b['meta_valor']);
        $pAt   = pct($b['realizado_atend'], $b['meta_atend']);
        $cor   = htmlspecialchars(($b['cor'] ?? '#e94560') ?? '#e94560');
        $atingiu = $pVal >= 100;
      ?>
      <div class="col-12 col-md-6 col-xl-4">
        <div class="meta-card" style="border-color:<?= $cor ?>33">
          <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:1rem">
            <div style="width:44px;height:44px;border-radius:50%;background:<?= $cor ?>22;color:<?= $cor ?>;
                        display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.1rem;flex-shrink:0">
              <?= mb_strtoupper(mb_substr($b['nome'],0,1)) ?>
            </div>
            <div style="flex:1">
              <div style="font-weight:700;color:#fff"><?= htmlspecialchars($b['nome']) ?></div>
              <?php if ($atingiu): ?>
              <span style="background:rgba(34,197,94,.15);color:#4ade80;border-radius:20px;padding:.1rem .55rem;font-size:.68rem;font-weight:700">
                🎯 META ATINGIDA!
              </span>
              <?php else: ?>
              <span style="font-size:.75rem;color:rgba(255,255,255,.4)"><?= $pVal ?>% da meta</span>
              <?php endif; ?>
            </div>
            <?php if ($b['bonus'] > 0 && $atingiu): ?>
            <div style="text-align:right">
              <div style="font-size:.68rem;color:rgba(255,255,255,.4)">Bônus</div>
              <div style="font-weight:800;color:#fbbf24">R$ <?= number_format($b['bonus'],2,',','.') ?></div>
            </div>
            <?php endif; ?>
          </div>

          <!-- Faturamento -->
          <div style="margin-bottom:.85rem">
            <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:.2rem">
              <span style="color:rgba(255,255,255,.5)"><i class="bi bi-currency-dollar me-1"></i>Faturamento</span>
              <span style="font-weight:700;color:<?= pctColor($pVal) ?>">R$ <?= number_format($b['realizado_valor'],2,',','.') ?> / R$ <?= number_format($b['meta_valor'],2,',','.') ?></span>
            </div>
            <div class="progress-track">
              <div class="progress-fill" style="width:<?= $pVal ?>%;background:<?= pctColor($pVal) ?>"></div>
            </div>
          </div>

          <!-- Atendimentos -->
          <?php if ($b['meta_atend'] > 0): ?>
          <div>
            <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:.2rem">
              <span style="color:rgba(255,255,255,.5)"><i class="bi bi-scissors me-1"></i>Atendimentos</span>
              <span style="font-weight:700;color:<?= pctColor($pAt) ?>"><?= $b['realizado_atend'] ?> / <?= $b['meta_atend'] ?></span>
            </div>
            <div class="progress-track">
              <div class="progress-fill" style="width:<?= $pAt ?>%;background:<?= pctColor($pAt) ?>"></div>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="row g-3">
      <!-- Formulário de metas -->
      <div class="col-12 col-lg-7">
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-pencil-square" style="color:#f59e0b"></i>
            Definir Metas — <?= date('m/Y', strtotime($mesFiltro . '-01')) ?>
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_metas">
            <input type="hidden" name="mes" value="<?= htmlspecialchars($mesFiltro) ?>">
            <div style="overflow-x:auto">
            <table style="width:100%;border-collapse:collapse">
              <thead>
                <tr style="font-size:.75rem;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.5px">
                  <th style="padding:.5rem .75rem;text-align:left">Barbeiro</th>
                  <th style="padding:.5rem .75rem;text-align:center">Meta R$</th>
                  <th style="padding:.5rem .75rem;text-align:center">Meta Atend.</th>
                  <th style="padding:.5rem .75rem;text-align:center">Bônus R$</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($barbeiros as $b): $cor = htmlspecialchars(($b['cor'] ?? '#e94560') ?? '#e94560'); ?>
              <tr style="border-top:1px solid rgba(255,255,255,.06)">
                <td style="padding:.6rem .75rem">
                  <div style="display:flex;align-items:center;gap:.5rem">
                    <div style="width:28px;height:28px;border-radius:50%;background:<?= $cor ?>22;color:<?= $cor ?>;
                                display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.75rem;flex-shrink:0">
                      <?= mb_strtoupper(mb_substr($b['nome'],0,1)) ?>
                    </div>
                    <span style="font-size:.88rem;font-weight:600;color:#fff"><?= htmlspecialchars($b['nome']) ?></span>
                  </div>
                </td>
                <td style="padding:.6rem .75rem">
                  <input type="number" step="0.01" min="0" name="meta_valor[<?= $b['id'] ?>]"
                         value="<?= number_format($b['meta_valor'],2,'.','')?>"
                         class="form-control-dark" style="text-align:center;min-width:90px" placeholder="0,00">
                </td>
                <td style="padding:.6rem .75rem">
                  <input type="number" min="0" name="meta_atend[<?= $b['id'] ?>]"
                         value="<?= $b['meta_atend'] ?>"
                         class="form-control-dark" style="text-align:center;min-width:70px" placeholder="0">
                </td>
                <td style="padding:.6rem .75rem">
                  <input type="number" step="0.01" min="0" name="bonus[<?= $b['id'] ?>]"
                         value="<?= number_format($b['bonus'],2,'.','')?>"
                         class="form-control-dark" style="text-align:center;min-width:90px" placeholder="0,00">
                </td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
            </div>
            <div style="margin-top:1rem">
              <button type="submit" class="btn-primary-custom">
                <i class="bi bi-check2 me-1"></i>Salvar Metas
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Histórico -->
      <div class="col-12 col-lg-5">
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-clock-history" style="color:#8b5cf6"></i>
            Histórico de Metas
          </div>
          <?php
          $mesAnterior = '';
          foreach ($historico as $h):
            if ($h['mes'] !== $mesAnterior) {
                if ($mesAnterior) echo '</div>';
                $mesAnterior = $h['mes'];
                echo '<div style="font-size:.72rem;font-weight:700;color:rgba(255,255,255,.35);text-transform:uppercase;letter-spacing:.5px;padding:.5rem 0 .3rem">'
                     . date('M/Y', strtotime($h['mes'] . '-01')) . '</div>';
                echo '<div>';
            }
            $p   = pct($h['realizado'], $h['meta_valor']);
            $cor = htmlspecialchars($h['cor'] ?? '#e94560');
          ?>
          <div style="display:flex;align-items:center;gap:.6rem;padding:.4rem 0;border-bottom:1px solid rgba(255,255,255,.04)">
            <div style="width:28px;height:28px;border-radius:50%;background:<?= $cor ?>22;color:<?= $cor ?>;
                        display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.72rem;flex-shrink:0">
              <?= mb_strtoupper(mb_substr($h['nome'],0,1)) ?>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:.82rem;font-weight:600;color:#fff"><?= htmlspecialchars($h['nome']) ?></div>
              <div style="height:4px;background:rgba(255,255,255,.08);border-radius:10px;margin-top:.25rem;overflow:hidden">
                <div style="height:100%;width:<?= $p ?>%;background:<?= pctColor($p) ?>;border-radius:10px"></div>
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div style="font-size:.78rem;font-weight:700;color:<?= pctColor($p) ?>"><?= $p ?>%</div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.3)">R$ <?= number_format($h['realizado'],0,',','.') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php if ($mesAnterior) echo '</div>'; ?>
          <?php if (empty($historico)): ?>
          <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25);font-size:.88rem">
            <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
            Nenhuma meta cadastrada ainda
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});
</script>
</body>
</html>
