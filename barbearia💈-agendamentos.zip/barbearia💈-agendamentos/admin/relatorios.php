<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

$periodo = $_GET['periodo'] ?? 'mes';
$barb_id = (int)($_GET['barbeiro'] ?? 0);

$hoje = date('Y-m-d');
switch($periodo) {
    case 'hoje':        $dataInicio = $hoje; break;
    case 'semana':      $dataInicio = date('Y-m-d', strtotime('-7 days')); break;
    case 'mes':         $dataInicio = date('Y-m-01'); break;
    case 'ano':         $dataInicio = date('Y-01-01'); break;
    case 'personalizado':
        $dataInicio = $_GET['data_inicio'] ?? date('Y-m-01');
        $dataFim    = $_GET['data_fim']    ?? $hoje;
        break;
    default: $dataInicio = date('Y-m-01');
}
$dataFim = $dataFim ?? $hoje;

$sql = "SELECT f.*, c.nome as cliente_nome, c.telefone,
               u.nome as barbeiro_nome, u.comissao_percent, u.foto as barbeiro_foto,
               s.nome as servico_nome
        FROM fila f
        JOIN clientes c ON c.id=f.cliente_id
        JOIN usuarios u ON u.id=f.barbeiro_id
        LEFT JOIN servicos s ON s.id=f.servico_id
        WHERE f.status='concluido'
          AND DATE(f.finalizado_em) >= ?
          AND DATE(f.finalizado_em) <= ?";
$params = [$dataInicio, $dataFim];
if ($barb_id) { $sql .= ' AND f.barbeiro_id=?'; $params[] = $barb_id; }
$sql .= ' ORDER BY f.finalizado_em DESC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$atendimentos = $stmt->fetchAll();

$totalFat    = array_sum(array_column($atendimentos, 'valor'));
$totalCortes = count($atendimentos);

$totalComissao = 0;
foreach ($atendimentos as $atend) {
    $totalComissao += ($atend['valor'] ?? 0) * ($atend['comissao_percent'] / 100);
}
$totalLucro = $totalFat - $totalComissao;

$barbeiros = $db->query("SELECT * FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();

// Agrupado por barbeiro
$porBarbeiro = [];
foreach($atendimentos as $a) {
    $bn = $a['barbeiro_nome'];
    if (!isset($porBarbeiro[$bn])) {
        $porBarbeiro[$bn] = [
            'cortes'      => 0,
            'faturamento' => 0,
            'comissao'    => 0,
            'foto'        => $a['barbeiro_foto'] ?? null,
            'comissao_pct'=> $a['comissao_percent'],
            'servicos'    => [],
            'pagamentos'  => [],
            'por_dia'     => [],
        ];
    }
    $porBarbeiro[$bn]['cortes']++;
    $porBarbeiro[$bn]['faturamento'] += $a['valor'] ?? 0;
    $porBarbeiro[$bn]['comissao']    += ($a['valor'] ?? 0) * ($a['comissao_percent'] / 100);
    $sn = $a['servico_nome'] ?? 'Sem serviço';
    $porBarbeiro[$bn]['servicos'][$sn] = ($porBarbeiro[$bn]['servicos'][$sn] ?? 0) + 1;
    $fp = $a['forma_pagamento'] ?? 'outro';
    $porBarbeiro[$bn]['pagamentos'][$fp] = ($porBarbeiro[$bn]['pagamentos'][$fp] ?? 0) + ($a['valor'] ?? 0);
}
uasort($porBarbeiro, function($a, $b) {
    return $b['faturamento'] <=> $a['faturamento'];
});

$porPagamento = [];
foreach($atendimentos as $a) {
    $fp = $a['forma_pagamento'] ?? 'outro';
    $porPagamento[$fp] = ($porPagamento[$fp] ?? 0) + ($a['valor'] ?? 0);
}
arsort($porPagamento);

$porServico = [];
foreach($atendimentos as $a) {
    $sn = $a['servico_nome'] ?? 'Sem serviço';
    if (!isset($porServico[$sn])) $porServico[$sn] = ['qtd'=>0,'fat'=>0];
    $porServico[$sn]['qtd']++;
    $porServico[$sn]['fat'] += $a['valor'] ?? 0;
}
uasort($porServico, function($a, $b) {
    return $b['qtd'] <=> $a['qtd'];
});

$porDia = [];
foreach($atendimentos as $a) {
    if (!$a['finalizado_em']) continue;
    $dia = date('d/m', strtotime($a['finalizado_em']));
    if (!isset($porDia[$dia])) $porDia[$dia] = ['fat'=>0,'cortes'=>0];
    $porDia[$dia]['fat']    += $a['valor'] ?? 0;
    $porDia[$dia]['cortes'] += 1;
}
$porDia = array_reverse($porDia);

$porHora = [];
foreach($atendimentos as $a) {
    if (!$a['finalizado_em']) continue;
    $hora = (int)date('H', strtotime($a['finalizado_em']));
    $porHora[$hora] = ($porHora[$hora] ?? 0) + 1;
}
ksort($porHora);
$horaMax = $porHora ? max($porHora) : 1;

$pgIcons = [
    'pix'     => 'bi-qr-code',
    'dinheiro'=> 'bi-cash',
    'debito'  => 'bi-credit-card',
    'credito' => 'bi-credit-card-2-front',
];
$pgCores = [
    'pix'     => '#22c55e',
    'dinheiro'=> '#4ade80',
    'debito'  => '#60a5fa',
    'credito' => '#a78bfa',
    'outro'   => '#94a3b8',
];

$nomeBarbearia = getConfig('nome_barbearia');

// ── EXPORTAR CSV — DEVE FICAR AQUI, ANTES DO HTML ──
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="relatorio_' . date('Y-m-d') . '.csv"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Data','Hora','Cliente','Barbeiro','Serviço','Pagamento','Valor','Comissão','Lucro'], ';');
    foreach ($atendimentos as $a) {
        $com = ($a['valor'] ?? 0) * ($a['comissao_percent'] / 100);
        fputcsv($out, [
            $a['finalizado_em'] ? date('d/m/Y', strtotime($a['finalizado_em'])) : '',
            $a['finalizado_em'] ? date('H:i',   strtotime($a['finalizado_em'])) : '',
            $a['cliente_nome'],
            $a['barbeiro_nome'],
            $a['servico_nome'] ?? '',
            $a['forma_pagamento'] ?? '',
            number_format($a['valor'] ?? 0, 2, ',', '.'),
            number_format($com, 2, ',', '.'),
            number_format(($a['valor'] ?? 0) - $com, 2, ',', '.'),
        ], ';');
    }
    fclose($out);
    exit;
}

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Relatórios – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  .sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:.25s;display:flex;align-items:center;gap:.75rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  .main-content{margin-left:260px;padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  .btn-periodo{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);
    color:rgba(255,255,255,.7);border-radius:8px;padding:.4rem .9rem;font-size:.85rem;
    transition:.2s;text-decoration:none;cursor:pointer;white-space:nowrap}
  .btn-periodo.active,.btn-periodo:hover{background:var(--primary);border-color:var(--primary);color:#fff}
  .sel-barb{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:10px;padding:.45rem .85rem;font-size:.875rem;cursor:pointer}
  .sel-barb option{background:#1a1a2e;color:#fff}
  .sel-barb:focus{outline:none;border-color:var(--primary)}
  .input-date{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:10px;padding:.45rem .85rem;font-size:.875rem}
  .input-date:focus{outline:none;border-color:var(--primary);background:rgba(255,255,255,.12)}

  .kpi-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
    border-radius:14px;padding:1.1rem 1.25rem;display:flex;align-items:center;gap:1rem}
  .kpi-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;
    justify-content:center;font-size:1.2rem;flex-shrink:0}
  .kpi-val{font-size:1.3rem;font-weight:800;color:#fff;line-height:1.1}
  .kpi-lbl{font-size:.75rem;color:rgba(255,255,255,.45);margin-top:.2rem}

  .section-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);
    border-radius:16px;padding:1.25rem;margin-bottom:1.25rem}
  .section-title{font-size:.95rem;font-weight:700;color:#fff;
    margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}

  .barb-rel-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);
    border-radius:14px;padding:1.1rem;margin-bottom:.75rem;transition:.2s;cursor:pointer}
  .barb-rel-card:last-child{margin-bottom:0}
  .barb-rel-card:hover{background:rgba(255,255,255,.08)}
  .barb-rel-avatar{width:46px;height:46px;border-radius:50%;object-fit:cover;
    border:2px solid rgba(233,69,96,.4);flex-shrink:0}
  .barb-rel-avatar-ph{width:46px;height:46px;border-radius:50%;
    background:linear-gradient(135deg,#e94560,#c41230);
    display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .barb-rel-nome{font-weight:700;color:#fff;font-size:.95rem;margin-bottom:.1rem}
  .barb-detail{display:none;margin-top:.85rem;padding-top:.85rem;
    border-top:1px solid rgba(255,255,255,.08)}
  .barb-detail.open{display:block}

  .prog-bar-wrap{background:rgba(255,255,255,.08);border-radius:99px;height:8px;overflow:hidden;flex:1}
  .prog-bar-fill{height:100%;border-radius:99px;transition:.6s ease}

  .hora-bar{display:flex;align-items:center;gap:.6rem;margin-bottom:.4rem}
  .hora-lbl{font-size:.75rem;color:rgba(255,255,255,.5);width:34px;flex-shrink:0;text-align:right}
  .hora-count{font-size:.72rem;color:rgba(255,255,255,.4);width:22px;text-align:right;flex-shrink:0}

  .hist-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
    border-radius:12px;padding:.85rem 1rem;margin-bottom:.5rem;transition:.2s}
  .hist-item:last-child{margin-bottom:0}
  .hist-item:hover{background:rgba(255,255,255,.07)}
  .hist-data{font-size:.78rem;color:rgba(255,255,255,.4);flex-shrink:0;min-width:70px}
  .hist-cliente{font-weight:600;color:#fff;font-size:.9rem}
  .hist-barbeiro{font-size:.78rem;color:rgba(255,255,255,.45)}
  .hist-servico{font-size:.75rem;background:rgba(59,130,246,.15);color:#60a5fa;border-radius:6px;padding:.15rem .5rem}
  .hist-pgto{font-size:.78rem;color:rgba(255,255,255,.5)}
  .hist-valor{font-weight:800;color:#4ade80;font-size:.95rem;flex-shrink:0}
  .hist-comissao{font-weight:700;color:#fbbf24;font-size:.82rem;flex-shrink:0}
  .hist-lucro{font-weight:700;color:#60a5fa;font-size:.78rem;flex-shrink:0}

  .vazio{text-align:center;padding:2.5rem 0;color:rgba(255,255,255,.3)}

  .btn-comp{background:rgba(255,255,255,.07);color:rgba(255,255,255,.5);
    border:none;border-radius:7px;padding:.3rem .55rem;font-size:.75rem;
    text-decoration:none;transition:.2s;display:inline-flex;align-items:center;gap:.3rem}
  .btn-comp:hover{background:rgba(233,69,96,.2);color:#e94560}

  .rank-badge{width:22px;height:22px;border-radius:50%;display:inline-flex;
    align-items:center;justify-content:center;font-size:.7rem;font-weight:800;flex-shrink:0}

  .pg-pill{display:inline-flex;align-items:center;gap:.4rem;background:rgba(255,255,255,.06);
    border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:.35rem .7rem;font-size:.8rem}

  .btn-export{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:rgba(255,255,255,.7);border-radius:8px;padding:.4rem .85rem;font-size:.83rem;
    cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.4rem;text-decoration:none}
  .btn-export:hover{background:rgba(34,197,94,.2);border-color:rgba(34,197,94,.4);color:#4ade80}

  h4,h5,h6{color:#fff;margin:0}

  @media print{
    .sidebar,.topbar,.btn-periodo,.sel-barb,.btn-export,
    .btn-comp,#btnMenu{display:none!important}
    .main-content{margin-left:0!important}
    body{background:#fff!important;color:#000!important}
  }
  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <h5 class="fw-bold" style="font-size:1rem">
        <i class="bi bi-graph-up me-2" style="color:#e94560"></i>Relatórios
      </h5>
    </div>
    <div class="d-flex gap-2">
      <a href="#" class="btn-export" onclick="window.print();return false">
        <i class="bi bi-printer"></i>Imprimir
      </a>
      <a href="?<?= http_build_query(array_merge($_GET,['export'=>'csv'])) ?>" class="btn-export">
        <i class="bi bi-download"></i>CSV
      </a>
    </div>
  </div>

  <div class="page-body">

    <!-- ── Filtros ── -->
    <div class="d-flex align-items-center gap-2 flex-wrap mb-4">
      <div class="d-flex gap-1 flex-wrap">
        <?php foreach(['hoje'=>'Hoje','semana'=>'7 dias','mes'=>'Mês','ano'=>'Ano','personalizado'=>'Período'] as $v=>$l): ?>
        <a href="?periodo=<?= $v ?>&barbeiro=<?= $barb_id ?>"
           class="btn-periodo <?= $periodo===$v ? 'active' : '' ?>">
          <?= $l ?>
        </a>
        <?php endforeach; ?>
      </div>
      <form method="GET" class="d-flex align-items-center gap-2 flex-wrap">
        <input type="hidden" name="periodo" value="<?= $periodo ?>">
        <?php if($periodo==='personalizado'): ?>
          <input type="date" name="data_inicio" class="input-date"
            value="<?= htmlspecialchars($dataInicio) ?>">
          <span style="color:rgba(255,255,255,.4);font-size:.85rem">até</span>
          <input type="date" name="data_fim" class="input-date"
            value="<?= htmlspecialchars($dataFim) ?>">
          <button type="submit" class="btn-periodo active">
            <i class="bi bi-search me-1"></i>Filtrar
          </button>
        <?php endif; ?>
        <select name="barbeiro" class="sel-barb" onchange="this.form.submit()">
          <option value="0">Todos os barbeiros</option>
          <?php foreach($barbeiros as $b): ?>
          <option value="<?= $b['id'] ?>" <?= $barb_id==$b['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($b['nome']) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>

    <!-- ── KPIs ── -->
    <div class="row g-2 mb-4">
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(233,69,96,.15)">
            <i class="bi bi-scissors" style="color:#e94560"></i>
          </div>
          <div>
            <div class="kpi-val"><?= $totalCortes ?></div>
            <div class="kpi-lbl">Total de Cortes</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(34,197,94,.15)">
            <i class="bi bi-cash-stack" style="color:#4ade80"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#4ade80;font-size:1.1rem"><?= formatMoney($totalFat) ?></div>
            <div class="kpi-lbl">Faturamento</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(245,158,11,.15)">
            <i class="bi bi-percent" style="color:#fbbf24"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#fbbf24;font-size:1.1rem"><?= formatMoney($totalComissao) ?></div>
            <div class="kpi-lbl">Total Comissões</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(59,130,246,.15)">
            <i class="bi bi-graph-up-arrow" style="color:#60a5fa"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#60a5fa;font-size:1.1rem"><?= formatMoney($totalLucro) ?></div>
            <div class="kpi-lbl">Lucro Líquido</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(168,85,247,.15)">
            <i class="bi bi-receipt" style="color:#a78bfa"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#a78bfa;font-size:1.1rem">
              <?= $totalCortes > 0 ? formatMoney($totalFat/$totalCortes) : 'R$ 0,00' ?>
            </div>
            <div class="kpi-lbl">Ticket Médio</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(20,184,166,.15)">
            <i class="bi bi-people-fill" style="color:#2dd4bf"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#2dd4bf"><?= count($porBarbeiro) ?></div>
            <div class="kpi-lbl">Barbeiros Ativos</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(251,146,60,.15)">
            <i class="bi bi-calendar-check" style="color:#fb923c"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#fb923c">
              <?= count($porDia) > 0 ? round($totalCortes / count($porDia), 1) : 0 ?>
            </div>
            <div class="kpi-lbl">Média Cortes/Dia</div>
          </div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="kpi-card">
          <div class="kpi-icon" style="background:rgba(236,72,153,.15)">
            <i class="bi bi-arrow-up-right-circle" style="color:#f472b6"></i>
          </div>
          <div>
            <div class="kpi-val" style="color:#f472b6;font-size:1.1rem">
              <?= $totalFat > 0 ? number_format(($totalLucro/$totalFat)*100,1) : 0 ?>%
            </div>
            <div class="kpi-lbl">Margem de Lucro</div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Grid: Pagamentos + Serviços + Pico ── -->
    <div class="row g-3 mb-3">
      <div class="col-12 col-md-4">
        <div class="section-card h-100 mb-0">
          <div class="section-title">
            <i class="bi bi-wallet2" style="color:#22c55e"></i>Formas de Pagamento
          </div>
          <?php if(empty($porPagamento)): ?>
            <div class="vazio" style="padding:1.5rem 0"><i class="bi bi-inbox"></i></div>
          <?php else: ?>
            <?php $totalPg = array_sum($porPagamento); ?>
            <?php foreach($porPagamento as $fp => $val):
              $pct  = $totalPg > 0 ? round($val/$totalPg*100) : 0;
              $cor  = $pgCores[$fp] ?? '#94a3b8';
              $icon = $pgIcons[$fp]  ?? 'bi-dash';
            ?>
            <div class="mb-3">
              <div class="d-flex justify-content-between align-items-center mb-1">
                <span style="font-size:.83rem;color:#fff">
                  <i class="bi <?= $icon ?> me-1" style="color:<?= $cor ?>"></i><?= ucfirst($fp) ?>
                </span>
                <span style="font-size:.82rem;color:<?= $cor ?>;font-weight:700">
                  <?= formatMoney($val) ?> <span style="color:rgba(255,255,255,.35);font-size:.75rem"><?= $pct ?>%</span>
                </span>
              </div>
              <div class="prog-bar-wrap">
                <div class="prog-bar-fill" style="width:<?= $pct ?>%;background:<?= $cor ?>"></div>
              </div>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <div class="col-12 col-md-4">
        <div class="section-card h-100 mb-0">
          <div class="section-title">
            <i class="bi bi-scissors" style="color:#e94560"></i>Serviços Mais Realizados
          </div>
          <?php if(empty($porServico)): ?>
            <div class="vazio" style="padding:1.5rem 0"><i class="bi bi-inbox"></i></div>
          <?php else: ?>
            <?php $maxSv = max(array_column($porServico,'qtd')); $rankSv=1; ?>
            <?php foreach($porServico as $sn => $sd):
              $pct = $maxSv > 0 ? round($sd['qtd']/$maxSv*100) : 0;
            ?>
            <div class="mb-3">
              <div class="d-flex justify-content-between align-items-center mb-1">
                <span style="font-size:.83rem;color:#fff">
                  <span class="rank-badge me-1"
                    style="background:<?= $rankSv===1?'rgba(250,204,21,.2)':($rankSv===2?'rgba(156,163,175,.2)':'rgba(180,83,9,.2)') ?>;
                    color:<?= $rankSv===1?'#facc15':($rankSv===2?'#9ca3af':'#b45309') ?>">
                    <?= $rankSv ?>
                  </span>
                  <?= htmlspecialchars($sn) ?>
                </span>
                <span style="font-size:.82rem;color:#e94560;font-weight:700">
                  <?= $sd['qtd'] ?>x
                  <span style="color:rgba(255,255,255,.35);font-weight:400;font-size:.75rem"><?= formatMoney($sd['fat']) ?></span>
                </span>
              </div>
              <div class="prog-bar-wrap">
                <div class="prog-bar-fill" style="width:<?= $pct ?>%;background:linear-gradient(90deg,#e94560,#c41230)"></div>
              </div>
            </div>
            <?php $rankSv++; if($rankSv>5) break; endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <div class="col-12 col-md-4">
        <div class="section-card h-100 mb-0">
          <div class="section-title">
            <i class="bi bi-clock-history" style="color:#fb923c"></i>Horários de Pico
          </div>
          <?php if(empty($porHora)): ?>
            <div class="vazio" style="padding:1.5rem 0"><i class="bi bi-inbox"></i></div>
          <?php else: ?>
            <?php foreach($porHora as $h => $cnt):
              $pct = round($cnt/$horaMax*100);
              $cor = $pct>=80?'#e94560':($pct>=50?'#fb923c':'#60a5fa');
            ?>
            <div class="hora-bar">
              <div class="hora-lbl"><?= str_pad($h,2,'0',STR_PAD_LEFT) ?>h</div>
              <div class="prog-bar-wrap">
                <div class="prog-bar-fill" style="width:<?= $pct ?>%;background:<?= $cor ?>"></div>
              </div>
              <div class="hora-count"><?= $cnt ?></div>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- ── Por Barbeiro ── -->
    <?php if(!$barb_id && !empty($porBarbeiro)): ?>
    <div class="section-card">
      <div class="section-title">
        <i class="bi bi-people-fill" style="color:#3b82f6"></i>Desempenho por Barbeiro
        <span style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.45);
          border-radius:20px;padding:.1rem .55rem;font-size:.72rem">clique para expandir</span>
      </div>
      <?php $rankB=1; foreach($porBarbeiro as $nome => $d):
        $lucroB  = $d['faturamento'] - $d['comissao'];
        $ticketB = $d['cortes'] > 0 ? $d['faturamento']/$d['cortes'] : 0;
        $temFoto = ($d['foto'] ?? null) && file_exists(__DIR__.'/../uploads/barbeiros/'.$d['foto']);
        $fotoUrl = $temFoto ? BASE_URL . '/uploads/barbeiros/'.htmlspecialchars($d['foto']) : null;
        arsort($d['servicos']);
        $topSv = array_key_first($d['servicos']) ?? '–';
        arsort($d['pagamentos']);
        $topPg = array_key_first($d['pagamentos']) ?? '–';
        $partFat = $totalFat > 0 ? round($d['faturamento']/$totalFat*100) : 0;
      ?>
      <div class="barb-rel-card" onclick="toggleDetail('bd<?= $rankB ?>')">
        <div class="d-flex align-items-center gap-3 w-100">
          <span class="rank-badge"
            style="background:<?= $rankB===1?'rgba(250,204,21,.2)':($rankB===2?'rgba(156,163,175,.2)':'rgba(255,255,255,.07)') ?>;
            color:<?= $rankB===1?'#facc15':($rankB===2?'#9ca3af':'rgba(255,255,255,.4)') ?>">
            <?= $rankB ?>
          </span>
          <?php if($fotoUrl): ?>
            <img src="<?= $fotoUrl ?>" alt="" class="barb-rel-avatar">
          <?php else: ?>
            <div class="barb-rel-avatar-ph"><i class="bi bi-person-fill text-white" style="font-size:.9rem"></i></div>
          <?php endif; ?>
          <div class="flex-grow-1">
            <div class="barb-rel-nome"><?= htmlspecialchars($nome) ?></div>
            <div class="d-flex align-items-center gap-2 mt-1">
              <div class="prog-bar-wrap" style="max-width:120px">
                <div class="prog-bar-fill" style="width:<?= $partFat ?>%;background:linear-gradient(90deg,#e94560,#c41230)"></div>
              </div>
              <span style="font-size:.72rem;color:rgba(255,255,255,.4)"><?= $partFat ?>% do fat.</span>
            </div>
          </div>
          <div class="d-flex gap-3 align-items-center flex-wrap">
            <div style="text-align:center">
              <div style="font-size:.95rem;font-weight:800;color:#e94560"><?= $d['cortes'] ?></div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.4)">Cortes</div>
            </div>
            <div style="text-align:center">
              <div style="font-size:.9rem;font-weight:800;color:#4ade80"><?= formatMoney($d['faturamento']) ?></div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.4)">Fat.</div>
            </div>
            <div style="text-align:center">
              <div style="font-size:.9rem;font-weight:800;color:#fbbf24"><?= formatMoney($d['comissao']) ?></div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.4)">Comissão</div>
            </div>
            <div style="text-align:center">
              <div style="font-size:.9rem;font-weight:800;color:#60a5fa"><?= formatMoney($lucroB) ?></div>
              <div style="font-size:.68rem;color:rgba(255,255,255,.4)">Lucro</div>
            </div>
          </div>
          <i class="bi bi-chevron-down" style="color:rgba(255,255,255,.3);font-size:.8rem;flex-shrink:0"></i>
        </div>
        <div class="barb-detail" id="bd<?= $rankB ?>">
          <div class="row g-2">
            <div class="col-6 col-md-3">
              <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:.7rem;text-align:center">
                <div style="font-size:.95rem;font-weight:800;color:#a78bfa"><?= formatMoney($ticketB) ?></div>
                <div style="font-size:.7rem;color:rgba(255,255,255,.4)">Ticket Médio</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:.7rem;text-align:center">
                <div style="font-size:.95rem;font-weight:800;color:#2dd4bf"><?= $d['comissao_pct'] ?>%</div>
                <div style="font-size:.7rem;color:rgba(255,255,255,.4)">Taxa Comissão</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:.7rem;text-align:center">
                <div style="font-size:.85rem;font-weight:700;color:#fb923c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                  <?= htmlspecialchars($topSv) ?>
                </div>
                <div style="font-size:.7rem;color:rgba(255,255,255,.4)">Serviço Top</div>
              </div>
            </div>
            <div class="col-6 col-md-3">
              <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:.7rem;text-align:center">
                <div style="font-size:.85rem;font-weight:700;color:#22c55e">
                  <i class="bi <?= $pgIcons[$topPg] ?? 'bi-dash' ?> me-1"></i><?= ucfirst($topPg) ?>
                </div>
                <div style="font-size:.7rem;color:rgba(255,255,255,.4)">Pgto Preferido</div>
              </div>
            </div>
          </div>
          <?php if(!empty($d['servicos'])): ?>
          <div class="mt-3">
            <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.5rem;font-weight:600">SERVIÇOS REALIZADOS</div>
            <div class="d-flex gap-2 flex-wrap">
              <?php foreach($d['servicos'] as $sv => $cnt): ?>
              <span class="hist-servico"><?= htmlspecialchars($sv) ?> <strong style="color:#fff"><?= $cnt ?>x</strong></span>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>
          <?php if(!empty($d['pagamentos'])): ?>
          <div class="mt-3">
            <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.5rem;font-weight:600">RECEITA POR FORMA DE PAGAMENTO</div>
            <div class="d-flex gap-2 flex-wrap">
              <?php foreach($d['pagamentos'] as $fp => $val):
                $cor  = $pgCores[$fp] ?? '#94a3b8';
                $icon = $pgIcons[$fp]  ?? 'bi-dash';
              ?>
              <span class="pg-pill" style="border-color:<?= $cor ?>33;color:<?= $cor ?>">
                <i class="bi <?= $icon ?>"></i><?= ucfirst($fp) ?>: <?= formatMoney($val) ?>
              </span>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <?php $rankB++; endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- ── Histórico Detalhado ── -->
    <div class="section-card">
      <div class="section-title">
        <i class="bi bi-clock-history" style="color:#e94560"></i>
        Histórico Detalhado
        <span style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.5);
          border-radius:20px;padding:.1rem .55rem;font-size:.75rem">
          <?= $totalCortes ?> registros
        </span>
      </div>
      <?php if(empty($atendimentos)): ?>
        <div class="vazio">
          <i class="bi bi-inbox" style="font-size:2.5rem;display:block;margin-bottom:.6rem"></i>
          Nenhum atendimento no período selecionado
        </div>
      <?php else: ?>
        <?php foreach($atendimentos as $a):
          $comissao = ($a['valor'] ?? 0) * ($a['comissao_percent'] / 100);
          $lucro    = ($a['valor'] ?? 0) - $comissao;
          $icon     = $pgIcons[$a['forma_pagamento'] ?? ''] ?? 'bi-dash';
          $keyComp  = substr(md5($a['id'] . 'barbearia_renato'), 0, 8);
        ?>
        <div class="hist-item">
          <div class="d-flex align-items-start gap-2 flex-wrap">
            <div class="hist-data">
              <?php if($a['finalizado_em']): ?>
                <div style="font-weight:600;color:rgba(255,255,255,.6)"><?= date('d/m/y',strtotime($a['finalizado_em'])) ?></div>
                <div style="font-size:.72rem;color:rgba(255,255,255,.35)"><?= date('H:i',strtotime($a['finalizado_em'])) ?></div>
              <?php else: ?>–<?php endif; ?>
            </div>
            <div class="flex-grow-1 min-width-0">
              <div class="hist-cliente"><?= htmlspecialchars($a['cliente_nome']) ?></div>
              <div class="d-flex align-items-center gap-1 flex-wrap mt-1">
                <span class="hist-barbeiro"><i class="bi bi-person-fill me-1"></i><?= htmlspecialchars($a['barbeiro_nome']) ?></span>
                <?php if($a['servico_nome']): ?>
                  <span class="hist-servico"><?= htmlspecialchars($a['servico_nome']) ?></span>
                <?php endif; ?>
                <?php if($a['forma_pagamento']): ?>
                  <span class="hist-pgto"><i class="bi <?= $icon ?> me-1"></i><?= ucfirst($a['forma_pagamento']) ?></span>
                <?php endif; ?>
              </div>
            </div>
            <div class="d-flex flex-column align-items-end gap-1">
              <?php if($a['valor']): ?>
                <div class="hist-valor"><?= formatMoney($a['valor']) ?></div>
                <div class="hist-comissao"><i class="bi bi-percent me-1"></i><?= formatMoney($comissao) ?></div>
                <div class="hist-lucro"><i class="bi bi-arrow-up-right me-1"></i><?= formatMoney($lucro) ?></div>
              <?php else: ?><span style="color:rgba(255,255,255,.3)">–</span><?php endif; ?>
              <?php if($keyComp && $a['valor']): ?>
                <a href="../comprovante.php?id=<?= $a['id'] ?>&key=<?= $keyComp ?>" target="_blank" class="btn-comp">
                  <i class="bi bi-receipt"></i>Comp.
                </a>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- ── Resumo Financeiro ── -->
    <?php if($totalCortes > 0): ?>
    <div class="section-card">
      <div class="section-title">
        <i class="bi bi-calculator" style="color:#22c55e"></i>Resumo Financeiro
      </div>
      <div class="row g-2">
        <div class="col-6 col-md-3">
          <div style="background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);border-radius:12px;padding:1rem;text-align:center">
            <div style="font-size:1.15rem;font-weight:800;color:#4ade80"><?= formatMoney($totalFat) ?></div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.45);margin-top:.2rem">Faturamento Total</div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:12px;padding:1rem;text-align:center">
            <div style="font-size:1.15rem;font-weight:800;color:#fbbf24"><?= formatMoney($totalComissao) ?></div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.45);margin-top:.2rem">Total Comissões</div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div style="background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);border-radius:12px;padding:1rem;text-align:center">
            <div style="font-size:1.15rem;font-weight:800;color:#60a5fa"><?= formatMoney($totalLucro) ?></div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.45);margin-top:.2rem">Lucro da Barbearia</div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div style="background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.2);border-radius:12px;padding:1rem;text-align:center">
            <div style="font-size:1.15rem;font-weight:800;color:#a78bfa"><?= formatMoney($totalFat/$totalCortes) ?></div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.45);margin-top:.2rem">Ticket Médio</div>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

function toggleDetail(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.toggle('open');
  const card = el.closest('.barb-rel-card');
  const icon = card?.querySelector('.bi-chevron-down, .bi-chevron-up');
  if (icon) {
    icon.classList.toggle('bi-chevron-down');
    icon.classList.toggle('bi-chevron-up');
  }
}
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</body>
</html>