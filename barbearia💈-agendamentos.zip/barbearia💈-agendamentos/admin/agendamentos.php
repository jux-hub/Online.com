<?php
/**
 * admin/agendamentos.php — Painel de gerenciamento de agendamentos
 */
require_once '../config.php';
requireAdmin();
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'atualizar_status') {
        $id     = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        if ($id && in_array($status, ['pendente','confirmado','concluido','cancelado','faltou'])) {
            $db->prepare("UPDATE agendamentos SET status=? WHERE id=?")->execute([$status, $id]);

            // Se concluído, mover para fila como atendimento finalizado
            if ($status === 'concluido') {
                $ag = $db->prepare("SELECT * FROM agendamentos WHERE id=?");
                $ag->execute([$id]);
                $ag = $ag->fetch();
                if ($ag) {
                    // Verifica se já existe na fila
                    // Adicionar coluna agendamento_id na fila se não existir
                    try { $db->exec("ALTER TABLE fila ADD COLUMN agendamento_id INTEGER"); } catch(Exception $e) {}
                    $existe = $db->prepare("SELECT id FROM fila WHERE agendamento_id=?");
                    $existe->execute([$id]);
                    if (!$existe->fetch()) {
                        $db->prepare("
                            INSERT INTO fila (cliente_id, barbeiro_id, servico_id, status,
                                valor, finalizado_em, agendamento_id)
                            SELECT ag.cliente_id, ag.barbeiro_id, ag.servico_id, 'concluido',
                                   s.preco, CURRENT_TIMESTAMP, ag.id
                            FROM agendamentos ag
                            LEFT JOIN servicos s ON s.id = ag.servico_id
                            WHERE ag.id = ?
                        ")->execute([$id]);
                    }
                }
            }
            flash('success', 'Status atualizado!');
        }
        header('Location: agendamentos.php?' . http_build_query($_GET)); exit;

    } elseif ($acao === 'salvar_configs') {
        $configs = [
            'agenda_modo_slots'         => $_POST['agenda_modo_slots']          ?? 'fixo',
            'agenda_intervalo'          => (int)($_POST['agenda_intervalo']      ?? 30),
            'agenda_antecedencia_min'   => (int)($_POST['agenda_antecedencia_min'] ?? 60),
            'agenda_max_dias'           => (int)($_POST['agenda_max_dias']       ?? 30),
            'agenda_ativo'              => $_POST['agenda_ativo']                ?? '0',
            'agenda_motivo'             => trim($_POST['agenda_motivo']           ?? ''),
            'agenda_whatsapp'           => preg_replace('/\D/', '', $_POST['agenda_whatsapp'] ?? ''),
        ];
        foreach ($configs as $k => $v) setConfig($k, $v);
        flash('success', 'Configurações salvas!');
        header('Location: agendamentos.php'); exit;

    } elseif ($acao === 'add_slot_manual') {
        $diaSem = $_POST['dia_semana']     ? (int)$_POST['dia_semana'] : null;
        $diaEsp = trim($_POST['dia_especifico'] ?? '');
        $hora   = trim($_POST['hora_slot'] ?? '');
        if ($hora && ($diaSem || $diaEsp)) {
            $db->prepare("INSERT INTO agenda_slots_manuais (dia_semana, dia_especifico, hora) VALUES (?,?,?)")
               ->execute([$diaSem ?: null, $diaEsp ?: null, $hora]);
            flash('success', 'Slot adicionado!');
        }
        header('Location: agendamentos.php?tab=config'); exit;

    } elseif ($acao === 'del_slot_manual') {
        $db->prepare("DELETE FROM agenda_slots_manuais WHERE id=?")->execute([(int)($_POST['id'] ?? 0)]);
        header('Location: agendamentos.php?tab=config'); exit;
    }
}

// ── Filtros ──
$dataFiltro   = $_GET['data']   ?? date('Y-m-d');
$statusFiltro = $_GET['status'] ?? '';
$barFiltro    = (int)($_GET['barbeiro_id'] ?? 0);
$tab          = $_GET['tab'] ?? 'hoje';

// ── Agendamentos ──
$where  = ["DATE(ag.data_hora) = ?"];
$params = [$dataFiltro];
if ($statusFiltro) { $where[] = "ag.status = ?"; $params[] = $statusFiltro; }
if ($barFiltro)    { $where[] = "ag.barbeiro_id = ?"; $params[] = $barFiltro; }

$agendamentos = $db->prepare("
    SELECT ag.*, s.nome AS servico_nome, s.preco AS servico_preco,
           b.nome AS barbeiro_nome, NULL AS barbeiro_cor
    FROM agendamentos ag
    LEFT JOIN servicos s ON s.id = ag.servico_id
    LEFT JOIN usuarios b ON b.id = ag.barbeiro_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY ag.data_hora ASC
");
$agendamentos->execute($params);
$agendamentos = $agendamentos->fetchAll();

// ── Stats do dia ──
$stats = $db->prepare("
    SELECT
        COUNT(*) AS total,
        COUNT(CASE WHEN status='pendente'   THEN 1 END) AS pendentes,
        COUNT(CASE WHEN status='confirmado' THEN 1 END) AS confirmados,
        COUNT(CASE WHEN status='concluido'  THEN 1 END) AS concluidos,
        COUNT(CASE WHEN status='cancelado'  THEN 1 END) AS cancelados,
        COUNT(CASE WHEN status='faltou'     THEN 1 END) AS faltou
    FROM agendamentos WHERE DATE(data_hora) = ?
");
$stats->execute([$dataFiltro]);
$stats = $stats->fetch();

// ── Próximos 7 dias (visão semana) ──
$semana = $db->query("
    SELECT DATE(data_hora) AS dia, COUNT(*) AS qtd,
           COUNT(CASE WHEN status='cancelado' THEN 1 END) AS cancelados
    FROM agendamentos
    WHERE data_hora >= DATE('now') AND data_hora < DATE('now','+8 days')
    GROUP BY DATE(data_hora)
    ORDER BY dia ASC
")->fetchAll();

// ── Configs ──
$modoSlots    = getConfig('agenda_modo_slots')          ?: 'fixo';
$intervalo    = getConfig('agenda_intervalo')           ?: '30';
$antecMin     = getConfig('agenda_antecedencia_min')    ?: '60';
$maxDias      = getConfig('agenda_max_dias')            ?: '30';
$agendaAtivo  = getConfig('agenda_ativo')               ?: '0';
$agendaMotivo = getConfig('agenda_motivo')              ?: '';
$agendaWpp    = getConfig('agenda_whatsapp')            ?: '';

// ── Slots manuais ──
$slotsMan = $db->query("SELECT * FROM agenda_slots_manuais ORDER BY dia_semana, hora")->fetchAll();

// ── Barbeiros ──
$barbeiros = $db->query("SELECT id, nome, NULL as cor FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();

$statusLabels = [
    'pendente'  => ['label'=>'Pendente',   'bg'=>'rgba(245,158,11,.15)', 'color'=>'#fbbf24'],
    'confirmado'=> ['label'=>'Confirmado', 'bg'=>'rgba(59,130,246,.15)', 'color'=>'#60a5fa'],
    'concluido' => ['label'=>'Concluído',  'bg'=>'rgba(34,197,94,.15)',  'color'=>'#4ade80'],
    'cancelado' => ['label'=>'Cancelado',  'bg'=>'rgba(239,68,68,.15)',  'color'=>'#f87171'],
    'faltou'    => ['label'=>'Faltou',     'bg'=>'rgba(107,114,128,.15)','color'=>'#9ca3af'],
];
$diasSemNomes = ['1'=>'Seg','2'=>'Ter','3'=>'Qua','4'=>'Qui','5'=>'Sex','6'=>'Sáb','7'=>'Dom'];

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agendamentos – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--primary:#e94560;--sidebar-w:260px}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
  background:linear-gradient(180deg,#1a1a2e,#16213e);
  border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto}
.sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
.sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
  border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
.nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
  margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.95rem;text-decoration:none}
.nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
.nav-link-side.active{border-left:3px solid var(--primary)}
.nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
.main-content{margin-left:var(--sidebar-w);min-height:100vh}
.topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
  padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
.page-body{padding:1.5rem}
.card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.1rem}
.card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
.stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
  border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:1rem;text-align:center}
.stat-value{font-size:1.5rem;font-weight:800;color:#fff;line-height:1}
.stat-label{color:rgba(255,255,255,.4);font-size:.73rem;margin-top:.25rem}
.ag-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
  border-radius:14px;padding:1rem;transition:all .2s;margin-bottom:.6rem}
.ag-card:hover{border-color:rgba(255,255,255,.18);background:rgba(255,255,255,.06)}
.form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
  color:#fff;border-radius:10px;padding:.55rem .85rem;font-size:.88rem}
.form-control-dark:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
select.form-control-dark option{background:#1a1a2e}
.btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;
  border-radius:10px;padding:.6rem 1.2rem;font-weight:700;cursor:pointer;transition:all .3s;font-size:.88rem}
.btn-primary-custom:hover{transform:translateY(-1px);box-shadow:0 5px 18px rgba(233,69,96,.4)}
.tab-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  color:rgba(255,255,255,.55);border-radius:10px;padding:.45rem .9rem;
  cursor:pointer;font-size:.82rem;font-weight:600;transition:.2s;text-decoration:none}
.tab-btn:hover,.tab-btn.active{background:rgba(233,69,96,.15);border-color:rgba(233,69,96,.3);color:#fff}
.semana-dia{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
  border-radius:10px;padding:.6rem .75rem;text-align:center;cursor:pointer;transition:.2s;text-decoration:none;display:block}
.semana-dia:hover{border-color:rgba(255,255,255,.2)}
.semana-dia.hoje{border-color:rgba(233,69,96,.4);background:rgba(233,69,96,.08)}
h4,h5,h6{color:#fff;margin:0}
@media(max-width:768px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.page-body{padding:1rem}}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div style="display:flex;align-items:center;gap:.75rem">
      <button id="btnMenuMobile" style="background:none;border:none;color:#fff;font-size:1.3rem;cursor:pointer" class="d-md-none">
        <i class="bi bi-list"></i>
      </button>
      <div>
        <div style="font-weight:700;color:#fff;font-size:1.05rem">
          <i class="bi bi-calendar3 me-2" style="color:var(--primary)"></i>Agendamentos
        </div>
        <div style="font-size:.78rem;color:rgba(255,255,255,.4)">Horários marcados</div>
      </div>
    </div>
    <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap">
      <a href="<?= BASE_URL ?>/agendar.php" target="_blank"
         style="background:rgba(37,211,102,.12);border:1px solid rgba(37,211,102,.25);color:#4ade80;
                border-radius:10px;padding:.4rem .9rem;text-decoration:none;font-size:.82rem;font-weight:700">
        <i class="bi bi-box-arrow-up-right me-1"></i>Página pública
      </a>
      <?php if ($agendaAtivo !== '1'): ?>
      <span style="background:rgba(239,68,68,.12);color:#f87171;border:1px solid rgba(239,68,68,.25);
                   border-radius:20px;padding:.3rem .75rem;font-size:.75rem;font-weight:700">
        <i class="bi bi-pause-circle me-1"></i>Desativado
      </span>
      <?php endif; ?>
    </div>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- Tabs -->
    <div style="display:flex;gap:.4rem;margin-bottom:1.25rem;flex-wrap:wrap">
      <a href="?tab=hoje&data=<?= date('Y-m-d') ?>"  class="tab-btn <?= $tab==='hoje'   ? 'active':'' ?>"><i class="bi bi-calendar-day me-1"></i>Hoje</a>
      <a href="?tab=semana"                           class="tab-btn <?= $tab==='semana' ? 'active':'' ?>"><i class="bi bi-calendar-week me-1"></i>Semana</a>
      <a href="?tab=todos"                            class="tab-btn <?= $tab==='todos'  ? 'active':'' ?>"><i class="bi bi-calendar3 me-1"></i>Por data</a>
      <a href="?tab=config"                           class="tab-btn <?= $tab==='config' ? 'active':'' ?>"><i class="bi bi-gear me-1"></i>Configurações</a>
    </div>

    <!-- ═══ TAB: HOJE / TODOS ═══ -->
    <?php if (in_array($tab, ['hoje','todos'])): ?>

    <!-- Stats -->
    <div class="row g-2 mb-3">
      <?php foreach ([
        ['total',      '#fff',    'bi-calendar3',       'Total'],
        ['pendentes',  '#fbbf24', 'bi-hourglass-split', 'Pendentes'],
        ['confirmados','#60a5fa', 'bi-check-circle',    'Confirmados'],
        ['concluidos', '#4ade80', 'bi-check2-all',      'Concluídos'],
        ['cancelados', '#f87171', 'bi-x-circle',        'Cancelados'],
      ] as [$k,$c,$ic,$lb]): ?>
      <div class="col">
        <div class="stat-card">
          <div class="stat-value" style="color:<?= $c ?>"><?= $stats[$k] ?></div>
          <div class="stat-label"><i class="bi <?= $ic ?> me-1"></i><?= $lb ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Filtros -->
    <form method="GET" style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem;align-items:center">
      <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">
      <input type="date" name="data" value="<?= htmlspecialchars($dataFiltro) ?>" class="form-control-dark" style="width:auto">
      <select name="status" class="form-control-dark" style="width:auto">
        <option value="">Todos status</option>
        <?php foreach ($statusLabels as $sk => $sl): ?>
        <option value="<?= $sk ?>" <?= $statusFiltro === $sk ? 'selected':'' ?>><?= $sl['label'] ?></option>
        <?php endforeach; ?>
      </select>
      <select name="barbeiro_id" class="form-control-dark" style="width:auto">
        <option value="">Todos barbeiros</option>
        <?php foreach ($barbeiros as $b): ?>
        <option value="<?= $b['id'] ?>" <?= $barFiltro === $b['id'] ? 'selected':'' ?>><?= htmlspecialchars($b['nome']) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn-primary-custom" style="padding:.5rem 1rem">Filtrar</button>
    </form>

    <!-- Lista de agendamentos -->
    <?php if (empty($agendamentos)): ?>
    <div style="text-align:center;padding:3rem;color:rgba(255,255,255,.25)">
      <i class="bi bi-calendar-x" style="font-size:2.5rem;display:block;margin-bottom:.75rem"></i>
      Nenhum agendamento nesta data
    </div>
    <?php else: ?>
    <?php foreach ($agendamentos as $ag):
      $sl  = $statusLabels[$ag['status']] ?? $statusLabels['pendente'];
      $cor = htmlspecialchars($ag['barbeiro_cor'] ?? '#e94560');
    ?>
    <div class="ag-card">
      <div style="display:flex;align-items:flex-start;gap:.85rem;flex-wrap:wrap">
        <!-- Hora -->
        <div style="background:rgba(255,255,255,.07);border-radius:10px;padding:.5rem .75rem;
                    text-align:center;flex-shrink:0;min-width:58px">
          <div style="font-size:1.1rem;font-weight:800;color:#fff;line-height:1"><?= date('H:i', strtotime($ag['data_hora'])) ?></div>
          <div style="font-size:.65rem;color:rgba(255,255,255,.35)"><?= date('d/m', strtotime($ag['data_hora'])) ?></div>
        </div>

        <!-- Info cliente -->
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;margin-bottom:.3rem">
            <span style="font-weight:700;color:#fff;font-size:.95rem"><?= htmlspecialchars($ag['cliente_nome']) ?></span>
            <span style="background:<?= $sl['bg'] ?>;color:<?= $sl['color'] ?>;border-radius:20px;
                         padding:.1rem .55rem;font-size:.7rem;font-weight:700"><?= $sl['label'] ?></span>
          </div>
          <div style="font-size:.8rem;color:rgba(255,255,255,.45);display:flex;gap:.75rem;flex-wrap:wrap">
            <span><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($ag['cliente_tel']) ?></span>
            <?php if ($ag['servico_nome']): ?>
            <span><i class="bi bi-scissors me-1"></i><?= htmlspecialchars($ag['servico_nome']) ?></span>
            <?php endif; ?>
            <?php if ($ag['barbeiro_nome']): ?>
            <span style="color:<?= $cor ?>"><i class="bi bi-person-fill me-1"></i><?= htmlspecialchars($ag['barbeiro_nome']) ?></span>
            <?php endif; ?>
            <?php if ($ag['duracao_min']): ?>
            <span><i class="bi bi-clock me-1"></i><?= $ag['duracao_min'] ?>min</span>
            <?php endif; ?>
          </div>
          <?php if ($ag['observacao']): ?>
          <div style="font-size:.75rem;color:rgba(255,255,255,.35);margin-top:.25rem;font-style:italic">
            "<?= htmlspecialchars($ag['observacao']) ?>"
          </div>
          <?php endif; ?>
        </div>

        <!-- Ações -->
        <div style="display:flex;gap:.35rem;flex-wrap:wrap;flex-shrink:0">
          <?php if ($ag['status'] === 'pendente'): ?>
          <form method="POST" style="display:inline">
            <input type="hidden" name="acao" value="atualizar_status">
            <input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <input type="hidden" name="status" value="confirmado">
            <button type="submit" style="background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.3);
              color:#60a5fa;border-radius:8px;padding:.3rem .65rem;cursor:pointer;font-size:.78rem;font-weight:700">
              <i class="bi bi-check2 me-1"></i>Confirmar
            </button>
          </form>
          <?php endif; ?>
          <?php if (in_array($ag['status'],['pendente','confirmado'])): ?>
          <form method="POST" style="display:inline">
            <input type="hidden" name="acao" value="atualizar_status">
            <input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <input type="hidden" name="status" value="concluido">
            <button type="submit" style="background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);
              color:#4ade80;border-radius:8px;padding:.3rem .65rem;cursor:pointer;font-size:.78rem;font-weight:700">
              <i class="bi bi-check2-all me-1"></i>Concluir
            </button>
          </form>
          <form method="POST" style="display:inline">
            <input type="hidden" name="acao" value="atualizar_status">
            <input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <input type="hidden" name="status" value="faltou">
            <button type="submit" style="background:rgba(107,114,128,.12);border:1px solid rgba(107,114,128,.25);
              color:#9ca3af;border-radius:8px;padding:.3rem .65rem;cursor:pointer;font-size:.78rem;font-weight:700">
              <i class="bi bi-person-x me-1"></i>Faltou
            </button>
          </form>
          <form method="POST" style="display:inline">
            <input type="hidden" name="acao" value="atualizar_status">
            <input type="hidden" name="id" value="<?= $ag['id'] ?>">
            <input type="hidden" name="status" value="cancelado">
            <button type="submit" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);
              color:#f87171;border-radius:8px;padding:.3rem .65rem;cursor:pointer;font-size:.78rem;font-weight:700">
              <i class="bi bi-x me-1"></i>Cancelar
            </button>
          </form>
          <?php endif; ?>
          <!-- WhatsApp -->
          <?php
          $telLimpo = preg_replace('/\D/','',$ag['cliente_tel']);
          $numBr    = str_starts_with($telLimpo,'55') ? $telLimpo : '55'.$telLimpo;
          $msgWa    = urlencode("Olá, {$ag['cliente_nome']}! Seu agendamento em *{$nomeBarbearia}* está confirmado para " . date('d/m', strtotime($ag['data_hora'])) . " às " . date('H:i', strtotime($ag['data_hora'])) . ". Te esperamos! ✂️💈");
          ?>
          <a href="https://wa.me/<?= $numBr ?>?text=<?= $msgWa ?>" target="_blank"
             style="background:rgba(37,211,102,.1);border:1px solid rgba(37,211,102,.25);
                    color:#4ade80;border-radius:8px;padding:.3rem .65rem;text-decoration:none;font-size:.78rem;font-weight:700">
            <i class="bi bi-whatsapp"></i>
          </a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>

    <!-- ═══ TAB: SEMANA ═══ -->
    <?php elseif ($tab === 'semana'): ?>
    <div class="row g-2 mb-3">
      <?php foreach ($semana as $dia):
        $ehHoje = $dia['dia'] === date('Y-m-d');
      ?>
      <div class="col">
        <a href="?tab=hoje&data=<?= $dia['dia'] ?>" class="semana-dia <?= $ehHoje ? 'hoje':'' ?>">
          <div style="font-size:.72rem;color:rgba(255,255,255,.4);text-transform:uppercase"><?= date('D', strtotime($dia['dia'])) ?></div>
          <div style="font-size:1.2rem;font-weight:800;color:#fff"><?= date('d', strtotime($dia['dia'])) ?></div>
          <div style="font-size:.78rem;font-weight:700;color:var(--primary)"><?= $dia['qtd'] ?> ag.</div>
          <?php if ($dia['cancelados']): ?>
          <div style="font-size:.65rem;color:rgba(239,68,68,.6)"><?= $dia['cancelados'] ?> cancel.</div>
          <?php endif; ?>
        </a>
      </div>
      <?php endforeach; ?>
      <?php if (empty($semana)): ?>
      <div class="col-12" style="text-align:center;padding:2rem;color:rgba(255,255,255,.3)">
        Nenhum agendamento nos próximos 7 dias
      </div>
      <?php endif; ?>
    </div>

    <!-- ═══ TAB: CONFIG ═══ -->
    <?php elseif ($tab === 'config'): ?>
    <div class="row g-3">
      <div class="col-12 col-lg-6">
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-gear" style="color:#f59e0b"></i>
            Configurações de Agendamento
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="salvar_configs">

            <div style="margin-bottom:.85rem">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">Status</label>
              <select name="agenda_ativo" id="selAgendaAtivo" class="form-control-dark" onchange="toggleAgendaStatus()">
                <option value="1" <?= $agendaAtivo==='1' ? 'selected':'' ?>>✅ Ativado — aceitar agendamentos</option>
                <option value="0" <?= $agendaAtivo!=='1' ? 'selected':'' ?>>🚫 Desativado</option>
              </select>
            </div>

            <!-- Campos extras quando desativado -->
            <div id="wrapDesativado" style="<?= $agendaAtivo==='1' ? 'display:none' : '' ?>">
              <div style="background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.2);
                          border-radius:12px;padding:1rem;margin-bottom:.85rem">

                <div style="margin-bottom:.75rem">
                  <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">
                    <i class="bi bi-chat-left-text me-1" style="color:#f87171"></i>Motivo (exibido ao cliente)
                  </label>
                  <textarea name="agenda_motivo" rows="2" placeholder="Ex: Estamos em reforma, voltamos em breve..." class="form-control-dark"
                    style="resize:none"><?= htmlspecialchars($agendaMotivo) ?></textarea>
                  <div style="font-size:.71rem;color:rgba(255,255,255,.28);margin-top:.25rem">
                    Deixe vazio para não exibir motivo
                  </div>
                </div>

                <div>
                  <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">
                    <i class="bi bi-whatsapp me-1" style="color:#25d366"></i>WhatsApp para contato (opcional)
                  </label>
                  <input type="tel" name="agenda_whatsapp" class="form-control-dark"
                    placeholder="Ex: 69999999999 (somente números)"
                    value="<?= htmlspecialchars($agendaWpp) ?>">
                  <div style="font-size:.71rem;color:rgba(255,255,255,.28);margin-top:.25rem">
                    Se preenchido, aparece botão "Falar no WhatsApp" na página do cliente
                  </div>
                </div>
              </div>
            </div>

            <div style="margin-bottom:.85rem">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">
                Modo de slots de horário
              </label>
              <select name="agenda_modo_slots" id="selModo" class="form-control-dark" onchange="toggleModo()">
                <option value="fixo"    <?= $modoSlots==='fixo'    ? 'selected':'' ?>>🕐 Fixo — intervalos regulares (ex: a cada 30min)</option>
                <option value="servico" <?= $modoSlots==='servico' ? 'selected':'' ?>>✂️ Por serviço — respeita duração de cada serviço</option>
                <option value="manual"  <?= $modoSlots==='manual'  ? 'selected':'' ?>>📋 Manual — admin define os slots um a um</option>
                <option value="livre"   <?= $modoSlots==='livre'   ? 'selected':'' ?>>🕑 Livre — cliente escolhe qualquer horário</option>
              </select>
            </div>

            <div id="wrapIntervalo" style="margin-bottom:.85rem;<?= $modoSlots==='manual' ? 'display:none':'' ?>">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">
                Intervalo entre slots (minutos)
              </label>
              <input type="number" min="15" max="180" step="5" name="agenda_intervalo"
                     value="<?= htmlspecialchars($intervalo) ?>" class="form-control-dark">
              <div style="font-size:.72rem;color:rgba(255,255,255,.3);margin-top:.25rem">
                Ex: 30 = slots às 9h, 9h30, 10h, 10h30…
              </div>
            </div>

            <div style="margin-bottom:.85rem">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">
                Antecedência mínima (minutos)
              </label>
              <input type="number" min="0" max="1440" step="15" name="agenda_antecedencia_min"
                     value="<?= htmlspecialchars($antecMin) ?>" class="form-control-dark">
              <div style="font-size:.72rem;color:rgba(255,255,255,.3);margin-top:.25rem">
                Ex: 60 = só aceita agendamentos com 1h de antecedência
              </div>
            </div>

            <div style="margin-bottom:1rem">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.3rem">
                Máximo de dias para agendar
              </label>
              <input type="number" min="1" max="365" name="agenda_max_dias"
                     value="<?= htmlspecialchars($maxDias) ?>" class="form-control-dark">
            </div>

            <button type="submit" class="btn-primary-custom">
              <i class="bi bi-check2 me-1"></i>Salvar Configurações
            </button>
          </form>
        </div>
      </div>

      <!-- Slots manuais -->
      <div class="col-12 col-lg-6">
        <div class="card-sec" id="wrapSlotsMan" style="<?= $modoSlots!=='manual' ? 'opacity:.5':'' ?>">
          <div class="card-title">
            <i class="bi bi-clock" style="color:#8b5cf6"></i>
            Slots Manuais
            <span style="font-size:.72rem;color:rgba(255,255,255,.3);font-weight:400">— só usado no modo Manual</span>
          </div>

          <!-- Adicionar slot -->
          <form method="POST" style="display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:1rem;align-items:flex-end">
            <input type="hidden" name="acao" value="add_slot_manual">
            <div>
              <label style="font-size:.75rem;color:rgba(255,255,255,.4);display:block;margin-bottom:.25rem">Dia da semana</label>
              <select name="dia_semana" class="form-control-dark" style="min-width:90px">
                <option value="">Todos</option>
                <?php foreach ($diasSemNomes as $k => $v): ?>
                <option value="<?= $k ?>"><?= $v ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div>
              <label style="font-size:.75rem;color:rgba(255,255,255,.4);display:block;margin-bottom:.25rem">ou data específica</label>
              <input type="date" name="dia_especifico" class="form-control-dark">
            </div>
            <div>
              <label style="font-size:.75rem;color:rgba(255,255,255,.4);display:block;margin-bottom:.25rem">Horário</label>
              <input type="time" name="hora_slot" class="form-control-dark" required>
            </div>
            <button type="submit" class="btn-primary-custom" style="padding:.5rem .9rem;height:fit-content;align-self:flex-end">
              <i class="bi bi-plus-lg"></i>
            </button>
          </form>

          <!-- Lista de slots -->
          <div style="max-height:300px;overflow-y:auto">
          <?php if (empty($slotsMan)): ?>
          <div style="text-align:center;padding:1.5rem;color:rgba(255,255,255,.25);font-size:.85rem">
            Nenhum slot cadastrado
          </div>
          <?php else: ?>
          <?php foreach ($slotsMan as $sm): ?>
          <div style="display:flex;align-items:center;gap:.65rem;padding:.4rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <span style="font-size:.82rem;color:rgba(255,255,255,.4);flex:1">
              <?php if ($sm['dia_especifico']): ?>
              <i class="bi bi-calendar3 me-1"></i><?= date('d/m/Y', strtotime($sm['dia_especifico'])) ?>
              <?php else: ?>
              <i class="bi bi-repeat me-1"></i><?= $diasSemNomes[$sm['dia_semana']] ?? 'Todos' ?>
              <?php endif; ?>
            </span>
            <strong style="color:#fff;font-size:.88rem"><?= htmlspecialchars($sm['hora']) ?></strong>
            <form method="POST" style="display:inline;margin:0">
              <input type="hidden" name="acao" value="del_slot_manual">
              <input type="hidden" name="id" value="<?= $sm['id'] ?>">
              <button type="submit" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);
                color:#f87171;border-radius:6px;padding:.2rem .45rem;cursor:pointer;font-size:.75rem">
                <i class="bi bi-trash"></i>
              </button>
            </form>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

function toggleModo() {
  const modo = document.getElementById('selModo')?.value;
  const wi   = document.getElementById('wrapIntervalo');
  const ws   = document.getElementById('wrapSlotsMan');
  if (wi) wi.style.display  = modo === 'manual' ? 'none' : 'block';
  if (ws) ws.style.opacity  = modo === 'manual' ? '1' : '.5';
}

function toggleAgendaStatus() {
  var sel  = document.getElementById('selAgendaAtivo');
  var wrap = document.getElementById('wrapDesativado');
  if (!sel || !wrap) return;
  wrap.style.display = sel.value === '0' ? '' : 'none';
}
</script>
</body>
</html>
