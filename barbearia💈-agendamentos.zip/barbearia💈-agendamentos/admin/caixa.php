<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia');

// ── Criar tabelas se não existirem ──
$db->exec("
    CREATE TABLE IF NOT EXISTS caixa_movimentos (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo         TEXT NOT NULL CHECK(tipo IN ('abertura','fechamento','entrada','saida','sangria','suprimento')),
        valor        REAL NOT NULL DEFAULT 0,
        descricao    TEXT,
        usuario      TEXT,
        criado_em    DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
$db->exec("
    CREATE TABLE IF NOT EXISTS caixa_sessoes (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        aberto_em       DATETIME DEFAULT CURRENT_TIMESTAMP,
        fechado_em      DATETIME,
        valor_abertura  REAL DEFAULT 0,
        valor_fechamento REAL,
        usuario         TEXT,
        observacao      TEXT
    )
");

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'abrir_caixa') {
        $valor = (float)($_POST['valor_abertura'] ?? 0);
        $obs   = trim($_POST['observacao'] ?? '');
        // Verificar se já há caixa aberto
        $aberto = $db->query("SELECT id FROM caixa_sessoes WHERE fechado_em IS NULL")->fetch();
        if (!$aberto) {
            $db->prepare("INSERT INTO caixa_sessoes (valor_abertura, usuario, observacao) VALUES (?,?,?)")
               ->execute([$valor, $_SESSION['usuario_nome'] ?? 'Admin', $obs]);
            $sessaoId = $db->lastInsertId();
            $db->prepare("INSERT INTO caixa_movimentos (tipo, valor, descricao, usuario) VALUES ('abertura',?,?,?)")
               ->execute([$valor, 'Abertura de caixa', $_SESSION['usuario_nome'] ?? 'Admin']);
            flash('success', 'Caixa aberto com R$ ' . number_format($valor, 2, ',', '.') . '!');
        } else {
            flash('warning', 'Já existe um caixa aberto.');
        }
        header('Location: caixa.php'); exit;

    } elseif ($acao === 'fechar_caixa') {
        $sessaoId = (int)($_POST['sessao_id'] ?? 0);
        $valorFech = (float)($_POST['valor_fechamento'] ?? 0);
        $obs = trim($_POST['observacao'] ?? '');
        $db->prepare("UPDATE caixa_sessoes SET fechado_em=CURRENT_TIMESTAMP, valor_fechamento=?, observacao=? WHERE id=? AND fechado_em IS NULL")
           ->execute([$valorFech, $obs, $sessaoId]);
        $db->prepare("INSERT INTO caixa_movimentos (tipo, valor, descricao, usuario) VALUES ('fechamento',?,?,?)")
           ->execute([$valorFech, 'Fechamento de caixa', $_SESSION['usuario_nome'] ?? 'Admin']);
        flash('success', 'Caixa fechado!');
        header('Location: caixa.php'); exit;

    } elseif ($acao === 'movimento') {
        $tipo  = $_POST['tipo_mov'] ?? '';
        $valor = (float)($_POST['valor_mov'] ?? 0);
        $desc  = trim($_POST['descricao_mov'] ?? '');
        if (in_array($tipo, ['sangria','suprimento','entrada','saida']) && $valor > 0) {
            $db->prepare("INSERT INTO caixa_movimentos (tipo, valor, descricao, usuario) VALUES (?,?,?,?)")
               ->execute([$tipo, $valor, $desc, $_SESSION['usuario_nome'] ?? 'Admin']);
            flash('success', 'Movimento registrado!');
        }
        header('Location: caixa.php'); exit;
    }
}

// ── Sessão atual ──
$sessaoAtual = $db->query("SELECT * FROM caixa_sessoes WHERE fechado_em IS NULL ORDER BY aberto_em DESC LIMIT 1")->fetch();

// ── Movimentos de hoje ──
$movimentos = $db->query("
    SELECT * FROM caixa_movimentos
    WHERE DATE(criado_em) = DATE('now')
    ORDER BY criado_em DESC
")->fetchAll();

// ── Totais do dia ──
$totais = $db->query("
    SELECT
        COALESCE(SUM(CASE WHEN tipo IN ('entrada','suprimento') THEN valor ELSE 0 END),0) AS total_entradas,
        COALESCE(SUM(CASE WHEN tipo IN ('saida','sangria') THEN valor ELSE 0 END),0)      AS total_saidas,
        COALESCE(SUM(CASE WHEN tipo='abertura' THEN valor ELSE 0 END),0)                   AS valor_abertura
    FROM caixa_movimentos
    WHERE DATE(criado_em) = DATE('now')
")->fetch();

// ── Faturamento do dia (atendimentos concluídos) ──
$faturamentoDia = $db->query("
    SELECT
        COALESCE(SUM(f.valor),0) AS total_servicos,
        COALESCE(SUM(0),0) AS total_produtos,
        COUNT(CASE WHEN f.status='concluido' THEN 1 END) AS total_atendimentos
    FROM fila f
    WHERE DATE(f.finalizado_em) = DATE('now')
")->fetch();

// ── Últimas 10 sessões fechadas ──
$sessoes = $db->query("
    SELECT s.*,
           ROUND((julianday(COALESCE(s.fechado_em, CURRENT_TIMESTAMP)) - julianday(s.aberto_em)) * 24, 1) AS horas_abertura
    FROM caixa_sessoes s
    ORDER BY s.aberto_em DESC
    LIMIT 10
")->fetchAll();

$saldoAtual = $totais['valor_abertura'] + $totais['total_entradas'] - $totais['total_saidas'] + $faturamentoDia['total_servicos'] + $faturamentoDia['total_produtos'];

function navActive(string $p, string $a): string { return $p === $a ? 'nav-link-side active' : 'nav-link-side'; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Caixa – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--primary:#e94560;--sidebar-w:260px}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
  background:linear-gradient(180deg,#1a1a2e,#16213e);
  border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
.sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
.sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
  border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
.nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
  margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;gap:.75rem;font-size:.95rem;text-decoration:none}
.nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
.nav-link-side.active{border-left:3px solid var(--primary)}
.nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
.main-content{margin-left:var(--sidebar-w);min-height:100vh}
.topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
  padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
.page-body{padding:1.5rem}
.card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.1rem}
.card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
.stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
  border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.2rem;text-align:center;position:relative;overflow:hidden}
.stat-value{font-size:1.6rem;font-weight:800;color:#fff;line-height:1}
.stat-label{color:rgba(255,255,255,.45);font-size:.78rem;margin-top:.3rem}
.badge-tipo{border-radius:20px;padding:.2rem .65rem;font-size:.72rem;font-weight:700}
.mov-item{display:flex;align-items:center;gap:.75rem;padding:.7rem 0;border-bottom:1px solid rgba(255,255,255,.05)}
.mov-item:last-child{border-bottom:none}
.mov-icon{width:36px;height:36px;border-radius:10px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:1rem}
.form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
  color:#fff;border-radius:10px;padding:.65rem 1rem;width:100%;font-size:.9rem;transition:.2s}
.form-control-dark:focus{outline:none;border-color:var(--primary);background:rgba(233,69,96,.07);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
.form-control-dark::placeholder{color:rgba(255,255,255,.3)}
select.form-control-dark option{background:#1a1a2e;color:#fff}
.btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;
  border-radius:10px;padding:.7rem 1.4rem;font-weight:700;cursor:pointer;transition:all .3s;font-size:.9rem}
.btn-primary-custom:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(233,69,96,.4)}
.caixa-aberto{background:rgba(34,197,94,.08);border:2px solid rgba(34,197,94,.3);border-radius:16px;padding:1.2rem}
.caixa-fechado{background:rgba(239,68,68,.08);border:2px dashed rgba(239,68,68,.3);border-radius:16px;padding:1.2rem}
h4,h5,h6{color:#fff;margin:0}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div style="display:flex;align-items:center;gap:.75rem">
      <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
      <div>
        <div style="font-weight:700;color:#fff;font-size:1.05rem"><i class="bi bi-cash-stack me-2" style="color:var(--primary)"></i>Caixa</div>
        <div style="font-size:.78rem;color:rgba(255,255,255,.4)"><?= date('l, d \d\e F \d\e Y') ?></div>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:.75rem">
      <?php if ($sessaoAtual): ?>
      <span style="background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.3);
                   border-radius:20px;padding:.3rem .85rem;font-size:.78rem;font-weight:700">
        <i class="bi bi-circle-fill me-1" style="font-size:.5rem"></i> CAIXA ABERTO
      </span>
      <?php else: ?>
      <span style="background:rgba(239,68,68,.12);color:#f87171;border:1px solid rgba(239,68,68,.25);
                   border-radius:20px;padding:.3rem .85rem;font-size:.78rem;font-weight:700">
        <i class="bi bi-circle me-1" style="font-size:.5rem"></i> CAIXA FECHADO
      </span>
      <?php endif; ?>
    </div>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- Stats do dia -->
    <div class="row g-3 mb-3">
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#4ade80">R$ <?= number_format($faturamentoDia['total_servicos'] + $faturamentoDia['total_produtos'], 2, ',', '.') ?></div>
          <div class="stat-label"><i class="bi bi-scissors me-1"></i>Faturamento Hoje</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#60a5fa"><?= $faturamentoDia['total_atendimentos'] ?></div>
          <div class="stat-label"><i class="bi bi-person-check me-1"></i>Atendimentos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:#f59e0b">R$ <?= number_format($totais['total_saidas'], 2, ',', '.') ?></div>
          <div class="stat-label"><i class="bi bi-arrow-down-circle me-1"></i>Saídas Hoje</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-card">
          <div class="stat-value" style="color:<?= $saldoAtual >= 0 ? '#4ade80' : '#f87171' ?>">
            R$ <?= number_format($saldoAtual, 2, ',', '.') ?>
          </div>
          <div class="stat-label"><i class="bi bi-wallet2 me-1"></i>Saldo Estimado</div>
        </div>
      </div>
    </div>

    <div class="row g-3">

      <!-- Coluna esquerda: Status do caixa + Movimentos -->
      <div class="col-12 col-lg-7">

        <!-- Status caixa -->
        <?php if ($sessaoAtual): ?>
        <div class="caixa-aberto mb-3">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem">
            <div>
              <div style="font-size:.72rem;color:rgba(34,197,94,.7);font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:.3rem">
                <i class="bi bi-circle-fill me-1" style="font-size:.5rem"></i>Caixa Aberto
              </div>
              <div style="font-size:1.1rem;font-weight:700;color:#fff">
                Aberto às <?= date('H:i', strtotime($sessaoAtual['aberto_em'])) ?>
                por <?= htmlspecialchars($sessaoAtual['usuario']) ?>
              </div>
              <div style="font-size:.82rem;color:rgba(255,255,255,.45);margin-top:.2rem">
                Troco inicial: R$ <?= number_format($sessaoAtual['valor_abertura'], 2, ',', '.') ?>
              </div>
            </div>
            <button onclick="document.getElementById('modalFechamento').style.display='flex'"
              style="background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);color:#f87171;
                     border-radius:10px;padding:.6rem 1.2rem;font-weight:700;cursor:pointer;font-size:.88rem">
              <i class="bi bi-lock-fill me-1"></i>Fechar Caixa
            </button>
          </div>
        </div>
        <?php else: ?>
        <div class="caixa-fechado mb-3">
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.75rem">
            <div>
              <div style="font-size:.72rem;color:rgba(239,68,68,.6);font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:.3rem">Caixa Fechado</div>
              <div style="font-size:1rem;color:rgba(255,255,255,.5)">Abra o caixa para registrar movimentos</div>
            </div>
            <button onclick="document.getElementById('modalAbertura').style.display='flex'"
              style="background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.3);color:#4ade80;
                     border-radius:10px;padding:.6rem 1.2rem;font-weight:700;cursor:pointer;font-size:.88rem">
              <i class="bi bi-unlock-fill me-1"></i>Abrir Caixa
            </button>
          </div>
        </div>
        <?php endif; ?>

        <!-- Movimentos do dia -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-arrow-left-right" style="color:#f59e0b"></i>
            Movimentos de Hoje
            <span style="background:rgba(245,158,11,.12);color:#fbbf24;border-radius:20px;
              padding:.1rem .5rem;font-size:.72rem;margin-left:auto"><?= count($movimentos) ?></span>
          </div>
          <?php if (empty($movimentos)): ?>
          <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25);font-size:.88rem">
            <i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
            Nenhum movimento registrado hoje
          </div>
          <?php else: ?>
          <div style="max-height:360px;overflow-y:auto">
          <?php foreach ($movimentos as $m):
            $isEntrada = in_array($m['tipo'], ['entrada','suprimento','abertura']);
            $cor   = $isEntrada ? '#4ade80' : '#f87171';
            $icone = match($m['tipo']) {
                'abertura'   => 'bi-unlock-fill',
                'fechamento' => 'bi-lock-fill',
                'entrada'    => 'bi-plus-circle-fill',
                'saida'      => 'bi-dash-circle-fill',
                'suprimento' => 'bi-arrow-up-circle-fill',
                'sangria'    => 'bi-arrow-down-circle-fill',
                default      => 'bi-circle'
            };
            $labels = ['abertura'=>'Abertura','fechamento'=>'Fechamento','entrada'=>'Entrada','saida'=>'Saída','suprimento'=>'Suprimento','sangria'=>'Sangria'];
          ?>
          <div class="mov-item">
            <div class="mov-icon" style="background:<?= $cor ?>22;color:<?= $cor ?>">
              <i class="bi <?= $icone ?>"></i>
            </div>
            <div style="flex:1;min-width:0">
              <div style="font-size:.88rem;font-weight:600;color:#fff"><?= $labels[$m['tipo']] ?? $m['tipo'] ?></div>
              <div style="font-size:.75rem;color:rgba(255,255,255,.35)"><?= htmlspecialchars($m['descricao'] ?? '') ?> · <?= date('H:i', strtotime($m['criado_em'])) ?></div>
            </div>
            <div style="font-weight:800;font-size:.95rem;color:<?= $cor ?>;flex-shrink:0">
              <?= $isEntrada ? '+' : '-' ?>R$ <?= number_format($m['valor'], 2, ',', '.') ?>
            </div>
          </div>
          <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>

        <!-- Faturamento por barbeiro hoje -->
        <?php
        $porBarbeiro = $db->query("
            SELECT b.nome, NULL as cor,
                   COUNT(CASE WHEN f.status='concluido' THEN 1 END) AS atend,
                   COALESCE(SUM(f.valor),0) AS total
            FROM usuarios b
            LEFT JOIN fila f ON f.barbeiro_id = b.id AND DATE(f.finalizado_em) = DATE('now') AND f.status = 'concluido'
            WHERE b.ativo = 1 AND b.tipo = 'barbeiro'
            GROUP BY b.id
            ORDER BY total DESC
        ")->fetchAll();
        ?>
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-people-fill" style="color:#8b5cf6"></i>
            Faturamento por Barbeiro Hoje
          </div>
          <?php foreach ($porBarbeiro as $bar): ?>
          <div style="display:flex;align-items:center;gap:.75rem;padding:.5rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <div style="width:32px;height:32px;border-radius:50%;background:<?= htmlspecialchars($bar['cor'] ?? '#e94560') ?>33;
                        color:<?= htmlspecialchars($bar['cor'] ?? '#e94560') ?>;display:flex;align-items:center;
                        justify-content:center;font-weight:800;font-size:.82rem;flex-shrink:0">
              <?= mb_strtoupper(mb_substr($bar['nome'], 0, 1)) ?>
            </div>
            <div style="flex:1">
              <div style="font-size:.88rem;font-weight:600;color:#fff"><?= htmlspecialchars($bar['nome']) ?></div>
              <div style="font-size:.73rem;color:rgba(255,255,255,.35)"><?= $bar['atend'] ?> atendimento<?= $bar['atend'] != 1 ? 's' : '' ?></div>
            </div>
            <div style="font-weight:800;color:#4ade80">R$ <?= number_format($bar['total'], 2, ',', '.') ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Coluna direita: Registrar movimento + Histórico sessões -->
      <div class="col-12 col-lg-5">

        <!-- Registrar movimento -->
        <?php if ($sessaoAtual): ?>
        <div class="card-sec" style="border-color:rgba(245,158,11,.2)">
          <div class="card-title">
            <i class="bi bi-plus-circle" style="color:#f59e0b"></i>
            Registrar Movimento
          </div>
          <form method="POST">
            <input type="hidden" name="acao" value="movimento">
            <div style="margin-bottom:.75rem">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;display:block">Tipo</label>
              <select name="tipo_mov" class="form-control-dark">
                <option value="entrada">💰 Entrada de dinheiro</option>
                <option value="saida">💸 Saída / Despesa</option>
                <option value="suprimento">⬆️ Suprimento de caixa</option>
                <option value="sangria">⬇️ Sangria</option>
              </select>
            </div>
            <div style="margin-bottom:.75rem">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;display:block">Valor (R$)</label>
              <input type="number" step="0.01" min="0.01" name="valor_mov" class="form-control-dark" placeholder="0,00" required>
            </div>
            <div style="margin-bottom:.85rem">
              <label style="font-size:.8rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;display:block">Descrição</label>
              <input type="text" name="descricao_mov" class="form-control-dark" placeholder="Ex: Pagamento de fornecedor…">
            </div>
            <button type="submit" class="btn-primary-custom w-100">
              <i class="bi bi-check2 me-1"></i>Registrar
            </button>
          </form>
        </div>
        <?php else: ?>
        <div class="card-sec" style="text-align:center;padding:2rem;border-color:rgba(239,68,68,.2)">
          <i class="bi bi-lock" style="font-size:2.5rem;color:rgba(255,255,255,.2);display:block;margin-bottom:.75rem"></i>
          <div style="color:rgba(255,255,255,.4);font-size:.88rem">Abra o caixa para registrar movimentos</div>
        </div>
        <?php endif; ?>

        <!-- Histórico de sessões -->
        <div class="card-sec">
          <div class="card-title">
            <i class="bi bi-calendar3" style="color:#3b82f6"></i>
            Últimas Sessões
          </div>
          <?php foreach ($sessoes as $s): ?>
          <?php $aberta = !$s['fechado_em']; ?>
          <div style="padding:.65rem 0;border-bottom:1px solid rgba(255,255,255,.05)">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.2rem">
              <div style="font-size:.85rem;font-weight:600;color:#fff">
                <?= date('d/m/Y', strtotime($s['aberto_em'])) ?>
              </div>
              <?php if ($aberta): ?>
              <span style="background:rgba(34,197,94,.15);color:#4ade80;border-radius:20px;padding:.1rem .5rem;font-size:.68rem;font-weight:700">ABERTO</span>
              <?php else: ?>
              <span style="background:rgba(255,255,255,.07);color:rgba(255,255,255,.4);border-radius:20px;padding:.1rem .5rem;font-size:.68rem">fechado</span>
              <?php endif; ?>
            </div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.35)">
              <?= date('H:i', strtotime($s['aberto_em'])) ?> →
              <?= $s['fechado_em'] ? date('H:i', strtotime($s['fechado_em'])) : 'aberto' ?>
              (<?= $s['horas_abertura'] ?>h) · <?= htmlspecialchars($s['usuario']) ?>
            </div>
            <?php if ($s['valor_fechamento'] !== null): ?>
            <div style="font-size:.78rem;color:#4ade80;font-weight:700;margin-top:.2rem">
              Fechamento: R$ <?= number_format($s['valor_fechamento'], 2, ',', '.') ?>
            </div>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- Modal Abrir Caixa -->
<div id="modalAbertura" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9000;align-items:center;justify-content:center">
  <div style="background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:1.75rem;width:100%;max-width:400px;margin:1rem">
    <h5 style="margin-bottom:1.25rem"><i class="bi bi-unlock-fill me-2" style="color:#4ade80"></i>Abrir Caixa</h5>
    <form method="POST">
      <input type="hidden" name="acao" value="abrir_caixa">
      <div style="margin-bottom:.75rem">
        <label style="font-size:.82rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;display:block">Valor inicial (troco) R$</label>
        <input type="number" step="0.01" min="0" name="valor_abertura" value="0" class="form-control-dark">
      </div>
      <div style="margin-bottom:1rem">
        <label style="font-size:.82rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;display:block">Observação</label>
        <input type="text" name="observacao" class="form-control-dark" placeholder="Opcional…">
      </div>
      <div style="display:flex;gap:.5rem">
        <button type="button" onclick="document.getElementById('modalAbertura').style.display='none'"
          style="flex:1;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.6);
                 border-radius:10px;padding:.65rem;cursor:pointer;font-weight:600">Cancelar</button>
        <button type="submit" style="flex:1;background:linear-gradient(135deg,#22c55e,#16a34a);border:none;color:#fff;
                border-radius:10px;padding:.65rem;cursor:pointer;font-weight:700">
          <i class="bi bi-unlock me-1"></i>Abrir
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Fechar Caixa -->
<div id="modalFechamento" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:9000;align-items:center;justify-content:center">
  <div style="background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px;padding:1.75rem;width:100%;max-width:400px;margin:1rem">
    <h5 style="margin-bottom:.5rem"><i class="bi bi-lock-fill me-2" style="color:#f87171"></i>Fechar Caixa</h5>
    <div style="background:rgba(34,197,94,.07);border:1px solid rgba(34,197,94,.15);border-radius:10px;padding:.75rem;margin-bottom:1rem">
      <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-bottom:.2rem">Saldo estimado em caixa</div>
      <div style="font-size:1.4rem;font-weight:800;color:#4ade80">R$ <?= number_format($saldoAtual, 2, ',', '.') ?></div>
    </div>
    <form method="POST">
      <input type="hidden" name="acao" value="fechar_caixa">
      <input type="hidden" name="sessao_id" value="<?= $sessaoAtual['id'] ?? '' ?>">
      <div style="margin-bottom:.75rem">
        <label style="font-size:.82rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;display:block">Valor contado em caixa R$</label>
        <input type="number" step="0.01" min="0" name="valor_fechamento" class="form-control-dark"
               value="<?= number_format($saldoAtual, 2, '.', '') ?>" required>
      </div>
      <div style="margin-bottom:1rem">
        <label style="font-size:.82rem;color:rgba(255,255,255,.5);margin-bottom:.3rem;display:block">Observação</label>
        <input type="text" name="observacao" class="form-control-dark" placeholder="Opcional…">
      </div>
      <div style="display:flex;gap:.5rem">
        <button type="button" onclick="document.getElementById('modalFechamento').style.display='none'"
          style="flex:1;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.6);
                 border-radius:10px;padding:.65rem;cursor:pointer;font-weight:600">Cancelar</button>
        <button type="submit" style="flex:1;background:linear-gradient(135deg,#ef4444,#dc2626);border:none;color:#fff;
                border-radius:10px;padding:.65rem;cursor:pointer;font-weight:700">
          <i class="bi bi-lock me-1"></i>Fechar
        </button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
// Fechar modais clicando fora
['modalAbertura','modalFechamento'].forEach(id => {
  document.getElementById(id)?.addEventListener('click', e => {
    if (e.target.id === id) e.target.style.display = 'none';
  });
});
</script>
</body>
</html>
