<?php
require_once '../config.php';
requireAdmin();
$db = getDB();
$paginaAtual   = basename($_SERVER['PHP_SELF']);
$nomeBarbearia = getConfig('nome_barbearia') ?: 'Barbearia';

function navActive(string $p, string $a): string { return $p===$a?'nav-link-side active':'nav-link-side'; }

$dbPath     = defined('DB_PATH') ? DB_PATH : __DIR__ . '/../barbearia.db';
$backupDir  = __DIR__ . '/../backups';
if (!is_dir($backupDir)) @mkdir($backupDir, 0755, true);

// ── POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    // Download direto do banco
    if ($acao === 'download_db') {
        if (file_exists($dbPath)) {
            $nome = 'barbearia_backup_' . date('Y-m-d_H-i-s') . '.db';
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $nome . '"');
            header('Content-Length: ' . filesize($dbPath));
            header('Cache-Control: no-cache');
            readfile($dbPath);
            exit;
        }
        flash('danger', 'Arquivo do banco não encontrado.');
        header('Location: backup.php'); exit;
    }

    // Criar backup local
    if ($acao === 'criar_backup') {
        if (file_exists($dbPath)) {
            $dest = $backupDir . '/backup_' . date('Y-m-d_H-i-s') . '.db';
            if (copy($dbPath, $dest)) {
                flash('success', 'Backup criado: ' . basename($dest));
            } else {
                flash('danger', 'Erro ao criar backup. Verifique permissões da pasta backups/.');
            }
        } else {
            flash('danger', 'Banco de dados não encontrado.');
        }
        header('Location: backup.php'); exit;
    }

    // Download de backup específico
    if ($acao === 'download_backup') {
        $arquivo = basename($_POST['arquivo'] ?? '');
        $full    = $backupDir . '/' . $arquivo;
        if ($arquivo && file_exists($full) && str_ends_with($arquivo, '.db')) {
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $arquivo . '"');
            header('Content-Length: ' . filesize($full));
            readfile($full);
            exit;
        }
        flash('danger', 'Arquivo não encontrado.');
        header('Location: backup.php'); exit;
    }

    // Excluir backup
    if ($acao === 'del_backup') {
        $arquivo = basename($_POST['arquivo'] ?? '');
        $full    = $backupDir . '/' . $arquivo;
        if ($arquivo && file_exists($full) && str_ends_with($arquivo, '.db')) {
            unlink($full);
            flash('success', 'Backup excluído.');
        }
        header('Location: backup.php'); exit;
    }

    // Restaurar backup
    if ($acao === 'restaurar') {
        $arquivo = basename($_POST['arquivo'] ?? '');
        $full    = $backupDir . '/' . $arquivo;
        if ($arquivo && file_exists($full) && str_ends_with($arquivo, '.db')) {
            // Fechar conexão antes de copiar
            unset($db);
            $safeDest = $backupDir . '/pre_restore_' . date('Y-m-d_H-i-s') . '.db';
            copy($dbPath, $safeDest); // salvar banco atual antes
            if (copy($full, $dbPath)) {
                flash('success', 'Banco restaurado! Backup do estado anterior salvo como ' . basename($safeDest));
            } else {
                flash('danger', 'Erro ao restaurar. Verifique permissões.');
            }
        } else {
            flash('danger', 'Arquivo de backup inválido.');
        }
        header('Location: backup.php'); exit;
    }

    header('Location: backup.php'); exit;
}

// ── Leitura ──
$dbSize    = file_exists($dbPath) ? filesize($dbPath) : 0;
$dbMtime   = file_exists($dbPath) ? filemtime($dbPath) : 0;

function humanSize(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes/1048576, 2) . ' MB';
    if ($bytes >= 1024)    return round($bytes/1024, 1)    . ' KB';
    return $bytes . ' B';
}

// Listar backups
$backups = [];
foreach (glob($backupDir . '/*.db') as $f) {
    $backups[] = ['nome' => basename($f), 'size' => filesize($f), 'mtime' => filemtime($f)];
}
usort($backups, fn($a,$b) => $b['mtime'] - $a['mtime']);

// Estatísticas do banco
$stats = [];
$tabelas = ['clientes','fila','agendamentos','servicos','usuarios','produtos','pedidos','vendas'];
foreach ($tabelas as $t) {
    try {
        $n = $db->query("SELECT COUNT(*) FROM $t")->fetchColumn();
        $stats[$t] = $n;
    } catch (Exception $e) { $stats[$t] = 0; }
}

// Log de últimas ações (simples, via configurações)
$ultimoBackup = getConfig('ultimo_backup_em') ?: null;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Backup – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}
  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}
  .main-content{margin-left:var(--sidebar-w);padding:0;min-height:100vh}
  .btn-menu-mobile{display:none;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:8px;padding:.35rem .6rem;cursor:pointer;font-size:1.2rem;line-height:1}
  .sidebar-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:999}
  .sidebar-backdrop.open{display:block}
  @media(max-width:768px){.sidebar{transform:translateX(-100%);transition:.3s}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}.btn-menu-mobile{display:inline-flex;align-items:center;justify-content:center}.page-body{padding:1rem}}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem;position:sticky;top:0;z-index:99}
  .page-body{padding:1.5rem}
  /* componente */
  .card-sec{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:1.35rem;margin-bottom:1.25rem}
  .card-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
  .btn-primary-custom{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;border-radius:10px;padding:.65rem 1.35rem;font-weight:700;cursor:pointer;font-size:.9rem;transition:.2s;display:inline-flex;align-items:center;gap:.45rem}
  .btn-primary-custom:hover{opacity:.88;transform:translateY(-1px)}
  .btn-outline-light-custom{background:transparent;border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.7);border-radius:10px;padding:.55rem 1.1rem;font-weight:600;cursor:pointer;font-size:.85rem;transition:.2s;display:inline-flex;align-items:center;gap:.4rem}
  .btn-outline-light-custom:hover{background:rgba(255,255,255,.08);color:#fff}
  .db-card{background:linear-gradient(135deg,rgba(233,69,96,.12),rgba(196,18,48,.06));border:1px solid rgba(233,69,96,.25);border-radius:18px;padding:1.5rem}
  .stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:.6rem;margin-top:1rem}
  .stat-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:.6rem .75rem;text-align:center}
  .stat-num{font-size:1.25rem;font-weight:800;color:#fff}
  .stat-lbl{font-size:.7rem;color:rgba(255,255,255,.35);text-transform:capitalize}
  .backup-row{display:flex;align-items:center;gap:.65rem;padding:.65rem 0;border-bottom:1px solid rgba(255,255,255,.05);flex-wrap:wrap}
  .backup-row:last-child{border-bottom:none}
  .backup-ico{width:36px;height:36px;border-radius:10px;background:rgba(59,130,246,.15);color:#60a5fa;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0}
  .btn-sm-action{border:none;border-radius:8px;padding:.28rem .6rem;cursor:pointer;font-size:.78rem;font-weight:600;transition:.15s;display:inline-flex;align-items:center;gap:.3rem}
  .btn-dl{background:rgba(59,130,246,.15);color:#60a5fa}
  .btn-dl:hover{background:rgba(59,130,246,.3)}
  .btn-res{background:rgba(245,158,11,.12);color:#fbbf24}
  .btn-res:hover{background:rgba(245,158,11,.25)}
  .btn-del{background:rgba(239,68,68,.1);color:#f87171}
  .btn-del:hover{background:rgba(239,68,68,.22)}
  .aviso-card{background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.2);border-radius:12px;padding:.85rem 1rem;font-size:.82rem;color:rgba(255,255,255,.6);line-height:1.6}
  h4,h5,h6{color:#fff;margin:0}
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Painel Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"            class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"          class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"             class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"     class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"             class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"               class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"         class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"              class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"           class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"            class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"            class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"    class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"                class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"                class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>

<div class="main-content">
<div class="topbar">
  <div class="d-flex align-items-center gap-2">
    <button class="btn-menu-mobile" id="btnMenuMobile"><i class="bi bi-list"></i></button>
    <h6 class="mb-0" style="color:#fff;font-weight:700"><i class="bi bi-cloud-arrow-down-fill me-2" style="color:var(--primary)"></i>Backup do Sistema</h6>
  </div>
  <div class="d-flex gap-2">
    <form method="POST">
      <input type="hidden" name="acao" value="criar_backup">
      <button type="submit" class="btn-outline-light-custom"><i class="bi bi-save"></i>Salvar backup local</button>
    </form>
    <form method="POST">
      <input type="hidden" name="acao" value="download_db">
      <button type="submit" class="btn-primary-custom"><i class="bi bi-download"></i>Baixar banco agora</button>
    </form>
  </div>
</div>
<div class="page-body">
  <?= renderFlash() ?>

  <div class="row g-3">
    <div class="col-lg-7">

      <!-- Info do banco -->
      <div class="db-card mb-3">
        <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap">
          <div style="width:56px;height:56px;background:rgba(233,69,96,.2);border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">
            🗄️
          </div>
          <div style="flex:1">
            <div style="font-weight:800;color:#fff;font-size:1.05rem">barbearia.db</div>
            <div style="font-size:.82rem;color:rgba(255,255,255,.45);margin-top:.2rem">
              Tamanho: <strong style="color:#fff"><?= humanSize($dbSize) ?></strong>
              &nbsp;·&nbsp; Última modificação: <strong style="color:#fff"><?= $dbMtime ? date('d/m/Y H:i', $dbMtime) : 'desconhecida' ?></strong>
            </div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.28);margin-top:.1rem;word-break:break-all"><?= htmlspecialchars($dbPath) ?></div>
          </div>
        </div>
        <div class="stat-grid">
          <?php foreach ($stats as $tabela => $qtd): ?>
          <div class="stat-item">
            <div class="stat-num"><?= number_format($qtd) ?></div>
            <div class="stat-lbl"><?= $tabela ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Lista de backups -->
      <div class="card-sec">
        <div class="card-title">
          <i class="bi bi-archive-fill" style="color:var(--primary)"></i>Backups Salvos
          <span style="background:rgba(255,255,255,.08);border-radius:20px;padding:.1rem .55rem;font-size:.72rem;color:rgba(255,255,255,.5);margin-left:auto"><?= count($backups) ?></span>
        </div>
        <?php if (empty($backups)): ?>
        <div style="text-align:center;padding:2rem;color:rgba(255,255,255,.25)">
          <i class="bi bi-archive" style="font-size:2.5rem;display:block;margin-bottom:.5rem"></i>
          Nenhum backup salvo ainda.<br>
          <span style="font-size:.82rem">Clique em "Salvar backup local" para criar um.</span>
        </div>
        <?php else: ?>
        <?php foreach ($backups as $bk): ?>
        <div class="backup-row">
          <div class="backup-ico"><i class="bi bi-database-fill"></i></div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:600;color:#fff;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($bk['nome']) ?></div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.35)">
              <?= humanSize($bk['size']) ?> · <?= date('d/m/Y H:i', $bk['mtime']) ?>
            </div>
          </div>
          <div class="d-flex gap-1 flex-wrap">
            <form method="POST">
              <input type="hidden" name="acao" value="download_backup">
              <input type="hidden" name="arquivo" value="<?= htmlspecialchars($bk['nome']) ?>">
              <button type="submit" class="btn-sm-action btn-dl"><i class="bi bi-download"></i>Baixar</button>
            </form>
            <form method="POST" onsubmit="return confirm('Restaurar este backup? O banco atual será salvo antes como pré-restauração.')">
              <input type="hidden" name="acao" value="restaurar">
              <input type="hidden" name="arquivo" value="<?= htmlspecialchars($bk['nome']) ?>">
              <button type="submit" class="btn-sm-action btn-res"><i class="bi bi-arrow-counterclockwise"></i>Restaurar</button>
            </form>
            <form method="POST" onsubmit="return confirm('Excluir este backup permanentemente?')">
              <input type="hidden" name="acao" value="del_backup">
              <input type="hidden" name="arquivo" value="<?= htmlspecialchars($bk['nome']) ?>">
              <button type="submit" class="btn-sm-action btn-del"><i class="bi bi-trash"></i></button>
            </form>
          </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>

    </div>

    <!-- Coluna direita -->
    <div class="col-lg-5">

      <!-- Dicas -->
      <div class="aviso-card mb-3">
        <div style="font-weight:700;color:#fbbf24;margin-bottom:.5rem"><i class="bi bi-exclamation-triangle-fill me-1"></i>Importante</div>
        Faça backup antes de qualquer alteração importante. O banco SQLite contém todos os dados do sistema — clientes, fila, histórico, configurações e financeiro.
      </div>

      <div class="card-sec" style="background:rgba(59,130,246,.06);border-color:rgba(59,130,246,.2)">
        <div class="card-title" style="color:#60a5fa"><i class="bi bi-info-circle"></i>Como fazer backup pelo cPanel</div>
        <div style="font-size:.82rem;color:rgba(255,255,255,.5);line-height:1.8">
          <strong style="color:#fff">Automático via cron:</strong><br>
          <code style="color:#a78bfa;font-size:.75rem;display:block;background:rgba(255,255,255,.04);padding:.4rem .6rem;border-radius:6px;margin:.35rem 0">0 3 * * * cp /home/cotpoobz/public_html/legal/barbearia.db /home/cotpoobz/public_html/legal/backups/auto_$(date +\%Y\%m\%d).db</code>
          <strong style="color:#fff">Manual:</strong><br>
          Clique em <em>Baixar banco agora</em> e salve o arquivo <code>.db</code> em local seguro (Google Drive, PC local, etc).
          <br><br>
          <strong style="color:#fff">Restaurar:</strong><br>
          Clique em <em>Restaurar</em> no backup desejado. O sistema salva automaticamente o estado atual antes de restaurar.
        </div>
      </div>

      <div class="card-sec">
        <div class="card-title"><i class="bi bi-shield-check-fill" style="color:#4ade80"></i>Recomendações</div>
        <div style="font-size:.82rem;color:rgba(255,255,255,.5);line-height:1.8">
          <div>✅ Faça backup diário (cron automático)</div>
          <div>✅ Baixe o banco manualmente antes de atualizações</div>
          <div>✅ Mantenha os últimos 7 backups</div>
          <div>⚠️ Nunca restaure em horário de pico</div>
          <div>⚠️ Após restaurar, faça logout e login novamente</div>
        </div>
      </div>

    </div>
  </div>
</div><!-- /page-body -->
</div><!-- /main-content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar');
  var bd=document.getElementById('sidebarBackdrop');
  var btn=document.getElementById('btnMenuMobile');
  function openSB(){if(sb)sb.classList.add('open');if(bd)bd.classList.add('open');}
  function closeSB(){if(sb)sb.classList.remove('open');if(bd)bd.classList.remove('open');}
  if(btn)btn.addEventListener('click',openSB);
  if(bd)bd.addEventListener('click',closeSB);
});
</script>
</body>
</html>
