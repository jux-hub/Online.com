<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// ── PRÉ-SELECÇÃO via GET (vindo de pacotes_produtos.php) ──
$preType  = $_GET['tipo']       ?? '';
$prePacId = (int)($_GET['pacote_id']  ?? 0);
$prePrdId = (int)($_GET['produto_id'] ?? 0);

// ── AÇÕES POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'registrar_venda') {
        $clienteId  = (int)($_POST['cliente_id'] ?? 0);
        $tipo       = $_POST['tipo'] ?? '';
        $pacoteId   = (int)($_POST['pacote_id']  ?? 0) ?: null;
        $produtoId  = (int)($_POST['produto_id'] ?? 0) ?: null;
        $qtd        = max(1, (int)($_POST['quantidade'] ?? 1));
        $valorUnit  = (float)str_replace(',', '.', $_POST['valor_unitario'] ?? 0);
        $pgto       = $_POST['forma_pagamento'] ?? 'dinheiro';
        $obs        = trim($_POST['observacoes'] ?? '');
        $vendedorId = $_SESSION['usuario_id'] ?? null;

        $ok = true;
        if (!$clienteId)                          { flash('danger', 'Selecione um cliente.'); $ok=false; }
        elseif (!in_array($tipo,['pacote','produto'])) { flash('danger', 'Tipo inválido.'); $ok=false; }
        elseif ($tipo==='pacote'  && !$pacoteId)  { flash('danger', 'Selecione um pacote.'); $ok=false; }
        elseif ($tipo==='produto' && !$produtoId) { flash('danger', 'Selecione um produto.'); $ok=false; }
        elseif ($valorUnit <= 0)                  { flash('danger', 'Valor inválido.'); $ok=false; }

        if ($ok) {
            $valorTotal = $valorUnit * $qtd;

            // Registra venda
            $db->prepare("
                INSERT INTO vendas (cliente_id,tipo,pacote_id,produto_id,quantidade,valor_unitario,valor_total,forma_pagamento,observacoes,vendedor_id)
                VALUES (?,?,?,?,?,?,?,?,?,?)
            ")->execute([$clienteId,$tipo,$pacoteId,$produtoId,$qtd,$valorUnit,$valorTotal,$pgto,$obs,$vendedorId]);

            $vendaId = $db->lastInsertId();

            if ($tipo === 'pacote' && $pacoteId) {
                // Busca créditos do pacote
                $pac = $db->prepare("SELECT creditos, validade_dias FROM pacotes WHERE id=?")->execute([$pacoteId]) ? null : null;
                $pac = $db->query("SELECT creditos, validade_dias FROM pacotes WHERE id=$pacoteId")->fetch();
                $creditos = ($pac['creditos'] ?? 1) * $qtd;
                $validade = null;
                if (($pac['validade_dias'] ?? 0) > 0) {
                    $validade = date('Y-m-d H:i:s', strtotime('+' . $pac['validade_dias'] . ' days'));
                }
                // Registra saldo do cliente
                $db->prepare("
                    INSERT INTO clientes_pacotes (cliente_id,pacote_id,venda_id,creditos_total,creditos_usados,creditos_restantes,validade_em)
                    VALUES (?,?,?,?,0,?,?)
                ")->execute([$clienteId,$pacoteId,$vendaId,$creditos,$creditos,$validade]);
            }

            if ($tipo === 'produto' && $produtoId) {
                // Deduz estoque
                $db->prepare("UPDATE produtos SET estoque = MAX(0, estoque - ?) WHERE id=?")
                   ->execute([$qtd, $produtoId]);
            }

            flash('success', 'Venda registrada com sucesso! 🎉');
            header('Location: vendas.php'); exit;
        }
    }

    if ($acao === 'cancelar_venda') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            // Busca venda
            $v = $db->query("SELECT * FROM vendas WHERE id=$id")->fetch();
            if ($v) {
                // Reverte estoque produto
                if ($v['tipo'] === 'produto' && $v['produto_id']) {
                    $db->prepare("UPDATE produtos SET estoque = estoque + ? WHERE id=?")
                       ->execute([$v['quantidade'], $v['produto_id']]);
                }
                // Desativa saldo de pacote
                if ($v['tipo'] === 'pacote') {
                    $db->prepare("UPDATE clientes_pacotes SET ativo=0 WHERE venda_id=?")
                       ->execute([$id]);
                }
                $db->prepare("DELETE FROM vendas WHERE id=?")->execute([$id]);
                flash('warning', 'Venda cancelada e estoque revertido.');
            }
        }
        header('Location: vendas.php'); exit;
    }
}

// ── FILTROS ──
$filtroTipo   = $_GET['ftipo']   ?? '';
$filtroPgto   = $_GET['fpgto']   ?? '';
$filtroBusca  = trim($_GET['busca'] ?? '');
$porPag       = 20;
$pagina       = max(1, (int)($_GET['pag'] ?? 1));
$offset       = ($pagina - 1) * $porPag;

$where  = [];
$params = [];
if ($filtroTipo)  { $where[] = "v.tipo=?";             $params[] = $filtroTipo; }
if ($filtroPgto)  { $where[] = "v.forma_pagamento=?";  $params[] = $filtroPgto; }
if ($filtroBusca) {
    $where[]  = "(c.nome LIKE ? OR c.telefone LIKE ?)";
    $params[] = "%$filtroBusca%";
    $params[] = "%$filtroBusca%";
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$totalR = $db->prepare("
    SELECT COUNT(*) FROM vendas v
    JOIN clientes c ON c.id=v.cliente_id
    $whereSql
");
$totalR->execute($params);
$total    = (int)$totalR->fetchColumn();
$totalPags = max(1, ceil($total / $porPag));
$pagina   = min($pagina, $totalPags);
$offset   = ($pagina - 1) * $porPag;

$vendas = $db->prepare("
    SELECT v.*,
           c.nome  AS cliente_nome,
           c.telefone AS cliente_tel,
           p.nome  AS pacote_nome,
           pr.nome AS produto_nome,
           u.nome  AS vendedor_nome
    FROM vendas v
    JOIN clientes c ON c.id = v.cliente_id
    LEFT JOIN pacotes  p  ON p.id  = v.pacote_id
    LEFT JOIN produtos pr ON pr.id = v.produto_id
    LEFT JOIN usuarios u  ON u.id  = v.vendedor_id
    $whereSql
    ORDER BY v.criado_em DESC
    LIMIT $porPag OFFSET $offset
");
$vendas->execute($params);
$vendas = $vendas->fetchAll();

// Stats
$statsVendas = $db->query("
    SELECT
        COUNT(*)                                                AS total_vendas,
        COALESCE(SUM(valor_total), 0)                          AS receita_total,
        COALESCE(SUM(CASE WHEN tipo='pacote'  THEN valor_total END), 0) AS rec_pacotes,
        COALESCE(SUM(CASE WHEN tipo='produto' THEN valor_total END), 0) AS rec_produtos,
        COUNT(CASE WHEN DATE(criado_em) = DATE('now') THEN 1 END) AS vendas_hoje
    FROM vendas
")->fetch();

// Dados para o formulário
$clientes = $db->query("SELECT id, nome, telefone FROM clientes ORDER BY nome")->fetchAll();
$pacotes  = $db->query("SELECT id, nome, preco, creditos FROM pacotes WHERE ativo=1 ORDER BY nome")->fetchAll();
$produtos = $db->query("SELECT id, nome, preco, estoque FROM produtos WHERE ativo=1 ORDER BY nome")->fetchAll();

$nomeBarbearia = getConfig('nome_barbearia');

function urlV(array $extra=[]): string {
    $p = array_merge([
        'busca' => $_GET['busca']  ?? '',
        'ftipo' => $_GET['ftipo']  ?? '',
        'fpgto' => $_GET['fpgto']  ?? '',
        'pag'   => $_GET['pag']    ?? 1,
    ], $extra);
    return 'vendas.php?'.http_build_query(array_filter($p, fn($v)=>$v!==''));
}

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Vendas – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
  :root{--primary:#e94560;--sidebar-w:260px}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  .sidebar{position:fixed;top:0;left:0;width:var(--sidebar-w);height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:all .25s;display:flex;align-items:center;
    gap:.75rem;font-size:.95rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  .main-content{margin-left:var(--sidebar-w);min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  /* Stats */
  .stat-card{background:linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.03));
    border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:1.25rem;position:relative;overflow:hidden}
  .stat-card::after{content:'';position:absolute;top:-15px;right:-15px;width:70px;height:70px;border-radius:50%;opacity:.12}
  .stat-card.c1::after{background:#e94560}.stat-card.c2::after{background:#22c55e}
  .stat-card.c3::after{background:#3b82f6}.stat-card.c4::after{background:#f59e0b}
  .stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:.85rem}
  .stat-value{font-size:1.4rem;font-weight:800;color:#fff;line-height:1}
  .stat-label{color:rgba(255,255,255,.5);font-size:.82rem;margin-top:.3rem}

  /* Formulário de venda */
  .venda-form{background:linear-gradient(135deg,rgba(233,69,96,.08),rgba(233,69,96,.03));
    border:1px solid rgba(233,69,96,.2);border-radius:18px;padding:1.5rem;margin-bottom:1.5rem}
  .venda-form-title{font-size:1rem;font-weight:800;color:#fff;margin-bottom:1.25rem;
    display:flex;align-items:center;gap:.6rem}

  .form-ctrl{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
    color:#fff;border-radius:10px;padding:.6rem 1rem;width:100%;font-size:.9rem;transition:.2s}
  .form-ctrl:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(233,69,96,.15);background:rgba(255,255,255,.1)}
  .form-ctrl::placeholder{color:rgba(255,255,255,.3)}
  select.form-ctrl option{background:#1a1a2e;color:#fff}
  .form-lbl{color:rgba(255,255,255,.7);font-size:.85rem;font-weight:600;margin-bottom:.4rem;display:block}

  /* Tipo seletor */
  .tipo-opt{display:flex;gap:.75rem;margin-bottom:1.25rem}
  .tipo-card{flex:1;background:rgba(255,255,255,.04);border:2px solid rgba(255,255,255,.1);
    border-radius:14px;padding:1rem;cursor:pointer;transition:.2s;text-align:center}
  .tipo-card:hover{border-color:rgba(255,255,255,.25)}
  .tipo-card.selected.pacote{border-color:var(--primary);background:rgba(233,69,96,.1)}
  .tipo-card.selected.produto{border-color:#22c55e;background:rgba(34,197,94,.08)}
  .tipo-card i{font-size:1.6rem;display:block;margin-bottom:.4rem}
  .tipo-card.selected.pacote i{color:var(--primary)}
  .tipo-card.selected.produto i{color:#22c55e}
  .tipo-card span{font-size:.85rem;font-weight:700;color:rgba(255,255,255,.65)}
  .tipo-card.selected span{color:#fff}

  /* Preview de valor */
  .valor-preview{background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);
    border-radius:12px;padding:.85rem 1.1rem;display:flex;justify-content:space-between;
    align-items:center;margin-top:.75rem}
  .valor-preview-label{font-size:.8rem;color:rgba(255,255,255,.5)}
  .valor-preview-total{font-size:1.4rem;font-weight:800;color:#4ade80}

  /* Busca cliente */
  .cliente-search-wrap{position:relative}
  .cliente-search-wrap .bi-search{position:absolute;left:.85rem;top:50%;transform:translateY(-50%);
    color:rgba(255,255,255,.3);pointer-events:none}
  .cliente-dropdown{position:absolute;top:110%;left:0;right:0;background:#1a1a2e;
    border:1px solid rgba(255,255,255,.15);border-radius:12px;z-index:999;
    max-height:200px;overflow-y:auto;display:none;box-shadow:0 8px 32px rgba(0,0,0,.5)}
  .cliente-item{padding:.7rem 1rem;cursor:pointer;transition:.15s;display:flex;align-items:center;gap:.75rem}
  .cliente-item:hover{background:rgba(255,255,255,.07)}
  .cliente-item-avatar{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;
    justify-content:center;font-size:.8rem;font-weight:800;flex-shrink:0}
  .cliente-selecionado{background:rgba(233,69,96,.1);border:1px solid rgba(233,69,96,.25);
    border-radius:10px;padding:.6rem 1rem;display:flex;align-items:center;justify-content:space-between;display:none}

  /* Filtros */
  .filtros-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09);
    border-radius:14px;padding:.85rem 1.1rem;margin-bottom:1.25rem}

  /* Tabela vendas */
  .table-card{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09);border-radius:16px;overflow:hidden}
  .venda-row{padding:.85rem 1rem;border-bottom:1px solid rgba(255,255,255,.05);
    display:grid;grid-template-columns:2.2fr 1.4fr 1fr 1fr 1fr 80px;
    gap:.5rem;align-items:center;transition:.15s}
  .venda-row:last-child{border-bottom:none}
  .venda-row:hover{background:rgba(255,255,255,.03)}
  .venda-head{background:rgba(255,255,255,.05);padding:.6rem 1rem;
    display:grid;grid-template-columns:2.2fr 1.4fr 1fr 1fr 1fr 80px;
    gap:.5rem;border-bottom:1px solid rgba(255,255,255,.08);
    font-size:.72rem;color:rgba(255,255,255,.4);font-weight:700;text-transform:uppercase;letter-spacing:.5px}

  .badge-tipo-pac{background:rgba(233,69,96,.15);color:#e94560;border:1px solid rgba(233,69,96,.25);
    border-radius:20px;padding:.15rem .55rem;font-size:.72rem;font-weight:700}
  .badge-tipo-prod{background:rgba(34,197,94,.12);color:#4ade80;border:1px solid rgba(34,197,94,.2);
    border-radius:20px;padding:.15rem .55rem;font-size:.72rem;font-weight:700}
  .badge-pgto{background:rgba(255,255,255,.07);color:rgba(255,255,255,.6);border-radius:20px;
    padding:.12rem .5rem;font-size:.7rem;font-weight:600}

  .btn-cancel-v{background:rgba(239,68,68,.1);border:none;color:#f87171;border-radius:8px;
    padding:.3rem .55rem;font-size:.78rem;cursor:pointer;transition:.2s}
  .btn-cancel-v:hover{background:rgba(239,68,68,.22)}

  /* Modal */
  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.12);border-radius:18px}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08);padding:1.25rem 1.5rem}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08);padding:1rem 1.5rem}
  .modal-title{color:#fff;font-weight:700}
  .btn-close{filter:invert(1) opacity(.5)}

  /* Paginação */
  .pag-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
    color:rgba(255,255,255,.6);border-radius:8px;padding:.3rem .65rem;font-size:.82rem;
    text-decoration:none;transition:.2s;display:inline-flex;align-items:center}
  .pag-btn:hover,.pag-btn.active{background:rgba(233,69,96,.2);border-color:rgba(233,69,96,.4);color:#fff}
  .pag-btn.disabled{opacity:.3;pointer-events:none}

  h4,h5,h6{color:#fff;margin:0}
  .empty-state{text-align:center;padding:3rem 0;color:rgba(255,255,255,.25)}
  .empty-state i{font-size:3rem;display:block;margin-bottom:.75rem}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
    .venda-row,.venda-head{grid-template-columns:1.5fr 1fr 80px}
    .col-hide-sm{display:none}
  }
</style>
</head>
<body>

<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">Vendas</h5>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">
          <?= number_format($statsVendas['vendas_hoje']) ?> hoje ·
          <?= formatMoney($statsVendas['receita_total']) ?> total
        </div>
      </div>
    </div>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- STATS -->
    <div class="row g-2 mb-3">
      <div class="col-6 col-xl-3">
        <div class="stat-card c1">
          <div class="stat-icon" style="background:rgba(233,69,96,.2)"><i class="bi bi-cart-check-fill" style="color:#e94560"></i></div>
          <div class="stat-value"><?= number_format($statsVendas['total_vendas']) ?></div>
          <div class="stat-label">Total de Vendas</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c2">
          <div class="stat-icon" style="background:rgba(34,197,94,.2)"><i class="bi bi-cash-stack" style="color:#22c55e"></i></div>
          <div class="stat-value" style="font-size:1.1rem"><?= formatMoney($statsVendas['receita_total']) ?></div>
          <div class="stat-label">Receita Total</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c3">
          <div class="stat-icon" style="background:rgba(59,130,246,.2)"><i class="bi bi-ticket-perforated-fill" style="color:#3b82f6"></i></div>
          <div class="stat-value" style="font-size:1.1rem"><?= formatMoney($statsVendas['rec_pacotes']) ?></div>
          <div class="stat-label">Receita Pacotes</div>
        </div>
      </div>
      <div class="col-6 col-xl-3">
        <div class="stat-card c4">
          <div class="stat-icon" style="background:rgba(245,158,11,.2)"><i class="bi bi-bag-fill" style="color:#f59e0b"></i></div>
          <div class="stat-value" style="font-size:1.1rem"><?= formatMoney($statsVendas['rec_produtos']) ?></div>
          <div class="stat-label">Receita Produtos</div>
        </div>
      </div>
    </div>

    <!-- ═══ FORMULÁRIO NOVA VENDA ═══ -->
    <div class="venda-form">
      <div class="venda-form-title">
        <i class="bi bi-cart-plus-fill" style="color:var(--primary)"></i>
        Registrar Nova Venda
      </div>
      <form method="POST" id="formVenda">
        <input type="hidden" name="acao" value="registrar_venda">
        <input type="hidden" name="tipo" id="inputTipo" value="<?= htmlspecialchars($preType ?: 'pacote') ?>">
        <input type="hidden" name="cliente_id" id="inputClienteId" value="">

        <!-- 1. Tipo -->
        <div class="mb-3">
          <label class="form-lbl">1. O que deseja vender?</label>
          <div class="tipo-opt">
            <div class="tipo-card pacote <?= (!$preType || $preType==='pacote') ? 'selected' : '' ?>"
                 onclick="selecionarTipo('pacote')">
              <i class="bi bi-ticket-perforated-fill"></i>
              <span>Pacote de Cortes</span>
            </div>
            <div class="tipo-card produto <?= $preType==='produto' ? 'selected' : '' ?>"
                 onclick="selecionarTipo('produto')">
              <i class="bi bi-bag-fill"></i>
              <span>Produto</span>
            </div>
          </div>
        </div>

        <!-- 2. Cliente -->
        <div class="mb-3">
          <label class="form-lbl">2. Selecionar Cliente</label>
          <div class="cliente-search-wrap" id="clienteSearchWrap">
            <i class="bi bi-search" style="position:absolute;left:.85rem;top:50%;transform:translateY(-50%);color:rgba(255,255,255,.3)"></i>
            <input type="text" id="buscaCliente" class="form-ctrl" autocomplete="off"
                   style="padding-left:2.4rem"
                   placeholder="Digite o nome ou telefone do cliente…">
            <div class="cliente-dropdown" id="clienteDropdown"></div>
          </div>
          <div class="cliente-selecionado" id="clienteSelecionado">
            <div style="display:flex;align-items:center;gap:.75rem">
              <div id="clienteAvatar" style="width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:800;background:rgba(233,69,96,.2);color:#e94560;flex-shrink:0"></div>
              <div>
                <div id="clienteNomeLabel" style="font-weight:700;color:#fff;font-size:.9rem"></div>
                <div id="clienteTelLabel"  style="font-size:.75rem;color:rgba(255,255,255,.4)"></div>
              </div>
            </div>
            <button type="button" onclick="limparCliente()"
              style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);
                     color:#f87171;border-radius:8px;padding:.3rem .65rem;font-size:.8rem;cursor:pointer">
              <i class="bi bi-x-lg"></i> Trocar
            </button>
          </div>
        </div>

        <!-- 3. Item -->
        <div class="row g-3 mb-3">
          <!-- Pacotes -->
          <div class="col-12 col-md-6" id="secaoPacote">
            <label class="form-lbl">3. Selecionar Pacote</label>
            <select name="pacote_id" id="selectPacote" class="form-ctrl"
                    onchange="atualizarValorPacote()">
              <option value="">— Escolha um pacote —</option>
              <?php foreach ($pacotes as $p): ?>
                <option value="<?= $p['id'] ?>"
                        data-preco="<?= $p['preco'] ?>"
                        data-creditos="<?= $p['creditos'] ?>"
                        <?= $prePacId===$p['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($p['nome']) ?> — <?= formatMoney($p['preco']) ?> (<?= $p['creditos'] ?> créditos)
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <!-- Produtos -->
          <div class="col-12 col-md-6" id="secaoProduto" style="display:none">
            <label class="form-lbl">3. Selecionar Produto</label>
            <select name="produto_id" id="selectProduto" class="form-ctrl"
                    onchange="atualizarValorProduto()">
              <option value="">— Escolha um produto —</option>
              <?php foreach ($produtos as $p): ?>
                <option value="<?= $p['id'] ?>"
                        data-preco="<?= $p['preco'] ?>"
                        data-estoque="<?= $p['estoque'] ?>"
                        <?= $prePrdId===$p['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($p['nome']) ?> — <?= formatMoney($p['preco']) ?>
                  <?php if ($p['estoque'] > 0): ?>(<?= $p['estoque'] ?> em estoque)<?php else: ?>(SEM ESTOQUE)<?php endif; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-6 col-md-3">
            <label class="form-lbl">Quantidade</label>
            <input type="number" name="quantidade" id="inputQtd" class="form-ctrl"
                   min="1" value="1" onchange="calcularTotal()">
          </div>
          <div class="col-6 col-md-3">
            <label class="form-lbl">Valor Unit. (R$)</label>
            <input type="text" name="valor_unitario" id="inputValorUnit" class="form-ctrl"
                   placeholder="0,00" oninput="calcularTotal()">
          </div>
        </div>

        <!-- Preview total -->
        <div class="valor-preview mb-3" id="valorPreview" style="display:none">
          <div>
            <div class="valor-preview-label">Total da Venda</div>
            <div style="font-size:.75rem;color:rgba(255,255,255,.3)" id="previewDesc"></div>
          </div>
          <div class="valor-preview-total" id="valorTotalLabel">R$ 0,00</div>
        </div>

        <!-- 4. Pagamento + Obs -->
        <div class="row g-3 mb-3">
          <div class="col-12 col-md-6">
            <label class="form-lbl">4. Forma de Pagamento</label>
            <select name="forma_pagamento" class="form-ctrl">
              <option value="dinheiro">💵 Dinheiro</option>
              <option value="pix">📲 PIX</option>
              <option value="debito">💳 Débito</option>
              <option value="credito">💳 Crédito</option>
            </select>
          </div>
          <div class="col-12 col-md-6">
            <label class="form-lbl">Observações</label>
            <input type="text" name="observacoes" class="form-ctrl" placeholder="Opcional…">
          </div>
        </div>

        <button type="submit" id="btnRegistrar"
          style="background:linear-gradient(135deg,var(--primary),#c41230);border:none;
                 color:#fff;border-radius:12px;padding:.7rem 1.75rem;font-weight:800;
                 font-size:.95rem;cursor:pointer;transition:opacity .2s;
                 display:flex;align-items:center;gap:.5rem">
          <i class="bi bi-check2-circle"></i> Registrar Venda
        </button>
      </form>
    </div>

    <!-- ═══ FILTROS ═══ -->
    <div class="filtros-card">
      <form method="GET" class="d-flex gap-2 flex-wrap align-items-center">
        <input type="text" name="busca" class="form-ctrl" style="max-width:220px"
               placeholder="Buscar cliente…" value="<?= htmlspecialchars($filtroBusca) ?>">
        <select name="ftipo" class="form-ctrl" style="max-width:160px">
          <option value="">Todos os tipos</option>
          <option value="pacote"  <?= $filtroTipo==='pacote'  ? 'selected':'' ?>>Pacotes</option>
          <option value="produto" <?= $filtroTipo==='produto' ? 'selected':'' ?>>Produtos</option>
        </select>
        <select name="fpgto" class="form-ctrl" style="max-width:160px">
          <option value="">Qualquer pagamento</option>
          <option value="pix"      <?= $filtroPgto==='pix'      ? 'selected':'' ?>>PIX</option>
          <option value="dinheiro" <?= $filtroPgto==='dinheiro' ? 'selected':'' ?>>Dinheiro</option>
          <option value="debito"   <?= $filtroPgto==='debito'   ? 'selected':'' ?>>Débito</option>
          <option value="credito"  <?= $filtroPgto==='credito'  ? 'selected':'' ?>>Crédito</option>
        </select>
        <button type="submit"
          style="background:var(--primary);border:none;color:#fff;border-radius:9px;
                 padding:.55rem 1.1rem;font-weight:700;font-size:.88rem;cursor:pointer">
          <i class="bi bi-funnel-fill me-1"></i>Filtrar
        </button>
        <?php if ($filtroTipo || $filtroPgto || $filtroBusca): ?>
        <a href="vendas.php"
           style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
                  color:rgba(255,255,255,.6);border-radius:9px;padding:.55rem .9rem;
                  font-size:.88rem;text-decoration:none">
          <i class="bi bi-x-lg"></i> Limpar
        </a>
        <?php endif; ?>
        <span style="font-size:.78rem;color:rgba(255,255,255,.3);margin-left:auto">
          <?= $total ?> registro<?= $total!==1?'s':'' ?>
        </span>
      </form>
    </div>

    <!-- ═══ TABELA ═══ -->
    <div class="table-card">
      <div class="venda-head">
        <div>Cliente</div>
        <div>Item</div>
        <div class="col-hide-sm">Valor</div>
        <div class="col-hide-sm">Pagamento</div>
        <div class="col-hide-sm">Data</div>
        <div style="text-align:center">Ação</div>
      </div>

      <?php if (empty($vendas)): ?>
        <div class="empty-state">
          <i class="bi bi-cart-x"></i>
          Nenhuma venda encontrada.
        </div>
      <?php else: ?>
        <?php foreach ($vendas as $v):
          $cores = ['#e94560','#3b82f6','#22c55e','#f59e0b','#8b5cf6','#06b6d4','#f97316','#ec4899'];
          $cor = $cores[abs(crc32($v['cliente_nome'])) % count($cores)];
          $inic = mb_strtoupper(mb_substr($v['cliente_nome'],0,1));
        ?>
        <div class="venda-row">
          <!-- Cliente -->
          <div class="d-flex align-items-center gap-2">
            <div style="width:34px;height:34px;border-radius:50%;flex-shrink:0;background:<?=$cor?>22;border:2px solid <?=$cor?>55;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:800;color:<?=$cor?>">
              <?= $inic ?>
            </div>
            <div style="min-width:0">
              <div style="font-weight:600;color:#fff;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                <?= htmlspecialchars($v['cliente_nome']) ?>
              </div>
              <div style="font-size:.73rem;color:rgba(255,255,255,.35)"><?= htmlspecialchars($v['cliente_tel']) ?></div>
            </div>
          </div>
          <!-- Item -->
          <div>
            <div style="font-size:.85rem;color:#fff;font-weight:600">
              <?= htmlspecialchars($v['tipo']==='pacote' ? ($v['pacote_nome']??'—') : ($v['produto_nome']??'—')) ?>
            </div>
            <div style="display:flex;gap:.35rem;margin-top:.2rem;flex-wrap:wrap">
              <?php if ($v['tipo']==='pacote'): ?>
                <span class="badge-tipo-pac"><i class="bi bi-ticket-perforated me-1"></i>Pacote</span>
              <?php else: ?>
                <span class="badge-tipo-prod"><i class="bi bi-bag me-1"></i>Produto</span>
              <?php endif; ?>
              <?php if ($v['quantidade'] > 1): ?>
                <span style="background:rgba(255,255,255,.07);color:rgba(255,255,255,.5);border-radius:20px;padding:.12rem .5rem;font-size:.7rem">x<?= $v['quantidade'] ?></span>
              <?php endif; ?>
            </div>
          </div>
          <!-- Valor -->
          <div class="col-hide-sm">
            <div style="font-weight:800;color:#4ade80"><?= formatMoney($v['valor_total']) ?></div>
            <?php if ($v['quantidade']>1): ?>
            <div style="font-size:.72rem;color:rgba(255,255,255,.3)"><?= formatMoney($v['valor_unitario']) ?>/un</div>
            <?php endif; ?>
          </div>
          <!-- Pagamento -->
          <div class="col-hide-sm">
            <span class="badge-pgto">
              <?php $pgIcons=['pix'=>'📲','dinheiro'=>'💵','debito'=>'💳','credito'=>'💳']; ?>
              <?= ($pgIcons[$v['forma_pagamento']] ?? '') ?> <?= ucfirst($v['forma_pagamento']) ?>
            </span>
          </div>
          <!-- Data -->
          <div class="col-hide-sm" style="font-size:.8rem;color:rgba(255,255,255,.45)">
            <?= date('d/m/y H:i', strtotime($v['criado_em'])) ?>
            <?php if ($v['vendedor_nome']): ?>
              <div style="font-size:.7rem;color:rgba(255,255,255,.25)">por <?= htmlspecialchars($v['vendedor_nome']) ?></div>
            <?php endif; ?>
          </div>
          <!-- Cancelar -->
          <div style="text-align:center">
            <form method="POST" onsubmit="return confirm('Cancelar esta venda? O estoque será revertido.')">
              <input type="hidden" name="acao" value="cancelar_venda">
              <input type="hidden" name="id"   value="<?= $v['id'] ?>">
              <button type="submit" class="btn-cancel-v" title="Cancelar venda">
                <i class="bi bi-x-circle-fill"></i>
              </button>
            </form>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- PAGINAÇÃO -->
    <?php if ($totalPags > 1): ?>
    <div class="d-flex align-items-center gap-1 flex-wrap mt-3">
      <a href="<?= urlV(['pag'=>$pagina-1]) ?>" class="pag-btn <?= $pagina<=1?'disabled':'' ?>"><i class="bi bi-chevron-left"></i></a>
      <?php for ($i=max(1,$pagina-2); $i<=min($totalPags,$pagina+2); $i++): ?>
        <a href="<?= urlV(['pag'=>$i]) ?>" class="pag-btn <?= $i===$pagina?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
      <a href="<?= urlV(['pag'=>$pagina+1]) ?>" class="pag-btn <?= $pagina>=$totalPags?'disabled':'' ?>"><i class="bi bi-chevron-right"></i></a>
      <span style="font-size:.78rem;color:rgba(255,255,255,.3);margin-left:.5rem">
        Página <?= $pagina ?>/<?= $totalPags ?>
      </span>
    </div>
    <?php endif; ?>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// ── Tipo ──
function selecionarTipo(tipo) {
  document.getElementById('inputTipo').value = tipo;
  document.querySelectorAll('.tipo-card').forEach(el => el.classList.remove('selected'));
  document.querySelector('.tipo-card.'+tipo).classList.add('selected');
  document.getElementById('secaoPacote').style.display  = tipo==='pacote'  ? '' : 'none';
  document.getElementById('secaoProduto').style.display = tipo==='produto' ? '' : 'none';
  document.getElementById('inputValorUnit').value = '';
  document.getElementById('valorPreview').style.display = 'none';
  if (tipo==='pacote')  atualizarValorPacote();
  if (tipo==='produto') atualizarValorProduto();
}

// Init tipo
selecionarTipo(document.getElementById('inputTipo').value || 'pacote');

// ── Valor pacote ──
function atualizarValorPacote() {
  const sel = document.getElementById('selectPacote');
  const opt = sel.options[sel.selectedIndex];
  if (!opt || !opt.value) { document.getElementById('valorPreview').style.display='none'; return; }
  const preco = parseFloat(opt.dataset.preco) || 0;
  document.getElementById('inputValorUnit').value = preco.toFixed(2).replace('.',',');
  calcularTotal();
}

// ── Valor produto ──
function atualizarValorProduto() {
  const sel = document.getElementById('selectProduto');
  const opt = sel.options[sel.selectedIndex];
  if (!opt || !opt.value) { document.getElementById('valorPreview').style.display='none'; return; }
  const preco = parseFloat(opt.dataset.preco) || 0;
  document.getElementById('inputValorUnit').value = preco.toFixed(2).replace('.',',');
  calcularTotal();
}

// ── Total ──
function calcularTotal() {
  const raw  = document.getElementById('inputValorUnit').value.replace(',','.');
  const unit = parseFloat(raw) || 0;
  const qtd  = parseInt(document.getElementById('inputQtd').value) || 1;
  const total = unit * qtd;
  if (unit > 0) {
    document.getElementById('valorPreview').style.display = '';
    document.getElementById('valorTotalLabel').textContent =
      'R$ ' + total.toFixed(2).replace('.',',');
    document.getElementById('previewDesc').textContent =
      qtd > 1 ? qtd + 'x R$ ' + unit.toFixed(2).replace('.',',') : '';
  } else {
    document.getElementById('valorPreview').style.display = 'none';
  }
}

// ── Busca cliente ──
const clientesData = <?= json_encode($clientes) ?>;
const cores = ['#e94560','#3b82f6','#22c55e','#f59e0b','#8b5cf6','#06b6d4','#f97316','#ec4899'];
function hashCode(s){let h=0;for(let i=0;i<s.length;i++)h=Math.imul(31,h)+s.charCodeAt(i)|0;return h;}

document.getElementById('buscaCliente').addEventListener('input', function() {
  const q = this.value.toLowerCase().trim();
  const dd = document.getElementById('clienteDropdown');
  if (!q) { dd.style.display='none'; return; }
  const filtered = clientesData.filter(c =>
    c.nome.toLowerCase().includes(q) || c.telefone.includes(q)
  ).slice(0,8);
  if (!filtered.length) { dd.style.display='none'; return; }
  dd.innerHTML = filtered.map(c => {
    const cor  = cores[Math.abs(hashCode(c.nome)) % cores.length];
    const inic = c.nome.charAt(0).toUpperCase();
    return `<div class="cliente-item" onclick="selecionarCliente(${c.id},'${escJs(c.nome)}','${escJs(c.telefone)}','${cor}')">
      <div class="cliente-item-avatar" style="background:${cor}22;color:${cor};border:2px solid ${cor}44">${inic}</div>
      <div>
        <div style="font-weight:600;color:#fff;font-size:.88rem">${escHtml(c.nome)}</div>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)">${escHtml(c.telefone)}</div>
      </div>
    </div>`;
  }).join('');
  dd.style.display = 'block';
});

function selecionarCliente(id, nome, tel, cor) {
  document.getElementById('inputClienteId').value = id;
  document.getElementById('clienteDropdown').style.display = 'none';
  document.getElementById('buscaCliente').value = '';
  document.getElementById('clienteSearchWrap').style.display = 'none';
  const sel = document.getElementById('clienteSelecionado');
  sel.style.display = 'flex';
  const inic = nome.charAt(0).toUpperCase();
  document.getElementById('clienteAvatar').textContent = inic;
  document.getElementById('clienteAvatar').style.background = cor+'22';
  document.getElementById('clienteAvatar').style.color = cor;
  document.getElementById('clienteAvatar').style.border = '2px solid '+cor+'55';
  document.getElementById('clienteNomeLabel').textContent = nome;
  document.getElementById('clienteTelLabel').textContent  = tel;
}

function limparCliente() {
  document.getElementById('inputClienteId').value = '';
  document.getElementById('clienteSelecionado').style.display = 'none';
  document.getElementById('clienteSearchWrap').style.display = '';
}

// Fecha dropdown ao clicar fora
document.addEventListener('click', e => {
  if (!e.target.closest('.cliente-search-wrap'))
    document.getElementById('clienteDropdown').style.display = 'none';
});

function escHtml(s){ if(!s)return''; return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function escJs(s){ return String(s||'').replace(/'/g,"\\'").replace(/\n/g,' '); }

// Init — se veio com pacote/produto pré-selecionado
<?php if ($prePacId): ?>atualizarValorPacote();<?php endif; ?>
<?php if ($prePrdId): ?>atualizarValorProduto();<?php endif; ?>
</script>
</body>
</html>