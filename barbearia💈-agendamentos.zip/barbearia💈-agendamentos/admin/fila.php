<?php
require_once '../config.php';
requireAdmin();
$db = getDB();

// ── Active dinâmico ──
$paginaAtual = basename($_SERVER['PHP_SELF']);

// ── API de busca de clientes (autocomplete) ──
if (isset($_GET['buscar_cliente'])) {
    header('Content-Type: application/json');
    $q = '%' . trim($_GET['buscar_cliente']) . '%';
    $stmt = $db->prepare("
        SELECT c.nome, c.telefone,
               COUNT(f.id) as total_visitas
        FROM clientes c
        LEFT JOIN fila f ON f.cliente_id = c.id AND f.status = 'concluido'
        WHERE c.nome LIKE ? OR c.telefone LIKE ?
        GROUP BY c.id
        ORDER BY total_visitas DESC, c.nome ASC
        LIMIT 8
    ");
    $stmt->execute([$q, $q]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    $id   = (int)($_POST['id'] ?? 0);

    switch ($acao) {

        case 'cancelar':
            // Permite cancelar tanto aguardando quanto atendendo
            $db->prepare("UPDATE fila SET status='cancelado'
                WHERE id=? AND status IN ('aguardando','atendendo')")
               ->execute([$id]);
            flash('success', 'Cliente removido da fila.');
            break;

        case 'iniciar':
            $db->prepare("UPDATE fila SET status='atendendo',
                iniciado_em=CURRENT_TIMESTAMP
                WHERE id=? AND status='aguardando'")
               ->execute([$id]);
            flash('success', 'Atendimento iniciado!');
            break;

        case 'finalizar':
            $valor = (float)str_replace(',', '.', $_POST['valor'] ?? 0);
            $pgto  = $_POST['forma_pagamento'] ?? null;
            if (!in_array($pgto, ['pix','dinheiro','debito','credito'])) $pgto = null;

            $db->prepare("UPDATE fila SET status='concluido', valor=?,
                forma_pagamento=?, finalizado_em=CURRENT_TIMESTAMP
                WHERE id=? AND status='atendendo'")
               ->execute([$valor, $pgto, $id]);

            require_once '../whatsapp/config.php';
            $stmtCli = $db->prepare("SELECT c.nome, c.telefone
                FROM fila f JOIN clientes c ON c.id=f.cliente_id WHERE f.id=?");
            $stmtCli->execute([$id]);
            $cli = $stmtCli->fetch();
            $nomeBarbeariaWa = getConfig('nome_barbearia');
            if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', $nomeBarbeariaWa);
            if ($cli && $valor > 0) {
                $msg     = montarMensagemConclusao($cli['nome'], $valor, $pgto ?? 'dinheiro');
                $keyComp = substr(md5($id . date('Y-m-d')), 0, 8);
                $urlComp = (isset($_SERVER['HTTPS']) ? 'https' : 'http')
                         . '://' . $_SERVER['HTTP_HOST']
                         . BASE_URL . "/comprovante.php?id={$id}&key={$keyComp}";
                $msg .= "\n\n📄 Comprovante: {$urlComp}";
                @enviarWhatsApp($cli['telefone'], $msg);
            }
            $keyLink = substr(md5($id . date('Y-m-d')), 0, 8);
            flash('success', "Atendimento finalizado! <a href='../comprovante.php?id={$id}&key={$keyLink}' target='_blank' class='alert-link'><i class='bi bi-receipt me-1'></i>Ver comprovante</a>");
            break;

        case 'mover':
            $novo_barbeiro = (int)($_POST['novo_barbeiro_id'] ?? 0);
            if ($novo_barbeiro) {
                $stmtPos = $db->prepare("SELECT COALESCE(MAX(posicao),0)+1 as prox
                    FROM fila WHERE barbeiro_id=? AND status='aguardando'");
                $stmtPos->execute([$novo_barbeiro]);
                $novaPosicao = (int)$stmtPos->fetch()['prox'];
                $db->prepare("UPDATE fila SET barbeiro_id=?, posicao=?
                    WHERE id=? AND status='aguardando'")
                   ->execute([$novo_barbeiro, $novaPosicao, $id]);
                flash('success', 'Cliente movido para outro barbeiro!');
            }
            break;

        case 'limpar_fila':
            $barb_id = (int)($_POST['barbeiro_id'] ?? 0);
            if ($barb_id) {
                $db->prepare("UPDATE fila SET status='cancelado'
                    WHERE barbeiro_id=? AND status='aguardando'")
                   ->execute([$barb_id]);
                flash('warning', 'Fila limpa! Todos os clientes em espera foram removidos.');
            }
            break;

        case 'adicionar_cliente':
            $barb_id    = (int)($_POST['barbeiro_id']  ?? 0);
            $servico_id = (int)($_POST['servico_id']   ?? 0) ?: null;
            $nome       = trim($_POST['cliente_nome']  ?? '');
            $telefone   = trim($_POST['cliente_fone']  ?? '');

            if (!$barb_id || !$nome) {
                flash('danger', 'Barbeiro e nome do cliente são obrigatórios.');
                break;
            }

            $stmtC = $db->prepare("SELECT id FROM clientes WHERE telefone=? LIMIT 1");
            $stmtC->execute([$telefone]);
            $cli = $stmtC->fetch();
            if ($cli) {
                $cli_id = $cli['id'];
                $db->prepare("UPDATE clientes SET nome=? WHERE id=?")->execute([$nome, $cli_id]);
            } else {
                $db->prepare("INSERT INTO clientes (nome, telefone) VALUES (?,?)")
                   ->execute([$nome, $telefone]);
                $cli_id = $db->lastInsertId();
            }

            $stmtP = $db->prepare("SELECT COALESCE(MAX(posicao),0)+1 as prox
                FROM fila WHERE barbeiro_id=? AND status='aguardando'");
            $stmtP->execute([$barb_id]);
            $pos = (int)$stmtP->fetch()['prox'];

            $db->prepare("INSERT INTO fila (cliente_id, barbeiro_id, servico_id, posicao, status, criado_em)
                VALUES (?,?,?,?,'aguardando',CURRENT_TIMESTAMP)")
               ->execute([$cli_id, $barb_id, $servico_id, $pos]);

            flash('success', "Cliente <strong>{$nome}</strong> adicionado à fila!");
            break;
    }

    header('Location: fila.php');
    exit;
}

$barbeiros      = $db->query("SELECT * FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();
$todosBarbeiros = $db->query("SELECT id, nome FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();
$servicos       = $db->query("SELECT * FROM servicos WHERE ativo=1 ORDER BY nome")->fetchAll();
$nomeBarbearia  = getConfig('nome_barbearia');
$tempoMedio     = (int)getConfig('tempo_medio_corte') ?: 30;
$alertaMinutos  = 20;

$totalFila = (int)$db->query("SELECT COUNT(*) FROM fila WHERE status IN ('aguardando','atendendo')")->fetchColumn();

function navActive(string $pagina, string $atual): string {
    return $pagina === $atual ? 'nav-link-side active' : 'nav-link-side';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fila Geral – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.php">
<meta name="theme-color" content="#e94560">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Barbearia">
<link rel="apple-touch-icon" href="<?= BASE_URL ?>/icons/icon-192.png">
<style>
  :root{--primary:#e94560}
  *{box-sizing:border-box}
  body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0}

  .sidebar{position:fixed;top:0;left:0;width:260px;height:100vh;
    background:linear-gradient(180deg,#1a1a2e,#16213e);
    border-right:1px solid rgba(255,255,255,.08);z-index:1000;overflow-y:auto;transition:.3s}
  .sidebar-brand{padding:1.5rem 1.25rem;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center}
  .sidebar-brand .icon{width:44px;height:44px;background:linear-gradient(135deg,var(--primary),#c41230);
    border-radius:12px;display:inline-flex;align-items:center;justify-content:center;
    font-size:1.3rem;margin-right:.75rem;flex-shrink:0}
  .nav-link-side{color:rgba(255,255,255,.65);padding:.65rem 1.25rem;border-radius:10px;
    margin:.15rem .75rem;transition:.25s;display:flex;align-items:center;gap:.75rem;text-decoration:none}
  .nav-link-side:hover,.nav-link-side.active{background:rgba(233,69,96,.15);color:#fff}
  .nav-link-side.active{border-left:3px solid var(--primary)}
  .nav-section{font-size:.7rem;font-weight:700;color:rgba(255,255,255,.3);
    padding:.75rem 1.5rem .25rem;text-transform:uppercase;letter-spacing:1px}

  .main-content{margin-left:260px;padding:0;min-height:100vh}
  .topbar{background:rgba(255,255,255,.03);border-bottom:1px solid rgba(255,255,255,.08);
    padding:.85rem 1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.5rem}
  .page-body{padding:1.5rem}

  /* ── Card adicionar cliente ── */
  .add-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);
    border-radius:16px;padding:1.25rem;margin-bottom:1.5rem}
  .add-card-title{font-size:.95rem;font-weight:700;color:#fff;
    display:flex;align-items:center;gap:.5rem;margin-bottom:1rem}
  .form-control-add{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:10px;padding:.5rem .85rem;font-size:.875rem;width:100%}
  .form-control-add:focus{outline:none;border-color:var(--primary);
    background:rgba(255,255,255,.12);box-shadow:0 0 0 .2rem rgba(233,69,96,.2)}
  .form-control-add::placeholder{color:rgba(255,255,255,.35)}
  .form-control-add option{background:#1a1a2e}
  .form-lbl{color:rgba(255,255,255,.65);font-size:.8rem;display:block;margin-bottom:.3rem}
  .btn-add-submit{background:linear-gradient(135deg,#e94560,#c41230);border:none;
    color:#fff;border-radius:10px;padding:.55rem 1.4rem;font-weight:700;
    font-size:.875rem;cursor:pointer;transition:.2s;white-space:nowrap}
  .btn-add-submit:hover{opacity:.9}

  /* ── Autocomplete ── */
  .autocomplete-wrap{position:relative}
  .autocomplete-lista{
    position:absolute;top:calc(100% + 4px);left:0;right:0;
    background:#1a1a2e;border:1px solid rgba(233,69,96,.35);
    border-radius:10px;z-index:999;overflow:hidden;
    box-shadow:0 8px 24px rgba(0,0,0,.5);display:none;
  }
  .autocomplete-lista.aberta{display:block}
  .autocomplete-item{
    padding:.65rem 1rem;cursor:pointer;transition:.15s;
    display:flex;align-items:center;gap:.75rem;
    border-bottom:1px solid rgba(255,255,255,.05);
  }
  .autocomplete-item:last-child{border-bottom:none}
  .autocomplete-item:hover,.autocomplete-item.ativo{background:rgba(233,69,96,.15)}
  .autocomplete-avatar{
    width:32px;height:32px;border-radius:50%;
    background:linear-gradient(135deg,#e94560,#c41230);
    display:flex;align-items:center;justify-content:center;
    flex-shrink:0;font-size:.8rem;font-weight:700;color:#fff;
  }
  .autocomplete-nome{font-weight:600;color:#fff;font-size:.88rem}
  .autocomplete-tel{font-size:.75rem;color:rgba(255,255,255,.45);margin-top:.1rem}
  .autocomplete-visitas{
    margin-left:auto;background:rgba(255,255,255,.08);
    border-radius:20px;padding:.15rem .5rem;
    font-size:.7rem;color:rgba(255,255,255,.45);
    white-space:nowrap;flex-shrink:0;
  }
  .autocomplete-novo{
    padding:.65rem 1rem;cursor:pointer;
    color:rgba(255,255,255,.5);font-size:.83rem;
    display:flex;align-items:center;gap:.5rem;transition:.15s;
  }
  .autocomplete-novo:hover{background:rgba(255,255,255,.05);color:#fff}
  .autocomplete-loading{
    padding:.65rem 1rem;color:rgba(255,255,255,.4);
    font-size:.83rem;display:flex;align-items:center;gap:.5rem;
  }
  .badge-novo{
    background:rgba(34,197,94,.2);color:#4ade80;
    border-radius:20px;padding:.15rem .55rem;font-size:.7rem;font-weight:700;
    flex-shrink:0;
  }

  /* ── Cards de barbeiro expansíveis ── */
  .barb-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);
    border-radius:16px;margin-bottom:.85rem;overflow:hidden;transition:.2s}
  .barb-card:last-child{margin-bottom:0}
  .barb-card-header{display:flex;align-items:center;gap:1rem;padding:1.1rem 1.25rem;
    cursor:pointer;user-select:none;transition:.2s}
  .barb-card-header:hover{background:rgba(255,255,255,.03)}
  .barb-avatar{width:50px;height:50px;border-radius:50%;object-fit:cover;
    border:2px solid rgba(233,69,96,.4);flex-shrink:0}
  .barb-avatar-ph{width:50px;height:50px;border-radius:50%;
    background:linear-gradient(135deg,#e94560,#c41230);
    display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .barb-info-nome{font-weight:700;color:#fff;font-size:1rem}
  .barb-badges{display:flex;align-items:center;gap:.5rem;margin-top:.3rem;flex-wrap:wrap}
  .badge-fila{border-radius:7px;padding:.2rem .65rem;font-size:.78rem;font-weight:700}
  .badge-aguard{background:rgba(245,158,11,.2);color:#fbbf24}
  .badge-atend{background:rgba(34,197,94,.2);color:#4ade80}
  .badge-vazia{background:rgba(255,255,255,.07);color:rgba(255,255,255,.4)}
  .chevron{font-size:.9rem;color:rgba(255,255,255,.35);transition:.3s;flex-shrink:0}
  .chevron.open{transform:rotate(180deg)}
  .barb-body{display:none;padding:0 1.25rem 1.25rem;border-top:1px solid rgba(255,255,255,.06)}
  .barb-body.open{display:block}

  .cliente-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);
    border-radius:12px;padding:.9rem;margin-bottom:.55rem;transition:.2s}
  .cliente-card:last-child{margin-bottom:0}
  .cliente-card.atendendo{border-color:rgba(34,197,94,.4);background:rgba(34,197,94,.07)}
  .cliente-card.alerta{border-color:rgba(245,158,11,.55)!important;
    background:rgba(245,158,11,.07)!important;
    animation:pulseAlerta 2s ease-in-out infinite}
  @keyframes pulseAlerta{
    0%,100%{box-shadow:0 0 0 0 rgba(245,158,11,.25)}
    50%{box-shadow:0 0 0 6px rgba(245,158,11,.0)}
  }
  .pos-badge{width:34px;height:34px;background:rgba(233,69,96,.2);color:#e94560;
    border-radius:50%;display:flex;align-items:center;justify-content:center;
    font-weight:800;font-size:.9rem;flex-shrink:0}
  .pos-badge.atd{background:rgba(34,197,94,.2);color:#4ade80}
  .pos-badge.alerta{background:rgba(245,158,11,.25);color:#fbbf24}
  .cronometro{font-size:.72rem;font-weight:700;border-radius:6px;
    padding:.2rem .55rem;display:inline-flex;align-items:center;gap:.3rem}
  .cronometro.esperando{background:rgba(255,255,255,.08);color:rgba(255,255,255,.5)}
  .cronometro.atendendo{background:rgba(34,197,94,.15);color:#4ade80}
  .cronometro.alerta{background:rgba(245,158,11,.2);color:#fbbf24}

  .btn-ac{border:none;border-radius:8px;padding:.35rem .7rem;
    font-size:.8rem;cursor:pointer;transition:.2s;display:inline-flex;align-items:center;gap:.3rem}
  .btn-iniciar{background:rgba(34,197,94,.2);color:#4ade80}
  .btn-iniciar:hover{background:rgba(34,197,94,.35)}
  .btn-finalizar{background:rgba(233,69,96,.2);color:#f87171}
  .btn-finalizar:hover{background:rgba(233,69,96,.35)}
  .btn-mover{background:rgba(59,130,246,.2);color:#60a5fa}
  .btn-mover:hover{background:rgba(59,130,246,.35)}
  .btn-cancelar{background:rgba(239,68,68,.15);color:#f87171}
  .btn-cancelar:hover{background:rgba(239,68,68,.3)}
  .btn-limpar-fila{background:rgba(245,158,11,.15);color:#fbbf24;
    border:1px solid rgba(245,158,11,.25);border-radius:8px;padding:.3rem .65rem;
    font-size:.78rem;cursor:pointer;transition:.2s}
  .btn-limpar-fila:hover{background:rgba(245,158,11,.3)}

  .form-finalizar{background:rgba(255,255,255,.04);border-radius:10px;
    padding:.75rem;margin-top:.6rem}
  .form-control-dark{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:8px;padding:.4rem .7rem;font-size:.85rem;width:100%}
  .form-control-dark:focus{outline:none;border-color:var(--primary);
    box-shadow:0 0 0 .2rem rgba(233,69,96,.2)}
  .form-control-dark::placeholder{color:rgba(255,255,255,.35)}
  .pgto-opt{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);
    color:rgba(255,255,255,.65);border-radius:7px;padding:.3rem .6rem;
    font-size:.78rem;cursor:pointer;transition:.2s}
  .pgto-opt:hover,.pgto-opt.sel{background:rgba(233,69,96,.2);
    border-color:var(--primary);color:#fff}
  .pgto-opt input{display:none}
  .btn-conf-finalizar{background:linear-gradient(135deg,#e94560,#c41230);
    border:none;color:#fff;border-radius:8px;padding:.45rem;
    font-size:.85rem;font-weight:600;width:100%;cursor:pointer;margin-top:.5rem}
  .btn-conf-finalizar:hover{opacity:.9}

  .modal-content{background:#1a1a2e;border:1px solid rgba(255,255,255,.1)}
  .modal-header{border-bottom:1px solid rgba(255,255,255,.08)}
  .modal-footer{border-top:1px solid rgba(255,255,255,.08)}
  .modal-title{color:#fff}
  .form-select-dark{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#fff;border-radius:10px;padding:.5rem .85rem;width:100%}
  .form-select-dark option{background:#1a1a2e}
  .form-select-dark:focus{border-color:var(--primary);
    box-shadow:0 0 0 .25rem rgba(233,69,96,.2);outline:none}

  .fila-vazia{text-align:center;padding:1.75rem 0;color:rgba(255,255,255,.3)}
  h4,h5,h6{color:#fff;margin:0}
  #relogio{font-size:.85rem;color:rgba(255,255,255,.5);font-variant-numeric:tabular-nums}

  @media(max-width:768px){
    .sidebar{transform:translateX(-100%)}
    .sidebar.open{transform:translateX(0)}
    .main-content{margin-left:0}
    .page-body{padding:1rem}
  }
</style>
</head>
<body>

<nav class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <span class="icon"><i class="bi bi-scissors text-white"></i></span>
    <div>
      <div style="color:#fff;font-weight:800;font-size:.92rem;line-height:1.2"><?= htmlspecialchars($nomeBarbearia) ?></div>
      <div style="color:rgba(255,255,255,.32);font-size:.68rem">Admin</div>
    </div>
  </div>
  <div class="pt-2 pb-4">
    <div class="nav-section">Principal</div>
    <a href="dashboard.php"    class="<?= navActive('dashboard.php',    $paginaAtual) ?>"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="fila.php"         class="<?= navActive('fila.php',         $paginaAtual) ?>"><i class="bi bi-list-ol"></i>Fila Geral</a>
    <a href="agendamentos.php" class="<?= navActive('agendamentos.php', $paginaAtual) ?>"><i class="bi bi-calendar3"></i>Agendamentos</a>
    <div class="nav-section">Gestão</div>
    <a href="barbeiros.php"           class="<?= navActive('barbeiros.php',           $paginaAtual) ?>"><i class="bi bi-people-fill"></i>Barbeiros</a>
    <a href="assistentes.php"         class="<?= navActive('assistentes.php',         $paginaAtual) ?>"><i class="bi bi-person-badge"></i>Assistentes</a>
    <a href="servicos.php"            class="<?= navActive('servicos.php',            $paginaAtual) ?>"><i class="bi bi-scissors"></i>Serviços</a>
    <a href="clientes_cadastrados.php" class="<?= navActive('clientes_cadastrados.php',$paginaAtual) ?>"><i class="bi bi-people"></i>Clientes</a>
    <a href="pacotes_produtos.php"    class="<?= navActive('pacotes_produtos.php',    $paginaAtual) ?>"><i class="bi bi-box-seam-fill"></i>Pacotes & Créditos</a>
    <a href="produtos.php"            class="<?= navActive('produtos.php',            $paginaAtual) ?>"><i class="bi bi-bag-fill"></i>Produtos p/ Venda</a>
    <a href="vendas.php"              class="<?= navActive('vendas.php',              $paginaAtual) ?>"><i class="bi bi-cart-fill"></i>Vendas</a>
    <a href="comprovantes.php"        class="<?= navActive('comprovantes.php',        $paginaAtual) ?>"><i class="bi bi-receipt"></i>Comprovantes</a>
    <a href="pedidos.php"             class="<?= navActive('pedidos.php',             $paginaAtual) ?>"><i class="bi bi-bag-check-fill"></i>Pedidos Online</a>
    <div class="nav-section">Marketing & Relatórios</div>
    <a href="relatorios.php"          class="<?= navActive('relatorios.php',          $paginaAtual) ?>"><i class="bi bi-graph-up"></i>Relatórios</a>
    <a href="historico.php"           class="<?= navActive('historico.php',           $paginaAtual) ?>"><i class="bi bi-clock-history"></i>Histórico</a>
    <a href="promocoes.php"           class="<?= navActive('promocoes.php',           $paginaAtual) ?>"><i class="bi bi-megaphone-fill"></i>Promoções</a>
    <a href="whatsapp_clientes.php"   class="<?= navActive('whatsapp_clientes.php',   $paginaAtual) ?>"><i class="bi bi-whatsapp"></i>WhatsApp</a>
    <div class="nav-section">Financeiro</div>
    <a href="caixa.php"               class="<?= navActive('caixa.php',               $paginaAtual) ?>"><i class="bi bi-cash-stack"></i>Caixa</a>
    <a href="metas.php"               class="<?= navActive('metas.php',               $paginaAtual) ?>"><i class="bi bi-bullseye"></i>Metas</a>
    <div class="nav-section">Sistema</div>
    <a href="feriados.php"             class="<?= navActive('feriados.php',            $paginaAtual) ?>"><i class="bi bi-calendar-x-fill"></i>Feriados & Folgas</a>
    <a href="notificacoes.php"         class="<?= navActive('notificacoes.php',        $paginaAtual) ?>"><i class="bi bi-bell-fill"></i>Notificações</a>
    <a href="backup.php"               class="<?= navActive('backup.php',              $paginaAtual) ?>"><i class="bi bi-cloud-arrow-down-fill"></i>Backup</a>
    <a href="pwa.php"                  class="<?= navActive('pwa.php',                 $paginaAtual) ?>"><i class="bi bi-phone-fill"></i>PWA & Ícones</a>
    <a href="configuracoes.php"        class="<?= navActive('configuracoes.php',       $paginaAtual) ?>"><i class="bi bi-gear-fill"></i>Configurações</a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link-side mt-3" style="color:#f87171"><i class="bi bi-box-arrow-left"></i>Sair</a>
  </div>
</nav>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div id="sidebarBackdrop" class="sidebar-backdrop"></div>
<div class="main-content">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="btn btn-sm d-md-none" id="btnMenuMobile"
        style="background:rgba(255,255,255,.1);color:#fff;border:none;border-radius:8px;padding:.4rem .65rem">
        <i class="bi bi-list fs-5"></i>
      </button>
      <div>
        <h5 class="fw-bold" style="font-size:1rem">
          <i class="bi bi-list-ol me-2" style="color:#e94560"></i>Fila em Tempo Real
        </h5>
        <div style="font-size:.72rem;color:rgba(255,255,255,.4)">
          <?= $totalFila ?> cliente(s) na fila · atualiza a cada 60s
        </div>
      </div>
    </div>
    <div id="relogio"></div>
  </div>

  <div class="page-body">
    <?= renderFlash() ?>

    <!-- ── Card de adicionar cliente ── -->
    <div class="add-card">
      <div class="add-card-title">
        <i class="bi bi-person-plus-fill" style="color:#e94560"></i>
        Adicionar Cliente à Fila
      </div>
      <form method="POST" id="formAddCliente">
        <input type="hidden" name="acao" value="adicionar_cliente">
        <div class="row g-2 align-items-end">

          <!-- Nome com autocomplete -->
          <div class="col-12 col-sm-6 col-md-3">
            <label class="form-lbl">Nome do cliente *</label>
            <div class="autocomplete-wrap">
              <input type="text" name="cliente_nome" id="inputNome"
                class="form-control-add" placeholder="Digite o nome..." required
                autocomplete="off">
              <div class="autocomplete-lista" id="listaAuto"></div>
            </div>
          </div>

          <!-- Telefone -->
          <div class="col-12 col-sm-6 col-md-3">
            <label class="form-lbl">
              Telefone / WhatsApp
              <span id="telAutoTag" style="display:none;background:rgba(34,197,94,.2);
                color:#4ade80;border-radius:20px;padding:.1rem .5rem;font-size:.7rem;
                margin-left:.3rem;font-weight:700">
                <i class="bi bi-check2"></i> preenchido
              </span>
            </label>
            <input type="tel" name="cliente_fone" id="inputTel"
              class="form-control-add" placeholder="(00) 00000-0000">
          </div>

          <!-- Barbeiro -->
          <div class="col-12 col-sm-6 col-md-2">
            <label class="form-lbl">Barbeiro *</label>
            <select name="barbeiro_id" class="form-control-add" required>
              <option value="">– Selecione –</option>
              <?php foreach($todosBarbeiros as $tb): ?>
              <option value="<?= $tb['id'] ?>"><?= htmlspecialchars($tb['nome']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Botão -->
          <div class="col-12 col-md-2">
  <button type="submit" class="btn-add-submit w-100">
    <i class="bi bi-plus-lg me-1"></i>Adicionar
  </button>
</div>

        </div>
      </form>
    </div>

    <!-- ── Cards expansíveis por barbeiro ── -->
    <?php foreach($barbeiros as $b):
      $filaB = $db->prepare("
          SELECT f.*, c.nome as cliente_nome, c.telefone,
                 s.nome as servico_nome, s.preco as servico_preco
          FROM fila f
          JOIN clientes c ON c.id=f.cliente_id
          LEFT JOIN servicos s ON s.id=f.servico_id
          WHERE f.barbeiro_id=? AND f.status IN ('aguardando','atendendo')
          ORDER BY f.status DESC, f.criado_em ASC
      ");
      $filaB->execute([$b['id']]);
      $clientes = $filaB->fetchAll();

      $temFoto = !empty($b['foto']) && file_exists(__DIR__.'/../uploads/barbeiros/'.$b['foto']);
      $fotoUrl = $temFoto ? BASE_URL . '/uploads/barbeiros/'.htmlspecialchars($b['foto']) : null;

      $qtdAguard = count(array_filter($clientes, fn($c) => $c['status']==='aguardando'));
      $qtdAtend  = count(array_filter($clientes, fn($c) => $c['status']==='atendendo'));
      $qtdTotal  = count($clientes);

      $temAlerta = false;
      foreach($clientes as $c) {
          if ($c['status']==='aguardando' && $c['criado_em']) {
              $mins = (int)floor((time() - strtotime($c['criado_em'])) / 60);
              if ($mins >= $alertaMinutos) { $temAlerta = true; break; }
          }
      }
      $cardId = 'barb-body-' . $b['id'];
    ?>
    <div class="barb-card"
      style="<?= $temAlerta ? 'border-color:rgba(245,158,11,.45)' : '' ?>">

      <div class="barb-card-header" onclick="toggleBarb('<?= $cardId ?>', this)">
        <?php if($fotoUrl): ?>
          <img src="<?= $fotoUrl ?>" alt="" class="barb-avatar">
        <?php else: ?>
          <div class="barb-avatar-ph"><i class="bi bi-person-fill text-white fs-5"></i></div>
        <?php endif; ?>

        <div class="flex-grow-1">
          <div class="barb-info-nome"><?= htmlspecialchars($b['nome']) ?></div>
          <div class="barb-badges">
            <?php if($qtdTotal === 0): ?>
              <span class="badge-fila badge-vazia">Fila vazia</span>
            <?php else: ?>
              <?php if($qtdAtend > 0): ?>
                <span class="badge-fila badge-atend">
                  <i class="bi bi-scissors me-1"></i><?= $qtdAtend ?> atendendo
                </span>
              <?php endif; ?>
              <?php if($qtdAguard > 0): ?>
                <span class="badge-fila badge-aguard">
                  <i class="bi bi-hourglass-split me-1"></i><?= $qtdAguard ?> aguardando
                </span>
              <?php endif; ?>
              <small style="color:rgba(255,255,255,.35);font-size:.72rem">
                ~<?= $qtdAguard * $tempoMedio ?> min
              </small>
            <?php endif; ?>
            <?php if($temAlerta): ?>
              <span style="background:rgba(245,158,11,.2);color:#fbbf24;
                border-radius:6px;padding:.2rem .6rem;font-size:.73rem;font-weight:700">
                <i class="bi bi-exclamation-triangle-fill me-1"></i>Espera longa
              </span>
            <?php endif; ?>
          </div>
        </div>

        <div class="d-flex align-items-center gap-2">
          <?php if($qtdTotal > 0): ?>
          <form method="POST" class="d-inline" onclick="event.stopPropagation()">
            <input type="hidden" name="acao" value="limpar_fila">
            <input type="hidden" name="barbeiro_id" value="<?= $b['id'] ?>">
            <button type="submit" class="btn-limpar-fila"
              onclick="return confirm('Limpar toda a fila de <?= htmlspecialchars($b['nome'], ENT_QUOTES) ?>?')"
              title="Limpar fila">
              <i class="bi bi-trash3"></i>
            </button>
          </form>
          <?php endif; ?>
          <i class="bi bi-chevron-down chevron" id="chv-<?= $b['id'] ?>"></i>
        </div>
      </div>

      <div class="barb-body <?= $temAlerta ? 'open' : '' ?>" id="<?= $cardId ?>">
        <div class="pt-3">
          <?php if(empty($clientes)): ?>
            <div class="fila-vazia">
              <i class="bi bi-check2-circle" style="font-size:2rem;display:block;margin-bottom:.4rem"></i>
              Fila vazia
            </div>
          <?php endif; ?>

          <?php foreach($clientes as $i => $c):
            $atd = $c['status'] === 'atendendo';
            $tsBase  = $atd ? ($c['iniciado_em'] ?? $c['criado_em']) : $c['criado_em'];
            $minutos = $tsBase ? (int)floor((time() - strtotime($tsBase)) / 60) : 0;
            $isAlerta = !$atd && $minutos >= $alertaMinutos;
          ?>
          <div class="cliente-card <?= $atd ? 'atendendo' : ($isAlerta ? 'alerta' : '') ?>">
            <div class="d-flex align-items-start gap-2">
              <div class="pos-badge <?= $atd ? 'atd' : ($isAlerta ? 'alerta' : '') ?>">
                <?php if($atd): ?>
                  <i class="bi bi-scissors" style="font-size:.7rem"></i>
                <?php elseif($isAlerta): ?>
                  <i class="bi bi-exclamation" style="font-size:.85rem"></i>
                <?php else: ?>
                  <?= $i + 1 ?>
                <?php endif; ?>
              </div>

              <div class="flex-grow-1 min-width-0">
                <div class="d-flex justify-content-between align-items-start gap-1 flex-wrap">
                  <div>
                    <div style="font-weight:700;color:#fff;font-size:.92rem">
                      <?= htmlspecialchars($c['cliente_nome']) ?>
                    </div>
                    <div style="font-size:.78rem;color:rgba(255,255,255,.45)">
                      <?= htmlspecialchars($c['telefone']) ?>
                    </div>
                  </div>
                  <?php if($tsBase): ?>
                  <span class="cronometro <?= $atd ? 'atendendo' : ($isAlerta ? 'alerta' : 'esperando') ?>"
                        data-ts="<?= strtotime($tsBase) ?>"
                        data-mode="<?= $atd ? 'atd' : 'esp' ?>">
                    <i class="bi bi-<?= $atd ? 'scissors' : ($isAlerta ? 'exclamation-triangle' : 'clock') ?>"></i>
                    <span class="crono-txt">...</span>
                  </span>
                  <?php endif; ?>
                </div>

                <?php if($c['servico_nome']): ?>
                <div class="mt-1">
                  <span style="background:rgba(59,130,246,.15);color:#60a5fa;
                    border-radius:6px;padding:.2rem .55rem;font-size:.75rem">
                    <i class="bi bi-scissors me-1"></i>
                    <?= htmlspecialchars($c['servico_nome']) ?> – <?= formatMoney($c['servico_preco']) ?>
                  </span>
                </div>
                <?php endif; ?>

                <?php if($isAlerta): ?>
                <div class="mt-1" style="font-size:.73rem;color:#fbbf24;display:flex;align-items:center;gap:.3rem">
                  <i class="bi bi-exclamation-triangle-fill"></i>
                  Aguardando há <?= $minutos ?> min
                </div>
                <?php endif; ?>

                <?php if(!$atd): ?>
                <!-- ── Botões: aguardando ── -->
                <div class="d-flex gap-1 mt-2 flex-wrap">
                  <form method="POST" class="d-inline">
                    <input type="hidden" name="acao" value="iniciar">
                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                    <button type="submit" class="btn-ac btn-iniciar">
                      <i class="bi bi-play-fill"></i>Iniciar
                    </button>
                  </form>
                  <button type="button" class="btn-ac btn-mover"
                    onclick="abrirModalMover(<?= $c['id'] ?>, '<?= htmlspecialchars($c['cliente_nome'], ENT_QUOTES) ?>', <?= $b['id'] ?>)">
                    <i class="bi bi-arrow-left-right"></i>Mover
                  </button>
                  <form method="POST" class="d-inline">
                    <input type="hidden" name="acao" value="cancelar">
                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                    <button type="submit" class="btn-ac btn-cancelar"
                      onclick="return confirm('Remover <?= htmlspecialchars($c['cliente_nome'], ENT_QUOTES) ?> da fila?')">
                      <i class="bi bi-x-lg"></i>Remover
                    </button>
                  </form>
                </div>

                <?php else: ?>
                <!-- ── Botões: em atendimento ── -->
                <div class="mt-2">
                  <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.5rem;flex-wrap:wrap">
                    <span style="background:rgba(34,197,94,.15);color:#4ade80;
                      border-radius:6px;padding:.2rem .6rem;font-size:.75rem">
                      <i class="bi bi-scissors me-1"></i>Em atendimento
                    </span>
                    <?php if($c['iniciado_em']): ?>
                    <small style="color:rgba(255,255,255,.3);font-size:.72rem">
                      desde <?= date('H:i', strtotime($c['iniciado_em'])) ?>
                    </small>
                    <?php endif; ?>
                  </div>

                  <!-- Form finalizar (oculto por padrão) -->
                  <div class="form-finalizar" id="formDiv_<?= $c['id'] ?>" style="display:none">
                    <form method="POST" id="formFin_<?= $c['id'] ?>">
                      <input type="hidden" name="acao" value="finalizar">
                      <input type="hidden" name="id" value="<?= $c['id'] ?>">
                      <div class="mb-2">
                        <label style="font-size:.78rem;color:rgba(255,255,255,.6);display:block;margin-bottom:.3rem">
                          Valor cobrado (R$)
                        </label>
                        <input type="text" name="valor" class="form-control-dark mascara-valor"
                          placeholder="0,00"
                          value="<?= $c['servico_preco'] ? number_format($c['servico_preco'],2,',','.') : '' ?>">
                      </div>
                      <div class="mb-1">
                        <label style="font-size:.78rem;color:rgba(255,255,255,.6);display:block;margin-bottom:.3rem">
                          Pagamento
                        </label>
                        <div class="d-flex gap-1 flex-wrap">
                          <?php foreach(['pix'=>'PIX','dinheiro'=>'Dinheiro','debito'=>'Débito','credito'=>'Crédito'] as $v=>$l): ?>
                          <label class="pgto-opt">
                            <input type="radio" name="forma_pagamento"
                              value="<?= $v ?>" form="formFin_<?= $c['id'] ?>">
                            <?= $l ?>
                          </label>
                          <?php endforeach; ?>
                        </div>
                      </div>
                      <button type="submit" class="btn-conf-finalizar">
                        <i class="bi bi-check-lg me-1"></i>Confirmar Finalização
                      </button>
                    </form>
                  </div>

                  <!-- ── Botões Finalizar + Remover ── -->
                  <div class="d-flex gap-1 mt-1 flex-wrap">
                    <button type="button" class="btn-ac btn-finalizar"
                      onclick="toggleFinalizar(<?= $c['id'] ?>)">
                      <i class="bi bi-check2-square"></i>Finalizar Atendimento
                    </button>
                    <form method="POST" class="d-inline">
                      <input type="hidden" name="acao" value="cancelar">
                      <input type="hidden" name="id" value="<?= $c['id'] ?>">
                      <button type="submit" class="btn-ac btn-cancelar"
                        onclick="return confirm('Remover <?= htmlspecialchars($c['cliente_nome'], ENT_QUOTES) ?> da fila? O atendimento em andamento será cancelado.')">
                        <i class="bi bi-x-lg"></i>Remover
                      </button>
                    </form>
                  </div>
                </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>

    <?php if(empty($barbeiros)): ?>
    <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);
      border-radius:16px;padding:3rem;text-align:center;color:rgba(255,255,255,.3)">
      <i class="bi bi-people fs-1 d-block mb-2"></i>
      Nenhum barbeiro ativo cadastrado
    </div>
    <?php endif; ?>

  </div>
</div>

<!-- Modal Mover -->
<div class="modal fade" id="modalMover" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          <i class="bi bi-arrow-left-right me-2" style="color:#60a5fa"></i>Mover Cliente
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <input type="hidden" name="acao" value="mover">
        <input type="hidden" name="id" id="moverFilaId" value="">
        <div class="modal-body">
          <p style="color:rgba(255,255,255,.7);font-size:.9rem;margin-bottom:1rem">
            Mover <strong id="moverClienteNome" style="color:#fff"></strong> para:
          </p>
          <label class="form-lbl" style="color:rgba(255,255,255,.7);font-size:.83rem;display:block;margin-bottom:.35rem">
            Novo barbeiro
          </label>
          <select name="novo_barbeiro_id" class="form-select-dark" id="selectNovoBarbeiro">
            <?php foreach($todosBarbeiros as $tb): ?>
            <option value="<?= $tb['id'] ?>"><?= htmlspecialchars($tb['nome']) ?></option>
            <?php endforeach; ?>
          </select>
          <small style="color:rgba(255,255,255,.35);font-size:.75rem;margin-top:.4rem;display:block">
            O cliente será adicionado ao final da fila.
          </small>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-sm"
            style="background:linear-gradient(135deg,#3b82f6,#1d4ed8);color:#fff;border:none;border-radius:8px;padding:.4rem 1.2rem;font-weight:600">
            <i class="bi bi-arrow-left-right me-1"></i>Mover
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded',function(){
  var sb=document.getElementById('sidebar'),bd=document.getElementById('sidebarBackdrop'),btn=document.getElementById('btnMenuMobile');
  function open(){sb&&sb.classList.add('open');bd&&bd.classList.add('open')}
  function close(){sb&&sb.classList.remove('open');bd&&bd.classList.remove('open')}
  btn&&btn.addEventListener('click',open);
  bd&&bd.addEventListener('click',close);
});

// ── Relógio ──
function atualizarRelogio() {
  const el = document.getElementById('relogio');
  if (el) el.textContent = new Date().toLocaleTimeString('pt-BR',
    {hour:'2-digit', minute:'2-digit', second:'2-digit'});
}
atualizarRelogio();
setInterval(atualizarRelogio, 1000);

// ── Autocomplete ──
const inputNome  = document.getElementById('inputNome');
const inputTel   = document.getElementById('inputTel');
const lista      = document.getElementById('listaAuto');
const telAutoTag = document.getElementById('telAutoTag');
let debounceTimer, indiceAtivo = -1;

function inicialLetra(nome) {
  return nome ? nome.trim().charAt(0).toUpperCase() : '?';
}

function renderLista(itens, query) {
  lista.innerHTML = '';
  indiceAtivo = -1;

  if (itens.length === 0 && query.length < 2) {
    lista.classList.remove('aberta');
    return;
  }

  const novo = document.createElement('div');
  novo.className = 'autocomplete-novo';
  novo.innerHTML = `<i class="bi bi-person-plus" style="color:#e94560"></i>
    Adicionar "<strong>${query}</strong>" como novo cliente
    <span class="badge-novo ms-auto">Novo</span>`;
  novo.addEventListener('mousedown', () => {
    inputNome.value = query;
    inputTel.value  = '';
    telAutoTag.style.display = 'none';
    lista.classList.remove('aberta');
  });
  lista.appendChild(novo);

  itens.forEach((item, idx) => {
    const div = document.createElement('div');
    div.className = 'autocomplete-item';
    div.dataset.idx = idx;

    const visitas = parseInt(item.total_visitas) || 0;
    const telFmt  = item.telefone
      ? item.telefone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3')
      : 'Sem telefone';

    div.innerHTML = `
      <div class="autocomplete-avatar">${inicialLetra(item.nome)}</div>
      <div style="min-width:0">
        <div class="autocomplete-nome">${item.nome}</div>
        <div class="autocomplete-tel">${telFmt}</div>
      </div>
      ${visitas > 0
        ? `<div class="autocomplete-visitas"><i class="bi bi-scissors me-1"></i>${visitas}x</div>`
        : ''}
    `;

    div.addEventListener('mousedown', () => selecionarCliente(item));
    lista.appendChild(div);
  });

  lista.classList.add('aberta');
}

function selecionarCliente(item) {
  inputNome.value = item.nome;
  if (item.telefone) {
    inputTel.value = item.telefone;
    telAutoTag.style.display = 'inline';
  } else {
    inputTel.value  = '';
    telAutoTag.style.display = 'none';
  }
  lista.classList.remove('aberta');
  indiceAtivo = -1;
}

function fecharLista() {
  lista.classList.remove('aberta');
  indiceAtivo = -1;
}

inputNome.addEventListener('input', function() {
  const q = this.value.trim();
  telAutoTag.style.display = 'none';
  clearTimeout(debounceTimer);
  if (q.length < 1) { fecharLista(); return; }

  lista.innerHTML = `<div class="autocomplete-loading">
    <div class="spinner-border spinner-border-sm text-danger me-2"></div>Buscando...
  </div>`;
  lista.classList.add('aberta');

  debounceTimer = setTimeout(async () => {
    try {
      const res  = await fetch(`fila.php?buscar_cliente=${encodeURIComponent(q)}`);
      const data = await res.json();
      renderLista(data, q);
    } catch(e) { fecharLista(); }
  }, 280);
});

inputNome.addEventListener('keydown', function(e) {
  const itens = lista.querySelectorAll('.autocomplete-item');
  if (!lista.classList.contains('aberta') || itens.length === 0) return;
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    indiceAtivo = Math.min(indiceAtivo + 1, itens.length - 1);
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    indiceAtivo = Math.max(indiceAtivo - 1, 0);
  } else if (e.key === 'Enter' && indiceAtivo >= 0) {
    e.preventDefault();
    itens[indiceAtivo].dispatchEvent(new Event('mousedown'));
    return;
  } else if (e.key === 'Escape') {
    fecharLista(); return;
  }
  itens.forEach((el, i) => el.classList.toggle('ativo', i === indiceAtivo));
  if (indiceAtivo >= 0) itens[indiceAtivo].scrollIntoView({block:'nearest'});
});

inputNome.addEventListener('blur', () => setTimeout(fecharLista, 150));
inputTel.addEventListener('input', () => { telAutoTag.style.display = 'none'; });

// ── Expandir/colapsar card barbeiro ──
function toggleBarb(bodyId, header) {
  const body = document.getElementById(bodyId);
  if (!body) return;
  const barbId = bodyId.replace('barb-body-', '');
  const chv    = document.getElementById('chv-' + barbId);
  body.classList.toggle('open');
  chv?.classList.toggle('open');
}

document.querySelectorAll('.barb-body.open').forEach(body => {
  const barbId = body.id.replace('barb-body-', '');
  document.getElementById('chv-' + barbId)?.classList.add('open');
});

// ── Cronômetros ──
function formatarTempo(seg) {
  if (seg < 60) return `${seg}s`;
  const m = Math.floor(seg / 60), s = seg % 60;
  if (m < 60) return `${m}min${s > 0 ? ' '+s+'s' : ''}`;
  const h = Math.floor(m / 60), rm = m % 60;
  return `${h}h ${rm}min`;
}
function atualizarCronometros() {
  document.querySelectorAll('.cronometro[data-ts]').forEach(el => {
    const diff = Math.max(0, Math.floor(Date.now()/1000) - parseInt(el.dataset.ts));
    el.querySelector('.crono-txt').textContent = formatarTempo(diff);
    if (el.dataset.mode === 'esp' && diff >= <?= $alertaMinutos * 60 ?>) {
      el.className = 'cronometro alerta';
      el.querySelector('i').className = 'bi bi-exclamation-triangle';
    }
  });
}
atualizarCronometros();
setInterval(atualizarCronometros, 1000);

// ── Toggle finalizar ──
function toggleFinalizar(id) {
  const div = document.getElementById('formDiv_' + id);
  if (div) div.style.display = div.style.display === 'none' ? 'block' : 'none';
}

// ── Modal mover ──
function abrirModalMover(filaId, clienteNome, barbActualId) {
  document.getElementById('moverFilaId').value = filaId;
  document.getElementById('moverClienteNome').textContent = clienteNome;
  const sel = document.getElementById('selectNovoBarbeiro');
  Array.from(sel.options).forEach(opt => {
    opt.disabled = (parseInt(opt.value) === barbActualId);
  });
  for (let opt of sel.options) {
    if (!opt.disabled) { opt.selected = true; break; }
  }
  new bootstrap.Modal(document.getElementById('modalMover')).show();
}

// ── Pagamento visual ──
document.querySelectorAll('.pgto-opt input').forEach(r => {
  r.addEventListener('change', function() {
    this.closest('.d-flex')?.querySelectorAll('.pgto-opt').forEach(b => b.classList.remove('sel'));
    this.closest('.pgto-opt')?.classList.add('sel');
  });
});

// ── Máscara valor ──
document.querySelectorAll('.mascara-valor').forEach(inp => {
  inp.addEventListener('input', function() {
    let v = this.value.replace(/\D/g, '');
    v = (parseInt(v || 0) / 100).toFixed(2).replace('.', ',');
    this.value = v;
  });
});

// ── Auto-refresh inteligente ──
const RELOAD_DELAY = 60000;
let reloadTimer;

const camposPreservar  = ['cliente_nome', 'cliente_fone'];
const selectsPreservar = ['barbeiro_id', 'servico_id'];

camposPreservar.forEach(name => {
  const el  = document.querySelector(`[name="${name}"]`);
  const val = sessionStorage.getItem('add_' + name);
  if (el && val) {
    el.value = val;
    if (name === 'cliente_fone' && val)
      telAutoTag.style.display = 'inline';
  }
});
selectsPreservar.forEach(name => {
  const el  = document.querySelector(`#formAddCliente [name="${name}"]`);
  const val = sessionStorage.getItem('add_' + name);
  if (el && val) el.value = val;
});

camposPreservar.forEach(name => {
  const el = document.querySelector(`[name="${name}"]`);
  if (el) el.addEventListener('input', () =>
    sessionStorage.setItem('add_' + name, el.value));
});
selectsPreservar.forEach(name => {
  const el = document.querySelector(`#formAddCliente [name="${name}"]`);
  if (el) el.addEventListener('change', () =>
    sessionStorage.setItem('add_' + name, el.value));
});

document.getElementById('formAddCliente').addEventListener('submit', () => {
  [...camposPreservar, ...selectsPreservar].forEach(name =>
    sessionStorage.removeItem('add_' + name));
});

function resetarTimer() {
  clearTimeout(reloadTimer);
  reloadTimer = setTimeout(() => location.reload(), RELOAD_DELAY);
}

inputNome.addEventListener('input', resetarTimer);
inputTel.addEventListener('input', resetarTimer);
document.querySelector('#formAddCliente [name="barbeiro_id"]')
  ?.addEventListener('change', resetarTimer);

resetarTimer();
</script>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('<?= BASE_URL ?>/sw.php')
      .then(reg => console.log('SW registrado:', reg.scope))
      .catch(err => console.log('SW erro:', err));
  });
}
</script>
</body>
</html>