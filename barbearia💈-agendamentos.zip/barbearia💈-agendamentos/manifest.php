{
    "name": "Barbearia Barba Negra",
    "short_name": "Barba Negra",
    "description": "Sistema de fila online – Barbearia Barba Negra",
    "start_url": "/legal/",
    "display": "standalone",
    "background_color": "#ffffff",
    "theme_color": "#000000",
    "orientation": "portrait-primary",
    "icons": [
        {
            "src": "/legal/icons/icon-72.png?v=1773342062",
            "sizes": "72x72",
            "type": "image/png",
            "purpose": "any"
        },
        {
            "src": "/legal/icons/icon-96.png?v=1773342062",
            "sizes": "96x96",
            "type": "image/png",
            "purpose": "any"
        },
        {
            "src": "/legal/icons/icon-128.png?v=1773342062",
            "sizes": "128x128",
            "type": "image/png",
            "purpose": "any"
        },
        {
            "src": "/legal/icons/icon-144.png?v=1773342062",
            "sizes": "144x144",
            "type": "image/png",
            "purpose": "any"
        },
        {
            "src": "/legal/icons/icon-152.png?v=1773342062",
            "sizes": "152x152",
            "type": "image/png",
            "purpose": "any"
        },
        {
            "src": "/legal/icons/icon-192.png?v=1773342062",
            "sizes": "192x192",
            "type": "image/png",
            "purpose": "any maskable"
        },
        {
            "src": "/legal/icons/icon-384.png?v=1773342062",
            "sizes": "384x384",
            "type": "image/png",
            "purpose": "any maskable"
        },
        {
            "src": "/legal/icons/icon-512.png?v=1773342062",
            "sizes": "512x512",
            "type": "image/png",
            "purpose": "any maskable"
        }
    ]
}