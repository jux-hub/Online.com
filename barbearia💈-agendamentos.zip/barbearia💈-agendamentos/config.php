<?php
session_start();
require_once __DIR__ . '/database.php';

// ── Timezone — usa configuração do banco, padrão America/Sao_Paulo ──
// Roda antes de qualquer date() para garantir hora correta
function applyTimezone() {
    try {
        $db  = getDB();
        $row = $db->query("SELECT valor FROM configuracoes WHERE chave='fuso_horario'")->fetch();
        $tz  = ($row && $row['valor']) ? $row['valor'] : 'America/Sao_Paulo';
    } catch (Exception $e) {
        $tz = 'America/Sao_Paulo';
    }
    date_default_timezone_set($tz);
}
applyTimezone();

// ── BASE_URL dinâmica — funciona em qualquer subpasta ──
if (!defined('BASE_URL')) {
    $scriptDir  = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    $configDir  = str_replace('\\', '/', __DIR__);
    $docRoot    = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);

    // Caminho relativo do config.php em relação ao document root
    $baseUrl = rtrim(str_replace($docRoot, '', $configDir), '/');

    // Se config.php estiver numa subpasta (admin/, barbeiro/, etc),
    // sobe um nível para chegar na raiz do projeto
    // Detecta se __DIR__ termina em subpasta conhecida do projeto
    $subpastas = ['admin','barbeiro','assistente','cliente','api','whatsapp'];
    $partes    = explode('/', trim($baseUrl, '/'));
    if (in_array(end($partes), $subpastas)) {
        array_pop($partes);
        $baseUrl = '/' . implode('/', $partes);
    }

    define('BASE_URL', rtrim($baseUrl, '/'));
}

function isLoggedIn()   { return isset($_SESSION['usuario_id']); }
function isAdmin()      { return isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'admin'; }
function isBarbeiro()   { return isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'barbeiro'; }
function isAssistente() { return isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'assistente'; }

function requireLogin() {
    if (!isLoggedIn()) { header('Location: ' . BASE_URL . '/login.php'); exit; }
}
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) { header('Location: ' . BASE_URL . '/barbeiro/dashboard.php'); exit; }
}
function requireBarbeiro() {
    requireLogin();
    if (!isBarbeiro() && !isAdmin()) { header('Location: ' . BASE_URL . '/login.php'); exit; }
}
function requireAssistente() {
    requireLogin();
    if (!isAssistente() && !isAdmin()) { header('Location: ' . BASE_URL . '/login.php'); exit; }
}

function getConfig($chave) {
    $db   = getDB();
    $stmt = $db->prepare('SELECT valor FROM configuracoes WHERE chave=?');
    $stmt->execute([$chave]);
    $row = $stmt->fetch();
    return $row ? $row['valor'] : null;
}
function setConfig($chave, $valor) {
    $db = getDB();
    $db->prepare('INSERT OR REPLACE INTO configuracoes (chave,valor) VALUES (?,?)')
       ->execute([$chave, $valor]);
}
function formatMoney($value) {
    return 'R$ ' . number_format((float)$value, 2, ',', '.');
}
function flash($tipo, $msg) {
    $_SESSION['flash'] = ['tipo' => $tipo, 'msg' => $msg];
}
function getFlash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}
function renderFlash() {
    $f = getFlash();
    if (!$f) return '';
    $cls = match($f['tipo']) {
        'success' => 'success',
        'danger'  => 'danger',
        'warning' => 'warning',
        default   => 'info'
    };
    return "<div class='alert alert-{$cls} alert-dismissible fade show' role='alert'>
                {$f['msg']}
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            </div>";
}

// ══════════════════════════════════════════════════════════
//  MIGRATIONS EXTRAS — rodam toda vez, falham silenciosamente
// ══════════════════════════════════════════════════════════
function runExtraMigrations() {
    $db = getDB();

    // ── fila: motivo_remocao + novos status ──
    try { $db->exec("ALTER TABLE fila ADD COLUMN motivo_remocao TEXT"); } catch(Exception $e) {}

    try {
        $tblInfo = $db->query("SELECT sql FROM sqlite_master WHERE type='table' AND name='fila'")->fetch();
        $sql = $tblInfo['sql'] ?? '';
        if (strpos($sql, "'faltou'") === false) {
            $db->exec("PRAGMA foreign_keys=OFF");
            $db->exec("BEGIN");
            $db->exec("
                CREATE TABLE IF NOT EXISTS fila_new (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome            TEXT,
                    telefone        TEXT,
                    cliente_id      INTEGER,
                    barbeiro_id     INTEGER NOT NULL,
                    servico_id      INTEGER,
                    status          TEXT    NOT NULL DEFAULT 'aguardando'
                                        CHECK(status IN ('aguardando','atendendo','concluido',
                                                         'cancelado','faltou','desistiu')),
                    posicao         INTEGER,
                    valor           REAL,
                    forma_pagamento TEXT    CHECK(forma_pagamento IN ('pix','dinheiro','debito','credito')),
                    observacoes     TEXT,
                    notificado      INTEGER DEFAULT 0,
                    avaliacao_nota  INTEGER DEFAULT NULL,
                    avaliacao_obs   TEXT    DEFAULT NULL,
                    motivo_remocao  TEXT,
                    token           TEXT,
                    criado_em       DATETIME DEFAULT CURRENT_TIMESTAMP,
                    iniciado_em     DATETIME,
                    finalizado_em   DATETIME,
                    FOREIGN KEY(cliente_id)  REFERENCES clientes(id),
                    FOREIGN KEY(barbeiro_id) REFERENCES usuarios(id),
                    FOREIGN KEY(servico_id)  REFERENCES servicos(id)
                )
            ");
            $db->exec("INSERT INTO fila_new SELECT
                id, nome, telefone, cliente_id, barbeiro_id, servico_id,
                CASE WHEN status IN ('aguardando','atendendo','concluido','cancelado')
                     THEN status ELSE 'cancelado' END,
                posicao, valor, forma_pagamento, observacoes, notificado,
                avaliacao_nota, avaliacao_obs,
                NULL, NULL,
                criado_em, iniciado_em, finalizado_em
            FROM fila");
            $db->exec("DROP TABLE fila");
            $db->exec("ALTER TABLE fila_new RENAME TO fila");
            $db->exec("COMMIT");
            $db->exec("PRAGMA foreign_keys=ON");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_barbeiro_status ON fila(barbeiro_id, status)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_status          ON fila(status)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_cliente         ON fila(cliente_id)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_criado          ON fila(criado_em)");
        }
    } catch(Exception $e) {
        try { $db->exec("ROLLBACK"); } catch(Exception $e2) {}
    }

    // ── fila_itens ──
    try {
        $db->exec("
            CREATE TABLE IF NOT EXISTS fila_itens (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                fila_id     INTEGER NOT NULL,
                produto_id  INTEGER,
                nome        TEXT    NOT NULL,
                preco       REAL    DEFAULT 0,
                qty         INTEGER DEFAULT 1,
                criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (fila_id)    REFERENCES fila(id),
                FOREIGN KEY (produto_id) REFERENCES produtos(id)
            )
        ");
    } catch(Exception $e) {}
    try { $db->exec("ALTER TABLE fila_itens ADD COLUMN qty INTEGER DEFAULT 1"); } catch(Exception $e) {}
    try { $db->exec("CREATE INDEX IF NOT EXISTS idx_fila_itens_fila ON fila_itens(fila_id)"); } catch(Exception $e) {}

    // ── produtos: garantir coluna tipo ──
    try { $db->exec("ALTER TABLE produtos ADD COLUMN tipo TEXT NOT NULL DEFAULT 'produto'"); } catch(Exception $e) {}
}

runExtraMigrations();