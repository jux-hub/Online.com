<?php
// whatsapp/config.php

if (!defined('NOME_BARBEARIA')) define('NOME_BARBEARIA', 'Barbearia');

function enviarWhatsApp(string $telefone, string $mensagem): bool {
    $provider = getConfig('wa_provider') ?? 'callmebot';

    $tel = preg_replace('/\D/', '', $telefone);
    if (strlen($tel) <= 11) $tel = '55' . $tel;

    $logDir = __DIR__ . '/../logs/';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $logFile = $logDir . 'whatsapp_debug.log';

    switch ($provider) {

        case 'callmebot':
            $apikey = getConfig('wa_callmebot_apikey') ?? '';
            $url = 'https://api.callmebot.com/whatsapp.php?' . http_build_query([
                'phone'  => $tel,
                'text'   => $mensagem,
                'apikey' => $apikey,
            ]);
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_USERAGENT      => 'Mozilla/5.0',
            ]);
            $resp = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $erro = curl_error($ch);
            curl_close($ch);
            file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                . "Provider : {$provider}\n"
                . "Telefone : {$tel}\n"
                . "API Key  : {$apikey}\n"
                . "URL      : {$url}\n"
                . "HTTP Code: {$code}\n"
                . "cURL Erro: {$erro}\n"
                . "Resposta : {$resp}\n"
                . str_repeat('-', 60) . "\n\n",
                FILE_APPEND
            );
            return $code === 200 && stripos($resp, 'Message queued') !== false;

        case 'zapi':
            $instance    = getConfig('wa_zapi_instance')     ?? '';
            $token       = getConfig('wa_zapi_token')        ?? '';
            $clientToken = getConfig('wa_zapi_client_token') ?? '';

            if (!$instance || !$token || !$clientToken || !$tel) {
                file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                    . "Provider     : zapi\n"
                    . "ERRO         : Instância, token ou client-token não configurados\n"
                    . "Instance     : {$instance}\n"
                    . "Token        : {$token}\n"
                    . "Client-Token : {$clientToken}\n"
                    . "Telefone     : {$tel}\n"
                    . str_repeat('-', 60) . "\n\n",
                    FILE_APPEND
                );
                return false;
            }

            $url  = "https://api.z-api.io/instances/{$instance}/token/{$token}/send-text";
            $body = json_encode([
                'phone'   => $tel,
                'message' => $mensagem,
            ]);

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $body,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    "Client-Token: {$clientToken}",
                ],
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_SSL_VERIFYPEER => false,
            ]);
            $resp = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $erro = curl_error($ch);
            curl_close($ch);

            $sucesso = $code >= 200 && $code < 300;

            file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                . "Provider     : zapi\n"
                . "Telefone     : {$tel}\n"
                . "Instance     : {$instance}\n"
                . "URL          : {$url}\n"
                . "HTTP Code    : {$code}\n"
                . "cURL Erro    : {$erro}\n"
                . "Resposta     : {$resp}\n"
                . "Sucesso      : " . ($sucesso ? 'SIM' : 'NÃO') . "\n"
                . str_repeat('-', 60) . "\n\n",
                FILE_APPEND
            );
            return $sucesso;

        case 'uazapi':
            $uazapiUrl      = rtrim(getConfig('wa_uazapi_url')      ?? '', '/');
            $uazapiToken    = getConfig('wa_uazapi_token')           ?? '';
            $uazapiInstance = getConfig('wa_uazapi_instance')        ?? '';

            if (!$uazapiUrl || !$uazapiToken || !$uazapiInstance || !$tel) {
                file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                    . "Provider : uazapi\n"
                    . "ERRO     : URL, token ou instância não configurados\n"
                    . "URL      : {$uazapiUrl}\n"
                    . "Token    : {$uazapiToken}\n"
                    . "Instance : {$uazapiInstance}\n"
                    . "Telefone : {$tel}\n"
                    . str_repeat('-', 60) . "\n\n",
                    FILE_APPEND
                );
                return false;
            }

            $url  = "{$uazapiUrl}/message/sendText/{$uazapiInstance}";
            $body = json_encode([
                'number'  => $tel,
                'text'    => $mensagem,
            ]);

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $body,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    "token: {$uazapiToken}",
                ],
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_SSL_VERIFYPEER => false,
            ]);
            $resp = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $erro = curl_error($ch);
            curl_close($ch);

            $sucesso = $code >= 200 && $code < 300;

            file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                . "Provider : uazapi\n"
                . "Telefone : {$tel}\n"
                . "URL      : {$url}\n"
                . "HTTP Code: {$code}\n"
                . "cURL Erro: {$erro}\n"
                . "Resposta : {$resp}\n"
                . "Sucesso  : " . ($sucesso ? 'SIM' : 'NÃO') . "\n"
                . str_repeat('-', 60) . "\n\n",
                FILE_APPEND
            );
            return $sucesso;

        case 'evolution':
            $baseUrl  = rtrim(getConfig('wa_evolution_url')      ?? '', '/');
            $apiKey   = getConfig('wa_evolution_key')            ?? '';
            $instance = getConfig('wa_evolution_instance')       ?? '';

            if (!$baseUrl || !$apiKey || !$instance || !$tel) {
                file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                    . "Provider : evolution\n"
                    . "ERRO     : URL, API Key ou instância não configurados\n"
                    . str_repeat('-', 60) . "\n\n",
                    FILE_APPEND
                );
                return false;
            }

            $url  = "{$baseUrl}/message/sendText/{$instance}";
            $body = json_encode([
                'number'      => $tel,
                'options'     => ['delay' => 1200, 'presence' => 'composing'],
                'textMessage' => ['text' => $mensagem],
            ]);

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $body,
                CURLOPT_HTTPHEADER     => [
                    'Content-Type: application/json',
                    "apikey: {$apiKey}",
                ],
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_SSL_VERIFYPEER => false,
            ]);
            $resp = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $erro = curl_error($ch);
            curl_close($ch);

            file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                . "Provider : evolution\n"
                . "Telefone : {$tel}\n"
                . "URL      : {$url}\n"
                . "HTTP Code: {$code}\n"
                . "cURL Erro: {$erro}\n"
                . "Resposta : {$resp}\n"
                . str_repeat('-', 60) . "\n\n",
                FILE_APPEND
            );
            return in_array($code, [200, 201]);

        default:
            file_put_contents($logFile, date('[Y-m-d H:i:s]') . "\n"
                . "ERRO: Provider desconhecido: {$provider}\n"
                . str_repeat('-', 60) . "\n\n",
                FILE_APPEND
            );
            return false;
    }
}

function montarMensagemEntrada(string $nomeCliente, string $nomeBarbeiro, int $posicao, int $tempoMin): string {
    $barbearia = defined('NOME_BARBEARIA') ? NOME_BARBEARIA : getConfig('nome_barbearia');
    return "✂️ *{$barbearia}*\n\n"
         . "Olá, *{$nomeCliente}*! Você entrou na fila.\n\n"
         . "💈 Barbeiro: *{$nomeBarbeiro}*\n"
         . "🔢 Posição: *{$posicao}º na fila*\n"
         . "⏱️ Tempo estimado: *~{$tempoMin} minutos*\n\n"
         . "Avisaremos quando for quase sua vez! 👍";
}

function montarMensagemAviso(string $nomeCliente, int $posicao): string {
    $barbearia = defined('NOME_BARBEARIA') ? NOME_BARBEARIA : getConfig('nome_barbearia');
    $msg = "⚠️ *{$barbearia}* – Atenção!\n\n"
         . "Olá, *{$nomeCliente}*!\n";
    if ($posicao === 0) {
        $msg .= "🔔 *É A SUA VEZ!* Dirija-se à cadeira agora! ✂️";
    } else {
        $msg .= "🔔 Faltam apenas *{$posicao} pessoa(s)* na sua frente!\nSe prepare! ✂️";
    }
    return $msg;
}

function montarMensagemConclusao(string $nomeCliente, float $valor, string $pgto): string {
    $barbearia = defined('NOME_BARBEARIA') ? NOME_BARBEARIA : getConfig('nome_barbearia');
    return "✅ *{$barbearia}*\n\n"
         . "Atendimento concluído!\n"
         . "Obrigado, *{$nomeCliente}*! 🙏\n\n"
         . "💰 Valor: *R$ " . number_format($valor, 2, ',', '.') . "*\n"
         . "💳 Pagamento: *" . ucfirst($pgto) . "*\n\n"
         . "Volte sempre! ✂️😊";
}