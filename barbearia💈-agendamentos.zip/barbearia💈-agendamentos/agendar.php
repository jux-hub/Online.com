<?php
/**
 * agendar.php — Página pública de agendamento
 * Não requer login. Cliente informa nome + telefone + serviço + data + hora.
 */
require_once 'config.php';
require_once __DIR__ . '/whatsapp/config.php';
$db = getDB();

$nomeBarbearia = getConfig('nome_barbearia')   ?: 'Barbearia';
$logoBarbearia = getConfig('logo_barbearia')   ?: '';
$corCapa       = getConfig('cor_primaria')     ?: '#e94560';
$antecMax      = (int)(getConfig('agenda_max_dias') ?: 30);
$antecMin      = (int)(getConfig('agenda_antecedencia_min') ?: 60);

// ── Verificar se agendamento está ativo ──
$agendaAtivo  = getConfig('agenda_ativo')    ?? '0';
$agendaMotivo = getConfig('agenda_motivo')   ?? '';
$agendaWpp    = getConfig('agenda_whatsapp') ?? '';
if ($agendaAtivo !== '1') {
    ?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agendamento Indisponível – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--primary:#e94560}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0;min-height:100vh;
  display:flex;flex-direction:column;align-items:center;justify-content:center;padding:1.5rem;text-align:center}
.card-off{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);
  border-radius:20px;padding:2.5rem 2rem;max-width:400px;width:100%}
.icon-wrap{width:80px;height:80px;border-radius:50%;
  background:rgba(233,69,96,.1);border:2px solid rgba(233,69,96,.25);
  display:flex;align-items:center;justify-content:center;
  font-size:2.2rem;color:#e94560;margin:0 auto 1.25rem}
h2{color:#fff;font-size:1.3rem;font-weight:800;margin:0 0 .5rem}
.sub{color:rgba(255,255,255,.4);font-size:.88rem;margin:0 0 1.25rem;line-height:1.5}
.motivo-box{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
  border-radius:12px;padding:.85rem 1rem;margin-bottom:1.25rem;
  color:rgba(255,255,255,.7);font-size:.88rem;line-height:1.5;text-align:left}
.motivo-label{font-size:.7rem;color:rgba(255,255,255,.35);font-weight:700;
  text-transform:uppercase;letter-spacing:.8px;margin-bottom:.35rem}
.btn-wpp{display:inline-flex;align-items:center;gap:.5rem;
  background:linear-gradient(135deg,#25d366,#1da851);border:none;
  color:#fff;border-radius:50px;padding:.65rem 1.5rem;font-size:.92rem;
  font-weight:800;text-decoration:none;transition:.2s;margin-bottom:.65rem;width:100%;justify-content:center}
.btn-wpp:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(37,211,102,.35);color:#fff}
.btn-home{display:inline-flex;align-items:center;gap:.5rem;
  background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
  color:rgba(255,255,255,.7);border-radius:50px;padding:.55rem 1.4rem;font-size:.85rem;
  font-weight:700;text-decoration:none;transition:.2s;width:100%;justify-content:center}
.btn-home:hover{background:rgba(255,255,255,.13);color:#fff}
.barbearia-name{font-size:.75rem;color:rgba(255,255,255,.2);margin-top:1.5rem}
</style>
</head>
<body>
<div class="card-off">
  <div class="icon-wrap"><i class="bi bi-calendar-x"></i></div>
  <h2>Agendamento Indisponível</h2>
  <p class="sub">
    A <strong style="color:#fff"><?= htmlspecialchars($nomeBarbearia) ?></strong><br>
    não está aceitando agendamentos online no momento.
  </p>

  <?php if ($agendaMotivo): ?>
  <div class="motivo-box">
    <div class="motivo-label"><i class="bi bi-info-circle me-1"></i>Motivo</div>
    <?= nl2br(htmlspecialchars($agendaMotivo)) ?>
  </div>
  <?php endif; ?>

  <?php if ($agendaWpp): ?>
  <?php $wppLink = 'https://wa.me/55' . preg_replace('/\D/','',$agendaWpp) . '?text=' . urlencode('Olá! Vi que o agendamento online está indisponível. Gostaria de agendar um horário.') ?>
  <a href="<?= $wppLink ?>" target="_blank" class="btn-wpp">
    <i class="bi bi-whatsapp"></i>Falar no WhatsApp
  </a>
  <?php endif; ?>

  <a href="<?= BASE_URL ?>/" class="btn-home">
    <i class="bi bi-house-fill"></i>Voltar ao início
  </a>
  <div class="barbearia-name"><?= htmlspecialchars($nomeBarbearia) ?></div>
</div>
</body>
</html>
<?php
    exit;
}

// ── Criar tabela de agendamentos ──
$db->exec("
    CREATE TABLE IF NOT EXISTS agendamentos (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente_nome  TEXT NOT NULL,
        cliente_tel   TEXT NOT NULL,
        cliente_id    INTEGER,
        barbeiro_id   INTEGER,
        servico_id    INTEGER,
        data_hora     DATETIME NOT NULL,
        duracao_min   INTEGER DEFAULT 30,
        status        TEXT DEFAULT 'pendente' CHECK(status IN ('pendente','confirmado','concluido','cancelado','faltou')),
        observacao    TEXT,
        token         TEXT UNIQUE,
        lembrete_env  INTEGER DEFAULT 0,
        criado_em     DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
$db->exec("
    CREATE TABLE IF NOT EXISTS agenda_slots_manuais (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        dia_semana     INTEGER,
        dia_especifico TEXT,
        hora           TEXT NOT NULL
    )
");

// ── Adicionar coluna duracao_min em servicos se não existir ──
try { $db->exec("ALTER TABLE servicos ADD COLUMN duracao_min INTEGER DEFAULT 30"); } catch(Exception $e) {}

// ── POST: salvar agendamento ──
$erro   = '';
$sucesso = false;
$agendamentoFeito = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome      = trim($_POST['nome']       ?? '');
    $tel       = trim($_POST['telefone']   ?? '');
    $servicoId = (int)($_POST['servico_id'] ?? 0);
    $barId     = (int)($_POST['barbeiro_id'] ?? 0) ?: null;
    $dataHora  = trim($_POST['data_hora']  ?? '');
    $obs       = trim($_POST['observacao'] ?? '');

    if (!$nome || !$tel || !$servicoId || !$dataHora) {
        $erro = 'Preencha todos os campos obrigatórios.';
    } elseif (strtotime($dataHora) < time() + ($antecMin * 60)) {
        $erro = "O agendamento deve ser feito com pelo menos {$antecMin} minutos de antecedência.";
    } else {
        // Verificar conflito
        $conflito = $db->prepare("
            SELECT id FROM agendamentos
            WHERE barbeiro_id = ? AND status NOT IN ('cancelado','faltou')
              AND ABS(strftime('%s',data_hora) - strftime('%s',?)) < duracao_min * 60
        ");
        $conflito->execute([$barId, $dataHora]);

        if ($conflito->fetch()) {
            $erro = 'Este horário não está mais disponível. Por favor, escolha outro.';
        } else {
            // Duração do serviço
            $svcStmt = $db->prepare("SELECT duracao_min FROM servicos WHERE id=?");
            $svcStmt->execute([$servicoId]);
            $svcRow  = $svcStmt->fetch();
            $duracao = $svcRow['duracao_min'] ?: (int)(getConfig('agenda_intervalo') ?: 30);

            // Associar cliente cadastrado se existir
            $cliStmt = $db->prepare("SELECT id FROM clientes WHERE telefone=?");
            $cliStmt->execute([preg_replace('/\D/','',$tel)]);
            $cliRow  = $cliStmt->fetch();
            $cliId   = $cliRow['id'] ?? null;

            // Token único para cancelamento
            $token = bin2hex(random_bytes(12));

            $db->prepare("
                INSERT INTO agendamentos (cliente_nome, cliente_tel, cliente_id, barbeiro_id, servico_id,
                    data_hora, duracao_min, observacao, token)
                VALUES (?,?,?,?,?,?,?,?,?)
            ")->execute([$nome, preg_replace('/\D/','',$tel), $cliId, $barId, $servicoId,
                         $dataHora, $duracao, $obs, $token]);

            $agId = $db->lastInsertId();

            // Buscar dados para confirmação
            $agendamentoFeito = $db->prepare("
                SELECT ag.*, s.nome AS servico_nome, s.preco AS servico_preco,
                       b.nome AS barbeiro_nome
                FROM agendamentos ag
                LEFT JOIN servicos s ON s.id = ag.servico_id
                LEFT JOIN usuarios b ON b.id = ag.barbeiro_id
                WHERE ag.id = ?
            ");
            $agendamentoFeito->execute([$agId]);
            $agendamentoFeito = $agendamentoFeito->fetch();

            // Enviar confirmação por WhatsApp
            $linkCancel = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
                        . '://' . $_SERVER['HTTP_HOST'] . BASE_URL
                        . '/agendar.php?cancelar=' . $token;

            $msgWa = "Olá, {$nome}! ✅\n\nSeu agendamento foi confirmado na *{$nomeBarbearia}*!\n\n"
                   . "📅 " . date('d/m/Y', strtotime($dataHora)) . " às " . date('H:i', strtotime($dataHora)) . "\n"
                   . "✂️ " . ($agendamentoFeito['servico_nome'] ?? '') . "\n"
                   . ($barId ? "💈 " . ($agendamentoFeito['barbeiro_nome'] ?? '') . "\n" : '')
                   . "\nPara cancelar: {$linkCancel}";

            enviarWhatsApp(preg_replace('/\D/','',$tel), $msgWa);
            $sucesso = true;
        }
    }
}

// ── Cancelamento via token ──
$cancelMsg = '';
if (isset($_GET['cancelar'])) {
    $token = trim($_GET['cancelar']);
    $ag = $db->prepare("SELECT * FROM agendamentos WHERE token=? AND status NOT IN ('cancelado','concluido','faltou')");
    $ag->execute([$token]);
    $agRow = $ag->fetch();
    if ($agRow) {
        if (strtotime($agRow['data_hora']) > time()) {
            $db->prepare("UPDATE agendamentos SET status='cancelado' WHERE token=?")->execute([$token]);
            $cancelMsg = 'Agendamento cancelado com sucesso.';
        } else {
            $cancelMsg = 'Este agendamento já passou ou não pode mais ser cancelado.';
        }
    } else {
        $cancelMsg = 'Token inválido ou agendamento já cancelado.';
    }
}

// ── Dados para o formulário ──
$servicos   = $db->query("SELECT id, nome, preco, duracao_min FROM servicos WHERE ativo=1 ORDER BY nome")->fetchAll();
$barbeiros  = $db->query("SELECT id, nome, NULL as cor FROM usuarios WHERE tipo='barbeiro' AND ativo=1 ORDER BY nome")->fetchAll();
$dataMin    = date('Y-m-d', strtotime('+' . ceil($antecMin/60) . ' hour'));
$dataMax    = date('Y-m-d', strtotime("+{$antecMax} days"));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agendar – <?= htmlspecialchars($nomeBarbearia) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--primary:<?= htmlspecialchars($corCapa) ?>;--wa:#25d366}
*{box-sizing:border-box}
body{background:#0f0f23;color:#e0e0e0;font-family:'Segoe UI',sans-serif;margin:0;min-height:100vh}

.hero{background:linear-gradient(135deg,#1a1a2e,#16213e);padding:2rem 1rem 1.5rem;text-align:center;
  border-bottom:1px solid rgba(255,255,255,.08)}
.hero-logo{width:72px;height:72px;border-radius:18px;object-fit:cover;margin-bottom:.75rem}
.hero-icon{width:72px;height:72px;border-radius:18px;background:linear-gradient(135deg,var(--primary),#c41230);
  display:inline-flex;align-items:center;justify-content:center;font-size:2rem;margin-bottom:.75rem}
.hero h1{font-size:1.5rem;font-weight:800;color:#fff;margin:0 0 .25rem}
.hero p{color:rgba(255,255,255,.5);font-size:.9rem;margin:0}

.container-form{max-width:520px;margin:0 auto;padding:1.5rem 1rem}

.step{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);
  border-radius:16px;padding:1.25rem;margin-bottom:1rem}
.step-header{display:flex;align-items:center;gap:.65rem;margin-bottom:1rem}
.step-num{width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#c41230);
  color:#fff;font-weight:800;font-size:.82rem;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.step-title{font-weight:700;color:#fff;font-size:.95rem}

.form-group{margin-bottom:.85rem}
.form-group label{display:block;font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;margin-bottom:.3rem}
.form-control-dark{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);
  color:#fff;border-radius:10px;padding:.65rem 1rem;width:100%;font-size:.9rem;transition:.2s}
.form-control-dark:focus{outline:none;border-color:var(--primary);
  background:rgba(233,69,96,.07);box-shadow:0 0 0 3px rgba(233,69,96,.15)}
.form-control-dark::placeholder{color:rgba(255,255,255,.3)}
select.form-control-dark option{background:#1a1a2e;color:#fff}

/* Serviços */
.servico-card{background:rgba(255,255,255,.05);border:2px solid rgba(255,255,255,.08);
  border-radius:12px;padding:.85rem;cursor:pointer;transition:all .2s;display:flex;align-items:center;gap:.75rem}
.servico-card:hover{border-color:rgba(233,69,96,.3);background:rgba(233,69,96,.05)}
.servico-card.selected{border-color:var(--primary);background:rgba(233,69,96,.1)}
.servico-card input[type=radio]{display:none}

/* Barbeiros */
.bar-card{background:rgba(255,255,255,.05);border:2px solid rgba(255,255,255,.08);
  border-radius:12px;padding:.75rem;cursor:pointer;transition:all .2s;text-align:center}
.bar-card:hover{border-color:rgba(255,255,255,.2)}
.bar-card.selected{border-color:var(--primary);background:rgba(233,69,96,.1)}
.bar-card input[type=radio]{display:none}
.bar-avatar{width:44px;height:44px;border-radius:50%;margin:0 auto .4rem;
  display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1rem}

/* Slots */
.slot-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
  color:rgba(255,255,255,.7);border-radius:8px;padding:.45rem .8rem;
  font-size:.85rem;font-weight:600;cursor:pointer;transition:all .2s}
.slot-btn:hover{background:rgba(233,69,96,.12);border-color:rgba(233,69,96,.3);color:#fff}
.slot-btn.selected{background:linear-gradient(135deg,var(--primary),#c41230);border-color:transparent;color:#fff}
.slot-btn:disabled{opacity:.3;cursor:not-allowed}

.btn-agendar{background:linear-gradient(135deg,var(--primary),#c41230);border:none;color:#fff;
  width:100%;border-radius:14px;padding:1rem;font-weight:800;font-size:1.05rem;
  cursor:pointer;transition:all .3s;margin-top:.5rem}
.btn-agendar:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(233,69,96,.4)}
.btn-agendar:disabled{opacity:.5;pointer-events:none;transform:none}

/* Confirmação */
.confirm-box{background:rgba(34,197,94,.07);border:2px solid rgba(34,197,94,.3);
  border-radius:18px;padding:2rem;text-align:center;max-width:420px;margin:2rem auto}

/* Nav bar */
.nav-public{
  background:rgba(10,10,30,.85);
  backdrop-filter:blur(12px);
  -webkit-backdrop-filter:blur(12px);
  border-bottom:1px solid rgba(255,255,255,.08);
  padding:.6rem 1.1rem;
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:100;gap:.5rem
}
.nav-btn{
  display:inline-flex;align-items:center;gap:.35rem;
  padding:.38rem .75rem;border-radius:20px;font-size:.8rem;font-weight:700;
  text-decoration:none;border:1px solid transparent;transition:.2s;white-space:nowrap;cursor:pointer
}
.nav-btn-ghost{
  background:rgba(255,255,255,.07);
  border-color:rgba(255,255,255,.12);
  color:rgba(255,255,255,.75)
}
.nav-btn-ghost:hover{background:rgba(255,255,255,.13);color:#fff}
.nav-btn-admin{
  background:rgba(233,69,96,.1);
  border-color:rgba(233,69,96,.25);
  color:#e94560
}
.nav-btn-admin:hover{background:rgba(233,69,96,.2);color:#ff6b85}
.nav-title-wrap{display:flex;flex-direction:column;align-items:center;gap:0;flex:1;text-align:center}
.nav-title-badge{
  background:linear-gradient(135deg,var(--primary),#c41230);
  color:#fff;font-size:.6rem;font-weight:800;letter-spacing:1.5px;
  text-transform:uppercase;padding:.15rem .55rem;border-radius:20px;margin-bottom:.15rem;
  display:inline-block
}
.nav-title-name{color:#fff;font-size:.88rem;font-weight:800;line-height:1}

/* Hero */
.hero{
  background:linear-gradient(160deg,#1a1a2e 0%,#16213e 60%,#0f3460 100%);
  padding:2.2rem 1rem 1.75rem;text-align:center;
  border-bottom:1px solid rgba(255,255,255,.07);
  position:relative;overflow:hidden
}
.hero::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse at 50% 0%,rgba(233,69,96,.18) 0%,transparent 70%);
  pointer-events:none
}
.hero-content{position:relative;z-index:1}
.hero-badge{
  display:inline-flex;align-items:center;gap:.4rem;
  background:rgba(233,69,96,.15);border:1px solid rgba(233,69,96,.3);
  border-radius:50px;padding:.3rem .9rem;
  font-size:.72rem;font-weight:700;color:#e94560;letter-spacing:.5px;
  text-transform:uppercase;margin-bottom:.85rem
}
.hero-logo{width:76px;height:76px;border-radius:20px;object-fit:cover;margin-bottom:.85rem;
  box-shadow:0 8px 24px rgba(0,0,0,.4)}
.hero-icon{width:76px;height:76px;border-radius:20px;
  background:linear-gradient(135deg,var(--primary),#c41230);
  display:inline-flex;align-items:center;justify-content:center;
  font-size:2.1rem;margin-bottom:.85rem;
  box-shadow:0 8px 24px rgba(233,69,96,.35)}
.hero h1{font-size:1.6rem;font-weight:900;color:#fff;margin:0 0 .3rem;letter-spacing:-.5px}
.hero p{color:rgba(255,255,255,.45);font-size:.88rem;margin:0}
</style>
</head>
<body>

<!-- Nav -->
<nav class="nav-public">
  <a href="<?= BASE_URL ?>/" class="nav-btn nav-btn-ghost">
    <i class="bi bi-arrow-left"></i>
    <span class="d-none d-sm-inline">Início</span>
  </a>

  <div class="nav-title-wrap">
    <span class="nav-title-badge"><i class="bi bi-calendar3 me-1"></i>Agendamento Online</span>
    <span class="nav-title-name"><?= htmlspecialchars($nomeBarbearia) ?></span>
  </div>

  <?php if (isset($_SESSION['tipo']) && in_array($_SESSION['tipo'],['admin','assistente'])): ?>
  <a href="<?= BASE_URL ?>/admin/agendamentos.php" class="nav-btn nav-btn-admin">
    <i class="bi bi-gear-fill"></i>
    <span class="d-none d-sm-inline">Admin</span>
  </a>
  <?php else: ?>
  <a href="<?= BASE_URL ?>/login.php" class="nav-btn nav-btn-admin">
    <i class="bi bi-shield-lock"></i>
    <span class="d-none d-sm-inline">Admin</span>
  </a>
  <?php endif; ?>
</nav>

<!-- Hero -->
<div class="hero">
  <div class="hero-content">
    <div class="hero-badge">
      <i class="bi bi-scissors"></i>Reserve seu horário
    </div>
    <?php if ($logoBarbearia && file_exists(__DIR__ . '/' . $logoBarbearia)): ?>
    <img src="<?= BASE_URL . '/' . htmlspecialchars($logoBarbearia) ?>" class="hero-logo" alt="">
    <?php else: ?>
    <div class="hero-icon"><i class="bi bi-scissors text-white"></i></div>
    <?php endif; ?>
    <h1><?= htmlspecialchars($nomeBarbearia) ?></h1>
    <p>Escolha o serviço, profissional e horário — rápido e sem filas</p>
  </div>
</div>

<div class="container-form">

<?php if ($cancelMsg): ?>
<div style="background:rgba(<?= str_contains($cancelMsg,'sucesso') ? '34,197,94' : '239,68,68' ?>,.1);
            border:1px solid rgba(<?= str_contains($cancelMsg,'sucesso') ? '34,197,94' : '239,68,68' ?>,.3);
            border-radius:14px;padding:1.25rem;text-align:center;margin-bottom:1.5rem">
  <i class="bi bi-<?= str_contains($cancelMsg,'sucesso') ? 'check-circle-fill' : 'exclamation-triangle-fill' ?> me-2"
     style="color:<?= str_contains($cancelMsg,'sucesso') ? '#4ade80' : '#f87171' ?>"></i>
  <?= htmlspecialchars($cancelMsg) ?>
</div>
<?php endif; ?>

<?php if ($sucesso && $agendamentoFeito): ?>
<!-- Confirmação -->
<div class="confirm-box">
  <div style="font-size:3rem;margin-bottom:.75rem">🎉</div>
  <h4 style="color:#4ade80;margin-bottom:.5rem">Agendamento Confirmado!</h4>
  <p style="color:rgba(255,255,255,.6);font-size:.9rem;margin-bottom:1.25rem">
    Você receberá uma confirmação pelo WhatsApp.
  </p>
  <div style="background:rgba(255,255,255,.05);border-radius:12px;padding:1rem;text-align:left;font-size:.88rem">
    <div style="display:flex;justify-content:space-between;padding:.35rem 0;border-bottom:1px solid rgba(255,255,255,.06)">
      <span style="color:rgba(255,255,255,.45)">📅 Data</span>
      <strong><?= date('d/m/Y', strtotime($agendamentoFeito['data_hora'])) ?></strong>
    </div>
    <div style="display:flex;justify-content:space-between;padding:.35rem 0;border-bottom:1px solid rgba(255,255,255,.06)">
      <span style="color:rgba(255,255,255,.45)">⏰ Horário</span>
      <strong><?= date('H:i', strtotime($agendamentoFeito['data_hora'])) ?></strong>
    </div>
    <div style="display:flex;justify-content:space-between;padding:.35rem 0;border-bottom:1px solid rgba(255,255,255,.06)">
      <span style="color:rgba(255,255,255,.45)">✂️ Serviço</span>
      <strong><?= htmlspecialchars($agendamentoFeito['servico_nome']) ?></strong>
    </div>
    <?php if ($agendamentoFeito['barbeiro_nome']): ?>
    <div style="display:flex;justify-content:space-between;padding:.35rem 0">
      <span style="color:rgba(255,255,255,.45)">💈 Barbeiro</span>
      <strong><?= htmlspecialchars($agendamentoFeito['barbeiro_nome']) ?></strong>
    </div>
    <?php endif; ?>
  </div>
  <a href="<?= BASE_URL ?>/agendar.php"
     style="display:block;margin-top:1rem;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
            color:rgba(255,255,255,.7);border-radius:10px;padding:.65rem;text-decoration:none;font-size:.88rem">
    <i class="bi bi-plus-circle me-1"></i>Fazer outro agendamento
  </a>
</div>

<?php else: ?>

<?php if ($erro): ?>
<div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:12px;
            padding:.85rem 1rem;margin-bottom:1rem;color:#f87171;font-size:.88rem">
  <i class="bi bi-exclamation-triangle me-1"></i><?= htmlspecialchars($erro) ?>
</div>
<?php endif; ?>

<form method="POST" id="formAgendar">
  <input type="hidden" name="data_hora" id="inputDataHora">
  <input type="hidden" name="servico_id" id="inputServicoId">
  <input type="hidden" name="barbeiro_id" id="inputBarId">

  <!-- Passo 1: Seus dados -->
  <div class="step">
    <div class="step-header">
      <div class="step-num">1</div>
      <div class="step-title">Seus dados</div>
    </div>
    <div class="form-group">
      <label>Nome completo *</label>
      <input type="text" name="nome" class="form-control-dark" placeholder="Ex: João Silva"
             value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
    </div>
    <div class="form-group" style="margin-bottom:0">
      <label>WhatsApp *</label>
      <input type="tel" name="telefone" class="form-control-dark" placeholder="(11) 99999-9999"
             value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>" required
             oninput="this.value=this.value.replace(/\D/g,'').replace(/^(\d{2})(\d)/,'($1) $2').replace(/(\d{5})(\d)/,'$1-$2').substring(0,15)">
    </div>
  </div>

  <!-- Passo 2: Serviço -->
  <div class="step">
    <div class="step-header">
      <div class="step-num">2</div>
      <div class="step-title">Escolha o serviço</div>
    </div>
    <div style="display:flex;flex-direction:column;gap:.5rem">
    <?php foreach ($servicos as $s): ?>
    <label class="servico-card" id="svc_<?= $s['id'] ?>" onclick="selecionarServico(<?= $s['id'] ?>, <?= (int)($s['duracao_min'] ?: 30) ?>)">
      <input type="radio" name="_servico" value="<?= $s['id'] ?>">
      <div style="flex:1">
        <div style="font-weight:700;color:#fff;font-size:.92rem"><?= htmlspecialchars($s['nome']) ?></div>
        <?php if ($s['duracao_min']): ?>
        <div style="font-size:.75rem;color:rgba(255,255,255,.4)"><i class="bi bi-clock me-1"></i><?= $s['duracao_min'] ?> min</div>
        <?php endif; ?>
      </div>
      <div style="font-weight:800;color:var(--primary);font-size:.95rem;flex-shrink:0">
        R$ <?= number_format($s['preco'],2,',','.') ?>
      </div>
    </label>
    <?php endforeach; ?>
    </div>
  </div>

  <!-- Passo 3: Barbeiro (opcional) -->
  <div class="step">
    <div class="step-header">
      <div class="step-num">3</div>
      <div class="step-title">Barbeiro <span style="color:rgba(255,255,255,.35);font-size:.8rem;font-weight:400">(opcional)</span></div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(90px,1fr));gap:.5rem">
      <label class="bar-card selected" id="bar_0" onclick="selecionarBar(0)">
        <input type="radio" name="_barbeiro" value="0" checked>
        <div class="bar-avatar" style="background:rgba(255,255,255,.1);color:rgba(255,255,255,.5)">
          <i class="bi bi-shuffle"></i>
        </div>
        <div style="font-size:.72rem;color:rgba(255,255,255,.5);font-weight:600">Qualquer</div>
      </label>
      <?php foreach ($barbeiros as $b): $cor = htmlspecialchars($b['cor'] ?? '#e94560'); ?>
      <label class="bar-card" id="bar_<?= $b['id'] ?>" onclick="selecionarBar(<?= $b['id'] ?>)">
        <input type="radio" name="_barbeiro" value="<?= $b['id'] ?>">
        <div class="bar-avatar" style="background:<?= $cor ?>22;color:<?= $cor ?>">
          <?= mb_strtoupper(mb_substr($b['nome'],0,1)) ?>
        </div>
        <div style="font-size:.72rem;color:#fff;font-weight:600"><?= htmlspecialchars(explode(' ',$b['nome'])[0]) ?></div>
      </label>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Passo 4: Data e horário -->
  <div class="step">
    <div class="step-header">
      <div class="step-num">4</div>
      <div class="step-title">Data e horário</div>
    </div>

    <div class="form-group">
      <label>Data</label>
      <input type="date" id="inputData" class="form-control-dark"
             min="<?= $dataMin ?>" max="<?= $dataMax ?>"
             onchange="carregarSlots()">
    </div>

    <div id="slotsWrap" style="display:none">
      <label style="font-size:.8rem;color:rgba(255,255,255,.5);font-weight:600;display:block;margin-bottom:.5rem">
        Horário disponível
      </label>
      <div id="slotsLoading" style="display:none;text-align:center;padding:.75rem;color:rgba(255,255,255,.3);font-size:.85rem">
        <span class="spinner-border spinner-border-sm me-1"></span> Verificando horários…
      </div>
      <div id="slotsGrid" style="display:flex;flex-wrap:wrap;gap:.4rem"></div>
      <div id="slotsVazio" style="display:none;text-align:center;padding:1rem;color:rgba(255,255,255,.3);font-size:.85rem">
        <i class="bi bi-calendar-x" style="font-size:1.5rem;display:block;margin-bottom:.3rem"></i>
        Nenhum horário disponível nesta data
      </div>
    </div>
  </div>

  <!-- Observação -->
  <div class="step" style="padding:.85rem 1.25rem">
    <div class="form-group" style="margin:0">
      <label><i class="bi bi-chat-left-text me-1"></i>Observação <span style="color:rgba(255,255,255,.3)">(opcional)</span></label>
      <textarea name="observacao" class="form-control-dark" rows="2"
                placeholder="Ex: cabelo + barba, trazer foto de referência…"><?= htmlspecialchars($_POST['observacao'] ?? '') ?></textarea>
    </div>
  </div>

  <button type="submit" class="btn-agendar" id="btnAgendar" disabled>
    <i class="bi bi-calendar-check me-2"></i>Confirmar Agendamento
  </button>
</form>

<?php endif; ?>

<div style="text-align:center;margin-top:1.5rem;padding-bottom:2.5rem">
  <a href="<?= BASE_URL ?>/" class="nav-btn nav-btn-ghost" style="border-radius:50px;padding:.5rem 1.25rem;font-size:.82rem">
    <i class="bi bi-house-fill"></i>Voltar ao início
  </a>
</div>
</div><!-- /container-form -->

<script>
const BASE_URL    = '<?= BASE_URL ?>';
let servicoAtual  = 0;
let duracaoAtual  = 30;
let barAtual      = 0;
let horarioAtual  = '';

function selecionarServico(id, dur) {
  document.querySelectorAll('.servico-card').forEach(c => c.classList.remove('selected'));
  document.getElementById('svc_' + id)?.classList.add('selected');
  servicoAtual = id;
  duracaoAtual = dur;
  document.getElementById('inputServicoId').value = id;
  // Recarregar slots se já tiver data
  const data = document.getElementById('inputData').value;
  if (data) carregarSlots();
  verificarPronto();
}

function selecionarBar(id) {
  document.querySelectorAll('.bar-card').forEach(c => c.classList.remove('selected'));
  document.getElementById('bar_' + id)?.classList.add('selected');
  barAtual = id;
  document.getElementById('inputBarId').value = id || '';
  // Recarregar slots
  const data = document.getElementById('inputData').value;
  if (data) carregarSlots();
}

function carregarSlots() {
  const data = document.getElementById('inputData').value;
  if (!data) return;

  document.getElementById('slotsWrap').style.display    = 'block';
  document.getElementById('slotsLoading').style.display = 'block';
  document.getElementById('slotsGrid').innerHTML        = '';
  document.getElementById('slotsVazio').style.display   = 'none';
  horarioAtual = '';
  document.getElementById('inputDataHora').value = '';
  verificarPronto();

  const url = `${BASE_URL}/api/slots.php?data=${data}&barbeiro_id=${barAtual}&servico_id=${servicoAtual}`;
  fetch(url)
    .then(r => r.json())
    .then(d => {
      document.getElementById('slotsLoading').style.display = 'none';
      if (!d.slots || d.slots.length === 0) {
        document.getElementById('slotsVazio').style.display = 'block';
        return;
      }
      const grid = document.getElementById('slotsGrid');
      d.slots.forEach(s => {
        const btn = document.createElement('button');
        btn.type      = 'button';
        btn.className = 'slot-btn';
        btn.textContent = s.hora;
        if (s.barbeiros_livres > 1) {
          btn.title = s.barbeiros_livres + ' barbeiros disponíveis';
        }
        btn.addEventListener('click', () => {
          document.querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
          btn.classList.add('selected');
          horarioAtual = data + 'T' + s.hora + ':00';
          document.getElementById('inputDataHora').value = data + ' ' + s.hora + ':00';
          verificarPronto();
        });
        grid.appendChild(btn);
      });
    })
    .catch(() => {
      document.getElementById('slotsLoading').style.display = 'none';
      document.getElementById('slotsVazio').style.display   = 'block';
    });
}

function verificarPronto() {
  const nome  = document.querySelector('[name=nome]')?.value?.trim();
  const tel   = document.querySelector('[name=telefone]')?.value?.trim();
  const pronto = nome && tel && servicoAtual && horarioAtual;
  const btn = document.getElementById('btnAgendar');
  btn.disabled = !pronto;
}

// Escutar mudanças nos campos de texto
document.querySelector('[name=nome]')?.addEventListener('input', verificarPronto);
document.querySelector('[name=telefone]')?.addEventListener('input', verificarPronto);

// Definir data mínima como hoje (ou amanhã dependendo da antecedência)
document.getElementById('inputData').value = '<?= $dataMin ?>';
carregarSlots();
</script>
</body>
</html>
